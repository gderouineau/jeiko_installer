# JEIKO — TODO / évolutions

Fonctionnalités à venir. Convention de statut : `[ ]` à faire · `[~]` en cours · `[x]` fait.

---

## [ ] MAJ-1 — Notification quotidienne de mise à jour disponible

**But** : détecter chaque jour si une version de `jeiko` **supérieure** à celle
installée a été publiée, et l'annoncer dans le *quick admin menu* par un lien
« Mise à jour en attente » (ex. « Mise à jour 1 ») qui renvoie vers la page de
mise à jour de l'administration. Le message disparaît une fois la mise à jour
réussie.

### Pourquoi passer par un cron (et pas un check à chaque requête)
Le canal de publication est distant (`version.json` sur
`raw.githubusercontent.com/gderouineau/jeiko`). Interroger le réseau à chaque
chargement de page serait lent et exposé au rate-limiting. On respecte aussi la
frontière de privilèges existante : **l'application ne fait pas d'appel réseau
sortant**. Un job root écrit le résultat dans un fichier d'état (comme
`update.state`), l'app le lit en local, sans coût ni droit particulier.

### Points d'ancrage existants (à réutiliser, ne pas réécrire)
- Version installée : `_jeiko_installed_version()` — `administration/views.py`
  (`importlib.metadata.version("jeiko")`).
- État de mise à jour : `_jeiko_update_state(site)` — lit
  `/var/lib/jeiko/<site>/update.state` (écrit par `jeiko-client-update`, root,
  non falsifiable par le site). Statuts déjà gérés : `idle` / `unknown` / …
- Version publiée : `jeiko_read_manifest` (`lib/jeiko-common.sh`) lit
  `version.json` sur `JEIKO_CHANNEL_URL`
  (défaut `JEIKO_DEFAULT_CHANNEL_URL`) → `JEIKO_PKG_VERSION`.
- Emplacement du badge : `templates/includes/quick_admin_menu.html`.
- Page cible du lien : la vue de mise à jour de l'administration
  (`administration/views.py`, autour de `JEIKO_CLIENT_UPDATER` /
  `_jeiko_update_state`) — reprendre son nom d'URL réel.

### Sous-tâches

- [ ] **Cron/timer côté serveur** (installeur). Ajouter un script d'étape +
  une unité systemd `timer` quotidienne (modèle : `scripts/13_backups.sh` et les
  unités `jeiko-update@`). Le job, en root :
  1. lit la version installée du site,
  2. `jeiko_read_manifest` sur le canal pour la version publiée,
  3. écrit `/var/lib/jeiko/<site>/update.available` (root, groupe du site, `0640`)
     avec `{ "latest": "<x.y.z>", "checked_at": "<iso>" }`.
  Déployé/convergé par `jeiko-server-update` (ajouter une étape), et déposé par
  `migrate_site.sh --tools-only`. Idempotent, échec réseau silencieux (dégrade,
  ne casse pas).

- [ ] **Lecture côté package.** Fonction `_jeiko_update_available(site)` qui lit
  `update.available` façon `_jeiko_update_state` (tolérante aux
  `FileNotFoundError` / `PermissionError`). Exposer au template via context
  processor ou tag, en réutilisant `_jeiko_site_name()`.

- [ ] **Badge dans le quick admin menu.** Dans `quick_admin_menu.html`, si
  `latest` > version installée (comparaison **sémantique**, pas lexicale : « 3.0.10 »
  > « 3.0.9 »), afficher un `<li>` « Mise à jour en attente » (compteur possible)
  pointant vers la page de mise à jour. N'afficher qu'aux comptes ayant le droit
  de lancer la mise à jour.

- [ ] **Disparition automatique.** Le badge est **dérivé** de
  `latest > installée` : après un `jeiko-client-update` réussi, la version
  installée rejoint `latest` → le badge s'efface sans action explicite. Gérer en
  plus l'état transitoire : si `_jeiko_update_state` est « en cours », afficher
  « Mise à jour en cours… » plutôt que le lien.

### Critères d'acceptation
1. Une version publiée supérieure fait apparaître le lien dans les 24 h (ou
   immédiatement après un passage manuel du cron).
2. Le lien mène à la page de mise à jour de l'administration.
3. Après une mise à jour réussie, le message disparaît de lui-même.
4. Aucun appel réseau depuis le processus web ; panne réseau du cron = pas de
   message, jamais d'erreur 500.
5. Le site ne peut pas se déclarer « à jour » en falsifiant un fichier
   (fichier d'état root, lecture seule pour le site).
