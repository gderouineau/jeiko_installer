#!/bin/bash
set -euo pipefail
# La bibliothèque du dossier de l'installeur quand install.sh la désigne : le
# contrôle préalable passe AVANT tout dépôt sur la machine (IG-07).
# shellcheck source=../lib/jeiko-common.sh
source "${JEIKO_COMMON:-/usr/local/lib/jeiko/common.sh}"

jeiko_step "[00] Pré-vol & vérifications"
jeiko_require_root

command -v apt-get >/dev/null 2>&1 || jeiko_die "Système non Debian/Ubuntu (apt-get introuvable)."
pidof systemd >/dev/null 2>&1 || jeiko_die "systemd requis."

DEBIAN_CODENAME="$(grep -oP '(?<=VERSION_CODENAME=).*' /etc/os-release || true)"
ARCH="$(uname -m)"
CPU="$(nproc)"
RAM_MB="$(awk '/MemTotal/ {print int($2/1024)}' /proc/meminfo)"
DISK_FREE_MB="$(df -Pm / | awk 'NR==2{print $4}')"

jeiko_log "ℹ️  Debian ${DEBIAN_CODENAME:-inconnue} | $ARCH | ${CPU} CPU | ${RAM_MB} Mo RAM | ${DISK_FREE_MB} Mo libres sur /"

# --------------------------------------------------------------------------- #
# Version de Debian
#
# L'installeur ne fige aucune version : les paquets sont des méta-paquets
# (postgresql, python3…) et la version du cluster PostgreSQL est détectée à
# l'exécution. Une release non testée a donc toutes les chances de fonctionner
# — on prévient sans bloquer, plutôt que de refuser une machine parfaitement
# capable ou d'obliger à maintenir un installeur par version.
# --------------------------------------------------------------------------- #
JEIKO_TESTED_RELEASES="${JEIKO_TESTED_RELEASES:-bookworm trixie}"

case " $JEIKO_TESTED_RELEASES " in
    *" ${DEBIAN_CODENAME:-inconnue} "*)
        jeiko_ok "Version de Debian testée : $DEBIAN_CODENAME"
        ;;
    *)
        jeiko_warn "Debian « ${DEBIAN_CODENAME:-inconnue} » n'est pas dans les versions testées ($JEIKO_TESTED_RELEASES)."
        jeiko_warn "     L'installation devrait fonctionner : aucune version n'est figée dans les scripts."
        jeiko_warn "     Signale-moi tout écart pour ajouter cette release à la liste."
        ;;
esac

# Un venv + PostgreSQL + les statiques tiennent difficilement sous 2 Go.
if [[ "$DISK_FREE_MB" -lt 2048 ]]; then
    jeiko_die "Moins de 2 Go libres sur / — libère de la place avant d'installer."
fi
if [[ "$RAM_MB" -lt 900 ]]; then
    jeiko_warn "Moins de 1 Go de RAM : le swap créé à l'étape 01 sera indispensable."
fi

if [[ -n "${DOMAIN_NAME:-}" ]]; then
    if getent hosts "$DOMAIN_NAME" >/dev/null 2>&1; then
        jeiko_ok "Résolution DNS OK pour $DOMAIN_NAME"
    else
        jeiko_warn "$DOMAIN_NAME ne résout pas encore."
        # Sans DNS, la validation Let's Encrypt échouera à coup sûr : autant le
        # dire maintenant plutôt qu'à l'étape 12, après 10 minutes d'install.
        if [[ "${ENABLE_SSL:-n}" == "y" ]]; then
            jeiko_die "HTTPS demandé mais le domaine ne résout pas : Let's Encrypt échouera. Attends la propagation DNS ou réponds 'n'."
        fi
    fi
    # Pour un domaine « apex », le certificat couvre aussi www (étape 12) :
    # un www sans DNS fait échouer toute la demande, après l'installation.
    if [[ "${ENABLE_SSL:-n}" == "y" ]] && jeiko_is_apex "$DOMAIN_NAME" \
       && ! getent hosts "www.$DOMAIN_NAME" >/dev/null 2>&1; then
        jeiko_die "HTTPS demandé mais www.$DOMAIN_NAME ne résout pas : le certificat le couvre aussi. Ajoute l'enregistrement DNS ou réponds 'n'."
    fi
    # Résoudre ne suffit pas : chaque adresse publiée doit être CE serveur
    # (voir jeiko_dns_hors_serveur — un AAAA resté sur la page d'attente du
    # registraire fait échouer le certificat).
    NOMS_DNS=("$DOMAIN_NAME")
    jeiko_is_apex "$DOMAIN_NAME" && NOMS_DNS+=("www.$DOMAIN_NAME")
    # Juger la zone telle qu'elle est, pas telle qu'elle était : une zone qu'on
    # vient de corriger restait vue à l'ancienne pendant une heure
    # (separdonner.fr, 27/10/2026). Ne vide que le cache de CETTE machine
    # (systemd-resolved) ; celui du résolveur de l'hébergeur, lui, demeure.
    resolvectl flush-caches >/dev/null 2>&1 || true
    # Un AAAA vers l'IPv6 que l'hébergeur a attribuée à CETTE machine, mais que
    # rien n'a activée (OVH en publie un à chaque nouvelle zone) : on propose de
    # l'activer plutôt que de refuser le domaine (voir jeiko_ipv6_attribuee).
    if ! jeiko_adresses_du_serveur | grep -q ':'; then
        for nom in "${NOMS_DNS[@]}"; do
            for a in $(jeiko_dns_hors_serveur "$nom" | grep ':'); do
                attribuee="$(jeiko_ipv6_attribuee "$a")"
                [[ -n "$attribuee" && "${attribuee%% *}" == "$(jeiko_ipv6_normale "$a")" ]] || continue
                jeiko_log "$(jeiko_t "ℹ️  %s vise l'IPv6 de ce serveur (%s), qui n'est pas encore activée." "$nom" "$a")"
                jeiko_demander REPONSE_IPV6 "$(jeiko_t "▶️  Activer l'IPv6 de ce serveur maintenant ? (o/n) [o] : ")" jeiko_oui_ou_non
                if [[ -z "$REPONSE_IPV6" ]] || jeiko_oui "$REPONSE_IPV6"; then
                    # shellcheck disable=SC2086  # « adresse passerelle » : deux arguments
                    jeiko_activer_ipv6 ${attribuee} && jeiko_ok "IPv6 de ce serveur activée"
                fi
                break 2
            done
        done
    fi
    DNS_AILLEURS=0
    for nom in "${NOMS_DNS[@]}"; do
        ailleurs="$(jeiko_dns_hors_serveur "$nom" | tr '\n' ' ')"
        if [[ -n "${ailleurs// /}" ]]; then
            DNS_AILLEURS=1
            jeiko_warn "$nom pointe aussi ailleurs qu'ici : ${ailleurs% }"
        fi
    done
    if (( DNS_AILLEURS == 1 )); then
        jeiko_warn "     Adresses de ce serveur : $(jeiko_adresses_du_serveur | tr '\n' ' ')"
        jeiko_warn "     Dans la zone DNS : un A vers son IPv4, un AAAA vers son IPv6 (ou aucun AAAA),"
        jeiko_warn "     pour le domaine ET pour www."
        if [[ "${ENABLE_SSL:-n}" == "y" ]]; then
            # Une zone tout juste corrigée : le résolveur de la machine peut
            # rendre l'ANCIENNE réponse jusqu'à la fin de sa durée de vie (une
            # heure chez OVH), alors que Let's Encrypt interroge les serveurs
            # de la zone. Vu sur separdonner.fr, 27/10/2026 : le serveur voyait
            # encore la page d'attente, la zone donnait déjà son IPv6. On
            # demande donc, non par défaut : continuer à tort arrête
            # l'installation à l'étape 12 (certbot), après les dix minutes
            # des étapes précédentes — à relancer une fois le DNS à jour.
            jeiko_log "$(jeiko_t "     Zone tout juste corrigée ? Ce serveur peut voir l'ancienne réponse pendant une heure ; Let's Encrypt, lui, interroge la zone.")"
            jeiko_demander REPONSE_DNS "$(jeiko_t "▶️  Continuer quand même ? (o/n) [n] : ")" jeiko_oui_ou_non
            if ! jeiko_oui "$REPONSE_DNS"; then
                jeiko_die "HTTPS demandé mais le DNS vise un autre serveur : Let's Encrypt échouera. Corrige la zone, attends la propagation, relance."
            fi
            jeiko_warn "Installation poursuivie malgré le DNS : si le certificat échoue, elle s'arrêtera à l'étape 12 — la relancer une fois le DNS à jour."
        fi
    else
        jeiko_ok "Le DNS de ${NOMS_DNS[*]} vise ce serveur"
    fi
fi

for p in 80 443; do
    if ss -lnt "( sport = :$p )" 2>/dev/null | grep -q ":$p"; then
        jeiko_warn "Port $p déjà occupé (probablement Nginx, ce qui est normal en réinstallation)."
    fi
done

# Un site homonyme déjà servi par nginx signale une collision de configuration.
if [[ -e "/etc/nginx/sites-enabled/${SITE_NAME}.conf" ]]; then
    jeiko_warn "Un vhost nginx '${SITE_NAME}.conf' existe déjà, il sera réécrit (une sauvegarde sera faite)."
fi

# Un AUTRE site du serveur sert déjà ce domaine (NGX-3, 09/10/2026) : nginx
# n'en retiendrait qu'un, et le nouveau site répondrait — ou pas — selon
# l'ordre alphabétique des fichiers. On refuse AVANT toute création (base,
# compte, dossiers). Un autre sous-domaine du même domaine n'est pas un
# doublon ; le vhost du site lui-même (réinstallation) non plus.
if [[ -n "${DOMAIN_NAME:-}" ]]; then
    NOMS=("$DOMAIN_NAME")
    jeiko_is_apex "$DOMAIN_NAME" && NOMS+=("www.$DOMAIN_NAME")
    DOUBLONS=""
    for nom in "${NOMS[@]}"; do
        DOUBLONS+="$(jeiko_vhosts_du_nom "$nom" "/etc/nginx/sites-enabled/${SITE_NAME}.conf")"
    done
    if [[ -n "$DOUBLONS" ]]; then
        jeiko_err "« ${NOMS[*]} » est déjà servi par un autre site de ce serveur :"
        sort -u <<<"$DOUBLONS" | while read -r f; do [[ -n "$f" ]] && jeiko_err "     $f"; done
        jeiko_die "Installation refusée : un domaine ne peut être servi que par un seul site. Rien n'a été créé."
    fi
fi

jeiko_ok "Préparation vérifiée."
