#!/bin/bash
set -euo pipefail
# shellcheck source=../lib/jeiko-common.sh
source /usr/local/lib/jeiko/common.sh

jeiko_step "[13] Sauvegardes (base, médias, configuration)"
jeiko_require_root

: "${SITE_NAME:?SITE_NAME manquant}"
: "${PROJECT_DIR:?PROJECT_DIR manquant}"
: "${DB_NAME:?DB_NAME manquant}"

BACKUP_DIR="$JEIKO_BACKUP_DIR/$SITE_NAME"
BACKUP_SCRIPT="/usr/local/sbin/jeiko-backup"
RESTORE_SCRIPT="/usr/local/sbin/jeiko-restore"

install -d -m 0700 -o root -g root "$BACKUP_DIR/daily" "$BACKUP_DIR/pre-update"

# --------------------------------------------------------------------------- #
# Script de sauvegarde — générique, un seul exemplaire pour tous les sites
#
# L'ancienne version générait un script par site avec le mot de passe
# PostgreSQL écrit en clair à l'intérieur. Ici les identifiants sont lus depuis
# la fiche du site (/etc/jeiko/sites/<site>.conf, 0600 root:root) au moment de
# l'exécution : ils n'existent qu'à un seul endroit sur le disque.
# --------------------------------------------------------------------------- #
cat >"$BACKUP_SCRIPT" <<'BACKUP'
#!/bin/bash
# jeiko-backup <site> — sauvegarde base + médias + configuration.
set -euo pipefail
source /usr/local/lib/jeiko/common.sh
jeiko_require_root

SITE="${1:?Usage: jeiko-backup <site>}"
jeiko_load_site "$SITE" || exit 1

RETENTION_DAYS="${JEIKO_BACKUP_RETENTION_DAYS:-30}"
# Une fiche éditée à la main ne doit pas désarmer le ménage : `find -mtime`
# sur une valeur invalide échoue en silence, et les archives s'accumulent.
jeiko_valider_ressource retention "$RETENTION_DAYS" 2>/dev/null || RETENTION_DAYS=30

# Une sauvegarde à la fois par site : le cron et un lancement à la main ne
# doivent pas écrire dans le même dossier à la même seconde.
jeiko_dossier_verrous
exec 8>"$JEIKO_LOCK_DIR/jeiko-backup-$SITE.lock"
flock -n 8 || jeiko_die "Une sauvegarde de « $SITE » est déjà en cours."
# Jamais pendant une mise à jour du MÊME site (IG-07) : le verrou de mise à
# jour du site est pris, en attendant qu'elle finisse — 30 min au plus. Les
# horaires (sauvegardes 02:00–05:00, mise à jour de la semaine 00:15–03:45)
# ne le garantissaient pas. La sauvegarde de contrôle d'une convergence est
# lancée SOUS ce verrou, déjà tenu par son parent : elle le dit.
if [[ "${JEIKO_VERROU_DU_SITE_TENU:-0}" != 1 ]]; then
    exec 7>"$JEIKO_LOCK_DIR/jeiko-update-$SITE.lock"
    flock -w 1800 7 || jeiko_die "Une mise à jour de « $SITE » dure depuis plus de 30 min : sauvegarde reportée."
fi

DEST="$JEIKO_BACKUP_DIR/$SITE/daily/$(date +%Y%m%d_%H%M%S)"
install -d -m 0700 "$DEST"

# Une sauvegarde à moitié écrite est pire qu'aucune : si quoi que ce soit
# échoue AVANT qu'elle soit complète, on efface le répertoire pour ne pas
# laisser croire à une archive valide. Une fois complète, elle reste, même si
# la copie hors site échoue ensuite : perdre la copie locale parce que la
# distante a raté, c'était perdre les deux. Le code de sortie non nul signale
# l'échec dans tous les cas.
LOCALE_OK=0
SEND_DIR=""
fin() {
    local rc=$?
    [[ -n "$SEND_DIR" && "$SEND_DIR" != "$DEST" ]] && rm -rf "$SEND_DIR"
    if [[ $rc -ne 0 && $LOCALE_OK -eq 0 ]]; then
        rm -rf "$DEST"; echo "❌ Sauvegarde $SITE échouée, répertoire supprimé." >&2
    elif [[ $rc -ne 0 ]]; then
        echo "❌ Sauvegarde locale de $SITE conservée ($DEST), copie hors site en échec." >&2
    fi
    exit "$rc"
}
trap fin EXIT

# La place d'abord (IG-07) : la base et les médias tels qu'ils sont, plus un
# cinquième et 200 Mo de marge — compressés, ils prennent moins ; on ne parie
# pas. Un disque rempli arrêterait PostgreSQL, pour tous les sites.
TAILLE_BASE="$(PGPASSWORD="$DB_PASS" psql -h 127.0.0.1 -U "$DB_USER" -d "$DB_NAME" -tAq \
    -c 'SELECT pg_database_size(current_database())' 2>/dev/null || echo 0)"
TAILLE_MEDIAS="$(du -sb "$PROJECT_DIR/mediadir" 2>/dev/null | cut -f1 || echo 0)"
[[ "$TAILLE_BASE" =~ ^[0-9]+$ ]] || TAILLE_BASE=0
[[ "$TAILLE_MEDIAS" =~ ^[0-9]+$ ]] || TAILLE_MEDIAS=0
BESOIN=$(( (TAILLE_BASE + TAILLE_MEDIAS) * 12 / 10 + 200 * 1024 * 1024 ))
if ! jeiko_place_suffisante "$DEST" "$BESOIN"; then
    echo "❌ Place insuffisante dans $JEIKO_BACKUP_DIR : ~$(( BESOIN / 1024 / 1024 )) Mo nécessaires — rien n'est sauvegardé. Libérer de la place, ou réduire la rétention (jeiko-server-update $SITE --retention JOURS)." >&2
    exit 1
fi

# La base PUIS les médias, dans cet ordre : un média déposé entre les deux
# n'est qu'un fichier de plus dans l'archive, jamais une référence de la base
# vers un fichier absent. L'inverse perdrait des images.
PGPASSWORD="$DB_PASS" pg_dump -h 127.0.0.1 -U "$DB_USER" -d "$DB_NAME" \
    --format=custom --compress=6 --file="$DEST/${DB_NAME}.dump"

# pg_restore --list échoue sur une archive tronquée : c'est une vérification
# bon marché qui distingue un dump exploitable d'un fichier de la bonne taille.
pg_restore --list "$DEST/${DB_NAME}.dump" >/dev/null

if [[ -d "$PROJECT_DIR/mediadir" ]]; then
    tar -czf "$DEST/media.tar.gz" -C "$PROJECT_DIR" mediadir
fi

# La fiche et le .env sont obligatoires (sans eux, une base restaurée ne se
# reconnecte pas) ; le vhost l'est s'il existe. Une archive de configuration
# ratée faisait jusqu'ici une sauvegarde « réussie ».
CONFIG=("etc/jeiko/sites/$SITE.conf" "${PROJECT_DIR#/}/$SITE/.env")
[[ -f "/etc/nginx/sites-available/$SITE.conf" ]] && CONFIG+=("etc/nginx/sites-available/$SITE.conf")
tar -czf "$DEST/config.tar.gz" -C / "${CONFIG[@]}"

# Ce qui a produit la base (IG-07) : jeiko-restore refuse de remettre une base
# sous un paquet plus ancien que celui-ci, et la met à niveau sinon.
{
    echo "site=$SITE"
    echo "date=$(date -Is)"
    echo "paquet=$(jeiko_version_du_paquet "$VENV_DIR" "$SITE_USER")"
    echo "installeur=$(jeiko_version_outillage)"
} >"$DEST/MANIFESTE"

chmod -R go= "$DEST"
# Empreintes calculées à côté puis posées : le fichier ne se liste pas lui-même.
( cd "$DEST" && sha256sum -- * >"$DEST.sums" ) && mv -f "$DEST.sums" "$DEST/SHA256SUMS"
LOCALE_OK=1

# ── Copie hors-site ─────────────────────────────────────────────────────────
#
# Sans elle, tout le dispositif protège contre l'intrusion mais rien contre la
# perte : un root compromis, un rançongiciel ou la disparition du VPS emporte
# les sauvegardes avec le site, puisqu'elles sont sur la même machine.
#
# Désactivée tant que JEIKO_OFFSITE_TARGET n'est pas renseignée dans la fiche
# du site. Deux formes acceptées :
#   · rclone   → "rclone:nom-du-remote:chemin"   (chiffrement côté remote)
#   · rsync    → "rsync:user@hote:/chemin"       (par SSH, clé sans phrase)
#
# Le dump est chiffré avant l'envoi si JEIKO_OFFSITE_PASSPHRASE_FILE pointe sur
# un fichier lisible par root seul : ce qui part hors de la machine ne doit pas
# être une base de données en clair.
if [[ -n "${JEIKO_OFFSITE_TARGET:-}" ]]; then
    SEND_DIR="$DEST"

    # Une phrase secrète CONFIGURÉE est une exigence : si elle est illisible,
    # mal protégée, ou si gpg manque, rien ne part — la sauvegarde locale
    # reste, l'échec est signalé. Sans phrase configurée, l'envoi en clair est
    # un choix, dit à chaque fois.
    if [[ -n "${JEIKO_OFFSITE_PASSPHRASE_FILE:-}" ]]; then
        PHRASE="$JEIKO_OFFSITE_PASSPHRASE_FILE"
        [[ -f "$PHRASE" && ! -L "$PHRASE" && -r "$PHRASE" ]] \
            || { echo "❌ Phrase secrète illisible ($PHRASE) : rien n'est envoyé hors site." >&2; exit 1; }
        [[ "$(stat -c '%u %a' "$PHRASE")" =~ ^0\ [0-7]00$ ]] \
            || { echo "❌ $PHRASE doit appartenir à root, en 0600 : rien n'est envoyé hors site." >&2; exit 1; }
        command -v gpg >/dev/null 2>&1 \
            || { echo "❌ gpg absent : rien n'est envoyé hors site (apt install gnupg)." >&2; exit 1; }
        SEND_DIR="$DEST.enc"
        mkdir -p "$SEND_DIR"; chmod 700 "$SEND_DIR"
        for f in "$DEST"/*; do
            [[ -f "$f" ]] || continue
            gpg --batch --yes --quiet --symmetric --cipher-algo AES256 \
                --passphrase-file "$PHRASE" \
                --output "$SEND_DIR/$(basename "$f").gpg" "$f"
        done
        echo "🔐 Archive chiffrée avant envoi."
    else
        echo "⚠️  Pas de passphrase configurée : envoi hors-site en clair." >&2
    fi

    OFFSITE_KIND="${JEIKO_OFFSITE_TARGET%%:*}"
    OFFSITE_DEST="${JEIKO_OFFSITE_TARGET#*:}"
    REMOTE_PATH="$OFFSITE_DEST/$SITE/$(basename "$DEST")"

    case "$OFFSITE_KIND" in
        rclone)
            command -v rclone >/dev/null 2>&1 || { echo "❌ rclone absent." >&2; exit 1; }
            rclone copy --quiet "$SEND_DIR" "$REMOTE_PATH" \
                || { echo "❌ Envoi hors-site (rclone) échoué." >&2; exit 1; }
            ;;
        rsync)
            command -v rsync >/dev/null 2>&1 || { echo "❌ rsync absent." >&2; exit 1; }
            rsync -az --chmod=D700,F600 -e 'ssh -o BatchMode=yes -o StrictHostKeyChecking=accept-new' \
                "$SEND_DIR/" "$REMOTE_PATH/" \
                || { echo "❌ Envoi hors-site (rsync) échoué." >&2; exit 1; }
            ;;
        *)
            echo "❌ JEIKO_OFFSITE_TARGET mal formé : attendu 'rclone:…' ou 'rsync:…'." >&2
            exit 1
            ;;
    esac

    echo "☁️  Copie hors-site : $REMOTE_PATH"
else
    echo "ℹ️  Pas de copie hors-site (JEIKO_OFFSITE_TARGET non renseignée dans la fiche du site)."
fi

# Rotation par ancienneté plutôt que par nombre : garder « les 30 derniers »
# ne dit rien de la fenêtre réellement couverte si le cron a été interrompu.
find "$JEIKO_BACKUP_DIR/$SITE/daily" -maxdepth 1 -type d -name '20*' \
     -mtime "+$RETENTION_DAYS" -exec rm -rf {} + 2>/dev/null || true

echo "✅ Sauvegarde de $SITE : $DEST ($(du -sh "$DEST" | cut -f1))"
BACKUP

chown root:root "$BACKUP_SCRIPT"
chmod 0700 "$BACKUP_SCRIPT"

# --------------------------------------------------------------------------- #
# Script de restauration
#
# Une sauvegarde qu'on ne sait pas restaurer n'est pas une sauvegarde. Ce
# script est le pendant explicite de jeiko-backup, à lancer à la main.
# --------------------------------------------------------------------------- #
cat >"$RESTORE_SCRIPT" <<'RESTORE'
#!/bin/bash
# jeiko-restore <site> <répertoire-de-sauvegarde> — restauration complète.
set -euo pipefail
source /usr/local/lib/jeiko/common.sh
jeiko_require_root

# jeiko-restore <site> <répertoire> [--avec-config] [--force]
#
# Ce qu'elle restaure : la BASE et les MÉDIAS ; avec --avec-config, le .env
# du site aussi (l'ancien est gardé en .env.avant-restauration). La fiche et
# le vhost restent dans config.tar.gz, pour une reprise à la main.
#
# La version du paquet (IG-07, 16/10/2026) : le MANIFESTE de la sauvegarde dit
# quel paquet a produit la base. Plus récent que celui installé : refusé (le
# code ne connaît pas ses tables) — mettre le paquet à jour d'abord, ou
# --force. Plus ancien ou inconnu : restaurée, puis `migrate` la met à niveau.
SITE="${1:?Usage: jeiko-restore <site> <répertoire> [--avec-config] [--force]}"
SRC="${2:?Usage: jeiko-restore <site> <répertoire> [--avec-config] [--force]}"
shift 2
AVEC_CONFIG=0; FORCER=0
while [[ $# -gt 0 ]]; do
    case "$1" in
        --avec-config) AVEC_CONFIG=1; shift ;;
        --force)       FORCER=1; shift ;;
        *) jeiko_die "Option inconnue : $1" ;;
    esac
done
jeiko_load_site "$SITE" || exit 1

[[ -d "$SRC" ]] || jeiko_die "Répertoire de sauvegarde introuvable : $SRC"
DUMP="$(find "$SRC" -maxdepth 1 -name '*.dump' | head -n1)"
[[ -n "$DUMP" ]] || jeiko_die "Aucun dump dans $SRC"

# Tout se vérifie AVANT d'arrêter le site : une archive abîmée ne doit coûter
# aucune interruption.
if [[ -f "$SRC/SHA256SUMS" ]]; then
    ( cd "$SRC" && sha256sum --quiet -c SHA256SUMS ) || jeiko_die "Empreintes incorrectes dans $SRC : archive abîmée, rien n'est touché."
else
    jeiko_warn "Pas de SHA256SUMS dans $SRC : intégrité non vérifiée."
fi
pg_restore --list "$DUMP" >/dev/null || jeiko_die "Dump illisible : $DUMP"
[[ ! -f "$SRC/media.tar.gz" ]] || tar -tzf "$SRC/media.tar.gz" >/dev/null || jeiko_die "Archive des médias illisible."
ENV_ARCHIVE="${PROJECT_DIR#/}/$SITE/.env"
if [[ $AVEC_CONFIG -eq 1 ]]; then
    tar -tzf "$SRC/config.tar.gz" "$ENV_ARCHIVE" >/dev/null 2>&1 \
        || jeiko_die "Pas de .env dans $SRC/config.tar.gz : --avec-config impossible."
    [[ ! -L "$PROJECT_DIR/$SITE/.env" ]] || jeiko_die ".env du site est un lien symbolique : refusé."
fi

V_SAUVEGARDE="$(sed -n 's/^paquet=//p' "$SRC/MANIFESTE" 2>/dev/null | head -n1)"
V_INSTALLEE="$(jeiko_version_du_paquet "$VENV_DIR" "$SITE_USER")"
case "$(jeiko_decision_de_restauration "$V_SAUVEGARDE" "$V_INSTALLEE")" in
    refuser)
        if [[ $FORCER -eq 0 ]]; then
            jeiko_die "Base sauvegardée par le paquet $V_SAUVEGARDE, plus récent que celui installé ($V_INSTALLEE) : le code ne connaît pas ses tables. Mettre d'abord le paquet à jour (sudo jeiko-client-update $SITE), ou --force."
        fi
        jeiko_warn "Base du paquet $V_SAUVEGARDE sous le paquet $V_INSTALLEE : forcé." ;;
    migrer)   jeiko_log "ℹ️  Base du paquet $V_SAUVEGARDE, paquet installé $V_INSTALLEE : migrate la mettra à niveau." ;;
    inconnue) jeiko_warn "Version du paquet de la sauvegarde inconnue (${V_SAUVEGARDE:-pas de MANIFESTE}) : migrate suivra la restauration." ;;
    *) ;;
esac

echo "⚠️  Cette opération ÉCRASE la base '$DB_NAME' et les médias du site '$SITE'."
echo "    Source : $SRC"
read -rp "    Taper le nom du site pour confirmer : " confirm
[[ "$confirm" == "$SITE" ]] || { echo "Annulé."; exit 0; }

# Le site et ses tâches planifiées s'arrêtent (maintenance, comme pendant une
# mise à jour) : rien ne doit écrire dans la base pendant qu'on la remplace.
# Ils repartent quoi qu'il arrive.
relancer() {
    local rc=$?
    jeiko_reprendre_le_site "$GUNICORN_SERVICE" || true
    [[ $rc -eq 0 ]] || jeiko_err "Restauration INTERROMPUE (code $rc) — la base peut être incomplète, à reprendre."
    exit "$rc"
}
trap relancer EXIT
jeiko_suspendre_le_site "$SITE" "$GUNICORN_SERVICE"

# « --clean » ne retire que les objets PRÉSENTS DANS LE DUMP : une table créée
# depuis survivrait, et la prochaine migration échouerait dessus. On retire
# d'abord les tables du rôle — exactement celles que l'application a créées.
jeiko_log "🛢️  Restauration de la base…"
PGPASSWORD="$DB_PASS" psql -h 127.0.0.1 -U "$DB_USER" -d "$DB_NAME" -q -v ON_ERROR_STOP=1 -c "DO \$\$
    DECLARE r record;
    BEGIN
      FOR r IN SELECT tablename FROM pg_tables WHERE schemaname = 'public' AND tableowner = current_user LOOP
        EXECUTE 'DROP TABLE IF EXISTS public.' || quote_ident(r.tablename) || ' CASCADE';
      END LOOP;
    END \$\$;"
# --no-acl : le dump porte les droits par défaut que `postgres` a posés à
# l'installation (étape 05). Le compte du site ne peut pas les rejouer, et
# pg_restore sortait en erreur alors que la base était bien revenue : « Restauration
# INTERROMPUE » sur une restauration réussie (essai.kojei.fr, 20/10/2026). Le site
# possède ses tables, il n'a pas besoin de droits ; ceux de `postgres` restent.
PGPASSWORD="$DB_PASS" pg_restore -h 127.0.0.1 -U "$DB_USER" -d "$DB_NAME" \
    --clean --if-exists --no-owner --no-acl --role="$DB_USER" "$DUMP"

# Les médias s'écrivent SOUS LE COMPTE DU SITE : le dossier du projet lui
# appartient, et root qui extrait là suivrait un lien qu'il y aurait posé.
if [[ -f "$SRC/media.tar.gz" ]]; then
    jeiko_log "🖼️  Restauration des médias…"
    jeiko_as_site "$SITE_USER" sh -c 'rm -rf "$1/mediadir.old"; if [ -d "$1/mediadir" ]; then mv "$1/mediadir" "$1/mediadir.old"; fi' sh "$PROJECT_DIR"
    jeiko_as_site "$SITE_USER" tar -xzf - -C "$PROJECT_DIR" <"$SRC/media.tar.gz"
fi

if [[ $AVEC_CONFIG -eq 1 ]]; then
    jeiko_log "⚙️  Restauration du .env…"
    # Écrit SOUS LE COMPTE DU SITE, par renommage : jamais à travers un lien.
    tar -xzOf "$SRC/config.tar.gz" "$ENV_ARCHIVE" \
        | jeiko_as_site "$SITE_USER" sh -c 'cp -p "$1" "$1.avant-restauration" 2>/dev/null; umask 077; cat >"$1.tmp" && mv -f "$1.tmp" "$1"' sh "$PROJECT_DIR/$SITE/.env" \
        || jeiko_die "Restauration du .env impossible."
fi

# Toujours : sans effet sur une base au niveau, nécessaire sur une plus ancienne.
jeiko_log "🔁 Mise à niveau de la base (migrate)…"
jeiko_manage "$PROJECT_DIR" "$VENV_DIR" "$SITE_USER" migrate --noinput \
    || jeiko_warn "migrate a échoué : la base est restaurée mais pas à niveau — à reprendre (journal ci-dessus)."

jeiko_fix_perms "$PROJECT_DIR" "$SITE_USER" "$SITE" "$VENV_DIR"
jeiko_ok "Restauration terminée. Anciens médias conservés dans mediadir.old."
RESTORE

chmod 0700 "$RESTORE_SCRIPT"
chown root:root "$RESTORE_SCRIPT"

# --------------------------------------------------------------------------- #
# Planification
#
# Horaire décalé par site (dérivé du nom) : dix sites qui lancent leur pg_dump
# à 3 h 17 pile mettent la machine à genoux.
# --------------------------------------------------------------------------- #
MINUTE=$(( $(printf '%s' "$SITE_NAME" | cksum | cut -d' ' -f1) % 60 ))
HOUR=$(( 2 + $(printf '%s' "$SITE_NAME" | cksum | cut -d' ' -f1) % 3 ))

cat >"/etc/cron.d/jeiko-backup-$SITE_NAME" <<EOF
# Sauvegarde quotidienne du site $SITE_NAME
SHELL=/bin/bash
PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
$MINUTE $HOUR * * * root $BACKUP_SCRIPT $SITE_NAME >>/var/log/jeiko/$SITE_NAME/backup.log 2>&1
EOF
chmod 0644 "/etc/cron.d/jeiko-backup-$SITE_NAME"

cat >"/etc/logrotate.d/jeiko-$SITE_NAME" <<EOF
/var/log/jeiko/$SITE_NAME/*.log {
    weekly
    rotate 8
    compress
    missingok
    notifempty
    create 0640 root ${SITE_USER:-root}
}
EOF

# --------------------------------------------------------------------------- #
# Vérification immédiate
# --------------------------------------------------------------------------- #
jeiko_log "🧪 Sauvegarde de contrôle…"
# Lancée par une convergence ou une installation : le verrou du site est tenu
# par le parent (jeiko-server-update) ou n'a pas lieu d'être.
if JEIKO_VERROU_DU_SITE_TENU=1 "$BACKUP_SCRIPT" "$SITE_NAME"; then
    jeiko_ok "Sauvegardes opérationnelles (quotidiennes à ${HOUR}h${MINUTE})."
else
    jeiko_warn "La sauvegarde de contrôle a échoué — à corriger avant la mise en production."
fi

jeiko_log "   Restauration : sudo jeiko-restore $SITE_NAME $BACKUP_DIR/daily/<horodatage>"

# --------------------------------------------------------------------------- #
# Surveillance (IG-05, 11/10/2026)
#
# Chaque heure, `jeiko-verifier` regarde le disque, la mémoire, les
# certificats, les services, CHAQUE SITE tel qu'un visiteur le voit (à
# travers nginx) et l'âge des sauvegardes. Il écrit dans un journal ET, si
# l'ensemble des problèmes a changé depuis le passage précédent — un nouveau,
# un de moins, ou le retour à la normale —, l'envoie par e-mail, sans passer
# par aucun site (`jeiko-alertes` configure l'envoi). Un problème qui dure ne
# renvoie pas un e-mail par heure.
# --------------------------------------------------------------------------- #
cat >/usr/local/sbin/jeiko-verifier <<'CONTROLE'
#!/bin/bash
# jeiko-verifier — état de santé du serveur. Chaque heure, ou à la demande.
# Prévient par e-mail quand l'état change (configurer : sudo jeiko-alertes).
set -uo pipefail
source /usr/local/lib/jeiko/common.sh

ALERTES=0
CLES=()
MESSAGES=()
# signaler <clé stable> <message> : la clé identifie le problème d'un passage
# à l'autre, le message le décrit.
signaler() { printf '⚠️  %s\n' "$2"; CLES+=("$1"); MESSAGES+=("$2"); ALERTES=$((ALERTES + 1)); }

printf '── Contrôle du %s ──\n' "$(date '+%d/%m/%Y %H:%M')"

# Disque : à 100 %, PostgreSQL cesse d'écrire et le site renvoie des erreurs.
while read -r pcent monte; do
    [[ "$pcent" -ge 90 ]] && signaler "disque:$monte" "Disque $monte à ${pcent}% — libérer de la place." || true
done < <(df --output=pcent,target / /var 2>/dev/null | tail -n +2 | tr -d '%' | sort -u -k2)

# Mémoire
DISPO=$(awk '/MemAvailable/ {print int($2/1024)}' /proc/meminfo)
[[ "$DISPO" -lt 150 ]] && signaler "memoire" "Mémoire disponible : ${DISPO} Mo." || true

# Certificats
if [[ -d /etc/letsencrypt/live ]]; then
    for cert in /etc/letsencrypt/live/*/cert.pem; do
        [[ -f "$cert" ]] || continue
        FIN=$(date -d "$(openssl x509 -enddate -noout -in "$cert" | cut -d= -f2)" +%s 2>/dev/null || echo 0)
        [[ "$FIN" -eq 0 ]] && continue
        JOURS=$(( (FIN - $(date +%s)) / 86400 ))
        NOM="$(basename "$(dirname "$cert")")"
        # Certbot renouvelle à 30 jours : en dessous de 20, il a échoué.
        [[ "$JOURS" -lt 20 ]] && signaler "certificat:$NOM" "Certificat $NOM expire dans ${JOURS} j — le renouvellement automatique ne fonctionne pas." || true
    done
fi

# Services et sites. La fiche est lue dans un sous-shell (elle ne doit pas
# polluer celui-ci), le signalement se fait ICI : dans le sous-shell, le
# compteur incrémenté serait une copie.
for site in $(jeiko_list_sites); do
    LU="$(source "$(jeiko_site_conf_path "$site")" && printf '%s|%s|%s|%s|%s' "$GUNICORN_SERVICE" "${DOMAIN_NAME:-}" "${ENABLE_SSL:-n}" "${PROJECT_DIR:-}" "${JEIKO_QUOTA_MEDIAS_GO:-}")" \
        || { signaler "fiche:$site" "Fiche de « $site » illisible."; continue; }
    IFS='|' read -r SERVICE DOMAINE SSL PROJET QUOTA <<<"$LU"
    # Espace des médias, pour un site hébergé qui a un quota (HEB-01). Une
    # alerte, pas un blocage : c'est à l'exploitant d'en parler au client.
    if [[ "$QUOTA" =~ ^[0-9]+$ && -d "$PROJET/mediadir" ]]; then
        # « du » muet (dossier disparu entre-temps) : 0, pas une erreur
        # d'arithmétique qui arrêterait le contrôle des sites suivants.
        KO="$(du -sk "$PROJET/mediadir" 2>/dev/null | cut -f1)"
        [[ "$KO" =~ ^[0-9]+$ ]] || KO=0
        MO=$(( KO / 1024 ))
        (( MO > 10#$QUOTA * 1024 )) && signaler "quota:$site" "« $site » : ${MO} Mo de médias, au-delà de son quota de ${QUOTA} Go."
    fi
    if ! systemctl is-active --quiet "$SERVICE"; then
        signaler "service:$SERVICE" "Service $SERVICE arrêté."
        continue
    fi
    if systemctl cat "jeiko-memcached-$site.service" >/dev/null 2>&1 \
       && ! systemctl is-active --quiet "jeiko-memcached-$site.service"; then
        signaler "cache:$site" "Cache de « $site » arrêté (jeiko-memcached-$site) — le site tourne sans cache."
    fi
    # Ce que voit un visiteur : la page d'accueil, à travers nginx. Une 5xx ou
    # rien du tout, c'est un site en panne, même si son service tourne.
    if [[ -n "$DOMAINE" ]]; then
        SCHEMA=http; PORT=80
        [[ "$SSL" == "y" ]] && { SCHEMA=https; PORT=443; }
        CODE="$(curl -sk -o /dev/null -w '%{http_code}' --max-time 15 \
                --resolve "$DOMAINE:$PORT:127.0.0.1" "$SCHEMA://$DOMAINE/" 2>/dev/null)" || true
        [[ "${CODE:-000}" =~ ^(5|000) ]] && signaler "site:$site" "« $site » ($DOMAINE) ne répond pas correctement : HTTP ${CODE:-000}."
    fi
done
# Un site resté « indisponible » parce qu'une mise à jour ou une restauration
# a été tuée net, sans retirer son drapeau de maintenance (C-07).
while read -r orphelin; do
    [[ -n "$orphelin" ]] && signaler "maintenance:$orphelin" "« $orphelin » était resté en maintenance (opération interrompue) : rouvert."
done < <(jeiko_drapeaux_orphelins)
# memcached : le commun, que les sites au paquet ancien utilisent encore.
for svc in nginx postgresql memcached fail2ban; do
    systemctl is-active --quiet "$svc" || signaler "service:$svc" "Service $svc arrêté."
done

# Sauvegardes : une sauvegarde qui a cessé de tourner ne se voit pas.
for site in $(jeiko_list_sites); do
    DERNIERE=$(find "/var/backups/jeiko/$site/daily" -maxdepth 1 -type d -name '20*' -mtime -2 2>/dev/null | head -n1)
    [[ -z "$DERNIERE" ]] && signaler "sauvegarde:$site" "Aucune sauvegarde de « $site » depuis plus de 48 h." || true
done

if [[ $ALERTES -eq 0 ]]; then
    echo "✅ Rien à signaler."
else
    echo "❌ $ALERTES point(s) à traiter."
fi

# Prévenir, seulement si l'état a changé depuis le passage précédent.
ETAT="$JEIKO_LIB_DIR/verifier.etat"
if printf '%s\n' "${CLES[@]+"${CLES[@]}"}" | jeiko_etat_a_change "$ETAT"; then
    if [[ $ALERTES -eq 0 ]]; then
        SUJET="Retour à la normale"
        CORPS="Plus aucun problème relevé sur ce serveur ($(date '+%d/%m/%Y %H:%M'))."
    else
        SUJET="$ALERTES problème(s) sur le serveur"
        CORPS="$(printf -- '- %s\n' "${MESSAGES[@]}")"$'\n\n'"Journal : /var/log/jeiko/verification.log — détail : sudo jeiko-verifier"
    fi
    printf '%s\n' "$CORPS" | jeiko_envoyer_alerte "$SUJET"
    case $? in
        0) echo "📧 Alerte envoyée." ;;
        2) echo "ℹ️  Alertes par e-mail non configurées (sudo jeiko-alertes)." ;;
        *) echo "❌ Alerte non envoyée — l'état sera reproposé au prochain passage."; jeiko_etat_a_reproposer "$ETAT" ;;
    esac
fi
[[ $ALERTES -eq 0 ]]
CONTROLE
chmod 0755 /usr/local/sbin/jeiko-verifier
chown root:root /usr/local/sbin/jeiko-verifier

# La configuration des alertes : une fois, en interactif. Le mot de passe du
# serveur d'envoi ne passe jamais par la ligne de commande.
cat >/usr/local/sbin/jeiko-alertes <<'ALERTES'
#!/bin/bash
# jeiko-alertes            — configurer l'envoi des alertes du serveur, puis
#                            envoyer un e-mail d'essai ;
# jeiko-alertes --essai    — renvoyer l'e-mail d'essai ;
# jeiko-alertes --voir     — montrer la configuration (sans le mot de passe).
set -euo pipefail
source /usr/local/lib/jeiko/common.sh
jeiko_require_root

essai() {
    printf "Cet e-mail confirme que le serveur sait prévenir.\nLes alertes partent quand l'état change (contrôle chaque heure).\n" \
        | jeiko_envoyer_alerte "Essai des alertes" && echo "✅ E-mail d'essai envoyé." \
        || { echo "❌ Envoi impossible — vérifier les réglages (sudo jeiko-alertes)."; exit 1; }
}

case "${1:-}" in
    --essai) essai; exit 0 ;;
    --voir)
        [[ -f "$JEIKO_ALERTES_CONF" ]] || { echo "Non configuré : sudo jeiko-alertes"; exit 0; }
        grep -v '^SMTP_MOT_DE_PASSE=' "$JEIKO_ALERTES_CONF"; exit 0 ;;
    "") ;;
    *) echo "Usage : jeiko-alertes [--essai|--voir]"; exit 1 ;;
esac

read -rp "Adresse qui reçoit les alertes : " A
read -rp "Serveur d'envoi (SMTP), ex. ssl0.ovh.net : " HOTE
read -rp "Port [587, ou 465] : " PORT; PORT="${PORT:-587}"
read -rp "Identifiant SMTP (souvent l'adresse d'envoi) : " UTIL
read -rsp "Mot de passe SMTP : " MDP; echo
read -rp "Adresse d'expédition [$UTIL] : " DE; DE="${DE:-$UTIL}"

for valeur in "$A" "$HOTE" "$PORT" "$UTIL" "$MDP" "$DE"; do
    [[ "$valeur" != *$'\n'* && "$valeur" != *$'\r'* ]] || { echo "❌ Retour à la ligne refusé."; exit 1; }
done
[[ "$A" =~ ^[^@[:space:]]+@[^@[:space:]]+\.[^@[:space:]]+$ ]] || { echo "❌ Adresse invalide."; exit 1; }
[[ "$PORT" =~ ^[0-9]{2,5}$ ]] || { echo "❌ Port invalide."; exit 1; }
[[ -n "$HOTE" ]] || { echo "❌ Serveur d'envoi requis."; exit 1; }

install -d -m 0755 -o root -g root "$(dirname "$JEIKO_ALERTES_CONF")"
TMP="$(mktemp "$JEIKO_ALERTES_CONF.XXXXXX")"; chmod 0600 "$TMP"
printf 'A=%s\nDE=%s\nSMTP_HOTE=%s\nSMTP_PORT=%s\nSMTP_UTILISATEUR=%s\nSMTP_MOT_DE_PASSE=%s\n' \
    "$A" "$DE" "$HOTE" "$PORT" "$UTIL" "$MDP" >"$TMP"
mv -f "$TMP" "$JEIKO_ALERTES_CONF"
echo "✅ Enregistré dans $JEIKO_ALERTES_CONF (root seul)."
essai
ALERTES
chmod 0755 /usr/local/sbin/jeiko-alertes
chown root:root /usr/local/sbin/jeiko-alertes

install -d -m 0755 /var/log/jeiko
cat >/etc/cron.d/jeiko-verifier <<'CRON'
# Contrôle de santé chaque heure — journal dans /var/log/jeiko/verification.log,
# e-mail quand l'état change (sudo jeiko-alertes pour le configurer).
SHELL=/bin/bash
PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
17 * * * * root /usr/local/sbin/jeiko-verifier >>/var/log/jeiko/verification.log 2>&1
CRON
chmod 0644 /etc/cron.d/jeiko-verifier

cat >/etc/logrotate.d/jeiko-verifier <<'ROT'
/var/log/jeiko/verification.log {
    monthly
    rotate 6
    compress
    missingok
    notifempty
    create 0640 root root
}
ROT

jeiko_ok "Surveillance chaque heure : sudo jeiko-verifier ; alertes par e-mail : sudo jeiko-alertes"
if [[ ! -f "$JEIKO_ALERTES_CONF" ]]; then
    jeiko_warn "Alertes par e-mail non configurées : le serveur ne préviendra personne d'une panne."
    jeiko_warn "     Une fois, sur ce serveur : sudo jeiko-alertes"
fi
