#!/bin/bash
set -euo pipefail
# shellcheck source=../lib/jeiko-common.sh
source /usr/local/lib/jeiko/common.sh

jeiko_step "[12] TLS Let's Encrypt et vhost HTTPS"
jeiko_require_root

: "${PROJECT_DIR:?PROJECT_DIR manquant}"
: "${SITE_NAME:?SITE_NAME manquant}"
: "${DOMAIN_NAME:?DOMAIN_NAME manquant}"

FINAL_CONF="/etc/nginx/sites-available/$SITE_NAME.conf"
ENABLED_CONF="/etc/nginx/sites-enabled/$SITE_NAME.conf"
ACME_ROOT="/var/www/acme"
CERT_DIR="/etc/letsencrypt/live/$DOMAIN_NAME"

WWW=0
jeiko_is_apex "$DOMAIN_NAME" && WWW=1

export DEBIAN_FRONTEND=noninteractive
dpkg -s certbot &>/dev/null || jeiko_apt install -y certbot python3-certbot-nginx

# --------------------------------------------------------------------------- #
# 1) Obtention du certificat
#
# Authentificateur webroot plutôt que --nginx : certbot ne touche pas à la
# configuration, donc il ne peut pas la casser, et le renouvellement emprunte
# exactement le même chemin que la première émission — celui qu'on vient de
# valider à l'étape 11.
# --------------------------------------------------------------------------- #
DOM_ARGS=(-d "$DOMAIN_NAME")
(( WWW == 1 )) && DOM_ARGS+=(-d "www.$DOMAIN_NAME") || true

install -d -m 0755 "$ACME_ROOT/.well-known/acme-challenge"

# IG-04 : présent ne suffit pas — encore valable 20 jours (certbot renouvelle
# à 30 : en dessous, son renouvellement a échoué) et portant chaque nom.
NOMS=("$DOMAIN_NAME")
(( WWW == 1 )) && NOMS+=("www.$DOMAIN_NAME") || true
if jeiko_certificat_convient "$CERT_DIR/fullchain.pem" 20 "${NOMS[@]}"; then
    jeiko_log "ℹ️  Certificat valable pour ${NOMS[*]} : réémission ignorée."
else
    [[ -f "$CERT_DIR/fullchain.pem" ]] \
        && jeiko_warn "Le certificat en place ne convient pas (proche de l'expiration, ou sans ${NOMS[*]}) : nouvelle demande."
    # L'adresse ne sert qu'à une DEMANDE de certificat : Let's Encrypt la garde
    # avec le compte, et les renouvellements s'en servent. Calculée et signalée
    # ici seulement — à chaque mise à jour, l'avertissement « aucune adresse »
    # s'affichait pour un certificat déjà en place, faute du compte
    # d'administration, qui n'est connu qu'à l'installation (09/10/2026).
    CERTBOT_EMAIL="${CERTBOT_EMAIL:-${DJANGO_SUPEREMAIL:-}}"
    if [[ -n "$CERTBOT_EMAIL" ]]; then
        EMAIL_ARGS=(-m "$CERTBOT_EMAIL")
    else
        # admin@<domaine> n'existe généralement pas : sans adresse valide, aucun
        # avertissement d'expiration ne parvient jamais.
        EMAIL_ARGS=(--register-unsafely-without-email)
        jeiko_warn "Aucune adresse e-mail : pas d'alerte avant expiration du certificat."
    fi
    jeiko_log "🔏 Demande de certificat pour ${DOM_ARGS[*]}…"
    # --cert-name : le même dossier live/<domaine> ; --expand : un nom ajouté
    # (www) étend le certificat au lieu d'en créer un second.
    if ! certbot certonly --webroot -w "$ACME_ROOT" \
            --non-interactive --agree-tos --cert-name "$DOMAIN_NAME" --expand \
            "${EMAIL_ARGS[@]}" "${DOM_ARGS[@]}"; then
        # Un certificat encore valable, même imparfait, vaut mieux que l'arrêt
        # de la convergence : le site reste en HTTPS, et on le dit.
        if jeiko_certificat_convient "$CERT_DIR/fullchain.pem" 0 "$DOMAIN_NAME"; then
            jeiko_warn "Certbot a échoué : le certificat en place est gardé, à reprendre (DNS, port 80)."
        else
            jeiko_die "Certbot a échoué. Vérifie que $DOMAIN_NAME pointe bien vers ce serveur et que le port 80 est joignable."
        fi
    fi
fi

CRT="$CERT_DIR/fullchain.pem"
KEY="$CERT_DIR/privkey.pem"
[[ -f "$CRT" && -f "$KEY" ]] || jeiko_die "Certificats introuvables ($CRT)."

# --------------------------------------------------------------------------- #
# 2) Vhost final — `jeiko_vhost_https`, la même écriture que l'étape 11 pour
#    un site déjà en HTTPS (IG-04).
# --------------------------------------------------------------------------- #
cp -a "$FINAL_CONF" "$FINAL_CONF.bak_$(date +%Y%m%d_%H%M%S)" 2>/dev/null || true
TMP_CONF="$(mktemp)"
jeiko_vhost_https "$SITE_NAME" "$DOMAIN_NAME" "$WWW" "$CERT_DIR" "$ACME_ROOT" >"$TMP_CONF"

install -m 0644 -o root -g root "$TMP_CONF" "$FINAL_CONF"
rm -f "$TMP_CONF"
ln -sfn "$FINAL_CONF" "$ENABLED_CONF"

# --------------------------------------------------------------------------- #
# 3) Validation, avec retour arrière si la conf est invalide
# --------------------------------------------------------------------------- #
if ! nginx -t 2>&1; then
    jeiko_err "nginx -t a échoué sur la configuration HTTPS."
    LAST_BAK="$(find /etc/nginx/sites-available -name "$SITE_NAME.conf.bak_*" -printf '%T@ %p\n' 2>/dev/null | sort -rn | head -n1 | cut -d' ' -f2-)"
    if [[ -n "$LAST_BAK" ]]; then
        cp -a "$LAST_BAK" "$FINAL_CONF"
        jeiko_warn "Configuration précédente restaurée depuis $LAST_BAK"
        nginx -t && systemctl reload nginx || true
    fi
    jeiko_die "TLS non appliqué. Le site reste servi dans son état antérieur."
fi

systemctl reload nginx

# --------------------------------------------------------------------------- #
# 4bis) Bascule de l'application en mode HTTPS
#
# Sans ça, Django continue de se croire en HTTP : pas de redirection SSL, pas
# de cookies Secure, pas de HSTS — alors que le certificat est en place. Il
# fallait éditer le .env à la main, ce qui n'était écrit nulle part.
#
# Le service n'est redémarré que si la valeur change réellement.
# --------------------------------------------------------------------------- #
ENV_PATH="$PROJECT_DIR/$SITE_NAME/.env"
SERVICE_NAME="${GUNICORN_SERVICE:-gunicorn-$SITE_NAME}"
COMPTE="${SITE_USER:-jeiko-$SITE_NAME}"

# Le .env est chez le site : lu et modifié SOUS SON COMPTE. Root y faisait sed,
# >>, puis chown/chmod en suivant les liens — un .env remplacé par un lien vers
# /etc/shadow en donnait la propriété au site (audit du 04/10/2026, I-01). Il
# suffisait au site d'effacer sa ligne JEIKO_SSL pour passer ici. Seul reste en
# root la réparation du propriétaire (jeiko_reparer_proprietaire).
if [[ -L "$ENV_PATH" ]]; then
    jeiko_err ".env est un lien symbolique ($ENV_PATH) : refusé."
    jeiko_die "Configuration TLS incomplète — un site JEIKO ne pose jamais de lien à cet endroit."
fi

if [[ -f "$ENV_PATH" ]]; then
    jeiko_reparer_proprietaire "$COMPTE" "$PROJECT_DIR" "$SITE_NAME"
    if jeiko_as_site "$COMPTE" grep -qE '^[[:space:]]*JEIKO_SSL[[:space:]]*=[[:space:]]*"?True"?[[:space:]]*$' -- "$ENV_PATH"; then
        jeiko_log "ℹ️  JEIKO_SSL est déjà à True."
    else
        if jeiko_site_a_la_cle "$COMPTE" "$ENV_PATH" JEIKO_SSL; then
            jeiko_as_site "$COMPTE" sed -ri 's|^[[:space:]]*JEIKO_SSL[[:space:]]*=.*|JEIKO_SSL="True"|' -- "$ENV_PATH" \
                || jeiko_die "Bascule de JEIKO_SSL impossible dans $ENV_PATH."
        else
            jeiko_site_ajouter "$COMPTE" "$ENV_PATH" 'JEIKO_SSL="True"' \
                || jeiko_die "Ajout de JEIKO_SSL impossible dans $ENV_PATH."
        fi
        jeiko_as_site "$COMPTE" chmod -- "$JEIKO_SECRET_MODE" "$ENV_PATH" \
            || jeiko_warn "Mode 0600 non appliqué à $ENV_PATH."
        jeiko_ok "JEIKO_SSL=True — redirection HTTPS, cookies Secure et HSTS activés."

        if systemctl is-active --quiet "$SERVICE_NAME"; then
            systemctl restart "$SERVICE_NAME"
            jeiko_log "🔁 $SERVICE_NAME redémarré pour prendre en compte la bascule."
        fi
    fi

    # La fiche du site sert de source de vérité à jeiko-server-update : si elle
    # reste à "n", une convergence ultérieure régénérerait un vhost sans TLS.
    CONF_SITE="$(jeiko_site_conf_path "$SITE_NAME")"
    if [[ -f "$CONF_SITE" ]] && ! grep -qE "^ENABLE_SSL='y'" "$CONF_SITE"; then
        sed -ri "s|^ENABLE_SSL=.*|ENABLE_SSL='y'|" "$CONF_SITE"
        jeiko_ok "Fiche du site mise à jour : ENABLE_SSL=y"
    fi
else
    # Le certificat est en place mais l'application l'ignore : elle continuera à
    # se croire en HTTP, donc à produire des liens et des cookies non sécurisés.
    # Un TLS à moitié posé est pire qu'un TLS absent — on ne le laisse pas passer.
    jeiko_err ".env introuvable ($ENV_PATH) : JEIKO_SSL n'a pas pu être basculé."
    jeiko_err "L'application se croirait en HTTP malgré le certificat."
    jeiko_die "Configuration TLS incomplète."
fi

# --------------------------------------------------------------------------- #
# 5) Renouvellement automatique
#
# On vérifie que le renouvellement fonctionne MAINTENANT, pendant qu'on est
# devant la machine, plutôt que de le découvrir à l'expiration.
# --------------------------------------------------------------------------- #
install -d -m 0755 /etc/letsencrypt/renewal-hooks/deploy
cat >/etc/letsencrypt/renewal-hooks/deploy/10-reload-nginx.sh <<'HOOK'
#!/bin/bash
# Recharge nginx après chaque renouvellement de certificat.
systemctl reload nginx || true
HOOK
chmod 0755 /etc/letsencrypt/renewal-hooks/deploy/10-reload-nginx.sh

systemctl enable --now certbot.timer 2>/dev/null || true

jeiko_log "🧪 Simulation d'un renouvellement…"
if certbot renew --dry-run --cert-name "$DOMAIN_NAME" 2>&1 | tail -n 5; then
    jeiko_ok "Le renouvellement automatique fonctionne."
else
    jeiko_warn "La simulation de renouvellement a échoué : le certificat expirera dans 90 jours sans intervention."
fi

jeiko_ok "TLS actif pour $DOMAIN_NAME."
