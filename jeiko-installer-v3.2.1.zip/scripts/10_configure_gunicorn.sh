#!/bin/bash
set -euo pipefail
# shellcheck source=../lib/jeiko-common.sh
source /usr/local/lib/jeiko/common.sh

jeiko_step "[10] Service Gunicorn"
jeiko_require_root

: "${PROJECT_DIR:?PROJECT_DIR manquant}"
: "${SITE_NAME:?SITE_NAME manquant}"
: "${SITE_USER:?SITE_USER manquant}"
: "${VENV_DIR:?VENV_DIR manquant}"

SERVICE_NAME="${GUNICORN_SERVICE:-gunicorn-$SITE_NAME}"
SERVICE_FILE="/etc/systemd/system/$SERVICE_NAME.service"
SOCKET_PATH="/run/$SERVICE_NAME/gunicorn.sock"
LOG_DIR="/var/log/gunicorn/$SITE_NAME"
WSGI_MODULE="$SITE_NAME.wsgi"

# ProtectHome=yes masque /home au service : un projet installé là devient
# invisible à son propre gunicorn, et systemd rapporte « No such file or
# directory » sur un binaire qui existe pourtant. On n'active donc le
# durcissement que si le projet vit hors de /home — ce qui est le cas par
# défaut (/var/www).
if [[ "$PROJECT_DIR" == /home/* || "$PROJECT_DIR" == /root/* ]]; then
    PROTECT_HOME="no"
    jeiko_warn "Projet sous $PROJECT_DIR : ProtectHome désactivé pour ce service."
    jeiko_warn "     Emplacement recommandé : /var/www (INSTALL_ROOT=/var/www)."
else
    PROTECT_HOME="yes"
fi

[[ -x "$VENV_DIR/bin/gunicorn" ]] || jeiko_die "gunicorn absent du venv : $VENV_DIR/bin/gunicorn"

# --------------------------------------------------------------------------- #
# Dimensionnement
# --------------------------------------------------------------------------- #
CPU="$(nproc --all 2>/dev/null || echo 2)"
WORKERS=$(( 2 * CPU + 1 ))
(( WORKERS < 3 ))  && WORKERS=3 || true
(( WORKERS > 12 )) && WORKERS=12 || true

# Chaque worker charge tout Django : sous 1 Go de RAM, en lancer 5 conduit à
# des OOM kills difficiles à diagnostiquer (le site « tombe » sans erreur).
RAM_MB="$(awk '/MemTotal/ {print int($2/1024)}' /proc/meminfo)"
MAX_BY_RAM=$(( RAM_MB / 200 ))
(( MAX_BY_RAM < 2 )) && MAX_BY_RAM=2 || true
if (( WORKERS > MAX_BY_RAM )); then
    jeiko_log "ℹ️  Workers ramenés de $WORKERS à $MAX_BY_RAM (${RAM_MB} Mo de RAM)."
    WORKERS=$MAX_BY_RAM
fi

install -d -m 0750 -o "$SITE_USER" -g www-data "$LOG_DIR"

# `install -d` ne corrige que le DOSSIER. Sur un site migré, les journaux
# existent déjà et appartiennent au compte de l'ancien service — souvent
# www-data en 0644. Le nouveau service, lancé sous un autre compte, ne peut
# alors pas les ouvrir en écriture : gunicorn sort immédiatement sur
# « PermissionError: … error.log » et le site tombe. Constaté en production
# le 15/08/2026 lors de la première migration.
chown -R "$SITE_USER":www-data "$LOG_DIR"
find "$LOG_DIR" -maxdepth 1 -type f -print0 | xargs -0r chmod 0640

# --------------------------------------------------------------------------- #
# Unité
# --------------------------------------------------------------------------- #
cat >"$SERVICE_FILE" <<EOF
[Unit]
Description=Gunicorn — $SITE_NAME (Django)
After=network.target postgresql.service memcached.service
Wants=postgresql.service

[Service]
Type=notify
User=$SITE_USER
# Groupe principal www-data : c'est ce qui permet à nginx d'atteindre le socket.
Group=www-data
# Mais dès qu'un Group= explicite est donné, systemd n'ajoute PAS les groupes
# dont l'utilisateur est membre — contrairement à « sudo -u », qui les charge.
# Sans cette ligne, le service perd l'appartenance à son propre groupe et ne
# peut plus lire ses fichiers en 0640 root:<site>, à commencer par
# /var/lib/jeiko/<site>/update.state : la page de mise à jour renvoyait une 500.
SupplementaryGroups=$SITE_USER
WorkingDirectory=$PROJECT_DIR
Environment=PYTHONUNBUFFERED=1
Environment=PYTHONNOUSERSITE=1
# Sans HOME, gunicorn 26 tente d'ouvrir son socket de contrôle dans le home du
# compte — masqué par ProtectHome=yes — et journalise à chaque démarrage
# « Control server error: Permission denied: '/home/<user>' ». Sans gravité,
# mais autant ne pas polluer les journaux avec une erreur sans objet.
Environment=HOME=$PROJECT_DIR

# systemd crée /run/$SERVICE_NAME au démarrage et le supprime à l'arrêt : pas
# de socket orpheline à nettoyer à la main.
RuntimeDirectory=$SERVICE_NAME
RuntimeDirectoryMode=0750

# 0007 pour que la socket unix soit en 0660 et joignable par nginx (www-data
# doit pouvoir y ÉCRIRE pour établir la connexion). Les fichiers uploadés ne
# dépendent pas de ce umask : settings.py force FILE_UPLOAD_PERMISSIONS=0640.
UMask=0007

ExecStart=$VENV_DIR/bin/gunicorn \\
  --name $SERVICE_NAME \\
  --workers $WORKERS \\
  --threads 2 \\
  --timeout 60 \\
  --graceful-timeout 30 \\
  --keep-alive 5 \\
  --max-requests 1000 \\
  --max-requests-jitter 100 \\
  --access-logfile $LOG_DIR/access.log \\
  --error-logfile $LOG_DIR/error.log \\
  --capture-output \\
  --bind unix:$SOCKET_PATH \\
  $WSGI_MODULE:application

ExecReload=/bin/kill -s HUP \$MAINPID
Restart=always
RestartSec=3s

# Sans limite, une boucle de démarrages ratés fait abandonner systemd au bout
# de 5 tentatives en 10 s, et le site reste éteint jusqu'à intervention. On
# élargit la fenêtre : une base momentanément indisponible ne doit pas coûter
# une intervention manuelle.
StartLimitIntervalSec=300
StartLimitBurst=10

# En cas de saturation mémoire, le noyau doit sacrifier un worker Gunicorn
# plutôt que PostgreSQL : un worker repart tout seul, une base interrompue en
# pleine écriture est autrement plus ennuyeuse.
OOMScoreAdjust=200

# Durcissement : le service n'a besoin d'écrire que dans son projet, ses logs
# et son runtime.
# NoNewPrivileges=no, et c'est délibéré.
#
# L'administration déclenche sa propre mise à jour par
# « sudo -n systemctl start jeiko-update@<site> ». sudo est un binaire setuid :
# avec NoNewPrivileges=yes le noyau lui interdit d'élever ses privilèges, et
# l'appel échoue par « the "no new privileges" flag is set ». Le durcissement
# entrait donc en contradiction frontale avec le mécanisme de mise à jour.
#
# Ce que l'application peut réellement faire reste borné par
# /etc/sudoers.d/jeiko-<site>, qui n'autorise QUE cette commande, à l'argument
# près — pas un shell, pas un script modifiable par le site. C'est le sudoers
# qui porte la sécurité ici, pas ce drapeau.
NoNewPrivileges=no
PrivateTmp=yes
ProtectSystem=full
ProtectHome=$PROTECT_HOME
ReadWritePaths=$PROJECT_DIR $LOG_DIR
ProtectControlGroups=yes

# ProtectKernelTunables=, ProtectKernelModules=, RestrictSUIDSGID= et
# LockPersonality= sont volontairement ABSENTS : systemd.exec(5) précise que
# chacune de ces options IMPLIQUE NoNewPrivileges=yes, et l'implication
# l'emporte sur le « NoNewPrivileges=no » ci-dessus. Les laisser rendait donc
# le drapeau actif malgré l'intention affichée, et « sudo -n systemctl start
# jeiko-update@<site> » échouait depuis l'application avec « the "no new
# privileges" flag is set » — la mise à jour depuis l'administration était
# inutilisable, alors que le contrôle de convergence la déclarait bonne (il
# teste sudo depuis le shell root, pas depuis le cgroup de gunicorn).
#
# ProtectControlGroups= est conservé : il ne figure pas dans la liste des
# options qui impliquent NoNewPrivileges.
#
# Comme expliqué plus haut, ce qui borne réellement l'application est
# /etc/sudoers.d/jeiko-<site> : deux commandes, à l'argument près.

[Install]
WantedBy=multi-user.target
EOF

# --------------------------------------------------------------------------- #
# Nettoyage d'une éventuelle socket-activation héritée
# --------------------------------------------------------------------------- #
if [[ -f "/etc/systemd/system/$SERVICE_NAME.socket" ]]; then
    systemctl stop "$SERVICE_NAME.socket" 2>/dev/null || true
    systemctl disable "$SERVICE_NAME.socket" 2>/dev/null || true
    rm -f "/etc/systemd/system/$SERVICE_NAME.socket"
fi

# --------------------------------------------------------------------------- #
# Rotation des logs — sans ça, access.log grossit jusqu'à saturer le disque
# --------------------------------------------------------------------------- #
cat >"/etc/logrotate.d/gunicorn-$SITE_NAME" <<EOF
$LOG_DIR/*.log {
    daily
    rotate 14
    compress
    delaycompress
    missingok
    notifempty
    create 0640 $SITE_USER www-data
    sharedscripts
    postrotate
        systemctl kill -s USR1 $SERVICE_NAME.service 2>/dev/null || true
    endscript
}
EOF

systemctl daemon-reload
systemctl enable "$SERVICE_NAME" >/dev/null
systemctl restart "$SERVICE_NAME"

# --------------------------------------------------------------------------- #
# Attente active
#
# `Type=notify` fait que systemctl restart ne rend la main qu'une fois gunicorn
# réellement prêt ; on vérifie tout de même la socket, car c'est elle que nginx
# ouvrira.
# --------------------------------------------------------------------------- #
for _ in {1..20}; do
    if [[ -S "$SOCKET_PATH" ]] && systemctl is-active --quiet "$SERVICE_NAME"; then
        jeiko_ok "Gunicorn actif — $WORKERS workers, socket $SOCKET_PATH"
        exit 0
    fi
    sleep 0.5
done

jeiko_err "Gunicorn n'a pas produit la socket attendue : $SOCKET_PATH"
journalctl -u "$SERVICE_NAME" -n 60 --no-pager || true
tail -n 40 "$LOG_DIR/error.log" 2>/dev/null || true
exit 1
