#!/bin/bash
set -euo pipefail
# shellcheck source=../lib/jeiko-common.sh
source /usr/local/lib/jeiko/common.sh

jeiko_step "[11] Nginx (vhost du site : HTTPS si son certificat convient, sinon HTTP prêt pour Certbot)"
jeiko_require_root

: "${PROJECT_DIR:?PROJECT_DIR manquant}"
: "${SITE_NAME:?SITE_NAME manquant}"
: "${DOMAIN_NAME:?DOMAIN_NAME manquant}"

# Le domaine part dans server_name, donc dans une configuration que le maître
# nginx lit en root. Pour un site migré, il vient du .env du site, sans contrôle
# à l'époque (migrate_site.sh) : un « ; » ou un retour à la ligne y injecterait
# une directive (audit du 04/10/2026, I-11). Contrôlé en minuscules — nginx ne
# distingue pas la casse —, la valeur elle-même n'est pas modifiée. On sort
# AVANT toute écriture : le vhost en place reste servi.
jeiko_validate_domain "${DOMAIN_NAME,,}" \
    || jeiko_die "Domaine refusé pour « $SITE_NAME » — vhost inchangé."

NGX_AVAIL="/etc/nginx/sites-available/$SITE_NAME.conf"
NGX_ENABLED="/etc/nginx/sites-enabled/$SITE_NAME.conf"
STATIC_ROOT="$PROJECT_DIR/staticdir"
MEDIA_ROOT="$PROJECT_DIR/mediadir"
SOCKET_PATH="/run/${GUNICORN_SERVICE:-gunicorn-$SITE_NAME}/gunicorn.sock"
# Le LiveKit de CE site (VISIO-04) : son port vient de son rang sur la
# machine, le même que celui que 15_visio.sh lui donne.
read -r VISIO_PORT _ < <(jeiko_visio_ports "$SITE_NAME") \
    || jeiko_die "Rang de visio impossible pour « $SITE_NAME » — vhost inchangé."
ACME_ROOT="/var/www/acme"
# Le site « attrape-tout » (NGX-2) : ce que reçoit une requête dont l'hôte
# n'est celui d'aucun site — adresse IP nue, robot, domaine pointé à tort.
ATTRAPE_AVAIL="/etc/nginx/sites-available/000-jeiko-attrape-tout.conf"
ATTRAPE_ENABLED="/etc/nginx/sites-enabled/000-jeiko-attrape-tout.conf"
ATTRAPE_ROOT="/var/www/jeiko-attrape-tout"

if jeiko_is_apex "$DOMAIN_NAME"; then
    SERVER_NAMES="$DOMAIN_NAME www.$DOMAIN_NAME"
else
    SERVER_NAMES="$DOMAIN_NAME"
fi

install -d -m 0755 "$ACME_ROOT/.well-known/acme-challenge"
chown -R root:www-data "$ACME_ROOT"

# --------------------------------------------------------------------------- #
# 1) Réglages globaux partagés par tous les sites
#
# La zone limit_req doit vivre dans le contexte http{}, pas dans un server{}.
# L'ancienne configuration activait le jail fail2ban « nginx-req-limit » sans
# qu'aucune zone n'existe : le filtre ne pouvait rien matcher, la protection
# était purement décorative.
# --------------------------------------------------------------------------- #
GLOBAL_CONF="/etc/nginx/conf.d/00-jeiko-global.conf"

# --------------------------------------------------------------------------- #
# Sauvegarde de l'état PARTAGÉ, avant toute écriture
#
# Cette étape touche des fichiers communs à tous les sites de la machine. Si la
# configuration finale est invalide, retirer le seul vhost du nouveau site ne
# suffit pas : un fichier global cassé fait échouer « nginx -t », donc bloque
# tout rechargement, et les autres sites tombent au premier redémarrage. On
# restaure donc l'intégralité de l'état partagé en cas d'échec.
# --------------------------------------------------------------------------- #
NGX_STATE_BAK="$(mktemp -d /tmp/jeiko-nginx-state.XXXXXX)"
chmod 0700 "$NGX_STATE_BAK"
install -d "$NGX_STATE_BAK/conf.d" "$NGX_STATE_BAK/snippets"

# Une copie ratée ne doit JAMAIS passer en silence : la restauration lirait son
# absence comme « fichier créé par cette exécution » et supprimerait la
# configuration d'un autre site (TODO de l'installeur, NGX-1). On s'arrête donc
# ici, avant toute écriture.
#
# Le vhost du site et son lien sites-enabled sont mis de côté eux aussi : un
# échec de « nginx -t » retirait le lien sans le remettre, et le site n'était
# plus servi (audit du 04/10/2026, I-09) — en mise à jour automatique, un
# gabarit fautif aurait retiré ainsi tous les sites de la machine, un à un.
jeiko_nginx_snapshot() {
    local f
    if [[ -f "$GLOBAL_CONF" ]]; then
        cp -a "$GLOBAL_CONF" "$NGX_STATE_BAK/conf.d/" \
            || jeiko_die "Sauvegarde de $GLOBAL_CONF impossible — rien n'a été modifié."
    fi
    for f in /etc/nginx/snippets/jeiko-*.conf; do
        [[ -f "$f" ]] || continue
        cp -a "$f" "$NGX_STATE_BAK/snippets/" \
            || jeiko_die "Sauvegarde de $f impossible — rien n'a été modifié."
    done
    if [[ -f "$NGX_AVAIL" ]]; then
        cp -a "$NGX_AVAIL" "$NGX_STATE_BAK/vhost.conf" \
            || jeiko_die "Sauvegarde de $NGX_AVAIL impossible — rien n'a été modifié."
    fi
    if [[ -L "$NGX_ENABLED" ]]; then
        : >"$NGX_STATE_BAK/lien-actif" \
            || jeiko_die "Sauvegarde de l'état de $NGX_ENABLED impossible — rien n'a été modifié."
    fi
    if [[ -f "$ATTRAPE_AVAIL" ]]; then
        cp -a "$ATTRAPE_AVAIL" "$NGX_STATE_BAK/attrape-tout.conf" \
            || jeiko_die "Sauvegarde de $ATTRAPE_AVAIL impossible — rien n'a été modifié."
    fi
    if [[ -L "$ATTRAPE_ENABLED" ]]; then
        : >"$NGX_STATE_BAK/attrape-tout-actif" \
            || jeiko_die "Sauvegarde de l'état de $ATTRAPE_ENABLED impossible — rien n'a été modifié."
    fi
}

# Remet le vhost du site tel qu'il était — fichier ET lien.
jeiko_nginx_restore_vhost() {
    if [[ -f "$NGX_STATE_BAK/vhost.conf" ]]; then
        cp -a "$NGX_STATE_BAK/vhost.conf" "$NGX_AVAIL"
    else
        rm -f "$NGX_AVAIL"
    fi
    if [[ -e "$NGX_STATE_BAK/lien-actif" ]]; then
        ln -sfn "$NGX_AVAIL" "$NGX_ENABLED"
    else
        rm -f "$NGX_ENABLED"
    fi
}

jeiko_nginx_restore() {
    local f base
    # L'attrape-tout : tel qu'il était, fichier ET lien.
    if [[ -f "$NGX_STATE_BAK/attrape-tout.conf" ]]; then
        cp -a "$NGX_STATE_BAK/attrape-tout.conf" "$ATTRAPE_AVAIL"
    else
        rm -f "$ATTRAPE_AVAIL"
    fi
    if [[ -e "$NGX_STATE_BAK/attrape-tout-actif" ]]; then
        ln -sfn "$ATTRAPE_AVAIL" "$ATTRAPE_ENABLED"
    else
        rm -f "$ATTRAPE_ENABLED"
    fi
    # Fichiers globaux : restaurés s'ils existaient, supprimés sinon.
    if [[ -f "$NGX_STATE_BAK/conf.d/$(basename "$GLOBAL_CONF")" ]]; then
        cp -a "$NGX_STATE_BAK/conf.d/$(basename "$GLOBAL_CONF")" "$GLOBAL_CONF"
    else
        rm -f "$GLOBAL_CONF"
    fi
    for f in /etc/nginx/snippets/jeiko-*.conf; do
        [[ -f "$f" ]] || continue
        base="$(basename "$f")"
        if [[ -f "$NGX_STATE_BAK/snippets/$base" ]]; then
            cp -a "$NGX_STATE_BAK/snippets/$base" "$f"
        else
            rm -f "$f"          # créé par cette exécution
        fi
    done
}

trap 'rm -rf "$NGX_STATE_BAK"' EXIT
jeiko_nginx_snapshot

# Certaines directives ne tolèrent qu'une seule déclaration par contexte http{}.
# Debian en pose déjà plusieurs dans nginx.conf (server_tokens, gzip…), et une
# machine qui héberge d'autres sites peut en avoir ajouté. Les redéclarer fait
# échouer « nginx -t » — donc TOUS les sites de la machine, pas seulement celui
# qu'on installe. On ne pose que ce qui manque.
jeiko_nginx_has_directive() {
    local directive="$1" f
    grep -qE "^[[:space:]]*${directive}[[:space:]]" /etc/nginx/nginx.conf 2>/dev/null && return 0
    for f in /etc/nginx/conf.d/*.conf; do
        [[ -e "$f" ]] || continue
        [[ "$f" == "$GLOBAL_CONF" ]] && continue   # notre propre fichier
        grep -qE "^[[:space:]]*${directive}[[:space:]]" "$f" 2>/dev/null && return 0
    done
    return 1
}

# Émet « directive valeur; » seulement si la directive n'existe pas déjà.
jeiko_nginx_emit() {
    local directive="$1"; shift
    if jeiko_nginx_has_directive "$directive"; then
        jeiko_log "   nginx : $directive déjà défini ailleurs, conservé tel quel."
    else
        printf '%s %s;\n' "$directive" "$*" >>"$GLOBAL_CONF"
    fi
}

cat >"$GLOBAL_CONF" <<'EOF'
# Généré par l'installeur JEIKO — commun à tous les sites.
EOF

# Ne pas divulguer la version de nginx dans les en-têtes et pages d'erreur.
jeiko_nginx_emit server_tokens off

cat >>"$GLOBAL_CONF" <<'EOF'

# Zones de limitation. 'jeiko_general' protège l'ensemble du site,
# 'jeiko_login' cible les formulaires d'authentification, qui sont la vraie
# surface d'attaque par force brute.
limit_req_zone $binary_remote_addr zone=jeiko_general:10m rate=30r/s;
limit_req_zone $binary_remote_addr zone=jeiko_login:10m   rate=5r/m;
# Endpoints publics non authentifiés qui écrivent en base et envoient des
# e-mails (réservation de rendez-vous, formulaires de contact). Le débit
# général de 30 r/s était sans rapport avec leur coût réel.
limit_req_zone $binary_remote_addr zone=jeiko_write:10m   rate=10r/m;
limit_req_status 429;
limit_conn_zone $binary_remote_addr zone=jeiko_conn:10m;

# La visio (VISIO-01) : un websocket relayé à LiveKit garde
# « Connection: upgrade » ; une requête ordinaire sur la même adresse le referme.
map $http_upgrade $jeiko_connection_upgrade {
    default upgrade;
    ''      close;
}

# Une adresse de visio porte un secret — le code du lien personnel
# (/visio/<code>/…) ou le jeton LiveKit du websocket (/visio-rtc/…?access_token=…).
# Elle reste hors du journal d'accès du site (audit V-19, 12/10/2026).
map $request_uri $jeiko_journal {
    ~^/visio(-rtc)?/  0;
    default           1;
}

# HSTS sur les fichiers statiques et les médias (IG-06). Leurs « location »
# posent leurs propres en-têtes, et perdent donc celui du vhost TLS. Valeur
# vide hors HTTPS : nginx n'envoie pas un en-tête vide — jamais de HSTS sur un
# site servi en clair.
map $https $jeiko_hsts {
    on      "max-age=31536000; includeSubDomains";
    default "";
}

# La langue d'une adresse (« /en/… » → « .en »), pour servir la copie de la
# page 500 dans cette langue quand le site est arrêté (location
# @jeiko_indisponible de chaque site). Un « map » et non un « if » dans la
# location : un « if » y ouvre un contexte où try_files ne s'applique plus —
# /en/… répondait 404 au lieu de la page (éprouvé le 07/10/2026).
map $uri $jeiko_langue_erreur {
    "~^/(?<jeiko_l>[a-z]{2})/"  ".$jeiko_l";
    default                     "";
}

# Cache des médias selon qu'ils sont VERSIONNÉS (28/09/2026). Une URL portant
# « ?v=… » change dès que le fichier change — logo (?v=<date de modification>),
# bundle de polices (?v=<assets_version>) — : elle peut donc être gelée un an,
# le changement de version suffit à « vider » le cache. Sans version, on ne
# sait pas si le fichier sera remplacé sous le même nom : trente jours.
map $arg_v $jeiko_media_cache {
    ""      "public, max-age=2592000";
    default "public, max-age=31536000, immutable";
}
EOF

# Compression. Debian active déjà « gzip on » dans nginx.conf : on ne la
# redéclare pas, on complète seulement ce qui manque.
printf '\n# Compression\n' >>"$GLOBAL_CONF"
jeiko_nginx_emit gzip            on
jeiko_nginx_emit gzip_vary       on
jeiko_nginx_emit gzip_proxied    any
jeiko_nginx_emit gzip_min_length 1024
jeiko_nginx_emit gzip_comp_level 5
jeiko_nginx_emit gzip_types \
    "text/plain text/css text/xml text/javascript" \
    "application/javascript application/json application/xml" \
    "application/rss+xml image/svg+xml font/woff font/woff2"

# Un upload d'image dépasse très vite le défaut de 1 Mo, qui se manifestait par
# un « 413 Request Entity Too Large » sans message côté application.
printf '\n# Tailles et délais\n' >>"$GLOBAL_CONF"
jeiko_nginx_emit client_max_body_size    25m
jeiko_nginx_emit client_body_timeout     60s
jeiko_nginx_emit client_header_timeout   20s
jeiko_nginx_emit send_timeout            60s

# Table des en-têtes transmis au proxy (28/09/2026). Les proxy_set_header des
# vhosts et les en-têtes de sécurité dépassent la taille par défaut (512/64) :
# nginx le signalait à chaque rechargement, par site — « could not build
# optimal proxy_headers_hash » —, un avertissement sans conséquence qui noyait
# le journal de convergence. Ceci ne change aucun en-tête, seulement la table.
printf '\n# Table des en-têtes du proxy\n' >>"$GLOBAL_CONF"
jeiko_nginx_emit proxy_headers_hash_max_size    1024
jeiko_nginx_emit proxy_headers_hash_bucket_size 128

# --------------------------------------------------------------------------- #
# 2) Fragments réutilisés par le vhost HTTP et le vhost HTTPS (étape 12)
# --------------------------------------------------------------------------- #
install -d -m 0755 /etc/nginx/snippets

# En-têtes de sécurité.
#
# Ils sont dans un fichier à part et ré-inclus dans CHAQUE bloc location, car
# add_header ne s'hérite pas : dès qu'un bloc enfant déclare son propre
# add_header, tous ceux du parent sont ignorés. Des en-têtes posés au niveau
# server{} auraient donc disparu sur les pages de l'application — c'est-à-dire
# exactement là où ils comptent.
#
# Deux fragments (17/10/2026). Sur les réponses de DJANGO, nosniff,
# X-Frame-Options et Referrer-Policy sont posés par Django lui-même
# (SecurityMiddleware, XFrameOptionsMiddleware) — et il choisit page par page :
# DENY par défaut, SAMEORIGIN pour un aperçu montré en cadre. nginx les
# ajoutait en plus : chaque page en portait DEUX, « DENY » et « SAMEORIGIN »,
# et un navigateur face à deux valeurs contraires retient la plus stricte.
# Les blocs qui relaient vers Django incluent donc jeiko-security-headers-app ;
# les fichiers que nginx sert seul (statiques, médias, page d'indisponibilité)
# gardent le fragment complet, qui l'inclut.
cat >/etc/nginx/snippets/jeiko-security-headers.conf <<'EOF'
add_header X-Content-Type-Options "nosniff" always;
add_header X-Frame-Options "SAMEORIGIN" always;
add_header Referrer-Policy "strict-origin-when-cross-origin" always;
include /etc/nginx/snippets/jeiko-security-headers-app.conf;
EOF

cat >/etc/nginx/snippets/jeiko-security-headers-app.conf <<'EOF'
add_header Permissions-Policy "accelerometer=(), geolocation=(), camera=(self), microphone=(self), display-capture=(self), payment=()" always;
add_header Cross-Origin-Opener-Policy "same-origin" always;

# ── Content-Security-Policy, en OBSERVATION ─────────────────────────────────
#
# « Report-Only » : le navigateur signale les violations dans sa console et
# n'en bloque aucune. Rien ne peut donc casser en l'activant — c'est une phase
# de mesure, pas une protection.
#
# Origines autorisées, relevées dans les gabarits et les scripts du package :
#   (Alpine.js, Chart.js, hls.js et Quill sont servis par le site.)
#   js.stripe.com / hooks.stripe.com / api.stripe.com
#                         paiement : script, cadres (dont la validation 3-D
#                         Secure) et appels de Stripe.js
#   fonts.googleapis.com / fonts.gstatic.com
#                         polices de l'administration et de l'éditeur ; le site
#                         PUBLIC les héberge lui-même (cf. fonts_selfhost.py)
#   *.b-cdn.net           les flux vidéo Bunny des formations, lus par hls.js
#   player.vimeo.com / youtube.com / youtube-nocookie.com / dailymotion.com
#                         lecteurs vidéo des formations et des blocs média
#   'self' en frame-src   les aperçus de l'administration (e-mails, PDF)
#   media-src https: blob:
#                         une vidéo de formation peut venir de n'importe quel
#                         stockage (S3, FTP, Bunny…) ; hls.js la lit par une
#                         adresse blob: — et son worker aussi (worker-src)
#
# Plus de `'unsafe-inline'` ni de `'unsafe-eval'` sur script-src (S-03,
# 16/10/2026) : le package n'écrit plus aucun script ni gestionnaire
# d'événement dans ses pages, et sert la version CSP d'Alpine, qui n'évalue
# pas ses attributs par `new Function`. Un script injecté dans la page serait
# donc refusé — dès que l'en-tête passe en application.
#
# Ce qui peut encore être signalé sur un site : du code collé à la main
# (code de suivi, widget tiers) ou une origine propre au site (stockage
# vidéo, carte). On l'ajoute ci-dessous, ou on le retire du site.
#
# Marche à suivre :
#   1. déployer tel quel, naviguer sur le site ET l'administration ;
#   2. relever les violations : les navigateurs les postent à /csp-rapport/
#      (report-uri, 09/10/2026), lisibles dans Pilotage › Signalements CSP ;
#   3. ajuster les origines ci-dessous jusqu'à n'avoir plus de signalement ;
#   4. remplacer « Content-Security-Policy-Report-Only » par
#      « Content-Security-Policy » pour passer en application.
add_header Content-Security-Policy-Report-Only "default-src 'self'; base-uri 'self'; object-src 'none'; frame-ancestors 'self'; form-action 'self'; script-src 'self' https://js.stripe.com; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' data: https://fonts.gstatic.com; img-src 'self' data: https:; media-src 'self' blob: https:; worker-src 'self' blob:; connect-src 'self' https://api.stripe.com https://*.b-cdn.net; frame-src 'self' https://js.stripe.com https://hooks.stripe.com https://www.youtube.com https://youtube.com https://www.youtube-nocookie.com https://player.vimeo.com https://www.dailymotion.com; report-uri /csp-rapport/" always;
EOF

cat >"/etc/nginx/snippets/jeiko-$SITE_NAME.conf" <<EOF
# Corps commun du site $SITE_NAME — inclus par les vhosts HTTP et HTTPS.

# ── Médias exécutables ──────────────────────────────────────────────────────
# Location en expression régulière, donc évaluée AVANT le préfixe /media/.
# Un fichier téléversé ne doit jamais être interprété comme du contenu actif
# servi depuis l'origine du site : un .html ou un .svg déposé par un formulaire
# deviendrait sinon du XSS stocké sur le domaine principal, avec accès aux
# cookies de session.
#
# La capture nommée est indispensable : « alias » dans une location en regex
# doit recevoir le chemin complet, et une location imbriquée dans un bloc à
# alias n'en hérite pas de façon fiable.
location ~* ^/media/(?<jeiko_media_file>.+\.(?:html?|xht|xhtml|svgz?|xml|js|mjs|php|phtml|py|pl|sh|cgi))\$ {
    alias $MEDIA_ROOT/\$jeiko_media_file;
    types { }
    default_type application/octet-stream;
    add_header Content-Disposition "attachment" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Content-Security-Policy "sandbox" always;
}

# ── Statiques ───────────────────────────────────────────────────────────────
# ManifestStaticFilesStorage hache les noms de fichiers : le cache long est sûr,
# l'empreinte change à chaque déploiement.
location /static/ {
    alias $STATIC_ROOT/;
    try_files \$uri =404;
    access_log off;
    expires 1y;
    include /etc/nginx/snippets/jeiko-security-headers.conf;
    add_header Cache-Control "public, max-age=31536000, immutable" always;
    add_header Strict-Transport-Security \$jeiko_hsts always;
}

# ── Contenu de formation payant : blocage de l'accès public direct ──────────
# Les vidéos et PDF de cours ne doivent JAMAIS être servis directement sur
# /media/ : une URL devinée contournerait l'authentification. Django vérifie
# les droits d'accès puis délègue la lecture à la location interne
# /protected-media/ via X-Accel-Redirect. « ^~ » garantit que ces deux règles
# priment sur « location /media/ ».
# NE PAS bloquer courses/thumbnails ni courses/video_thumbnails : ces
# miniatures sont publiques et doivent rester servies par /media/.
location ^~ /media/courses/videos/ { return 404; }
location ^~ /media/courses/pdfs/   { return 404; }
# Les fichiers déposés dans une salle de visio (VISIO-01) : servis par Django
# après contrôle du lien de l'invité, via /protected-media/ — jamais en direct.
location ^~ /media/visio/          { return 404; }

# Location interne : atteignable uniquement via X-Accel-Redirect émis par
# Django (ex: « X-Accel-Redirect: /protected-media/courses/videos/xxx.mp4 »),
# jamais par une requête cliente directe. nginx lit alors
# \$MEDIA_ROOT/courses/videos/xxx.mp4 et gère nativement le Range (seek vidéo).
#
# « nosniff » : le navigateur s'en tient au type que nginx déduit de
# l'extension (.mp4, .pdf) ; un fichier déguisé — du HTML nommé « .pdf » —
# n'est pas interprété comme une page du site (résiduel AUDIT_COURSES,
# 09/10/2026). Pas de « Content-Security-Policy: sandbox » ici, à la
# différence des médias exécutables : Chrome refuse d'afficher un PDF servi
# avec, et les supports de cours ne se liraient plus.
location /protected-media/ {
    internal;
    alias $MEDIA_ROOT/;
    add_header X-Content-Type-Options "nosniff" always;
}

# ── Médias dont le nom change avec le contenu : cache d'un an ───────────────
# PageSpeed relevait « durée de cache 7 jours » sur les images et les polices
# (28/09/2026). Deux familles de fichiers ne sont JAMAIS réécrites sous le
# même nom, et peuvent donc être gelées comme les statiques :
#   · les polices auto-hébergées (fonts/families/…woff2) : nom = empreinte
#     fournie par Google (fonts_selfhost.py) ;
#   · les variantes d'images (…-<horodatage>-<aléa>.webp) : chaque génération
#     produit un nom neuf (administration_pages/models.py, _make_derivative_webp).
# Regex entre guillemets : nginx l'exige dès qu'elle contient des accolades.
location ~* "^/media/(?<jeiko_media_long>(?:fonts/families/.+\.woff2|.+-[0-9]{10}-[0-9a-f]{6}\.webp))\$" {
    alias $MEDIA_ROOT/\$jeiko_media_long;
    access_log off;
    expires 1y;
    include /etc/nginx/snippets/jeiko-security-headers.conf;
    add_header Cache-Control "public, max-age=31536000, immutable" always;
    add_header Strict-Transport-Security \$jeiko_hsts always;
}

# ── Médias ordinaires ───────────────────────────────────────────────────────
# Sans version dans l'URL, pas d'« immutable » : un original supprimé puis
# renvoyé peut reprendre le même nom, et resterait gelé chez les visiteurs.
# Trente jours plutôt que sept. Avec « ?v=… », un an.
location /media/ {
    alias $MEDIA_ROOT/;
    try_files \$uri =404;
    include /etc/nginx/snippets/jeiko-security-headers.conf;
    # Un an si l'URL est versionnée (?v=…), trente jours sinon : voir la
    # « map » \$jeiko_media_cache dans conf.d/00-jeiko-global.conf.
    add_header Cache-Control \$jeiko_media_cache always;
    add_header Strict-Transport-Security \$jeiko_hsts always;
}

location = /favicon.ico { access_log off; log_not_found off; }

# Pas de bloc « location = /robots.txt » : il capturait la requête sans
# proxy_pass, donc nginx cherchait un fichier sur disque et renvoyait 404 —
# alors que l'application expose bien une vue robots_txt. En laissant la route
# passer par « location / », Django la sert comme sitemap.xml.

# ── Connecteur MCP par OAuth (P-04, 28/09/2026) ─────────────────────────────
# claude.ai et l'app Claude lisent les métadonnées OAuth sous /.well-known/ :
# sans ce bloc, la règle « fichiers cachés » ci-dessous répond 403 et la
# connexion échoue sans dire pourquoi. « ^~ » empêche l'évaluation des regex.
# Seul le préfixe oauth- est ouvert ; le reste de /.well-known/ reste fermé
# (hors acme-challenge, servi dans le vhost).
location ^~ /.well-known/oauth- {
    include /etc/nginx/snippets/jeiko-security-headers-app.conf;
    proxy_set_header Host \$host;
    proxy_set_header X-Forwarded-Host \$host;
    proxy_set_header X-Forwarded-Proto \$scheme;
    proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
    proxy_set_header X-Real-IP \$remote_addr;
    proxy_pass http://unix:$SOCKET_PATH;
}
# Enregistrement et échange de code : des écritures sans jeton. L'application
# les borne déjà ; ce plafond réseau les complète, comme la réservation.
location ^~ /oauth/ {
    limit_req zone=jeiko_write burst=10 nodelay;
    include /etc/nginx/snippets/jeiko-security-headers-app.conf;
    proxy_set_header Host \$host;
    proxy_set_header X-Forwarded-Host \$host;
    proxy_set_header X-Forwarded-Proto \$scheme;
    proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
    proxy_set_header X-Real-IP \$remote_addr;
    proxy_pass http://unix:$SOCKET_PATH;
}

# ── La visio (VISIO-01) ─────────────────────────────────────────────────────
# Le navigateur ouvre wss://<domaine>/visio-rtc/… : nginx le relaie au LiveKit
# DU SITE, qui n'écoute que 127.0.0.1:<son port> (15_visio.sh). Ni sous-domaine ni
# certificat de plus ; le son et l'image, eux, vont droit aux ports 7881/7882.
# La caméra et le micro sont permis au site lui-même (Permissions-Policy du
# fragment commun) — interdits auparavant, ce qui aurait rendu la visio muette.
location ^~ /visio-rtc/ {
    proxy_pass http://127.0.0.1:$VISIO_PORT/;
    proxy_http_version 1.1;
    proxy_set_header Upgrade \$http_upgrade;
    proxy_set_header Connection \$jeiko_connection_upgrade;
    proxy_set_header Host \$host;
    proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
    proxy_set_header X-Real-IP \$remote_addr;
    proxy_buffering off;
    proxy_read_timeout 1h;
    proxy_send_timeout 1h;
}

# Ni fichiers cachés, ni sauvegardes d'éditeur.
location ~ /\.        { deny all; }
location ~ ~\$         { deny all; }
location ~* \.(bak|old|orig|sql|dump|env)\$ { deny all; }

# ── Écritures publiques non authentifiées ───────────────────────────────────
# Réservation de rendez-vous : exempté de CSRF par conception (API publique),
# il écrit en base et déclenche des e-mails. Ses garde-fous applicatifs
# existent ; ce plafond réseau les complète.
location ~ ^/(calendars?|rendez-vous|api)/.*(book|reserve|appointment) {
    limit_req zone=jeiko_write burst=5 nodelay;
    include /etc/nginx/snippets/jeiko-security-headers-app.conf;
    proxy_set_header Host \$host;
    proxy_set_header X-Forwarded-Host \$host;
    proxy_set_header X-Forwarded-Proto \$scheme;
    proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
    proxy_set_header X-Real-IP \$remote_addr;
    proxy_pass http://unix:$SOCKET_PATH;
}

# ── Authentification ────────────────────────────────────────────────────────
# Limitation stricte : c'est la vraie surface de force brute.
location ~ ^/(accounts|admin)/login {
    limit_req zone=jeiko_login burst=5 nodelay;
    include /etc/nginx/snippets/jeiko-security-headers-app.conf;
    proxy_set_header Host \$host;
    proxy_set_header X-Forwarded-Host \$host;
    proxy_set_header X-Forwarded-Proto \$scheme;
    proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
    proxy_set_header X-Real-IP \$remote_addr;
    proxy_pass http://unix:$SOCKET_PATH;
}

# ── Site arrêté ─────────────────────────────────────────────────────────────
# Quand gunicorn ne répond pas (arrêté, redémarrage, socket absente : 502 ;
# trop lent : 504), nginx sert la copie statique de la page 500 que le site a
# écrite (administration_pages/pages_erreur.py, A-10) — dans la langue de
# l'adresse si elle existe — au lieu de sa page brute. Le code reste 502/504.
# Pas le 503 : c'est celui de limit_conn, qui n'est pas une panne. Sans copie
# (aucune page choisie), la page de nginx, comme avant. Les réponses de Django
# lui-même, 500 comprise, passent telles quelles : pas de proxy_intercept_errors.
# Mise à jour en cours (C-07) : tant que le drapeau du site existe, la page
# « indisponible », même si gunicorn a déjà été relancé pour le contrôle de
# santé — qui, lui, passe par la socket. Les visiteurs ne reviennent qu'après
# le verdict : rien n'est écrit dans une base qu'un retour arrière remplacerait.
if (-f $JEIKO_MAINTENANCE_DIR/$SITE_NAME) {
    return 502;
}
error_page 502 504 @jeiko_indisponible;
location @jeiko_indisponible {
    root $MEDIA_ROOT/jeiko-erreurs;
    include /etc/nginx/snippets/jeiko-security-headers.conf;
    add_header Cache-Control "no-store" always;
    try_files /500\$jeiko_langue_erreur.html /500.html =502;
}

# ── Application ─────────────────────────────────────────────────────────────
location / {
    limit_req zone=jeiko_general burst=60 nodelay;
    limit_conn jeiko_conn 30;

    # Pas d'« include proxy_params » ici ni dans les blocs ci-dessus : le
    # fichier de Debian pose déjà Host, X-Real-IP, X-Forwarded-For et
    # X-Forwarded-Proto, et les redéclarer en dessous les ENVOYAIT EN DOUBLE.
    # Django recolle deux en-têtes en « a,a » : X-Real-IP valait
    # « 160.79.106.160,160.79.106.160 », que PostgreSQL refuse dans un champ
    # inet (02/10/2026, l'horodatage des agents échouait à chaque appel).
    include /etc/nginx/snippets/jeiko-security-headers-app.conf;

    # Ces en-têtes sont RÉÉCRITS, jamais relayés depuis le client : Django se
    # fie à X-Forwarded-Proto pour savoir si la requête d'origine était en
    # HTTPS, un client ne doit pas pouvoir le forger.
    proxy_set_header Host \$host;
    proxy_set_header X-Forwarded-Host \$host;
    proxy_set_header X-Forwarded-Proto \$scheme;
    proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
    proxy_set_header X-Real-IP \$remote_addr;

    # 120 s : une mise à jour ne passe plus par une requête HTTP, mais un
    # import ou une génération de miniatures peut encore être long.
    proxy_read_timeout 120s;
    proxy_connect_timeout 30s;
    proxy_send_timeout 120s;
    proxy_buffering on;
    proxy_redirect off;

    proxy_pass http://unix:$SOCKET_PATH;
}
EOF

# --------------------------------------------------------------------------- #
# 3) Vhost HTTP
# --------------------------------------------------------------------------- #
[[ -f "$NGX_AVAIL" ]] && cp -a "$NGX_AVAIL" "$NGX_AVAIL.bak_$(date +%Y%m%d_%H%M%S)" || true
# Copie de confort pour l'exploitant — la restauration, elle, s'appuie sur
# l'instantané pris plus haut. Chaque convergence en déposait deux (étapes 11 et
# 12), sans fin : on garde les cinq plus récentes.
find /etc/nginx/sites-available -maxdepth 1 -name "$SITE_NAME.conf.bak_*" -printf '%T@ %p\n' 2>/dev/null \
    | sort -rn | tail -n +6 | cut -d' ' -f2- | xargs -r rm -f --

# IG-04 : un site DÉJÀ en HTTPS, dont le certificat est encore valable et
# porte chaque nom, reçoit tout de suite son vhost final — la même écriture
# que l'étape 12. Le vhost HTTP seul, rechargé ici, lui retirait son HTTPS
# jusqu'à l'étape 12 : une coupure à chaque convergence. Sans certificat qui
# convient (installation neuve, nom ajouté), le vhost HTTP sert au défi ACME.
NOMS_TLS=("$DOMAIN_NAME")
jeiko_is_apex "$DOMAIN_NAME" && NOMS_TLS+=("www.$DOMAIN_NAME")
if [[ "${ENABLE_SSL:-n}" == "y" ]] \
   && jeiko_certificat_convient "/etc/letsencrypt/live/$DOMAIN_NAME/fullchain.pem" 0 "${NOMS_TLS[@]}" \
   && [[ -r "/etc/letsencrypt/live/$DOMAIN_NAME/privkey.pem" ]]; then
    WWW_TLS=0
    (( ${#NOMS_TLS[@]} > 1 )) && WWW_TLS=1
    jeiko_vhost_https "$SITE_NAME" "$DOMAIN_NAME" "$WWW_TLS" "/etc/letsencrypt/live/$DOMAIN_NAME" "$ACME_ROOT" >"$NGX_AVAIL"
    jeiko_log "🔒 Certificat valable : vhost HTTPS écrit directement (pas de passage par HTTP seul)."
else
cat >"$NGX_AVAIL" <<EOF
# $SITE_NAME — vhost HTTP. Remplacé par l'étape 12 si TLS est activé.
server {
    listen 80;
    listen [::]:80;
    server_name $SERVER_NAMES;

    access_log /var/log/nginx/${SITE_NAME}_access.log combined if=\$jeiko_journal;
    error_log  /var/log/nginx/${SITE_NAME}_error.log;

    # Doit rester servi en clair et sans redirection, y compris après passage
    # en HTTPS : c'est par là que Let's Encrypt valide les renouvellements.
    # « ^~ » empêche l'évaluation des locations en regex sur ce préfixe : le
    # défi ACME ne doit être intercepté ni par la règle « fichiers cachés »
    # (le chemin commence par /.well-known), ni par une redirection HTTPS.
    location ^~ /.well-known/acme-challenge/ {
        root $ACME_ROOT;
        default_type "text/plain";
        allow all;
    }

    include /etc/nginx/snippets/jeiko-$SITE_NAME.conf;
}
EOF
fi

rm -f /etc/nginx/sites-enabled/default
ln -sfn "$NGX_AVAIL" "$NGX_ENABLED"

# --------------------------------------------------------------------------- #
# Le site « attrape-tout » (NGX-2, 09/10/2026)
#
# Le site par défaut de Debian retiré, une requête dont l'hôte n'est celui
# d'aucun site (IP nue, robot, domaine pointé à tort) partait chez le PREMIER
# vhost en ordre alphabétique — sous son certificat, dans son journal —, et
# tout site ajouté pouvait prendre ce rôle en silence. Elle reçoit désormais
# une page fixe qui renvoie vers jeiko.fr : du HTML seul, sans base ni
# application, qui ne peut rien casser. En HTTPS, la poignée de main est
# refusée (ssl_reject_handshake) : aucun certificat de site n'est montré.
#
# Sans effet sur les sites : seules les requêtes qu'AUCUN site ne déclare
# l'atteignent. Jamais posé si la machine a déjà un « default_server »
# ailleurs (deux font échouer nginx -t) : on le dit, et on n'y touche pas.
# Restauré avec le reste si nginx -t échoue.
# --------------------------------------------------------------------------- #
jeiko_poser_l_attrape_tout() {
    local autres version
    # « || true » : sans aucun default_server — le cas ordinaire, celui du
    # site par défaut de Debian retiré —, grep rend 1 ; sous pipefail,
    # l'affectation échouait et set -e sortait SANS UN MOT, au milieu de
    # l'étape (première convergence en 3.4.0, 11/10/2026).
    autres="$( { grep -rlE "^[^#]*listen[^;#]*default_server" /etc/nginx/sites-enabled /etc/nginx/conf.d /etc/nginx/nginx.conf 2>/dev/null || true; } \
              | while read -r f; do [[ "$(readlink -f "$f")" == "$(readlink -f "$ATTRAPE_AVAIL")" ]] || echo "$f"; done)"
    if [[ -n "$autres" ]]; then
        jeiko_log "ℹ️  Un « default_server » existe déjà ($(tr '\n' ' ' <<<"$autres")) : site attrape-tout non posé."
        return 0
    fi

    install -d -m 0755 "$ATTRAPE_ROOT"
    cat >"$ATTRAPE_ROOT/index.html" <<'HTML'
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex">
<title>JEIKO</title>
<style>
  :root { color-scheme: light; }
  body { margin: 0; min-height: 100vh; display: flex; align-items: center; justify-content: center;
         background: #181c26; color: #e7e5e4; font: 17px/1.6 system-ui, -apple-system, "Segoe UI", sans-serif; }
  main { max-width: 34rem; padding: 2rem 1.5rem; }
  .marque { color: #d97706; font-weight: 700; letter-spacing: .08em; font-size: .85rem; }
  h1 { color: #fff; font-size: 2rem; line-height: 1.2; margin: .4rem 0 1rem; }
  p { margin: 0 0 1.5rem; color: #d6d3d1; }
  a { display: inline-block; background: #b45309; color: #fff; text-decoration: none; font-weight: 600;
      padding: .8rem 1.4rem; border-radius: 8px; }
  a:hover { background: #92400e; }
</style>
</head>
<body>
<main>
  <div class="marque">JEIKO</div>
  <h1>Aucun site à cette adresse.</h1>
  <p>Ce serveur héberge des sites construits avec JEIKO, mais l'adresse demandée ne correspond à aucun d'eux.</p>
  <a href="https://jeiko.fr/">Découvrir JEIKO</a>
</main>
</body>
</html>
HTML
    chmod 0644 "$ATTRAPE_ROOT/index.html"

    {
        cat <<EOF
# Site « attrape-tout » de JEIKO (NGX-2) — écrit par l'installeur, ne pas modifier.
# Reçoit les requêtes dont l'hôte n'est celui d'aucun site de la machine.
server {
    listen 80 default_server;
    listen [::]:80 default_server;
    server_name _;
    root $ATTRAPE_ROOT;
    access_log off;
    location / { try_files /index.html =404; }
}
EOF
        # ssl_reject_handshake : nginx 1.19.4 et au-delà (Debian 12). Plus
        # ancien, pas de bloc 443 : l'HTTPS inconnu garde l'ancien comportement.
        version="$(nginx -v 2>&1 | sed -n 's#.*nginx/\([0-9.]*\).*#\1#p')"
        if [[ -n "$version" ]] && [[ "$(printf '%s\n1.19.4\n' "$version" | sort -V | head -1)" == "1.19.4" ]]; then
            cat <<'EOF'
server {
    listen 443 ssl default_server;
    listen [::]:443 ssl default_server;
    server_name _;
    ssl_reject_handshake on;
}
EOF
        fi
    } >"$ATTRAPE_AVAIL"
    ln -sfn "$ATTRAPE_AVAIL" "$ATTRAPE_ENABLED"
}
jeiko_poser_l_attrape_tout

# --------------------------------------------------------------------------- #
# Vhost concurrent servant le même domaine.
#
# nginx retient le PREMIER bloc server déclarant un server_name donné et ignore
# les suivants, en se contentant d'un avertissement « conflicting server name »
# que « nginx -t » qualifie malgré tout de « successful ». Un ancien vhost resté
# actif continue donc de servir le site — vers une socket qui n'existe plus,
# d'où des 502 pour les visiteurs — pendant que la convergence et son contrôle
# final affichent des voyants verts, puisqu'ils interrogent le backend et non
# le trafic public. Constaté le 15/08/2026 : un fichier « ah_new » (sans
# extension, non symbolique) primait sur « ah_new.conf » en ordre ASCII.
# --------------------------------------------------------------------------- #
# La création d'un site en doublon est refusée dès l'étape 00 (NGX-3) ; ici,
# sur un site EXISTANT, on avertit sans arrêter : le site est en service, et
# un arrêt de sa mise à jour ne le servirait pas mieux.
CONCURRENTS=""
for nom in $SERVER_NAMES; do
    CONCURRENTS+=" $(jeiko_vhosts_du_nom "$nom" "$NGX_ENABLED" | tr '\n' ' ')"
done
CONCURRENTS="$(tr ' ' '\n' <<<"$CONCURRENTS" | sed '/^$/d' | sort -u | tr '\n' ' ')"
CONCURRENTS="${CONCURRENTS% }"

if [[ -n "$CONCURRENTS" ]]; then
    jeiko_warn "Un autre vhost actif déclare déjà « $DOMAIN_NAME » :"
    for f in $CONCURRENTS; do jeiko_warn "     $f"; done
    jeiko_warn "     nginx n'en retient qu'un : le site peut répondre 502 alors que"
    jeiko_warn "     tous les contrôles de cette convergence seront au vert."
    jeiko_warn "     Désactiver l'ancien puis recharger :"
    jeiko_warn "       sudo mv <fichier> /root/  &&  sudo nginx -t && sudo systemctl reload nginx"
fi

# --------------------------------------------------------------------------- #
# 4) Validation
#
# On teste AVANT de recharger : une configuration invalide rechargée met à
# terre tous les sites de la machine, pas seulement celui qu'on installe.
# --------------------------------------------------------------------------- #
if ! nginx -t 2>&1; then
    jeiko_err "nginx -t a échoué — la configuration N'A PAS été rechargée."
    jeiko_err "Vhosts actifs :"; ls -l /etc/nginx/sites-enabled/ || true

    # Retour à l'état d'avant : le vhost du site ET tout ce qui est partagé.
    jeiko_nginx_restore_vhost
    jeiko_nginx_restore

    if nginx -t >/dev/null 2>&1; then
        jeiko_ok "État nginx d'origine restauré — les autres sites sont intacts."
    else
        jeiko_err "ATTENTION : nginx -t échoue encore APRÈS restauration."
        jeiko_err "Un problème préexistant affecte la configuration de la machine :"
        nginx -t || true
    fi
    jeiko_die "Vhost '$SITE_NAME' non installé, rien n'a été modifié durablement."
fi

if systemctl is-active --quiet nginx; then
    systemctl reload nginx
else
    systemctl enable --now nginx
fi

jeiko_ok "Nginx configuré pour $SERVER_NAMES (socket : $SOCKET_PATH)"
