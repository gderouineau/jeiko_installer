# shellcheck shell=bash
###############################################################################
# jeiko-common.sh — fonctions partagées JEIKO
#
# Déployé en /usr/local/lib/jeiko/common.sh (root:root 0644).
# Sourcé par l'installeur ET par /usr/local/sbin/jeiko-update.
#
# ⚠️  Il ne doit exister qu'UN SEUL exemplaire de ce fichier sur la machine.
#     La divergence de permissions entre installation et mise à jour venait
#     précisément d'avoir deux implémentations du même modèle de droits.
#
# Ce fichier ne fait pas `set -euo pipefail` : c'est au script appelant de le
# décider.
###############################################################################

JEIKO_COMMON_VERSION="2.0"

# --------------------------------------------------------------------------- #
# Emplacements canoniques
# --------------------------------------------------------------------------- #
JEIKO_ETC_DIR="/etc/jeiko"
JEIKO_SITES_DIR="$JEIKO_ETC_DIR/sites"     # registre des sites (root:root 0700)
JEIKO_LIB_DIR="/var/lib/jeiko"             # état + cache des wheels
JEIKO_LOG_DIR="/var/log/jeiko"             # logs de mise à jour, par site
JEIKO_BACKUP_DIR="/var/backups/jeiko"      # dumps DB + media
# Les verrous vivent dans un dossier root SEUL (0700), pas dans /run/lock qui
# est inscriptible par tous (1777) : sur /run/lock, n'importe quel compte local
# — donc le compte web d'un site, tenu pour compromis — pouvait créer le
# fichier de verrou d'avance, ou le tenir via un simple descripteur en lecture
# (flock ne regarde pas le mode d'ouverture), et arrêter EN SILENCE toute mise à
# jour du serveur (rapport du 05/10, P1-b). /run est un tmpfs : le dossier est
# recréé à chaque prise de verrou (jeiko_dossier_verrous).
JEIKO_LOCK_DIR="/run/jeiko"

# Canal de distribution par défaut (surchargeable par site dans sa fiche).
JEIKO_DEFAULT_CHANNEL_URL="https://raw.githubusercontent.com/gderouineau/jeiko/main"

# Canal de l'INSTALLEUR (outillage serveur), et dépôt de cet outillage. Tous
# deux surchargeables par l'environnement, comme l'était déjà JEIKO_ASSET_DIR
# dans jeiko-server-update.
JEIKO_INSTALLER_CHANNEL_URL="${JEIKO_INSTALLER_CHANNEL_URL:-https://raw.githubusercontent.com/gderouineau/jeiko_installer/main}"
JEIKO_ASSET_DIR="${JEIKO_ASSET_DIR:-/usr/local/share/jeiko}"

# --------------------------------------------------------------------------- #
# Modèle de permissions canonique
#
#  Répertoires  2750  setgid → le groupe www-data est hérité par tout nouveau
#                     fichier, donc nginx peut lire sans intervention manuelle
#  Fichiers     0640  propriétaire lit/écrit, nginx lit via le groupe,
#                     les autres utilisateurs locaux ne voient rien
#  .env         0600  jamais lisible par le groupe (contient DB_PASS)
#  Exécutables  0750
#
# Le socket gunicorn fait exception : nginx doit pouvoir y ÉCRIRE pour s'y
# connecter, il est donc en 0660 group=www-data (géré par UMask dans l'unité
# systemd). C'est la raison pour laquelle les uploads Django sont, eux, forcés
# explicitement via FILE_UPLOAD_PERMISSIONS dans settings.py plutôt que laissés
# au umask du processus.
# --------------------------------------------------------------------------- #
JEIKO_DIR_MODE="2750"
JEIKO_FILE_MODE="0640"
JEIKO_EXEC_MODE="0750"
JEIKO_SECRET_MODE="0600"

# --------------------------------------------------------------------------- #
# Journalisation
# --------------------------------------------------------------------------- #
jeiko_log()  { printf '%s\n' "$*"; }
jeiko_step() { printf '\n▶ %s\n' "$*"; }
jeiko_ok()   { printf '✅ %s\n' "$*"; }
jeiko_warn() { printf '⚠️  %s\n' "$*" >&2; }
jeiko_err()  { printf '❌ %s\n' "$*" >&2; }
jeiko_die()  { jeiko_err "$*"; exit 1; }

jeiko_require_root() {
    [[ ${EUID:-$(id -u)} -eq 0 ]] || jeiko_die "Cette opération doit être exécutée en root."
}

# --------------------------------------------------------------------------- #
# Validation
#
# Le nom de site sert à construire des noms d'unités systemd, des chemins et
# des entrées sudoers : il doit être strictement contraint. Cette fonction est
# la seule barrière entre une valeur fournie par l'utilisateur et un ExecStart.
# --------------------------------------------------------------------------- #
jeiko_validate_site_name() {
    local name="${1:-}"
    [[ -n "$name" ]] || { jeiko_err "Nom de site vide."; return 1; }
    [[ "$name" =~ ^[a-z0-9][a-z0-9_-]{0,30}$ ]] || {
        jeiko_err "Nom de site invalide : '$name' (minuscules, chiffres, - et _, 31 max, commence par un alphanumérique)."
        return 1
    }
    # Un nom de site devient aussi un nom de paquet Python de projet Django.
    [[ "$name" != *-* ]] || {
        jeiko_err "Nom de site invalide : '$name' contient un tiret, or il sert de nom de module Python (utilise _)."
        return 1
    }
    return 0
}

jeiko_validate_domain() {
    local domain="${1:-}"
    [[ "$domain" =~ ^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$ ]] || {
        jeiko_err "Domaine invalide : '$domain'"
        return 1
    }
    [[ ${#domain} -le 253 ]] || { jeiko_err "Domaine trop long."; return 1; }
    return 0
}

# Un domaine « apex » (exemple.fr) mérite un vhost www ; un sous-domaine non.
jeiko_is_apex() {
    [[ "${1:-}" =~ ^[^.]+\.[^.]+$ ]]
}

# --------------------------------------------------------------------------- #
# Registre des sites
#
# /etc/jeiko/sites/<site>.conf (root:root 0600) est la source de vérité unique
# pour l'updater, les backups et les scripts de maintenance. Il remplace le
# .env.<site> qui traînait dans le dossier de l'installeur en 0644.
# --------------------------------------------------------------------------- #
jeiko_site_conf_path() { printf '%s/%s.conf' "$JEIKO_SITES_DIR" "$1"; }

# Le dossier des verrous, root seul. Sur /run (tmpfs, effacé au redémarrage) :
# à (re)créer avant toute prise de verrou. Appelé par jeiko_init_dirs ET,
# directement, par les scripts qui verrouillent sans passer par jeiko_init_dirs
# (jeiko-server-update, jeiko-client-update).
jeiko_dossier_verrous() {
    install -d -m 0700 -o root -g root "$JEIKO_LOCK_DIR"
}

jeiko_init_dirs() {
    jeiko_require_root
    jeiko_dossier_verrous
    install -d -m 0755 -o root -g root "$JEIKO_ETC_DIR"
    install -d -m 0700 -o root -g root "$JEIKO_SITES_DIR"

    # 0755 et non 0750 : chaque site doit pouvoir TRAVERSER cette racine pour
    # lire son propre /var/lib/jeiko/<site>/update.state — c'est ce qui alimente
    # la page de mise à jour de son administration. Le cloisonnement est porté
    # par les sous-dossiers, en 0750 root:<compte du site> ; la racine ne
    # contient rien d'autre que des noms de sites.
    # 0750 root:root ici rendait l'état illisible pour TOUS les sites, et
    # « install -d -m » réapplique le mode même à un dossier existant : chaque
    # migrate_site.sh recassait donc les sites déjà en place.
    install -d -m 0755 -o root -g root "$JEIKO_LIB_DIR"
    install -d -m 0755 -o root -g root "$JEIKO_LOG_DIR"
    install -d -m 0700 -o root -g root "$JEIKO_BACKUP_DIR"
}

# Écrit (ou réécrit) la fiche d'un site. Toutes les valeurs sont échappées.
jeiko_write_site_conf() {
    jeiko_require_root
    local site="$1"
    jeiko_validate_site_name "$site" || return 1

    local conf; conf="$(jeiko_site_conf_path "$site")"
    local tmp;  tmp="$(mktemp "${conf}.XXXXXX")"
    chmod 0600 "$tmp"

    {
        echo "# Fiche du site '$site' — générée par l'installeur JEIKO."
        echo "# Source de vérité pour jeiko-update et les sauvegardes. Ne pas éditer à la main"
        echo "# sans relancer 'nginx -t' et 'systemctl restart gunicorn-$site'."
        echo "SITE_NAME=$(jeiko_shell_quote "$site")"
        echo "DOMAIN_NAME=$(jeiko_shell_quote "${DOMAIN_NAME:-}")"
        echo "BASE_DIR=$(jeiko_shell_quote "${BASE_DIR:-}")"
        echo "PROJECT_DIR=$(jeiko_shell_quote "${PROJECT_DIR:-${BASE_DIR:-}/$site}")"
        echo "SITE_USER=$(jeiko_shell_quote "${SITE_USER:-jeiko-$site}")"
        echo "VENV_DIR=$(jeiko_shell_quote "${VENV_DIR:-${BASE_DIR:-}/$site/venv}")"
        echo "GUNICORN_SERVICE=$(jeiko_shell_quote "${GUNICORN_SERVICE:-gunicorn-$site}")"
        echo "DB_NAME=$(jeiko_shell_quote "${DB_NAME:-}")"
        echo "DB_USER=$(jeiko_shell_quote "${DB_USER:-}")"
        echo "DB_PASS=$(jeiko_shell_quote "${DB_PASS:-}")"
        echo "ENABLE_SSL=$(jeiko_shell_quote "${ENABLE_SSL:-n}")"
        echo "ADMIN_SSH_USER=$(jeiko_shell_quote "${ADMIN_SSH_USER:-}")"
        # Canal de distribution : d'où proviennent les mises à jour.
        echo "JEIKO_CHANNEL_URL=$(jeiko_shell_quote "${JEIKO_CHANNEL_URL:-$JEIKO_DEFAULT_CHANNEL_URL}")"
        echo "INSTALLED_AT=$(jeiko_shell_quote "${INSTALLED_AT:-$(date -Is)}")"
        echo ""
        echo "# Copie hors-site des sauvegardes. Vide = désactivée : les"
        echo "# sauvegardes restent alors sur la même machine que le site, et"
        echo "# disparaissent avec lui."
        echo "#   rclone:mon-remote:/jeiko    ou    rsync:user@hote:/sauvegardes"
        echo "JEIKO_OFFSITE_TARGET=$(jeiko_shell_quote "${JEIKO_OFFSITE_TARGET:-}")"
        echo "# Fichier contenant la phrase secrète GPG (root:root 0600). Sans"
        echo "# elle, la base part en clair hors de la machine."
        echo "JEIKO_OFFSITE_PASSPHRASE_FILE=$(jeiko_shell_quote "${JEIKO_OFFSITE_PASSPHRASE_FILE:-}")"
    } >"$tmp"

    mv -f "$tmp" "$conf"
    chown root:root "$conf"
    chmod 0600 "$conf"
}

# Charge une fiche de site dans l'environnement courant.
jeiko_load_site() {
    local site="$1"
    jeiko_validate_site_name "$site" || return 1
    local conf; conf="$(jeiko_site_conf_path "$site")"
    [[ -r "$conf" ]] || {
        jeiko_err "Fiche de site introuvable : $conf"
        jeiko_err "Site jamais installé, ou pas encore migré (voir migrate_site.sh)."
        return 1
    }
    # shellcheck disable=SC1090
    source "$conf"
    : "${PROJECT_DIR:?PROJECT_DIR absent de $conf}"
    : "${SITE_USER:?SITE_USER absent de $conf}"
    : "${VENV_DIR:?VENV_DIR absent de $conf}"
    return 0
}

jeiko_list_sites() {
    [[ -d "$JEIKO_SITES_DIR" ]] || return 0
    find "$JEIKO_SITES_DIR" -maxdepth 1 -name '*.conf' -printf '%f\n' 2>/dev/null \
        | sed 's/\.conf$//' | sort
}

# Quoting sûr pour réinjection dans un fichier sourcé par bash.
#
# Le motif de remplacement passe par des variables plutôt que par une cascade
# d'échappements littéraux : écrite en une seule expression, la substitution
# produisait une chaîne mal formée dès que la valeur contenait une apostrophe —
# un mot de passe PostgreSQL avec une apostrophe rendait la fiche du site
# illisible, donc le site immettable à jour.
jeiko_shell_quote() {
    local s="${1-}"
    local quote="'"
    local escaped="'\\''"
    printf "'%s'" "${s//$quote/$escaped}"
}

# --------------------------------------------------------------------------- #
# Exécution sous l'identité du site
#
# On passe par `runuser -u <user> -- cmd args…` : la commande est exécutée par
# execvp, sans shell intermédiaire. L'ancienne implémentation construisait une
# chaîne injectée dans `bash -s <<EOF`, ce qui exposait chaque variable
# (chemins, URL, nom de site) à une interprétation shell.
# --------------------------------------------------------------------------- #
jeiko_as_site() {
    local user="$1"; shift
    [[ $# -gt 0 ]] || { jeiko_err "jeiko_as_site: aucune commande fournie."; return 2; }
    # Depuis `/`, jamais depuis le dossier courant de l'exploitant (28/09/2026).
    # `python -` et `python -c` placent le dossier courant en TÊTE de sys.path :
    # lancé depuis /var/www/jeiko-installer, où traînait un dossier `jeiko/`
    # d'une ancienne archive, `import jeiko` trouvait ce dossier au lieu du
    # package installé. Le réalignement de settings.py était sauté, `check`
    # échouait et la mise à jour 3.5.0 repartait en arrière sur tous les sites.
    # Tous les chemins transmis ici sont absolus : le dossier courant ne sert
    # à rien, il ne peut que nuire.
    #
    # Deux protections, posées DANS le sous-shell pour ne rien changer chez
    # l'appelant (rapport du 05/10) :
    #  · on ferme les descripteurs de verrou (6,7,8,9) avant de redescendre vers
    #    le compte du site — tenu pour compromis. runuser les lui laisserait
    #    hériter : une prise en écriture sur les verrous de /run et sur un
    #    verrou root ouvert (P1-b). Fermer un descripteur non ouvert est sans
    #    effet, donc inoffensif dans les contextes qui n'ont pas tous ces fd.
    #  · setsid détache du terminal de contrôle de l'exploitant quand l'outil
    #    est lancé en SSH : sans ça, le code du site pourrait y réinjecter des
    #    frappes (ioctl TIOCSTI, CVE-2016-2779 ; P1-f). `-w` attend la fin et
    #    rend le code de sortie de la commande ; l'entrée standard (un éventuel
    #    tube, pour jeiko_site_ecrire) est conservée.
    local detache=()
    command -v setsid >/dev/null 2>&1 && detache=(setsid -w)
    if command -v runuser >/dev/null 2>&1; then
        ( exec 6>&- 7>&- 8>&- 9>&-; cd / && "${detache[@]}" runuser -u "$user" -- "$@" )
    else
        ( exec 6>&- 7>&- 8>&- 9>&-; cd / && "${detache[@]}" sudo -n -u "$user" -- "$@" )
    fi
}

# --------------------------------------------------------------------------- #
# Fichiers de l'arborescence d'un site : jamais touchés par root
#
# Le compte du site possède son dossier de projet : il peut y remplacer à tout
# moment un fichier par un lien symbolique. Root qui lit, écrit, `chown` ou
# `chmod` un chemin de cette arborescence suit le lien — vers /etc/shadow, par
# exemple (audit du 04/10/2026, I-01 et I-04). La règle est donc : ce qui se
# trouve chez le site se lit et s'écrit SOUS SON COMPTE. Un lien piégé ne mène
# alors qu'à ce que le site pouvait déjà atteindre.
#
# Le seul geste root qui reste est `chown -h`, qui agit sur le lien lui-même et
# jamais sur sa cible (il sert à réparer un fichier qui aurait changé de
# propriétaire).
# --------------------------------------------------------------------------- #

# Remplace le contenu de <chemin> par l'entrée standard, sous le compte du site.
# Écriture dans un fichier voisin puis renommage : jamais de fichier à moitié
# écrit, et un fichier existant appartenant à quelqu'un d'autre est remplacé
# (le dossier appartient au site) au lieu de faire échouer l'écriture.
# Le fichier provisoire naît en 0600 (umask 077) et ne prend son mode qu'une
# fois écrit : un .env ne passe jamais, même un instant, par un mode lisible
# par d'autres.
# Usage : <contenu> | jeiko_site_ecrire <compte> <chemin> <mode>
jeiko_site_ecrire() {
    local user="$1" chemin="$2" mode="$3"
    jeiko_as_site "$user" sh -c '
        umask 077
        t="$1.jeiko-tmp.$$"
        if cat >"$t" && chmod "$2" "$t" && mv -f "$t" "$1"; then exit 0; fi
        rm -f "$t"; exit 1
    ' sh "$chemin" "$mode"
}

# Ajoute une ligne à <chemin>, sous le compte du site. S'il n'existait pas, il
# naît en 0600, comme ci-dessus.
# Usage : jeiko_site_ajouter <compte> <chemin> <ligne>
jeiko_site_ajouter() {
    printf '%s\n' "$3" | jeiko_as_site "$1" sh -c 'umask 077; cat >>"$1"' sh "$2"
}

# Vrai si <chemin> contient une affectation « NOM= », lu sous le compte du site.
# Usage : jeiko_site_a_la_cle <compte> <chemin> <NOM>
jeiko_site_a_la_cle() {
    jeiko_as_site "$1" grep -qE "^[[:space:]]*$3[[:space:]]*=" -- "$2" 2>/dev/null
}

# --------------------------------------------------------------------------- #
# Droits sudo d'un site — un seul exemplaire
#
# Ce fichier était écrit à DEUX endroits (14_finalize.sh à l'installation,
# jeiko-server-update à chaque convergence) : une règle ajoutée à l'un et pas à
# l'autre disparaissait à la convergence suivante, ou manquait aux installations
# neuves. Il est désormais écrit ici seulement.
#
# L'application ne peut que DÉCLENCHER des unités systemd dont l'ExecStart est
# un binaire root:root hors de son arborescence, et redémarrer son propre
# service. Rien d'autre, à l'argument près : sudo compare la ligne entière.
#   · jeiko-update@<site>         — mise à jour du paquet de CE site ;
#   · jeiko-maj-serveur@<site>    — mise à jour du serveur demandée par ce site
#                                   (n'agit que si un installeur plus récent
#                                   est publié : voir jeiko-maj) ;
#   · restart de son gunicorn.
#
# Ni « !syslog » (il effaçait la trace sudo du compte le plus exposé du
# système), ni « reload nginx » (nginx est partagé par tous les sites).
# Usage : jeiko_ecrire_sudoers <site> <compte> <service gunicorn>
# --------------------------------------------------------------------------- #
jeiko_ecrire_sudoers() {
    jeiko_require_root
    local site="$1" user="$2" service="$3"
    jeiko_validate_site_name "$site" || return 1
    jeiko_require_systemctl_path || return 1

    local cible="/etc/sudoers.d/jeiko-$site" tmp
    tmp="$(mktemp)"
    cat >"$tmp" <<EOF
# Droits accordés à l'application JEIKO du site « $site ».
# Généré par l'outillage JEIKO (jeiko_ecrire_sudoers) — ne pas éditer à la main.
#
# L'application ne peut que déclencher des unités dont l'ExecStart est un
# binaire root:root hors de son arborescence, et redémarrer son propre service.

Defaults:$user !requiretty

$user ALL=(root) NOPASSWD: $JEIKO_SYSTEMCTL start --no-block jeiko-update@$site.service
$user ALL=(root) NOPASSWD: $JEIKO_SYSTEMCTL start --no-block jeiko-maj-serveur@$site.service
$user ALL=(root) NOPASSWD: $JEIKO_SYSTEMCTL restart $service.service
EOF
    # visudo AVANT la mise en place : un sudoers invalide rend sudo inutilisable
    # sur toute la machine, y compris pour le réparer.
    if ! visudo -cqf "$tmp"; then
        rm -f "$tmp"
        jeiko_err "sudoers généré invalide pour « $site », non installé."
        return 1
    fi
    install -m 0440 -o root -g root "$tmp" "$cible"
    rm -f "$tmp"
    return 0
}

# La mise à jour est-elle déclenchable depuis l'application ?
#
# `sudo -l <commande>` répond si la règle sudoers autorise CETTE commande, à
# l'argument près, sans rien exécuter. Le contrôle précédent démarrait une vraie
# mise à jour puis l'arrêtait au bout de 2 s : si une version plus récente du
# paquet était publiée, l'arrêt pouvait tomber en plein `pip install` et laisser
# le venv à moitié installé (audit du 04/10/2026, I-05).
# Usage : jeiko_verifier_declenchement <site> <compte> [préfixe d'unité]
#         (préfixe : jeiko-update par défaut, ou jeiko-maj-serveur)
jeiko_verifier_declenchement() {
    jeiko_as_site "$2" sudo -n -l "$JEIKO_SYSTEMCTL" start --no-block "${3:-jeiko-update}@$1.service" \
        >/dev/null 2>&1
}

# Lance manage.py sous l'identité du site, avec le python du venv.
# Usage : jeiko_manage <project_dir> <venv_dir> <site_user> migrate --noinput
jeiko_manage() {
    local project_dir="$1" venv_dir="$2" site_user="$3"; shift 3
    local py="$venv_dir/bin/python"
    [[ -x "$py" ]] || { jeiko_err "Python du venv introuvable : $py"; return 1; }
    # PYTHONNOUSERSITE empêche un ~/.local/lib parasite de masquer le venv.
    jeiko_as_site "$site_user" env \
        PYTHONNOUSERSITE=1 \
        PYTHONUNBUFFERED=1 \
        HOME="$project_dir" \
        "$py" "$project_dir/manage.py" "$@"
}

# --------------------------------------------------------------------------- #
# Permissions — implémentation unique
# --------------------------------------------------------------------------- #

# Applique le modèle canonique à l'arborescence d'un site.
# Le venv est traité à part : ses binaires doivent rester exécutables.
jeiko_fix_perms() {
    jeiko_require_root
    local project_dir="$1" site_user="$2" site_name="$3"
    local venv_dir="${4:-$project_dir/venv}"

    [[ -d "$project_dir" ]] || { jeiko_err "Dossier projet introuvable : $project_dir"; return 1; }

    jeiko_log "🔐 Application des permissions sur $project_dir…"

    local env_path="$project_dir/$site_name/.env"

    # ─────────────────────────────────────────────────────────────────────────
    # L'arborescence appartient au site, qui peut y poser un lien symbolique à
    # tout instant. Deux gestes seulement restent en root, et aucun ne suit un
    # lien : `chown -Rh` (agit sur le lien, jamais sur sa cible). TOUT le reste
    # — création des dossiers, chmod — se fait SOUS LE COMPTE DU SITE.
    #
    # C'était la dernière course de l'audit du 04/10 laissée ouverte (I-06,
    # « limite connue ») : les `find … | xargs chmod` tournaient en root, et un
    # lien substitué entre le parcours et le chmod faisait poser un mode sur un
    # fichier root. On la tenait pour bénigne (« panne, pas élévation ») — à
    # tort : le site peut rejouer cette passe à volonté (jeiko-update@ sans
    # limite de fréquence), et un 0640 posé sur le .env d'un VOISIN le rend
    # lisible par www-data, groupe que tous les gunicorn portent — fuite de
    # secrets entre sites (rapport du 05/10, P1-c). Sous son compte, le site ne
    # pose que des modes qu'il a déjà le droit de poser, sur ce qu'il possède :
    # un lien substitué ne mène qu'à ce qu'il atteignait déjà.
    #
    # Le bit setgid des dossiers (2750) : le site l'applique car il est membre
    # de www-data (02_users_dirs). D'abord le propriétaire et le groupe (root,
    # sûr), ENSUITE les modes (site), pour que le groupe soit bien www-data au
    # moment où le setgid est posé.
    # ─────────────────────────────────────────────────────────────────────────
    local d
    for d in staticdir mediadir logs; do
        if [[ -L "$project_dir/$d" ]]; then
            jeiko_warn "$project_dir/$d est un lien symbolique : remplacé par un vrai répertoire."
        fi
        # Remplacement d'un éventuel lien ET création, d'un seul geste, sous le
        # compte du site : pas de fenêtre entre un rm root et un install root.
        jeiko_as_site "$site_user" sh -c '
            [ -L "$1" ] && rm -f "$1"
            mkdir -p "$1"' sh "$project_dir/$d"
    done

    chown -Rh "$site_user":www-data "$project_dir"

    # Les modes, sous le compte du site (voir ci-dessus). Les variables de mode
    # passent par l'environnement ; les chemins, en arguments positionnels.
    # shellcheck disable=SC2016  # $DIR_MODE/$1 s'expandent dans le shell enfant, pas ici
    jeiko_as_site "$site_user" env \
        DIR_MODE="$JEIKO_DIR_MODE" FILE_MODE="$JEIKO_FILE_MODE" EXEC_MODE="$JEIKO_EXEC_MODE" \
        sh -c '
            pd="$1"; venv="$2"; env="$3"
            # Hors venv : dossiers 2750, fichiers 0640. Un lien (ni -type d ni
            # -type f) est ignore. Le .env est exclu : il passerait sinon par
            # 0640 (lisible par www-data) entre ce chmod et son 0600 final.
            find "$pd" -path "$venv" -prune -o -type d -print0 | xargs -0r chmod "$DIR_MODE"
            find "$pd" -path "$venv" -prune -o -type f ! -path "$env" -print0 | xargs -0r chmod "$FILE_MODE"
            # Venv : lecture et execution pour le proprietaire et le groupe.
            if [ -d "$venv" ]; then
                find "$venv" -type d -print0 | xargs -0r chmod u=rwx,g=rx,o=
                find "$venv" -type f -print0 | xargs -0r chmod u=rw,g=r,o=
                if [ -d "$venv/bin" ]; then
                    chmod "$EXEC_MODE" "$venv/bin"
                    find "$venv/bin" -maxdepth 1 -type f -print0 | xargs -0r chmod "$EXEC_MODE"
                fi
            fi
        ' sh "$project_dir" "$venv_dir" "$env_path"

    # Exceptions explicites — déjà sous le compte du site : `[[ -f ]]` est vrai
    # pour un lien vers un fichier, et chmod suit le lien. Un manage.py remplacé
    # par un lien vers /usr/bin/sudo lui aurait fait perdre son bit setuid
    # (I-06). Le lien est écarté, et la course qui resterait ne mène qu'à des
    # fichiers que le site possède déjà.
    if [[ -f "$project_dir/manage.py" && ! -L "$project_dir/manage.py" ]]; then
        jeiko_as_site "$site_user" chmod "$JEIKO_EXEC_MODE" -- "$project_dir/manage.py" || true
    fi
    if [[ -f "$env_path" && ! -L "$env_path" ]]; then
        jeiko_as_site "$site_user" chmod "$JEIKO_SECRET_MODE" -- "$env_path" || true
    fi

    # /var/www doit rester traversable par nginx.
    local base_dir; base_dir="$(dirname "$project_dir")"
    chmod o+x "$base_dir" 2>/dev/null || true

    return 0
}

# Confort SSH : l'administrateur humain peut lire le projet sans sudo.
#
# Aucune ACL « par défaut » (d:u:) n'est posée. La version précédente en
# mettait une sur toute l'arborescence : tout fichier créé ensuite héritait du
# droit de lecture pour l'administrateur, y compris un .env recréé plus tard —
# le mot de passe de la base redevenait lisible sans sudo, en contradiction
# avec le 0600 affiché. Le confort de lecture ne justifiait pas cet écart.
jeiko_apply_admin_acl() {
    local project_dir="$1" admin_user="${2:-}"
    [[ -n "$admin_user" ]] || return 0
    id -u "$admin_user" >/dev/null 2>&1 || return 0
    command -v setfacl >/dev/null 2>&1 || { jeiko_warn "setfacl absent, ACL non appliquées."; return 0; }

    local base_dir; base_dir="$(dirname "$project_dir")"
    local site_name; site_name="$(basename "$project_dir")"

    setfacl -m "u:$admin_user:rx" "$base_dir" 2>/dev/null || true
    setfacl -R -m "u:$admin_user:rX" "$project_dir" 2>/dev/null || true

    # Les secrets restent des secrets, ACL ou pas. L'échec est signalé plutôt
    # que silencieusement avalé : si le retrait ne prend pas, l'administrateur
    # conserve un accès en lecture au mot de passe de la base.
    local env_path="$project_dir/$site_name/.env"
    if [[ -f "$env_path" ]]; then
        if ! setfacl -x "u:$admin_user" "$env_path" 2>/dev/null; then
            jeiko_warn "ACL non retirée de $env_path — vérifier : getfacl $env_path"
        fi
    fi
}

# --------------------------------------------------------------------------- #
# Réseau / intégrité
# --------------------------------------------------------------------------- #

# Télécharge dans un fichier, sans pipe vers un interpréteur.
jeiko_download() {
    local url="$1" dest="$2"
    curl -fsSL --proto '=https' --tlsv1.2 \
         --retry 4 --retry-connrefused --retry-delay 2 \
         --max-time 300 --speed-time 30 --speed-limit 1024 \
         -o "$dest" "$url"
}

# Vérifie un sha256 attendu. C'est le seul garde-fou entre le dépôt distant et
# l'exécution de code sur la machine : ne jamais rendre cet appel optionnel.
jeiko_verify_sha256() {
    local file="$1" expected="$2"
    [[ -s "$file" ]] || { jeiko_err "Fichier vide ou absent : $file"; return 1; }
    [[ "$expected" =~ ^[a-f0-9]{64}$ ]] || { jeiko_err "Empreinte sha256 malformée : '$expected'"; return 1; }

    local actual
    actual="$(sha256sum "$file" | awk '{print $1}')"
    if [[ "$actual" != "$expected" ]]; then
        jeiko_err "Empreinte sha256 incorrecte pour $(basename "$file")."
        jeiko_err "  attendue : $expected"
        jeiko_err "  obtenue  : $actual"
        return 1
    fi
    jeiko_ok "Empreinte sha256 vérifiée ($(basename "$file"))."
    return 0
}

# --------------------------------------------------------------------------- #
# Récupération vérifiée du package JEIKO
#
# Deux fonctions, utilisées par l'installation initiale (script 08) comme par
# jeiko-update. Une seule implémentation, donc pas de chemin « rapide » où le
# sha256 serait contourné — c'est le point où un package altéré entrerait dans
# le système.
# --------------------------------------------------------------------------- #

# Lit version.json et renseigne JEIKO_PKG_VERSION / _WHEEL_NAME / _WHEEL_SHA.
# Ne télécharge pas le package : permet à `--check` de comparer les versions
# sans rapatrier plusieurs mégaoctets.
jeiko_read_manifest() {
    local channel="$1" tmp="$2"

    # Le python SYSTÈME, jamais celui du venv : ce dernier appartient à
    # l'utilisateur du site, et l'exécuter en root lui rendrait précisément les
    # privilèges qu'on cherche à lui retirer.
    local system_py; system_py="$(command -v python3 || true)"
    [[ -x "$system_py" ]] || { jeiko_err "python3 système introuvable."; return 1; }

    local manifest="$tmp/version.json"
    jeiko_download "$channel/version.json" "$manifest" || {
        jeiko_err "version.json introuvable sur $channel"
        jeiko_err "Génère-le depuis le dépôt jeiko avec : ./release.sh <version>"
        return 1
    }

    local version wheel sha
    read -r version wheel sha < <("$system_py" - "$manifest" <<'PY'
import json, sys
try:
    d = json.load(open(sys.argv[1], encoding="utf-8"))
except (OSError, ValueError):
    d = {}
print(d.get("version", ""), d.get("wheel", ""), d.get("sha256", ""))
PY
)

    [[ -n "$version" && -n "$wheel" && -n "$sha" ]] || {
        jeiko_err "Manifeste incomplet ou illisible : version, wheel et sha256 sont requis."
        return 1
    }
    # Le nom du wheel provient du réseau et sert à construire un chemin local :
    # sans ce bornage, un manifeste hostile écrirait où il veut sur le disque.
    [[ "$wheel" =~ ^[A-Za-z0-9._+-]+\.whl$ ]] || {
        jeiko_err "Nom de wheel refusé : '$wheel'"
        return 1
    }

    JEIKO_PKG_VERSION="$version"
    JEIKO_PKG_WHEEL_NAME="$wheel"
    JEIKO_PKG_WHEEL_SHA="$sha"
    return 0
}

# Télécharge le wheel décrit par le manifeste et vérifie son empreinte.
# Renseigne JEIKO_PKG_WHEEL (chemin local). À appeler après jeiko_read_manifest.
jeiko_fetch_wheel() {
    local channel="$1" tmp="$2"
    : "${JEIKO_PKG_WHEEL_NAME:?jeiko_read_manifest doit être appelé avant}"

    local dest="$tmp/$JEIKO_PKG_WHEEL_NAME"
    jeiko_download "$channel/dist/$JEIKO_PKG_WHEEL_NAME" "$dest" \
        || { jeiko_err "Téléchargement du wheel impossible."; return 1; }
    jeiko_verify_sha256 "$dest" "$JEIKO_PKG_WHEEL_SHA" || return 1

    JEIKO_PKG_WHEEL="$dest"
    return 0
}

# Enchaînement des deux, pour l'installation initiale.
jeiko_fetch_package() {
    jeiko_read_manifest "$1" "$2" && jeiko_fetch_wheel "$1" "$2"
}

# --------------------------------------------------------------------------- #
# Versions de l'outillage serveur — « le serveur avant les sites »
#
# Deux repères, et pas un :
#   · $JEIKO_ASSET_DIR/VERSION — l'installeur dont l'outillage est DÉPOSÉ
#     (écrit par migrate_site.sh --tools-only et par l'installation) ;
#   · $JEIKO_LIB_DIR/<site>/serveur.version — l'installeur avec lequel CE site
#     a été CONVERGÉ avec succès (écrit par jeiko-server-update et par
#     l'installation).
# Un seul repère, posé au dépôt, aurait fait croire « à jour » un serveur dont
# la convergence avait échoué à mi-parcours : elle n'aurait jamais été
# reprise. Et c'est site par site que se vérifie l'ordre exigé par
# jeiko-client-update : le paquet d'un site ne passe qu'après la convergence de
# CE site avec l'installeur publié.
# --------------------------------------------------------------------------- #

# Vrai si la version <a> est STRICTEMENT plus récente que <b> (vide = 0).
jeiko_version_superieure() {
    local a="${1:-0}" b="${2:-0}"
    [[ "$a" != "$b" ]] && [[ "$(printf '%s\n%s\n' "$a" "$b" | sort -V | tail -n1)" == "$a" ]]
}

# Lit une version dans un fichier root ; « 0 » si absent ou mal formé.
jeiko_lire_version() {
    local v=""
    [[ -f "$1" && ! -L "$1" ]] && v="$(head -c 32 "$1" | tr -d ' \n\r')"
    [[ "$v" =~ ^[0-9]+(\.[0-9]+){0,3}$ ]] || v="0"
    printf '%s' "$v"
}

jeiko_version_outillage() { jeiko_lire_version "$JEIKO_ASSET_DIR/VERSION"; }

jeiko_version_convergee() { jeiko_lire_version "$JEIKO_LIB_DIR/$1/serveur.version"; }

# Note qu'un site vient d'être convergé avec <version>. Le fichier est lisible
# par le site (son administration l'affiche), modifiable par root seul.
# Usage : jeiko_noter_convergence <site> <compte> <version>
jeiko_noter_convergence() {
    local dossier="$JEIKO_LIB_DIR/$1"
    install -d -m 0750 -o root -g "$2" "$dossier"
    printf '%s\n' "$3" >"$dossier/serveur.version.tmp"
    chown root:"$2" "$dossier/serveur.version.tmp"
    chmod 0640 "$dossier/serveur.version.tmp"
    mv -f "$dossier/serveur.version.tmp" "$dossier/serveur.version"
}

# Verdict du contrôle de santé d'une convergence, d'après le code HTTP du site
# AVANT qu'on y touche et APRÈS (jeiko-server-update, étape 8) :
#   ok    — il répond (1xx/2xx/3xx) ;
#   avert — il répond mais route mal (4xx) : debout, on n'échoue pas ;
#   deja  — il ne répond pas, mais ne répondait déjà pas avant : ce n'est pas
#           la convergence qui l'a cassé. L'en accuser bloquerait son paquet
#           (jeiko-client-update exige un site convergé) — donc la mise à jour
#           même qui peut le réparer ;
#   casse — il répondait avant, plus maintenant : la convergence l'a cassé, et
#           casserait de même les sites suivants.
# Usage : jeiko_verdict_de_sante <code avant> <code après>
jeiko_verdict_de_sante() {
    if [[ "$2" =~ ^[123] ]]; then echo ok
    elif [[ "$2" =~ ^4 ]]; then echo avert
    elif [[ "$1" =~ ^[1234] ]]; then echo casse
    else echo deja
    fi
}

# Lit le manifeste de l'installeur publié et renseigne JEIKO_INST_VERSION,
# JEIKO_INST_ARCHIVE et JEIKO_INST_SHA256. Le python du SYSTÈME, comme pour le
# paquet. Chaque champ est borné : le nom d'archive sert à construire une URL
# et un chemin local.
# Usage : jeiko_lire_manifeste_installeur <dossier temporaire root>
jeiko_lire_manifeste_installeur() {
    local tmp="$1" system_py lu
    system_py="$(command -v python3 || true)"
    [[ -x "$system_py" ]] || { jeiko_err "python3 système introuvable."; return 1; }
    jeiko_download "$JEIKO_INSTALLER_CHANNEL_URL/version.json" "$tmp/installeur.json" || {
        jeiko_err "Manifeste de l'installeur injoignable ($JEIKO_INSTALLER_CHANNEL_URL/version.json)."
        return 1
    }
    lu="$("$system_py" - "$tmp/installeur.json" <<'PY'
import json, re, sys
try:
    d = json.load(open(sys.argv[1], encoding="utf-8"))
except (OSError, ValueError):
    sys.exit(1)
version, archive, sha = (str(d.get(k, "")) for k in ("version", "archive", "sha256"))
if not (re.fullmatch(r"[0-9]+\.[0-9]+\.[0-9]+", version)
        and archive == "jeiko-installer-v%s.zip" % version
        and re.fullmatch(r"[a-f0-9]{64}", sha)):
    sys.exit(1)
print(version, archive, sha)
PY
)" || { jeiko_err "Manifeste de l'installeur illisible ou incomplet."; return 1; }
    # shellcheck disable=SC2034  # lues par les appelants (jeiko-maj, jeiko-client-update)
    read -r JEIKO_INST_VERSION JEIKO_INST_ARCHIVE JEIKO_INST_SHA256 <<<"$lu"
    return 0
}

# --------------------------------------------------------------------------- #
# Chemin de systemctl
#
# La règle sudoers et la commande émise par la vue Django doivent correspondre
# AU CARACTÈRE PRÈS : sudo compare la ligne de commande complète, pas seulement
# le binaire. /bin/systemctl et /usr/bin/systemctl désignent le même fichier sur
# Debian (usrmerge) mais sont deux chaînes différentes pour sudo.
# On fige donc /usr/bin/systemctl des deux côtés.
# --------------------------------------------------------------------------- #
JEIKO_SYSTEMCTL="/usr/bin/systemctl"

jeiko_require_systemctl_path() {
    if [[ ! -x "$JEIKO_SYSTEMCTL" ]]; then
        local found; found="$(command -v systemctl || true)"
        jeiko_err "systemctl attendu en $JEIKO_SYSTEMCTL, trouvé : ${found:-nulle part}."
        jeiko_err "La règle sudoers et la vue Django doivent viser le même chemin."
        return 1
    fi
    return 0
}

# --------------------------------------------------------------------------- #
# systemd
# --------------------------------------------------------------------------- #
jeiko_unit_exists() {
    systemctl list-unit-files "$1" >/dev/null 2>&1 && \
    systemctl list-unit-files --no-legend "$1" | grep -q .
}

jeiko_restart_if_exists() {
    local unit="$1"
    if jeiko_unit_exists "$unit"; then
        jeiko_log "🔁 Redémarrage de $unit…"
        systemctl restart "$unit"
    else
        jeiko_warn "Unité absente, ignorée : $unit"
    fi
}

# --------------------------------------------------------------------------- #
# Tâches planifiées
#
# Le serveur ne connaît aucune cadence à l'avance : il demande la liste au
# package (`manage.py jeiko_cron_units --json`) et s'y conforme. Ajouter un
# fichier `cron_<cadence>.py` dans jeiko fait donc apparaître le timer à la
# prochaine mise à jour serveur ; le retirer fait disparaître le timer.
#
# Une unité modèle par cadence, instanciée par site :
#   jeiko-cron-5m@monsite.timer  ->  jeiko-cron-5m@monsite.service
# --------------------------------------------------------------------------- #

# Liste les cadences actuellement installées POUR UN SITE.
#
# On s'appuie sur les drop-ins plutôt que sur les gabarits : ces derniers sont
# partagés entre tous les sites de la machine, alors que le drop-in est la
# marque qu'une cadence a bien été déployée pour ce site-là.
# Usage : jeiko_installed_cron_cadences <site>
jeiko_installed_cron_cadences() {
    local site="$1" dir base
    for dir in "/etc/systemd/system/jeiko-cron-"*"@$site.service.d"; do
        [[ -d "$dir" ]] || continue
        base="$(basename "$dir")"           # jeiko-cron-5m@monsite.service.d
        base="${base#jeiko-cron-}"
        printf '%s\n' "${base%%@*}"
    done
}

# Écrit (ou met à jour) le couple service+timer d'une cadence.
#
# Les gabarits sont PARTAGÉS par tous les sites de la machine : ils ne doivent
# donc contenir que ce qui est commun à tous. Rien de propre à un site — ni les
# chemins, ni l'horaire — ne peut y figurer, sinon deux sites installés sur des
# versions différentes de JEIKO se voleraient mutuellement leur configuration,
# le dernier convergé imposant la sienne aux autres.
#
# D'où l'absence délibérée de ExecStart/User côté service et de OnCalendar côté
# timer : tout cela vient des drop-ins par site. Une unité incomplète est un
# choix — si son drop-in manquait, systemd refuserait de la démarrer, ce qui
# est un échec visible plutôt qu'un cron tournant sur la mauvaise cadence.
#
# Usage : jeiko_write_cron_unit <cadence>
jeiko_write_cron_unit() {
    local cadence="$1"
    local service="/etc/systemd/system/jeiko-cron-$cadence@.service"
    local timer="/etc/systemd/system/jeiko-cron-$cadence@.timer"

    cat >"$service" <<EOF
# Généré par jeiko-server-update — ne pas éditer à la main.
# Gabarit PARTAGÉ : cadence « $cadence », toutes instances de site confondues.
# Le contenu des jobs vit dans le package (commande manage.py cron_$cadence).
# ExecStart, User et WorkingDirectory sont fournis par
# /etc/systemd/system/jeiko-cron-$cadence@<site>.service.d/site.conf
[Unit]
Description=Tâches planifiées $cadence — site %i
After=network-online.target postgresql.service
Wants=network-online.target

[Service]
Type=oneshot
Environment=PYTHONNOUSERSITE=1
Environment=PYTHONUNBUFFERED=1

# Un job qui traîne ne doit pas chevaucher le déclenchement suivant.
TimeoutStartSec=900

StandardOutput=journal
StandardError=journal
# %i dans l'identifiant : les journaux de deux sites ne doivent pas se mélanger.
SyslogIdentifier=jeiko-cron-$cadence-%i

# ProtectHome n'est volontairement pas activé : le projet et son venv vivent
# sous /home/<compte du site>, et certains jobs y écrivent (médias, journaux).
NoNewPrivileges=yes
PrivateTmp=yes
ProtectSystem=full
ProtectKernelTunables=yes
ProtectKernelModules=yes
ProtectControlGroups=yes
RestrictRealtime=yes
LockPersonality=yes
EOF

    cat >"$timer" <<EOF
# Généré par jeiko-server-update — ne pas éditer à la main.
# Gabarit PARTAGÉ. L'horaire est propre à chaque site : il est défini dans
# /etc/systemd/system/jeiko-cron-$cadence@<site>.timer.d/site.conf
[Unit]
Description=Déclenchement $cadence des tâches planifiées — site %i

[Timer]
Unit=jeiko-cron-$cadence@%i.service

[Install]
WantedBy=timers.target
EOF

    chmod 0644 "$service" "$timer"
}

# Fixe tout ce qui est propre à un site pour une cadence donnée : ses chemins
# et son horaire. C'est ce qui permet à deux sites de la même machine de tourner
# sur des versions différentes de JEIKO sans se marcher dessus.
#
# Usage : jeiko_write_cron_dropin <cadence> <site> <project_dir> <venv_dir> \
#                                 <site_user> <on_calendar> <persistent> <delay> \
#                                 [description]
jeiko_write_cron_dropin() {
    local cadence="$1" site="$2" project_dir="$3" venv_dir="$4" site_user="$5"
    local on_calendar="$6" persistent="$7" delay="$8"
    local description="${9:-Tâches planifiées $cadence}"
    local svc_dir="/etc/systemd/system/jeiko-cron-$cadence@$site.service.d"
    local tmr_dir="/etc/systemd/system/jeiko-cron-$cadence@$site.timer.d"

    install -d -m 0755 -o root -g root "$svc_dir" "$tmr_dir"

    # La description vient du package installé SUR CE SITE : `systemctl status`
    # affiche donc ce que fait réellement la cadence dans sa version à lui.
    cat >"$svc_dir/site.conf" <<EOF
# Généré par jeiko-server-update — ne pas éditer à la main.
# Chemins du site « $site », relus à chaque convergence depuis sa fiche.
[Unit]
Description=$description — site $site

[Service]
User=$site_user
WorkingDirectory=$project_dir
ExecStart=$venv_dir/bin/python $project_dir/manage.py cron_$cadence
EOF

    # OnCalendar s'ACCUMULE d'un fragment à l'autre : la ligne vide remet le
    # compteur à zéro avant de poser la valeur du site. Sans elle, une cadence
    # modifiée dans le package s'ajouterait à l'ancienne au lieu de la remplacer.
    cat >"$tmr_dir/site.conf" <<EOF
# Généré par jeiko-server-update — ne pas éditer à la main.
# Horaire du site « $site », tel que déclaré par SA version du package.
[Timer]
OnCalendar=
OnCalendar=$on_calendar
# Étalement : plusieurs sites cohabitent, leurs timers ne doivent pas partir
# à la même seconde et se disputer la base.
RandomizedDelaySec=$delay
Persistent=$persistent
EOF

    chmod 0644 "$svc_dir/site.conf" "$tmr_dir/site.conf"
}

# Lit sur l'entrée standard le JSON de `manage.py jeiko_cron_units --json` et
# rend une ligne par cadence ACCEPTÉE : cadence, OnCalendar, persistant,
# délai, description — séparés par des tabulations.
#
# Les bornes sont celles de ce qu'une unité systemd peut recevoir sans risque :
#   · cadence     : 1 à 4 chiffres et m/h/d (sert de nom de fichier) ;
#   · OnCalendar  : lettres, chiffres, espace et « *:/,.~- » — de quoi écrire
#                   « *:0/5 » ou « Mon *-*-* 03:30:00 », rien qui ouvre une
#                   ligne ou une section ;
#   · délai       : entier de 0 à 86 400 ;
#   · description : caractères imprimables, sans « \ » (continuation de ligne)
#                   ni « % » (spécificateurs systemd), 120 au plus.
# Un enregistrement hors bornes est écarté, et dit sur la sortie d'erreur ; les
# autres restent planifiés.
# Usage : <json> | jeiko_lire_les_cadences <python3 système>
jeiko_lire_les_cadences() {
    "$1" -c '
import json, re, sys

CADENCE = re.compile(r"[0-9]{1,4}[mhd]")
CALENDRIER = re.compile(r"[A-Za-z0-9 *:/,.~-]{1,80}")

def propre(texte):
    texte = "".join(c for c in str(texte) if c.isprintable() and c not in "\\%")
    return " ".join(texte.split())[:120]

try:
    specs = json.load(sys.stdin)
except ValueError:
    sys.exit(1)
if not isinstance(specs, list):
    sys.exit(1)

for spec in specs:
    if not isinstance(spec, dict):
        continue
    cadence = str(spec.get("cadence", ""))
    calendrier = str(spec.get("on_calendar", ""))
    try:
        delai = int(spec.get("randomized_delay_sec") or 0)
    except (TypeError, ValueError):
        delai = -1
    if not (CADENCE.fullmatch(cadence) and CALENDRIER.fullmatch(calendrier)
            and 0 <= delai <= 86400):
        print("cadence écartée (valeurs hors bornes) : %r" % cadence[:40], file=sys.stderr)
        continue
    print("\t".join([
        cadence,
        calendrier,
        "true" if spec.get("persistent") else "false",
        str(delai),
        propre(spec.get("description") or ""),
    ]))
'
}

# Converge les timers d'un site sur ce que déclare le package.
# Usage : jeiko_sync_cron_timers <site> <project_dir> <venv_dir> <site_user> [dry_run]
jeiko_sync_cron_timers() {
    jeiko_require_root
    local site="$1" project_dir="$2" venv_dir="$3" site_user="$4" dry_run="${5:-0}"

    local specs
    if ! specs="$(jeiko_manage "$project_dir" "$venv_dir" "$site_user" \
                    jeiko_cron_units --json 2>/dev/null)"; then
        jeiko_warn "Impossible d'interroger les cadences (jeiko_cron_units absent ?) — timers inchangés."
        return 0
    fi
    [[ -n "$specs" ]] || { jeiko_warn "Aucune cadence retournée par le package."; return 0; }

    # Ce JSON vient du code du site : il est lu par le python du SYSTÈME, et
    # chaque champ est borné avant d'entrer dans une unité systemd écrite par
    # root (audit du 04/10/2026, I-02 et I-03). Avant, c'était le python du
    # venv — que le site possède : un sitecustomize.py s'y exécutait en root —
    # et les valeurs passaient telles quelles : un retour à la ligne dans la
    # description ajoutait « ExecStartPre=+… » (exécuté en root malgré User=),
    # un « ../ » dans la cadence faisait écrire hors de /etc/systemd/system.
    local system_py; system_py="$(command -v python3 || true)"
    [[ -x "$system_py" ]] || { jeiko_warn "python3 système introuvable — timers inchangés."; return 0; }

    local parsed
    if ! parsed="$(printf '%s' "$specs" | jeiko_lire_les_cadences "$system_py")"; then
        jeiko_warn "Réponse de jeiko_cron_units illisible — timers inchangés."
        return 0
    fi

    local wanted=() cadence on_calendar persistent delay description
    while IFS=$'\t' read -r cadence on_calendar persistent delay description; do
        [[ -n "$cadence" ]] || continue
        wanted+=("$cadence")

        if [[ $dry_run -eq 1 ]]; then
            jeiko_log "   [simulation] cadence $cadence → $on_calendar (délai ${delay}s)"
            continue
        fi

        jeiko_write_cron_unit "$cadence"
        jeiko_write_cron_dropin "$cadence" "$site" "$project_dir" "$venv_dir" \
                                "$site_user" "$on_calendar" "$persistent" "$delay" \
                                "$description"
        jeiko_log "   cadence $cadence → $on_calendar (délai ${delay}s)"
    done <<<"$parsed"

    [[ ${#wanted[@]} -gt 0 ]] || { jeiko_warn "Aucune cadence exploitable."; return 0; }

    if [[ $dry_run -eq 1 ]]; then
        return 0
    fi

    systemctl daemon-reload

    # Activation de ce qui est déclaré.
    for cadence in "${wanted[@]}"; do
        systemctl enable --now "jeiko-cron-$cadence@$site.timer" >/dev/null 2>&1 \
            || jeiko_warn "Activation impossible : jeiko-cron-$cadence@$site.timer"
    done

    # Retrait de ce qui ne l'est plus. On ne supprime que l'instance du site ;
    # le gabarit reste tant qu'un autre site l'utilise.
    local installed keep
    for installed in $(jeiko_installed_cron_cadences "$site"); do
        keep=0
        for cadence in "${wanted[@]}"; do
            [[ "$installed" == "$cadence" ]] && { keep=1; break; }
        done
        if [[ $keep -eq 0 ]]; then
            jeiko_log "   cadence $installed retirée du package → désactivation"
            systemctl disable --now "jeiko-cron-$installed@$site.timer" >/dev/null 2>&1 || true
            rm -rf "/etc/systemd/system/jeiko-cron-$installed@$site.service.d" \
                   "/etc/systemd/system/jeiko-cron-$installed@$site.timer.d"

            # Le gabarit est partagé : on ne le supprime que si plus aucun site
            # ne l'utilise, sinon on casserait les autres sites de la machine.
            if ! compgen -G "/etc/systemd/system/jeiko-cron-$installed@*.service.d" >/dev/null; then
                rm -f "/etc/systemd/system/jeiko-cron-$installed@.timer" \
                      "/etc/systemd/system/jeiko-cron-$installed@.service"
            fi
        fi
    done

    systemctl daemon-reload
    jeiko_ok "Tâches planifiées synchronisées (${#wanted[@]} cadence(s))."
}
