#!/bin/bash
set -euo pipefail
# shellcheck source=../lib/jeiko-common.sh
source /usr/local/lib/jeiko/common.sh

jeiko_step "[14] Migrations, statiques, droits de mise à jour, contrôles"
jeiko_require_root

: "${PROJECT_DIR:?PROJECT_DIR manquant}"
: "${SITE_NAME:?SITE_NAME manquant}"
: "${SITE_USER:?SITE_USER manquant}"
: "${VENV_DIR:?VENV_DIR manquant}"
: "${DJANGO_SUPERUSER:?DJANGO_SUPERUSER manquant}"

SERVICE_NAME="${GUNICORN_SERVICE:-gunicorn-$SITE_NAME}"

# --------------------------------------------------------------------------- #
# 1) Base et fichiers statiques
# --------------------------------------------------------------------------- #
jeiko_log "🔄 Migrations…"
jeiko_manage "$PROJECT_DIR" "$VENV_DIR" "$SITE_USER" migrate --noinput

jeiko_log "📦 Collecte des fichiers statiques…"
jeiko_manage "$PROJECT_DIR" "$VENV_DIR" "$SITE_USER" collectstatic --noinput

# --------------------------------------------------------------------------- #
# 1 bis) Tâches planifiées
#
# Les cadences ne sont pas listées ici : elles sont demandées au package, qui
# est la source de vérité. Un site fraîchement installé repart donc avec
# exactement les timers que sa version de JEIKO déclare.
# --------------------------------------------------------------------------- #
jeiko_log "⏱  Tâches planifiées…"
jeiko_sync_cron_timers "$SITE_NAME" "$PROJECT_DIR" "$VENV_DIR" "$SITE_USER"

# --------------------------------------------------------------------------- #
# 2) Compte d'administration initial (O-05)
#
# Le mot de passe transite par l'environnement du processus plutôt que par
# l'interpolation d'une chaîne dans un script shell : il n'apparaît ni dans le
# journal d'installation, ni dans l'historique des commandes, ni dans un
# fichier temporaire.
#
# La commande du paquet crée le compte ET confirme son adresse dans allauth.
# `createsuperuser` seul donnait un compte refusé à la connexion (confirmation
# d'adresse obligatoire), sur un site qui ne sait pas encore envoyer d'e-mail.
# Elle refuse une adresse absente, invalide ou déjà prise : l'installation
# s'arrête alors ici plutôt que d'annoncer un site où personne ne peut entrer.
# --------------------------------------------------------------------------- #
jeiko_log "👤 Compte d'administration initial…"
if ! jeiko_manage "$PROJECT_DIR" "$VENV_DIR" "$SITE_USER" help jeiko_compte_initial >/dev/null 2>&1; then
    jeiko_die "Le paquet JEIKO installé ne fournit pas jeiko_compte_initial : installeur plus récent que le paquet. Publiez le paquet correspondant."
fi
DJANGO_SU_NAME="$DJANGO_SUPERUSER" \
DJANGO_SU_EMAIL="${DJANGO_SUPEREMAIL:-}" \
DJANGO_SU_PASS="${DJANGO_SUPERPASS:-}" \
jeiko_manage "$PROJECT_DIR" "$VENV_DIR" "$SITE_USER" jeiko_compte_initial \
    || jeiko_die "Compte d'administration initial non prêt (voir le message ci-dessus)."

# --------------------------------------------------------------------------- #
# 3) django.contrib.sites
# --------------------------------------------------------------------------- #
jeiko_log "🌐 Synchronisation de django.contrib.sites…"
JEIKO_DOMAIN="$DOMAIN_NAME" JEIKO_SITENAME="$SITE_NAME" \
jeiko_manage "$PROJECT_DIR" "$VENV_DIR" "$SITE_USER" shell <<'PY'
import os
from django.contrib.sites.models import Site

domain = os.environ.get("JEIKO_DOMAIN", "")
name = os.environ.get("JEIKO_SITENAME") or domain

if domain:
    site, _ = Site.objects.get_or_create(id=1, defaults={"domain": domain, "name": name})
    site.domain, site.name = domain, name
    site.save()
    print(f"✅ Site(id=1) = {site.domain} ({site.name})")
else:
    print("⚠️  DOMAIN_NAME absent, django.contrib.sites non modifié.")
PY

# --------------------------------------------------------------------------- #
# 4) Droits de mise à jour — le correctif central
#
# L'interface d'administration lançait `sudo <script dans site-packages>`, alors
# que le fichier sudoers n'autorisait que systemctl : sudo réclamait un mot de
# passe, sans terminal pour le saisir, et la mise à jour échouait toujours.
#
# Deux corrections indissociables :
#   · la règle autorise exactement la commande émise par la vue Django ;
#   · cette commande ne fait que DÉCLENCHER une unité systemd dont l'ExecStart
#     pointe vers un binaire root:root. Le site ne peut plus choisir ce qui est
#     exécuté sous privilèges — il ne peut que demander son propre déclenchement.
#
# Le chemin est figé à /usr/bin/systemctl : sudo compare la ligne de commande
# telle qu'écrite, et /bin/systemctl — pourtant le même fichier via usrmerge —
# serait une chaîne différente, donc une règle qui ne s'applique pas.
#
# Le fichier est écrit par jeiko_ecrire_sudoers (jeiko-common.sh), seul
# exemplaire : il l'était ici ET dans jeiko-server-update, et une règle ajoutée
# à l'un manquait à l'autre.
# --------------------------------------------------------------------------- #
SUDOERS="/etc/sudoers.d/jeiko-$SITE_NAME"
jeiko_ecrire_sudoers "$SITE_NAME" "$SITE_USER" "$SERVICE_NAME" \
    || jeiko_die "Le fichier sudoers n'a pas pu être installé (voir ci-dessus)."
jeiko_ok "Droits de mise à jour accordés à $SITE_USER (3 commandes, rien d'autre)."

# Purge d'une éventuelle règle héritée de l'ancien schéma, qui autorisait un
# script situé dans site-packages.
if [[ -f "/etc/sudoers.d/jeiko-$SITE_NAME.old" ]]; then
    rm -f "/etc/sudoers.d/jeiko-$SITE_NAME.old"
fi

systemctl daemon-reload

# --------------------------------------------------------------------------- #
# 5) Permissions finales et ACL
# --------------------------------------------------------------------------- #
jeiko_fix_perms "$PROJECT_DIR" "$SITE_USER" "$SITE_NAME" "$VENV_DIR"
jeiko_apply_admin_acl "$PROJECT_DIR" "${ADMIN_SSH_USER:-}"

# --------------------------------------------------------------------------- #
# 6) Redémarrage et contrôles
# --------------------------------------------------------------------------- #
jeiko_log "🔁 Redémarrage des services…"
systemctl restart "$SERVICE_NAME"
systemctl reload nginx || systemctl restart nginx

jeiko_log "🔎 Contrôle de déploiement Django…"
jeiko_manage "$PROJECT_DIR" "$VENV_DIR" "$SITE_USER" check --deploy 2>&1 || \
    jeiko_warn "Des avertissements subsistent (voir ci-dessus)."

# Contrôle de bout en bout, par la socket : c'est exactement le chemin
# qu'empruntera nginx.
SOCKET="/run/$SERVICE_NAME/gunicorn.sock"
HEALTHY=0
for _ in {1..15}; do
    sleep 1
    [[ -S "$SOCKET" ]] || continue
    CODE="$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 \
            --unix-socket "$SOCKET" \
            -H "Host: $DOMAIN_NAME" -H "X-Forwarded-Proto: https" \
            "http://localhost/" 2>/dev/null || echo 000)"
    if [[ "$CODE" =~ ^[123] ]]; then HEALTHY=1; break; fi
done

if [[ $HEALTHY -eq 1 ]]; then
    jeiko_ok "L'application répond (HTTP $CODE)."
else
    # C'est LE contrôle final : une installation qui se termine doit laisser un
    # site qui répond. Se contenter d'un avertissement laissait croire au succès
    # et reportait la découverte du problème à la mise en production.
    jeiko_err "L'application ne répond pas (dernier code : ${CODE:-aucun})."
    jeiko_err "Journal du service :"
    journalctl -u "$SERVICE_NAME" -n 40 --no-pager >&2 || true
    jeiko_err "Diagnostic :"
    jeiko_err "  systemctl status $SERVICE_NAME -l"
    jeiko_err "  cd $PROJECT_DIR && sudo -u $SITE_USER $VENV_DIR/bin/python manage.py check"
    jeiko_die "Installation incomplète : le site ne répond pas."
fi

# --------------------------------------------------------------------------- #
# 7) Vérification du mécanisme de mise à jour
#
# On le teste maintenant, à vide. Découvrir qu'il ne fonctionne pas le jour
# d'une mise à jour urgente est exactement ce qu'on cherche à éviter.
# --------------------------------------------------------------------------- #
jeiko_log "🧪 Vérification du déclenchement de la mise à jour…"

# Ce test passe par « sudo -u », qui ne reproduit PAS les conditions du service :
# ni son NoNewPrivileges, ni ses groupes. Il a donc longtemps validé une chaîne
# qui échouait en production avec « the "no new privileges" flag is set ».
# On contrôle donc d'abord les deux réglages de l'unité dont dépend l'appel.
NNP="$(systemctl show "$SERVICE_NAME" -p NoNewPrivileges --value 2>/dev/null || echo '?')"
if [[ "$NNP" == "yes" ]]; then
    jeiko_err "$SERVICE_NAME a NoNewPrivileges=yes : sudo y est inopérant."
    jeiko_die "L'application ne pourrait pas déclencher sa mise à jour."
fi

SVC_GROUPS="$(systemctl show "$SERVICE_NAME" -p SupplementaryGroups --value 2>/dev/null || echo '')"
if [[ "$SVC_GROUPS" != *"$SITE_USER"* ]]; then
    jeiko_err "$SERVICE_NAME n'a pas $SITE_USER dans SupplementaryGroups."
    jeiko_err "Le service ne pourra pas lire /var/lib/jeiko/$SITE_NAME/update.state."
    jeiko_die "Configuration du service incomplète."
fi

# sudo -l répond sans rien lancer. On démarrait ici une vraie mise à jour,
# arrêtée au bout de 2 s : sur un serveur qui héberge déjà des sites, avec une
# version plus récente publiée, l'arrêt pouvait tomber en plein pip install
# (audit du 04/10/2026, I-05).
if jeiko_verifier_declenchement "$SITE_NAME" "$SITE_USER"; then
    jeiko_ok "L'application peut déclencher sa mise à jour sans mot de passe."
else
    jeiko_err "Le déclenchement de mise à jour ne fonctionne pas — vérifie $SUDOERS"
    jeiko_die "La mise à jour depuis l'administration serait inutilisable."
fi
if jeiko_verifier_declenchement "$SITE_NAME" "$SITE_USER" jeiko-maj-serveur; then
    jeiko_ok "… et demander la mise à jour du serveur."
else
    jeiko_warn "Demande de mise à jour du serveur impossible depuis l'application — vérifie $SUDOERS"
fi

# Le site naît convergé avec l'installeur qui vient de le poser : sans ce
# repère, jeiko-client-update le croirait en retard et refuserait sa première
# mise à jour du paquet (voir jeiko-common.sh).
jeiko_noter_convergence "$SITE_NAME" "$SITE_USER" "$(jeiko_version_outillage)"

jeiko_ok "Finalisation terminée."
