#!/bin/bash
###############################################################################
# migrate_site.sh — amorçage de l'outillage JEIKO sur un serveur.
#
# Ce script ne s'exécute qu'une fois par serveur (ou après une mise à jour de
# l'installeur). Il dépose l'outillage puis passe la main à jeiko-server-update,
# qui devient ensuite le point d'entrée permanent :
#
#     sudo jeiko-server-update <site>          convergence de la config serveur
#     sudo jeiko-server-update --all           tous les sites
#     sudo jeiko-client-update <site>          mise à jour du package
#
# Ce qu'il dépose :
#   /usr/local/lib/jeiko/common.sh        modèle de permissions partagé
#   /usr/local/sbin/jeiko-server-update   convergence serveur (terminal)
#   /usr/local/sbin/jeiko-client-update   mise à jour du package (site + terminal)
#   /usr/local/share/jeiko/               gabarits nginx, unités, scripts d'étape
#   /etc/systemd/system/jeiko-update@…    déclenchement depuis l'administration
#   /etc/jeiko/sites/<site>.conf          fiche du site, si elle n'existe pas
#
# Pour un site déjà en production, il reconstitue d'abord la fiche du site à
# partir de ce qu'il trouve sur la machine, puis lance la convergence.
#
# Usage :
#   sudo ./migrate_site.sh <site>              amorce puis converge ce site
#   sudo ./migrate_site.sh <site> --dry-run    montre sans rien modifier
#   sudo ./migrate_site.sh --list              liste les sites détectés
#   sudo ./migrate_site.sh --tools-only        dépose l'outillage, sans site
###############################################################################

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
ASSET_DIR="/usr/local/share/jeiko"

[[ ${EUID} -eq 0 ]] || { echo "❌ À exécuter avec sudo."; exit 1; }

DRY_RUN=0; SITE=""; TOOLS_ONLY=0
while [[ $# -gt 0 ]]; do
    case "$1" in
        --dry-run)    DRY_RUN=1; shift ;;
        --tools-only) TOOLS_ONLY=1; shift ;;
        --list)
            echo "Sites Django détectés :"
            for d in /var/www/*/ /srv/*/ ; do
                [[ -f "$d/manage.py" ]] || continue
                s="$(basename "$d")"
                if [[ -f "/etc/jeiko/sites/$s.conf" ]]; then
                    printf '  %-24s ✅ enregistré\n' "$s"
                else
                    printf '  %-24s ⚠️  non enregistré\n' "$s"
                fi
            done
            exit 0 ;;
        -*) echo "Option inconnue : $1"; exit 1 ;;
        *)  SITE="$1"; shift ;;
    esac
done

run()  { if [[ $DRY_RUN -eq 1 ]]; then echo "   [simulation] $*"; else "$@"; fi; }
say()  { printf '\n\033[1m▶ %s\033[0m\n' "$*"; }
ok()   { printf '   ✅ %s\n' "$*"; }
warn() { printf '   ⚠️  %s\n' "$*"; }
die()  { printf '   ❌ %s\n' "$*" >&2; exit 1; }

###############################################################################
# 1) Dépôt de l'outillage
###############################################################################
say "Dépôt de l'outillage JEIKO"

[[ -f "$SCRIPT_DIR/lib/jeiko-common.sh" ]] || die "lib/jeiko-common.sh introuvable dans $SCRIPT_DIR"

run install -d -m 0755 -o root -g root /usr/local/lib/jeiko "$ASSET_DIR" "$ASSET_DIR/scripts"
run install -m 0644 -o root -g root "$SCRIPT_DIR/lib/jeiko-common.sh" /usr/local/lib/jeiko/common.sh
ok "/usr/local/lib/jeiko/common.sh"

for tool in jeiko-server-update jeiko-client-update jeiko-maj; do
    [[ -f "$SCRIPT_DIR/updater/$tool" ]] || die "updater/$tool introuvable"
    run install -m 0755 -o root -g root "$SCRIPT_DIR/updater/$tool" "/usr/local/sbin/$tool"
    ok "/usr/local/sbin/$tool (root:root 0755)"
done

# Les ressources dont jeiko-server-update a besoin pour converger un site.
run install -m 0644 -o root -g root \
    "$SCRIPT_DIR/updater/jeiko-update@.service" "$ASSET_DIR/jeiko-update@.service"
run install -m 0755 -o root -g root "$SCRIPT_DIR/updater/jeiko-client-update" "$ASSET_DIR/jeiko-client-update"
for s in 10_configure_gunicorn.sh 11_configure_nginx.sh 12_setup_tls_letsencrypt.sh 13_backups.sh; do
    [[ -f "$SCRIPT_DIR/scripts/$s" ]] && run install -m 0755 -o root -g root "$SCRIPT_DIR/scripts/$s" "$ASSET_DIR/scripts/$s" || true
done
run install -m 0644 -o root -g root \
    "$SCRIPT_DIR/updater/jeiko-update@.service" /etc/systemd/system/jeiko-update@.service

# La mise à jour automatique (jeiko-maj) : ses unités — le timer hebdomadaire et
# la demande d'un site —, activées à chaque dépôt. Sans site qui ait coché la
# mise à jour automatique, la passe hebdomadaire ne fait rien.
for unite in jeiko-maj.service jeiko-maj.timer jeiko-maj-serveur@.service; do
    [[ -f "$SCRIPT_DIR/updater/$unite" ]] || die "updater/$unite introuvable"
    run install -m 0644 -o root -g root "$SCRIPT_DIR/updater/$unite" "/etc/systemd/system/$unite"
done
run systemctl daemon-reload
run systemctl enable --now jeiko-maj.timer || warn "jeiko-maj.timer non activé."
ok "$ASSET_DIR (gabarits nginx, unités, scripts d'étape) ; jeiko-maj.timer actif"

# L'ancien updater monolithique, remplacé par le couple serveur/client.
if [[ -f /usr/local/sbin/jeiko-update ]]; then
    run rm -f /usr/local/sbin/jeiko-update
    ok "Ancien /usr/local/sbin/jeiko-update retiré (remplacé par les deux scripts)"
fi

if [[ -f /usr/local/lib/jeiko/common.sh ]]; then
    # shellcheck source=lib/jeiko-common.sh
    source /usr/local/lib/jeiko/common.sh
else
    source "$SCRIPT_DIR/lib/jeiko-common.sh"
fi

[[ $DRY_RUN -eq 1 ]] || jeiko_init_dirs

# Version de l'outillage maintenant déposé — le repère que jeiko-maj compare à
# l'installeur publié. Écrite APRÈS le dépôt complet : un dépôt interrompu
# laisse l'ancienne version, et la passe suivante recommence.
[[ -f "$SCRIPT_DIR/VERSION" ]] || die "VERSION absent de $SCRIPT_DIR"
run install -m 0644 -o root -g root "$SCRIPT_DIR/VERSION" "$ASSET_DIR/VERSION"
ok "Outillage : installeur $(tr -d ' \n\r' <"$SCRIPT_DIR/VERSION")"

# Bibliothèques système qu'une version du paquet a ajoutées depuis
# l'installation : `03_check_dependencies.sh` ne repasse pas sur un serveur en
# service. Sans elles le site démarre, mais sans la fonction (le PDF de
# jeiko.pdf, par exemple). Même liste que dans 03 ; rien n'est réinstallé.
#
# Jamais bloquant : un échec ici (réseau, verrou dpkg tenu par les mises à jour
# automatiques de Debian) ne doit pas empêcher de déposer l'outillage ni de
# converger — le site fonctionne sans ces bibliothèques. On attend le verrou
# jusqu'à 5 minutes, puis on prévient et on continue.
say "Bibliothèques système"
MANQUANTS=()
for pkg in libpango-1.0-0 libpangoft2-1.0-0 libharfbuzz-subset0 fonts-dejavu-core; do
    dpkg -s "$pkg" &>/dev/null || MANQUANTS+=("$pkg")
done
if [[ ${#MANQUANTS[@]} -eq 0 ]]; then
    ok "Déjà présentes"
elif run env DEBIAN_FRONTEND=noninteractive apt-get -o DPkg::Lock::Timeout=300 update -y \
     && run env DEBIAN_FRONTEND=noninteractive apt-get -o DPkg::Lock::Timeout=300 install -y "${MANQUANTS[@]}"; then
    ok "Installées : ${MANQUANTS[*]}"
else
    warn "Installation impossible pour l'instant : ${MANQUANTS[*]}"
    warn "Les sites tournent sans (pas de PDF) ; ce sera retenté au prochain passage."
fi

if [[ $TOOLS_ONLY -eq 1 ]]; then
    say "Outillage déposé"
    echo "   Convergence d'un site : sudo jeiko-server-update <site>"
    exit 0
fi

[[ -n "$SITE" ]] || die "Usage : sudo ./migrate_site.sh <site> [--dry-run] | --list | --tools-only"
jeiko_validate_site_name "$SITE" || exit 1

###############################################################################
# 2) Fiche du site — la reconstituer si elle n'existe pas
###############################################################################
CONF="$(jeiko_site_conf_path "$SITE")"

if [[ -f "$CONF" ]]; then
    say "Fiche du site déjà enregistrée"
    ok "$CONF"
else
    say "Reconstitution de la fiche du site « $SITE »"

    PROJECT_DIR=""
    for candidate in "/var/www/$SITE" "/srv/$SITE" "/opt/www/$SITE"; do
        [[ -f "$candidate/manage.py" ]] && { PROJECT_DIR="$candidate"; break; } || true
    done
    [[ -n "$PROJECT_DIR" ]] || die "Aucun projet Django trouvé pour « $SITE » (manage.py introuvable)."

    BASE_DIR="$(dirname "$PROJECT_DIR")"
    SETTINGS_DIR="$PROJECT_DIR/$SITE"
    ENV_PATH="$SETTINGS_DIR/.env"
    VENV_DIR="$PROJECT_DIR/venv"
    [[ -d "$VENV_DIR" ]] || VENV_DIR="$PROJECT_DIR/.venv"

    SITE_USER="$(stat -c '%U' "$PROJECT_DIR")"
    if [[ "$SITE_USER" == "root" || -z "$SITE_USER" ]]; then
        SITE_USER="jeiko-$SITE"
    fi
    GUNICORN_SERVICE="gunicorn-$SITE"

    # Les identifiants vivent déjà dans le .env du site : on les y lit plutôt
    # que de les redemander. Un .env qui est un lien ferait lire root ailleurs.
    [[ -L "$ENV_PATH" ]] && die ".env est un lien symbolique ($ENV_PATH) : refusé."
    read_env() {
        [[ -f "$ENV_PATH" ]] || return 0
        grep -E "^\s*$1\s*=" "$ENV_PATH" | tail -n1 | cut -d= -f2- \
            | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//' \
                  -e 's/^"//' -e 's/"$//' -e "s/^'//" -e "s/'$//"
    }
    DB_NAME="$(read_env DB_NAME)"
    DB_USER="$(read_env DB_USER)"
    DB_PASS="$(read_env DB_PASS)"
    DOMAIN_NAME="$(read_env DOMAIN_NAME)"

    # Repli sur l'ancien fichier de l'installeur, qui traînait en 0644.
    LEGACY_ENV="$SCRIPT_DIR/.env.$SITE"
    if [[ -z "$DB_PASS" && -f "$LEGACY_ENV" ]]; then
        warn "Identifiants absents du .env du site, lecture de $LEGACY_ENV"
        # shellcheck disable=SC1090
        source "$LEGACY_ENV"
    fi

    [[ -n "$DB_NAME" && -n "$DB_USER" ]] || die "Identifiants de base introuvables dans $ENV_PATH"
    [[ -n "$DOMAIN_NAME" ]] || die "DOMAIN_NAME introuvable dans $ENV_PATH"

    # Ces valeurs viennent du .env, que le site rédige ; elles vont dans la
    # fiche root, puis dans le vhost nginx (lu en root) et dans les commandes
    # PostgreSQL de la désinstallation. Les mêmes règles qu'à l'installation
    # (audit du 04/10/2026, I-11).
    jeiko_validate_domain "${DOMAIN_NAME,,}" || die "DOMAIN_NAME refusé : « $DOMAIN_NAME »"
    for valeur in "$DB_NAME" "$DB_USER"; do
        [[ "$valeur" =~ ^[a-zA-Z_][a-zA-Z0-9_]{0,62}$ ]] \
            || die "Nom PostgreSQL refusé : « $valeur » (lettres, chiffres, _ ; 63 au plus)."
    done

    ENABLE_SSL="n"
    [[ -d "/etc/letsencrypt/live/$DOMAIN_NAME" ]] && ENABLE_SSL="y" || true
    ADMIN_SSH_USER="${SUDO_USER:-debian}"

    echo "   Projet      : $PROJECT_DIR"
    echo "   Compte      : $SITE_USER"
    echo "   Domaine     : $DOMAIN_NAME"
    echo "   Base        : $DB_NAME (rôle $DB_USER)"
    echo "   TLS         : $([[ "$ENABLE_SSL" == "y" ]] && echo "certificat présent" || echo "aucun")"

    export PROJECT_DIR BASE_DIR SITE_USER VENV_DIR GUNICORN_SERVICE
    export DB_NAME DB_USER DB_PASS DOMAIN_NAME ENABLE_SSL ADMIN_SSH_USER
    export INSTALLED_AT="fiche reconstituée le $(date -Is)"

    if [[ $DRY_RUN -eq 0 ]]; then
        jeiko_write_site_conf "$SITE"
        ok "$CONF (0600 root:root)"
    else
        echo "   [simulation] écriture de $CONF"
    fi

    # L'ancien fichier de l'installeur exposait le mot de passe PostgreSQL en 0644.
    if [[ -f "$LEGACY_ENV" && $DRY_RUN -eq 0 ]]; then
        warn "$LEGACY_ENV est en $(stat -c '%a' "$LEGACY_ENV") et contient DB_PASS."
        read -rp "   Le supprimer ? (y/n) : " rmleg
        if [[ "$rmleg" == "y" ]]; then
            shred -u "$LEGACY_ENV" 2>/dev/null || rm -f "$LEGACY_ENV"
            ok "Supprimé."
        else
            chmod 0600 "$LEGACY_ENV"; ok "Conservé, ramené à 0600."
        fi
    fi
fi

###############################################################################
# 3) Purge de l'ancien updater embarqué dans le package
#
# C'était le chemin d'élévation : inscriptible par l'utilisateur du site, et
# exécuté via sudo.
###############################################################################
say "Purge de l'ancien mécanisme"
# shellcheck disable=SC1090
source "$CONF" 2>/dev/null || true
if [[ -n "${VENV_DIR:-}" && -d "$VENV_DIR" ]]; then
    OLD="$(find "$VENV_DIR/lib" -path '*/jeiko/scripts/update_jeiko.sh' 2>/dev/null || true)"
    if [[ -n "$OLD" ]]; then
        warn "Ancien updater trouvé dans site-packages :"
        echo "$OLD" | sed 's/^/      /'
        while IFS= read -r f; do run rm -f "$f"; done <<<"$OLD"
        ok "Supprimé."
    else
        ok "Rien à purger."
    fi
fi
[[ -n "${PROJECT_DIR:-}" && -f "${PROJECT_DIR}/update_jeiko.sh" ]] && { run rm -f "$PROJECT_DIR/update_jeiko.sh"; ok "Copie à la racine du projet supprimée."; } || true

###############################################################################
# 4) Passage de relais
###############################################################################
say "Convergence par jeiko-server-update"

if [[ $DRY_RUN -eq 1 ]]; then
    # En simulation la fiche n'a pas été écrite (voir plus haut) : la
    # convergence, qui l'exige, échouerait systématiquement sur « Fiche de site
    # introuvable ». Le --dry-run ne pouvait donc jamais aboutir précisément
    # dans le cas où il est le plus utile — l'amorçage d'un site non encore
    # enregistré. On s'arrête ici en le disant clairement.
    if [[ ! -f "$CONF" ]]; then
        say "Simulation terminée"
        ok "Fiche reconstituée avec succès (non écrite : simulation)."
        echo "   La convergence n'est pas simulée : elle exige la fiche, qui"
        echo "   n'existe pas encore pour « $SITE »."
        echo ""
        echo "   Pour appliquer :        sudo ./migrate_site.sh $SITE"
        echo "   Pour simuler ensuite :  sudo jeiko-server-update $SITE --dry-run"
        exit 0
    fi
    exec /usr/local/sbin/jeiko-server-update "$SITE" --dry-run
else
    echo ""
    read -rp "Lancer la convergence de « $SITE » maintenant ? (oui/non) : " go
    if [[ "$go" == "oui" ]]; then
        exec /usr/local/sbin/jeiko-server-update "$SITE"
    fi
    echo ""
    echo "   Outillage en place. Pour converger plus tard :"
    echo "     sudo jeiko-server-update $SITE"
fi
