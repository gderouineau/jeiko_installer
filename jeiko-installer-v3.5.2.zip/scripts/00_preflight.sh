#!/bin/bash
set -euo pipefail
# shellcheck source=../lib/jeiko-common.sh
source /usr/local/lib/jeiko/common.sh

jeiko_step "[00] Pré-vol & vérifications"
jeiko_require_root

command -v apt-get >/dev/null 2>&1 || jeiko_die "Système non Debian/Ubuntu (apt-get introuvable)."
pidof systemd >/dev/null 2>&1 || jeiko_die "systemd requis."

DEBIAN_CODENAME="$(grep -oP '(?<=VERSION_CODENAME=).*' /etc/os-release || true)"
ARCH="$(uname -m)"
CPU="$(nproc)"
RAM_MB="$(awk '/MemTotal/ {print int($2/1024)}' /proc/meminfo)"
DISK_FREE_MB="$(df -Pm / | awk 'NR==2{print $4}')"

jeiko_log "ℹ️  Debian ${DEBIAN_CODENAME:-inconnue} | $ARCH | ${CPU} CPU | ${RAM_MB} Mo RAM | ${DISK_FREE_MB} Mo libres sur /"

# --------------------------------------------------------------------------- #
# Version de Debian
#
# L'installeur ne fige aucune version : les paquets sont des méta-paquets
# (postgresql, python3…) et la version du cluster PostgreSQL est détectée à
# l'exécution. Une release non testée a donc toutes les chances de fonctionner
# — on prévient sans bloquer, plutôt que de refuser une machine parfaitement
# capable ou d'obliger à maintenir un installeur par version.
# --------------------------------------------------------------------------- #
JEIKO_TESTED_RELEASES="${JEIKO_TESTED_RELEASES:-bookworm trixie}"

case " $JEIKO_TESTED_RELEASES " in
    *" ${DEBIAN_CODENAME:-inconnue} "*)
        jeiko_ok "Version de Debian testée : $DEBIAN_CODENAME"
        ;;
    *)
        jeiko_warn "Debian « ${DEBIAN_CODENAME:-inconnue} » n'est pas dans les versions testées ($JEIKO_TESTED_RELEASES)."
        jeiko_warn "     L'installation devrait fonctionner : aucune version n'est figée dans les scripts."
        jeiko_warn "     Signale-moi tout écart pour ajouter cette release à la liste."
        ;;
esac

# Un venv + PostgreSQL + les statiques tiennent difficilement sous 2 Go.
if [[ "$DISK_FREE_MB" -lt 2048 ]]; then
    jeiko_die "Moins de 2 Go libres sur / — libère de la place avant d'installer."
fi
if [[ "$RAM_MB" -lt 900 ]]; then
    jeiko_warn "Moins de 1 Go de RAM : le swap créé à l'étape 01 sera indispensable."
fi

if [[ -n "${DOMAIN_NAME:-}" ]]; then
    if getent hosts "$DOMAIN_NAME" >/dev/null 2>&1; then
        jeiko_ok "Résolution DNS OK pour $DOMAIN_NAME"
    else
        jeiko_warn "$DOMAIN_NAME ne résout pas encore."
        # Sans DNS, la validation Let's Encrypt échouera à coup sûr : autant le
        # dire maintenant plutôt qu'à l'étape 12, après 10 minutes d'install.
        if [[ "${ENABLE_SSL:-n}" == "y" ]]; then
            jeiko_die "HTTPS demandé mais le domaine ne résout pas : Let's Encrypt échouera. Attends la propagation DNS ou réponds 'n'."
        fi
    fi
    # Pour un domaine « apex », le certificat couvre aussi www (étape 12) :
    # un www sans DNS fait échouer toute la demande, après l'installation.
    if [[ "${ENABLE_SSL:-n}" == "y" ]] && jeiko_is_apex "$DOMAIN_NAME" \
       && ! getent hosts "www.$DOMAIN_NAME" >/dev/null 2>&1; then
        jeiko_die "HTTPS demandé mais www.$DOMAIN_NAME ne résout pas : le certificat le couvre aussi. Ajoute l'enregistrement DNS ou réponds 'n'."
    fi
fi

for p in 80 443; do
    if ss -lnt "( sport = :$p )" 2>/dev/null | grep -q ":$p"; then
        jeiko_warn "Port $p déjà occupé (probablement Nginx, ce qui est normal en réinstallation)."
    fi
done

# Un site homonyme déjà servi par nginx signale une collision de configuration.
if [[ -e "/etc/nginx/sites-enabled/${SITE_NAME}.conf" ]]; then
    jeiko_warn "Un vhost nginx '${SITE_NAME}.conf' existe déjà, il sera réécrit (une sauvegarde sera faite)."
fi

# Un AUTRE site du serveur sert déjà ce domaine (NGX-3, 09/10/2026) : nginx
# n'en retiendrait qu'un, et le nouveau site répondrait — ou pas — selon
# l'ordre alphabétique des fichiers. On refuse AVANT toute création (base,
# compte, dossiers). Un autre sous-domaine du même domaine n'est pas un
# doublon ; le vhost du site lui-même (réinstallation) non plus.
if [[ -n "${DOMAIN_NAME:-}" ]]; then
    NOMS=("$DOMAIN_NAME")
    jeiko_is_apex "$DOMAIN_NAME" && NOMS+=("www.$DOMAIN_NAME")
    DOUBLONS=""
    for nom in "${NOMS[@]}"; do
        DOUBLONS+="$(jeiko_vhosts_du_nom "$nom" "/etc/nginx/sites-enabled/${SITE_NAME}.conf")"
    done
    if [[ -n "$DOUBLONS" ]]; then
        jeiko_err "« ${NOMS[*]} » est déjà servi par un autre site de ce serveur :"
        sort -u <<<"$DOUBLONS" | while read -r f; do [[ -n "$f" ]] && jeiko_err "     $f"; done
        jeiko_die "Installation refusée : un domaine ne peut être servi que par un seul site. Rien n'a été créé."
    fi
fi

jeiko_ok "Préparation vérifiée."
