#!/bin/bash
set -euo pipefail
# shellcheck source=../lib/jeiko-common.sh
source /usr/local/lib/jeiko/common.sh

jeiko_step "[02] Compte système, dossiers et permissions"
jeiko_require_root

: "${BASE_DIR:?BASE_DIR manquant}"
: "${SITE_NAME:?SITE_NAME manquant}"
: "${PROJECT_DIR:?PROJECT_DIR manquant}"
: "${SITE_USER:?SITE_USER manquant}"

# --------------------------------------------------------------------------- #
# 1) Utilisateur système dédié au site
#
# Un compte par site : une faille dans un site ne donne pas accès aux autres.
# Pas de shell, pas de home : ce compte ne sert qu'à faire tourner gunicorn.
# --------------------------------------------------------------------------- #
if ! id -u "$SITE_USER" >/dev/null 2>&1; then
    useradd --system --no-create-home --shell /usr/sbin/nologin "$SITE_USER"
    jeiko_ok "Utilisateur système créé : $SITE_USER"
else
    jeiko_log "ℹ️  Utilisateur système déjà présent : $SITE_USER"
fi

# Son groupe à lui (créé par useradd), dont nginx est membre : le site ne
# partage plus www-data avec les autres sites (IG-01).
jeiko_isoler_le_site "$SITE_USER"
SITE_GROUP="$(jeiko_groupe_du_site "$SITE_USER")"

# --------------------------------------------------------------------------- #
# 2) Arborescence
# --------------------------------------------------------------------------- #
install -d -m 0755 "$BASE_DIR"
install -d -m "$JEIKO_DIR_MODE" -o "$SITE_USER" -g "$SITE_GROUP" \
    "$PROJECT_DIR" "$PROJECT_DIR/staticdir" "$PROJECT_DIR/mediadir" "$PROJECT_DIR/logs"

# --------------------------------------------------------------------------- #
# 3) Permissions
#
# Une seule implémentation, partagée avec jeiko-update : installation et mise à
# jour ne peuvent plus diverger (l'ancienne posait 2750/0640 à l'install puis
# 2775/0664 à chaque mise à jour, ce qui rendait progressivement les fichiers
# inscriptibles par le groupe).
# --------------------------------------------------------------------------- #
jeiko_fix_perms "$PROJECT_DIR" "$SITE_USER" "$SITE_NAME" "${VENV_DIR:-$PROJECT_DIR/venv}"

# --------------------------------------------------------------------------- #
# 4) Confort administrateur
# --------------------------------------------------------------------------- #
if command -v setfacl >/dev/null 2>&1; then
    jeiko_apply_admin_acl "$PROJECT_DIR" "${ADMIN_SSH_USER:-}"
    jeiko_ok "ACL de lecture appliquées pour ${ADMIN_SSH_USER:-(aucun)}"
else
    jeiko_log "ℹ️  setfacl arrive à l'étape 03, ACL reportées à l'étape 14."
fi

# --------------------------------------------------------------------------- #
# 5) Journaux
# --------------------------------------------------------------------------- #
# Les racines sont PARTAGÉES par tous les sites : elles doivent rester
# traversables par tous (0755 root:root). « install -d » applique ses options à
# chaque dossier qu'il crée, parents compris : créer directement le sous-dossier
# donnait à la racine le groupe du DERNIER site installé, et le site précédent
# perdait alors l'accès à son propre update.state.
install -d -m 0755 -o root -g root "$JEIKO_LOG_DIR" "$JEIKO_LIB_DIR"

# Les sous-dossiers, eux, sont bien réservés à leur site.
install -d -m 0750 -o root -g "$SITE_USER" "$JEIKO_LOG_DIR/$SITE_NAME"
install -d -m 0750 -o root -g "$SITE_USER" "$JEIKO_LIB_DIR/$SITE_NAME"

# Rattrape une racine déjà créée au groupe d'un autre site par une version
# précédente de ce script — sinon le défaut persiste sur les serveurs existants.
chown root:root "$JEIKO_LOG_DIR" "$JEIKO_LIB_DIR"
chmod 0755 "$JEIKO_LOG_DIR" "$JEIKO_LIB_DIR"

jeiko_ok "Comptes, dossiers et permissions prêts pour $SITE_NAME"
