#!/bin/bash
set -euo pipefail
# shellcheck source=../lib/jeiko-common.sh
source /usr/local/lib/jeiko/common.sh

jeiko_step "[00] Pré-vol & vérifications"
jeiko_require_root

command -v apt-get >/dev/null 2>&1 || jeiko_die "Système non Debian/Ubuntu (apt-get introuvable)."
pidof systemd >/dev/null 2>&1 || jeiko_die "systemd requis."

DEBIAN_CODENAME="$(grep -oP '(?<=VERSION_CODENAME=).*' /etc/os-release || true)"
ARCH="$(uname -m)"
CPU="$(nproc)"
RAM_MB="$(awk '/MemTotal/ {print int($2/1024)}' /proc/meminfo)"
DISK_FREE_MB="$(df -Pm / | awk 'NR==2{print $4}')"

jeiko_log "ℹ️  Debian ${DEBIAN_CODENAME:-inconnue} | $ARCH | ${CPU} CPU | ${RAM_MB} Mo RAM | ${DISK_FREE_MB} Mo libres sur /"

# Un venv + PostgreSQL + les statiques tiennent difficilement sous 2 Go.
if [[ "$DISK_FREE_MB" -lt 2048 ]]; then
    jeiko_die "Moins de 2 Go libres sur / — libère de la place avant d'installer."
fi
if [[ "$RAM_MB" -lt 900 ]]; then
    jeiko_warn "Moins de 1 Go de RAM : le swap créé à l'étape 01 sera indispensable."
fi

if [[ -n "${DOMAIN_NAME:-}" ]]; then
    if getent hosts "$DOMAIN_NAME" >/dev/null 2>&1; then
        jeiko_ok "Résolution DNS OK pour $DOMAIN_NAME"
    else
        jeiko_warn "$DOMAIN_NAME ne résout pas encore."
        # Sans DNS, la validation Let's Encrypt échouera à coup sûr : autant le
        # dire maintenant plutôt qu'à l'étape 12, après 10 minutes d'install.
        if [[ "${ENABLE_SSL:-n}" == "y" ]]; then
            jeiko_die "HTTPS demandé mais le domaine ne résout pas : Let's Encrypt échouera. Attends la propagation DNS ou réponds 'n'."
        fi
    fi
fi

for p in 80 443; do
    if ss -lnt "( sport = :$p )" 2>/dev/null | grep -q ":$p"; then
        jeiko_warn "Port $p déjà occupé (probablement Nginx, ce qui est normal en réinstallation)."
    fi
done

# Un site homonyme déjà servi par nginx signale une collision de configuration.
if [[ -e "/etc/nginx/sites-enabled/${SITE_NAME}.conf" ]]; then
    jeiko_warn "Un vhost nginx '${SITE_NAME}.conf' existe déjà, il sera réécrit (une sauvegarde sera faite)."
fi

jeiko_ok "Préparation vérifiée."
