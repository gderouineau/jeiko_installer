#!/bin/bash
set -euo pipefail
# shellcheck source=../lib/jeiko-common.sh
source /usr/local/lib/jeiko/common.sh

jeiko_step "[08] Package JEIKO et mécanisme de mise à jour"
jeiko_require_root

: "${PROJECT_DIR:?PROJECT_DIR manquant}"
: "${SITE_NAME:?SITE_NAME manquant}"
: "${SITE_USER:?SITE_USER manquant}"
: "${VENV_DIR:?VENV_DIR manquant}"
: "${SCRIPT_DIR:?SCRIPT_DIR manquant}"

PY="$VENV_DIR/bin/python"
[[ -x "$PY" ]] || jeiko_die "venv introuvable ($PY). Lance 07_install_python_env.sh."

PIP=(env PYTHONNOUSERSITE=1 PIP_DISABLE_PIP_VERSION_CHECK=1 "$PY" -m pip)
CHANNEL_URL="${JEIKO_CHANNEL_URL:-$JEIKO_DEFAULT_CHANNEL_URL}"

# --------------------------------------------------------------------------- #
# 1) Déploiement de l'outillage de mise à jour
#
# Deux scripts aux responsabilités disjointes :
#   · jeiko-server-update — configuration serveur, lancé à la main ;
#   · jeiko-client-update — package et gabarits du projet, déclenchable depuis
#     l'interface d'administration via systemd.
#
# Tous deux en root:root, hors de l'arborescence du site : l'application peut
# DÉCLENCHER une mise à jour, elle ne peut pas décider de ce qui est exécuté.
# --------------------------------------------------------------------------- #
ASSET_DIR="/usr/local/share/jeiko"
install -d -m 0755 -o root -g root "$ASSET_DIR" "$ASSET_DIR/scripts"

for tool in jeiko-server-update jeiko-client-update; do
    install -m 0755 -o root -g root "$SCRIPT_DIR/updater/$tool" "/usr/local/sbin/$tool"
done

# Ressources dont jeiko-server-update a besoin pour converger un site plus tard.
install -m 0755 -o root -g root "$SCRIPT_DIR/updater/jeiko-client-update" "$ASSET_DIR/jeiko-client-update"
install -m 0644 -o root -g root "$SCRIPT_DIR/updater/jeiko-update@.service" "$ASSET_DIR/jeiko-update@.service"
for s in 11_configure_nginx.sh 12_setup_tls_letsencrypt.sh 13_backups.sh; do
    install -m 0755 -o root -g root "$SCRIPT_DIR/scripts/$s" "$ASSET_DIR/scripts/$s"
done

install -m 0644 -o root -g root "$SCRIPT_DIR/updater/jeiko-update@.service" \
    /etc/systemd/system/jeiko-update@.service
systemctl daemon-reload
jeiko_ok "Outillage déployé : jeiko-server-update et jeiko-client-update (root:root 0755)"

# --------------------------------------------------------------------------- #
# 2) Récupération vérifiée du package
# --------------------------------------------------------------------------- #
TMP_DIR="$(mktemp -d /tmp/jeiko-install.XXXXXXXX)"
# 0711 et non 0700 : le téléchargement et la vérification sha256 se font en root,
# mais pip installe sous le compte du site — il doit pouvoir LIRE le wheel et
# requirements.txt. Le bit d'exécution seul autorise la traversée sans permettre
# de lister le dossier, et l'absence de « w » pour les autres préserve ce qui
# compte vraiment : personne ne peut substituer l'archive entre sa vérification
# et son installation.
chmod 0711 "$TMP_DIR"
trap 'rm -rf "$TMP_DIR"' EXIT

# Rend lisible par le compte du site un fichier déposé dans TMP_DIR par les
# fonctions de téléchargement, qui les créent avec l'umask de root.
# L'absence du fichier est une erreur : on ne continue pas sans lui.
jeiko_share_with_site() {
    [[ -f "$1" ]] || jeiko_die "Fichier attendu introuvable : $1"
    chmod 0644 "$1" || jeiko_die "Impossible de rendre lisible : $1"
    jeiko_as_site "$SITE_USER" test -r "$1" \
        || jeiko_die "$SITE_USER ne peut pas lire $1 — vérifie les permissions de $(dirname "$1")."
}

jeiko_log "📡 Canal : $CHANNEL_URL"
jeiko_fetch_package "$CHANNEL_URL" "$TMP_DIR" \
    || jeiko_die "Impossible de récupérer un package JEIKO vérifiable."

jeiko_log "📦 Version : $JEIKO_PKG_VERSION"
jeiko_share_with_site "$JEIKO_PKG_WHEEL"

# --------------------------------------------------------------------------- #
# 3) Dépendances puis package
#
# --no-deps sur le wheel : les versions sont figées par requirements.txt, on ne
# laisse pas pip re-résoudre un arbre différent de celui qui a été testé.
# --------------------------------------------------------------------------- #
# Le manifeste indique où trouver les dépendances (dans le dépôt, le fichier
# vit sous jeiko/ et release.sh le republie sous dist/).
REQ_PATH="$("$(command -v python3)" -c "import json,sys;print(json.load(open(sys.argv[1])).get('requirements') or 'requirements.txt')" "$TMP_DIR/version.json" 2>/dev/null || echo requirements.txt)"
REQ_FILE="$TMP_DIR/requirements.txt"

# requirements.txt est OBLIGATOIRE. Le wheel est installé avec --no-deps : sans
# ce fichier, aucune dépendance n'entre dans le venv — ni Django, ni gunicorn —
# et l'installation ne casse que deux étapes plus loin, sur un « gunicorn: No
# such file or directory » incompréhensible. On échoue ici, au bon endroit.
jeiko_download "$CHANNEL_URL/$REQ_PATH" "$REQ_FILE" \
    || jeiko_die "requirements.txt introuvable sur le canal ($CHANNEL_URL/$REQ_PATH)."
jeiko_share_with_site "$REQ_FILE"

jeiko_log "📥 Dépendances (requirements.txt)…"
jeiko_as_site "$SITE_USER" "${PIP[@]}" install --no-cache-dir -r "$REQ_FILE" \
    || jeiko_die "Installation des dépendances échouée."

jeiko_log "🛠️  Installation de $(basename "$JEIKO_PKG_WHEEL")…"
jeiko_as_site "$SITE_USER" "${PIP[@]}" install --no-cache-dir --force-reinstall --no-deps "$JEIKO_PKG_WHEEL" \
    || jeiko_die "Installation du package JEIKO échouée."

# --------------------------------------------------------------------------- #
# 4) Mise en cache pour le retour arrière
#
# jeiko-update --rollback réinstalle le wheel précédent depuis ce cache. Sans
# cette copie initiale, la toute première mise à jour n'aurait rien vers quoi
# revenir.
# --------------------------------------------------------------------------- #
WHEEL_CACHE="$JEIKO_LIB_DIR/$SITE_NAME/wheels"
install -d -m 0750 -o root -g root "$WHEEL_CACHE"
install -m 0640 -o root -g root "$JEIKO_PKG_WHEEL" "$WHEEL_CACHE/"

jeiko_fix_perms "$PROJECT_DIR" "$SITE_USER" "$SITE_NAME" "$VENV_DIR"

# --------------------------------------------------------------------------- #
# 5) Contrôle de ce qui a réellement été installé
#
# Une étape qui se termine doit garantir son résultat. On vérifie donc que le
# package ET les dépendances dont dépendent les étapes suivantes sont là :
# gunicorn est lancé par l'étape 10, Django par l'étape 14.
# --------------------------------------------------------------------------- #
INSTALLED="$(jeiko_as_site "$SITE_USER" env PYTHONNOUSERSITE=1 "$PY" -c \
    'from importlib.metadata import version; print(version("jeiko"))' 2>/dev/null || true)"
[[ -n "$INSTALLED" ]] \
    || jeiko_die "Le package jeiko n'est pas importable après installation."

DJANGO_VER="$(jeiko_as_site "$SITE_USER" env PYTHONNOUSERSITE=1 "$PY" -c \
    'import django; print(django.get_version())' 2>/dev/null || true)"
[[ -n "$DJANGO_VER" ]] \
    || jeiko_die "Django absent du venv — les dépendances ne se sont pas installées."

# Le binaire, pas seulement le module : c'est lui que systemd exécute.
[[ -x "$VENV_DIR/bin/gunicorn" ]] \
    || jeiko_die "gunicorn absent de $VENV_DIR/bin — l'étape 10 ne pourrait pas démarrer le service."

jeiko_ok "JEIKO $INSTALLED · Django $DJANGO_VER · gunicorn présent."
