#!/bin/bash
set -euo pipefail
# shellcheck source=../lib/jeiko-common.sh
source /usr/local/lib/jeiko/common.sh

jeiko_step "[03] Dépendances système"
jeiko_require_root

export DEBIAN_FRONTEND=noninteractive

REQUIRED_PACKAGES=(
    # Outils de base
    curl unzip git jq htop ca-certificates lsb-release
    acl                       # setfacl, pour l'accès SSH en lecture
    util-linux                # runuser, flock

    # Web & TLS
    nginx certbot python3-certbot-nginx

    # Toolchain Python
    python3 python3-venv python3-pip python3-dev build-essential pkg-config

    # PostgreSQL
    postgresql postgresql-contrib libpq-dev

    # Memcached (+ en-têtes pour pylibmc)
    memcached libmemcached-dev libsasl2-dev zlib1g-dev

    # Pillow
    libjpeg-dev libfreetype6-dev libwebp-dev libtiff-dev
)

MISSING=()
for pkg in "${REQUIRED_PACKAGES[@]}"; do
    dpkg -s "$pkg" &>/dev/null || MISSING+=("$pkg")
done

if [[ ${#MISSING[@]} -gt 0 ]]; then
    jeiko_log "📦 À installer : ${MISSING[*]}"
    apt-get update -y
    apt-get install -y "${MISSING[@]}"
else
    jeiko_log "ℹ️  Toutes les dépendances sont déjà présentes."
fi

# --------------------------------------------------------------------------- #
# Vérifications
# --------------------------------------------------------------------------- #
PY_VERSION="$(python3 -c 'import sys; print("%d.%d" % sys.version_info[:2])')"
MIN_VERSION="3.10"
if [[ "$(printf '%s\n' "$MIN_VERSION" "$PY_VERSION" | sort -V | head -n1)" != "$MIN_VERSION" ]]; then
    jeiko_die "Python $MIN_VERSION minimum requis (présent : $PY_VERSION)."
fi

# runuser est ce qui permet de descendre vers l'utilisateur du site sans passer
# par un shell — donc sans exposer les chemins à une réinterprétation.
command -v runuser >/dev/null 2>&1 || jeiko_warn "runuser absent : repli sur sudo -u."
command -v flock   >/dev/null 2>&1 || jeiko_die "flock absent (paquet util-linux) : le verrou de mise à jour serait inopérant."

jeiko_ok "Dépendances OK (Python $PY_VERSION)."
