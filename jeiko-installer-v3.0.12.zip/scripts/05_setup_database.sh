#!/bin/bash
set -euo pipefail
# shellcheck source=../lib/jeiko-common.sh
source /usr/local/lib/jeiko/common.sh

jeiko_step "[05] Base de données et rôle applicatif"
jeiko_require_root

: "${DB_NAME:?DB_NAME manquant}"
: "${DB_USER:?DB_USER manquant}"
: "${DB_PASS:?DB_PASS manquant}"

# --------------------------------------------------------------------------- #
# Rôle
#
# L'ancienne version interpolait le mot de passe directement dans la chaîne SQL
# (`PASSWORD '$DB_PASS'`) : une apostrophe suffisait à casser l'installation,
# et un mot de passe choisi malicieusement à injecter du SQL exécuté en tant
# que superutilisateur postgres.
#
# Ici, psql reçoit la valeur comme variable (:'dbpass'), format() applique le
# quoting littéral (%L) et \gexec exécute la commande ainsi construite.
# --------------------------------------------------------------------------- #
ROLE_EXISTS="$(sudo -u postgres psql -tAc \
    "SELECT 1 FROM pg_roles WHERE rolname = '$(sed "s/'/''/g" <<<"$DB_USER")'")"

if [[ "$ROLE_EXISTS" == "1" ]]; then
    jeiko_log "ℹ️  Rôle '$DB_USER' déjà présent → mise à jour du mot de passe."
    SQL_ROLE="SELECT format('ALTER ROLE %I WITH LOGIN PASSWORD %L', :'dbuser', :'dbpass')"
else
    SQL_ROLE="SELECT format('CREATE ROLE %I WITH LOGIN PASSWORD %L', :'dbuser', :'dbpass')"
fi

sudo -u postgres psql -v ON_ERROR_STOP=1 \
    -v dbuser="$DB_USER" -v dbpass="$DB_PASS" \
    -q <<SQL
$SQL_ROLE \gexec
SQL

[[ "$ROLE_EXISTS" == "1" ]] || jeiko_ok "Rôle '$DB_USER' créé."

# Le rôle applicatif n'a aucun besoin de créer des bases ou d'autres rôles.
sudo -u postgres psql -v ON_ERROR_STOP=1 -v dbuser="$DB_USER" -q <<'SQL'
SELECT format('ALTER ROLE %I NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION', :'dbuser') \gexec
SQL

# --------------------------------------------------------------------------- #
# Base — createdb prend ses arguments en argv, aucune interpolation SQL.
# --------------------------------------------------------------------------- #
DB_EXISTS="$(sudo -u postgres psql -tAc \
    "SELECT 1 FROM pg_database WHERE datname = '$(sed "s/'/''/g" <<<"$DB_NAME")'")"

if [[ "$DB_EXISTS" != "1" ]]; then
    sudo -u postgres createdb -E UTF8 -T template0 -O "$DB_USER" "$DB_NAME"
    jeiko_ok "Base '$DB_NAME' créée (propriétaire : $DB_USER)."
else
    jeiko_log "ℹ️  Base '$DB_NAME' déjà présente."
fi

# --------------------------------------------------------------------------- #
# Droits
#
# Depuis PostgreSQL 15, le schéma public n'est plus inscriptible par défaut :
# sans ce GRANT explicite, `migrate` échoue avec « permission denied for
# schema public ».
# --------------------------------------------------------------------------- #
sudo -u postgres psql -v ON_ERROR_STOP=1 -v dbname="$DB_NAME" -v dbuser="$DB_USER" -q <<'SQL'
SELECT format('GRANT ALL PRIVILEGES ON DATABASE %I TO %I', :'dbname', :'dbuser') \gexec
SQL

sudo -u postgres psql -v ON_ERROR_STOP=1 -d "$DB_NAME" -v dbuser="$DB_USER" -q <<'SQL'
SELECT format('GRANT ALL ON SCHEMA public TO %I', :'dbuser') \gexec
SELECT format('ALTER SCHEMA public OWNER TO %I', :'dbuser') \gexec
SELECT format('ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO %I', :'dbuser') \gexec
SELECT format('ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO %I', :'dbuser') \gexec
SQL

# --------------------------------------------------------------------------- #
# Vérification de bout en bout : c'est exactement la connexion que Django fera.
# --------------------------------------------------------------------------- #
if PGPASSWORD="$DB_PASS" psql -h 127.0.0.1 -U "$DB_USER" -d "$DB_NAME" -tAc 'SELECT 1' >/dev/null 2>&1; then
    jeiko_ok "Connexion applicative vérifiée ($DB_USER@127.0.0.1/$DB_NAME)."
else
    jeiko_die "Connexion impossible avec les identifiants applicatifs — vérifie pg_hba.conf."
fi
