#!/bin/bash
set -euo pipefail
# shellcheck source=../lib/jeiko-common.sh
source /usr/local/lib/jeiko/common.sh

jeiko_step "[12] TLS Let's Encrypt et vhost HTTPS"
jeiko_require_root

: "${PROJECT_DIR:?PROJECT_DIR manquant}"
: "${SITE_NAME:?SITE_NAME manquant}"
: "${DOMAIN_NAME:?DOMAIN_NAME manquant}"

FINAL_CONF="/etc/nginx/sites-available/$SITE_NAME.conf"
ENABLED_CONF="/etc/nginx/sites-enabled/$SITE_NAME.conf"
ACME_ROOT="/var/www/acme"
CERT_DIR="/etc/letsencrypt/live/$DOMAIN_NAME"

WWW=0
jeiko_is_apex "$DOMAIN_NAME" && WWW=1

export DEBIAN_FRONTEND=noninteractive
dpkg -s certbot &>/dev/null || apt-get install -y certbot python3-certbot-nginx

# --------------------------------------------------------------------------- #
# 1) Obtention du certificat
#
# Authentificateur webroot plutôt que --nginx : certbot ne touche pas à la
# configuration, donc il ne peut pas la casser, et le renouvellement emprunte
# exactement le même chemin que la première émission — celui qu'on vient de
# valider à l'étape 11.
# --------------------------------------------------------------------------- #
DOM_ARGS=(-d "$DOMAIN_NAME")
(( WWW == 1 )) && DOM_ARGS+=(-d "www.$DOMAIN_NAME") || true

CERTBOT_EMAIL="${CERTBOT_EMAIL:-${DJANGO_SUPEREMAIL:-}}"
if [[ -n "$CERTBOT_EMAIL" ]]; then
    EMAIL_ARGS=(-m "$CERTBOT_EMAIL")
else
    # admin@<domaine> n'existe généralement pas : sans adresse valide, aucun
    # avertissement d'expiration ne parvient jamais.
    EMAIL_ARGS=(--register-unsafely-without-email)
    jeiko_warn "Aucune adresse e-mail : pas d'alerte avant expiration du certificat."
fi

install -d -m 0755 "$ACME_ROOT/.well-known/acme-challenge"

if [[ -f "$CERT_DIR/fullchain.pem" ]]; then
    jeiko_log "ℹ️  Certificat déjà présent pour $DOMAIN_NAME, réémission ignorée."
else
    jeiko_log "🔏 Demande de certificat pour ${DOM_ARGS[*]}…"
    certbot certonly --webroot -w "$ACME_ROOT" \
        --non-interactive --agree-tos \
        "${EMAIL_ARGS[@]}" "${DOM_ARGS[@]}" \
        || jeiko_die "Certbot a échoué. Vérifie que $DOMAIN_NAME pointe bien vers ce serveur et que le port 80 est joignable."
fi

CRT="$CERT_DIR/fullchain.pem"
KEY="$CERT_DIR/privkey.pem"
[[ -f "$CRT" && -f "$KEY" ]] || jeiko_die "Certificats introuvables ($CRT)."

# --------------------------------------------------------------------------- #
# 2) Réglages TLS
#
# L'ancienne configuration écrasait celle de certbot sans jamais inclure
# options-ssl-nginx.conf : le site retombait sur les défauts de nginx, protocoles
# obsolètes compris. On l'inclut, avec un repli explicite si le fichier manque.
# --------------------------------------------------------------------------- #
SSL_OPTIONS="/etc/letsencrypt/options-ssl-nginx.conf"
SSL_DHPARAM="/etc/letsencrypt/ssl-dhparams.pem"

if [[ -f "$SSL_OPTIONS" ]]; then
    SSL_INCLUDE="include $SSL_OPTIONS;"
else
    SSL_INCLUDE=$(cat <<'TLS'
ssl_protocols TLSv1.2 TLSv1.3;
    ssl_prefer_server_ciphers off;
    ssl_ciphers ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305;
    ssl_session_cache shared:JeikoSSL:10m;
    ssl_session_timeout 1d;
    ssl_session_tickets off;
TLS
)
fi

DHPARAM_LINE=""
[[ -f "$SSL_DHPARAM" ]] && DHPARAM_LINE="ssl_dhparam $SSL_DHPARAM;" || true

# `listen … http2` est déprécié depuis nginx 1.25 au profit de la directive
# `http2 on`. On choisit selon la version réellement installée pour éviter à la
# fois l'avertissement sur Debian 13 et l'erreur de syntaxe sur Debian 12.
NGX_VER="$(nginx -v 2>&1 | grep -oP '\d+\.\d+\.\d+' || echo 0.0.0)"
if [[ "$(printf '%s\n' "1.25.1" "$NGX_VER" | sort -V | head -n1)" == "1.25.1" ]]; then
    LISTEN_443="listen 443 ssl;\n    listen [::]:443 ssl;\n    http2 on;"
else
    LISTEN_443="listen 443 ssl http2;\n    listen [::]:443 ssl http2;"
fi

# --------------------------------------------------------------------------- #
# 3) Vhost final
# --------------------------------------------------------------------------- #
cp -a "$FINAL_CONF" "$FINAL_CONF.bak_$(date +%Y%m%d_%H%M%S)" 2>/dev/null || true
TMP_CONF="$(mktemp)"

{
    echo "# $SITE_NAME — configuration HTTPS (générée par l'installeur JEIKO)"
    echo ""
    echo "server {"
    echo "    listen 80;"
    echo "    listen [::]:80;"
    if (( WWW == 1 )); then
        echo "    server_name $DOMAIN_NAME www.$DOMAIN_NAME;"
    else
        echo "    server_name $DOMAIN_NAME;"
    fi
    echo ""
    echo "    # Le défi ACME reste servi en clair : sans cette exception, la"
    echo "    # redirection 301 ci-dessous renverrait le validateur Let's Encrypt"
    echo "    # vers HTTPS et le renouvellement échouerait au bout de 90 jours."
    echo "    location ^~ /.well-known/acme-challenge/ {"
    echo "        root $ACME_ROOT;"
    echo "        default_type \"text/plain\";"
    echo "        allow all;"
    echo "    }"
    echo ""
    echo "    location / { return 301 https://$DOMAIN_NAME\$request_uri; }"
    echo "}"
    echo ""

    if (( WWW == 1 )); then
        echo "# www → apex, en HTTPS"
        echo "server {"
        echo -e "    $LISTEN_443"
        echo "    server_name www.$DOMAIN_NAME;"
        echo ""
        echo "    ssl_certificate     $CRT;"
        echo "    ssl_certificate_key $KEY;"
        echo "    $SSL_INCLUDE"
        [[ -n "$DHPARAM_LINE" ]] && echo "    $DHPARAM_LINE" || true
        echo ""
        echo "    return 301 https://$DOMAIN_NAME\$request_uri;"
        echo "}"
        echo ""
    fi

    echo "# Serveur principal"
    echo "server {"
    echo -e "    $LISTEN_443"
    echo "    server_name $DOMAIN_NAME;"
    echo ""
    echo "    access_log /var/log/nginx/${SITE_NAME}_access.log;"
    echo "    error_log  /var/log/nginx/${SITE_NAME}_error.log;"
    echo ""
    echo "    ssl_certificate     $CRT;"
    echo "    ssl_certificate_key $KEY;"
    echo "    ssl_trusted_certificate $CERT_DIR/chain.pem;"
    echo "    ssl_stapling on;"
    echo "    ssl_stapling_verify on;"
    echo "    $SSL_INCLUDE"
    [[ -n "$DHPARAM_LINE" ]] && echo "    $DHPARAM_LINE" || true
    echo ""
    echo "    # HSTS n'est posé QUE sur le vhost TLS : l'envoyer depuis un site"
    echo "    # servi en clair rendrait le domaine inaccessible pendant un an si"
    echo "    # le certificat venait à manquer."
    echo "    add_header Strict-Transport-Security \"max-age=31536000; includeSubDomains\" always;"
    echo ""
    echo "    include /etc/nginx/snippets/jeiko-$SITE_NAME.conf;"
    echo "}"
} >"$TMP_CONF"

install -m 0644 -o root -g root "$TMP_CONF" "$FINAL_CONF"
rm -f "$TMP_CONF"
ln -sfn "$FINAL_CONF" "$ENABLED_CONF"

# --------------------------------------------------------------------------- #
# 4) Validation, avec retour arrière si la conf est invalide
# --------------------------------------------------------------------------- #
if ! nginx -t 2>&1; then
    jeiko_err "nginx -t a échoué sur la configuration HTTPS."
    LAST_BAK="$(find /etc/nginx/sites-available -name "$SITE_NAME.conf.bak_*" -printf '%T@ %p\n' 2>/dev/null | sort -rn | head -n1 | cut -d' ' -f2-)"
    if [[ -n "$LAST_BAK" ]]; then
        cp -a "$LAST_BAK" "$FINAL_CONF"
        jeiko_warn "Configuration précédente restaurée depuis $LAST_BAK"
        nginx -t && systemctl reload nginx || true
    fi
    jeiko_die "TLS non appliqué. Le site reste servi dans son état antérieur."
fi

systemctl reload nginx

# --------------------------------------------------------------------------- #
# 4bis) Bascule de l'application en mode HTTPS
#
# Sans ça, Django continue de se croire en HTTP : pas de redirection SSL, pas
# de cookies Secure, pas de HSTS — alors que le certificat est en place. Il
# fallait éditer le .env à la main, ce qui n'était écrit nulle part.
#
# Le service n'est redémarré que si la valeur change réellement.
# --------------------------------------------------------------------------- #
ENV_PATH="$PROJECT_DIR/$SITE_NAME/.env"
SERVICE_NAME="${GUNICORN_SERVICE:-gunicorn-$SITE_NAME}"

if [[ -f "$ENV_PATH" ]]; then
    if grep -qE '^\s*JEIKO_SSL\s*=\s*"?True"?\s*$' "$ENV_PATH"; then
        jeiko_log "ℹ️  JEIKO_SSL est déjà à True."
    else
        if grep -qE '^\s*JEIKO_SSL\s*=' "$ENV_PATH"; then
            sed -ri 's|^\s*JEIKO_SSL\s*=.*|JEIKO_SSL="True"|' "$ENV_PATH"
        else
            printf 'JEIKO_SSL="True"\n' >>"$ENV_PATH"
        fi
        chown "${SITE_USER:-jeiko-$SITE_NAME}":www-data "$ENV_PATH"
        chmod "$JEIKO_SECRET_MODE" "$ENV_PATH"
        jeiko_ok "JEIKO_SSL=True — redirection HTTPS, cookies Secure et HSTS activés."

        if systemctl is-active --quiet "$SERVICE_NAME"; then
            systemctl restart "$SERVICE_NAME"
            jeiko_log "🔁 $SERVICE_NAME redémarré pour prendre en compte la bascule."
        fi
    fi

    # La fiche du site sert de source de vérité à jeiko-server-update : si elle
    # reste à "n", une convergence ultérieure régénérerait un vhost sans TLS.
    CONF_SITE="$(jeiko_site_conf_path "$SITE_NAME")"
    if [[ -f "$CONF_SITE" ]] && ! grep -qE "^ENABLE_SSL='y'" "$CONF_SITE"; then
        sed -ri "s|^ENABLE_SSL=.*|ENABLE_SSL='y'|" "$CONF_SITE"
        jeiko_ok "Fiche du site mise à jour : ENABLE_SSL=y"
    fi
else
    # Le certificat est en place mais l'application l'ignore : elle continuera à
    # se croire en HTTP, donc à produire des liens et des cookies non sécurisés.
    # Un TLS à moitié posé est pire qu'un TLS absent — on ne le laisse pas passer.
    jeiko_err ".env introuvable ($ENV_PATH) : JEIKO_SSL n'a pas pu être basculé."
    jeiko_err "L'application se croirait en HTTP malgré le certificat."
    jeiko_die "Configuration TLS incomplète."
fi

# --------------------------------------------------------------------------- #
# 5) Renouvellement automatique
#
# On vérifie que le renouvellement fonctionne MAINTENANT, pendant qu'on est
# devant la machine, plutôt que de le découvrir à l'expiration.
# --------------------------------------------------------------------------- #
install -d -m 0755 /etc/letsencrypt/renewal-hooks/deploy
cat >/etc/letsencrypt/renewal-hooks/deploy/10-reload-nginx.sh <<'HOOK'
#!/bin/bash
# Recharge nginx après chaque renouvellement de certificat.
systemctl reload nginx || true
HOOK
chmod 0755 /etc/letsencrypt/renewal-hooks/deploy/10-reload-nginx.sh

systemctl enable --now certbot.timer 2>/dev/null || true

jeiko_log "🧪 Simulation d'un renouvellement…"
if certbot renew --dry-run --cert-name "$DOMAIN_NAME" 2>&1 | tail -n 5; then
    jeiko_ok "Le renouvellement automatique fonctionne."
else
    jeiko_warn "La simulation de renouvellement a échoué : le certificat expirera dans 90 jours sans intervention."
fi

jeiko_ok "TLS actif pour $DOMAIN_NAME."
