#!/bin/bash
set -euo pipefail
# shellcheck source=../lib/jeiko-common.sh
source /usr/local/lib/jeiko/common.sh

jeiko_step "[04] PostgreSQL — service et durcissement"
jeiko_require_root

command -v psql >/dev/null 2>&1 || jeiko_die "PostgreSQL absent (psql introuvable). Lance 03_check_dependencies.sh."

systemctl enable --now postgresql

# --------------------------------------------------------------------------- #
# Localisation du cluster
#
# pg_lsclusters affiche un en-tête : on filtre sur les lignes de données plutôt
# que sur « NR==2 », qui cassait dès qu'un second cluster existait.
# --------------------------------------------------------------------------- #
CLUSTER_LINE="$(pg_lsclusters --no-header 2>/dev/null | awk '$4=="online"{print; exit}')"
[[ -n "$CLUSTER_LINE" ]] || CLUSTER_LINE="$(pg_lsclusters --no-header 2>/dev/null | head -n1)"
[[ -n "$CLUSTER_LINE" ]] || jeiko_die "Aucun cluster PostgreSQL détecté."

PG_VER="$(awk '{print $1}' <<<"$CLUSTER_LINE")"
PG_CLUSTER="$(awk '{print $2}' <<<"$CLUSTER_LINE")"
PG_CONF_DIR="/etc/postgresql/$PG_VER/$PG_CLUSTER"

PG_CONF="$PG_CONF_DIR/postgresql.conf"
HBA_CONF="$PG_CONF_DIR/pg_hba.conf"
[[ -f "$PG_CONF" && -f "$HBA_CONF" ]] || jeiko_die "Configuration PostgreSQL introuvable dans $PG_CONF_DIR"

jeiko_log "ℹ️  Cluster $PG_VER/$PG_CLUSTER ($PG_CONF_DIR)"

cp -n "$PG_CONF" "$PG_CONF.jeiko.bak" 2>/dev/null || true
cp -n "$HBA_CONF" "$HBA_CONF.jeiko.bak" 2>/dev/null || true

# --------------------------------------------------------------------------- #
# Écoute locale uniquement + chiffrement scram
# --------------------------------------------------------------------------- #
CHANGED=0
if ! grep -qE "^listen_addresses\s*=\s*'127\.0\.0\.1'" "$PG_CONF"; then
    sed -ri "s|^#?\s*listen_addresses.*|listen_addresses = '127.0.0.1'|" "$PG_CONF"
    jeiko_log "🔒 listen_addresses = 127.0.0.1 (base non exposée au réseau)."
    CHANGED=1
fi
if ! grep -qE "^password_encryption\s*=\s*scram-sha-256" "$PG_CONF"; then
    sed -ri "s|^#?\s*password_encryption.*|password_encryption = scram-sha-256|" "$PG_CONF"
    jeiko_log "🔐 password_encryption = scram-sha-256"
    CHANGED=1
fi

# --------------------------------------------------------------------------- #
# pg_hba
#
# On remplace les lignes host locales existantes plutôt que d'en empiler de
# nouvelles à chaque réinstallation : le fichier finissait par accumuler des
# doublons contradictoires, et c'est la PREMIÈRE règle correspondante qui
# gagne — donc une vieille ligne 'md5' pouvait masquer le scram ajouté en fin
# de fichier.
# --------------------------------------------------------------------------- #
if ! grep -q '# JEIKO' "$HBA_CONF"; then
    # Délimiteur '#' et non '|' : le motif contient lui-même une alternance
    # (127.0.0.1/32|::1/128), et sed refermait l'expression sur ce '|'.
    sed -ri 's#^(host\s+all\s+all\s+(127\.0\.0\.1/32|::1/128)\s+).*#\1scram-sha-256#' "$HBA_CONF"
    {
        echo ""
        echo "# JEIKO — connexions applicatives locales"
        grep -qE '^host\s+all\s+all\s+127\.0\.0\.1/32' "$HBA_CONF" || \
            echo "host    all             all             127.0.0.1/32            scram-sha-256"
        grep -qE '^host\s+all\s+all\s+::1/128' "$HBA_CONF" || \
            echo "host    all             all             ::1/128                 scram-sha-256"
    } >>"$HBA_CONF"
    CHANGED=1
fi

# --------------------------------------------------------------------------- #
# Dimensionnement
#
# PostgreSQL sort de l'installation avec shared_buffers = 128 Mo quelle que
# soit la machine — un réglage prévu pour ne jamais échouer à démarrer, pas
# pour servir un site. Sur un VPS de 4 Go, la base travaille avec 3 % de la
# mémoire disponible et relit constamment le disque.
#
# Les valeurs ci-dessous suivent les recommandations usuelles : 25 % de la RAM
# en cache partagé, 75 % annoncés comme cache effectif (le noyau met en cache
# le reste), et un work_mem prudent puisqu'il est alloué PAR opération de tri.
# --------------------------------------------------------------------------- #
RAM_MB="$(awk '/MemTotal/ {print int($2/1024)}' /proc/meminfo)"
CPU="$(nproc --all 2>/dev/null || echo 2)"

SHARED_BUFFERS=$(( RAM_MB / 4 ));            (( SHARED_BUFFERS < 128 ))  && SHARED_BUFFERS=128
EFFECTIVE_CACHE=$(( RAM_MB * 3 / 4 ));       (( EFFECTIVE_CACHE < 256 )) && EFFECTIVE_CACHE=256
MAINTENANCE_MEM=$(( RAM_MB / 16 ));          (( MAINTENANCE_MEM < 64 ))  && MAINTENANCE_MEM=64
                                             (( MAINTENANCE_MEM > 512 )) && MAINTENANCE_MEM=512
# work_mem est alloué PAR opération de tri, pas par connexion — et plusieurs
# sites partagent cette instance. Une valeur généreuse multipliée par le nombre
# de tris simultanés est le moyen classique de faire intervenir le tueur de
# processus. On reste modeste.
WORK_MEM=$(( RAM_MB / 128 ));                (( WORK_MEM < 4 ))          && WORK_MEM=4
                                             (( WORK_MEM > 16 ))         && WORK_MEM=16
WORKERS=$CPU;                                (( WORKERS > 8 ))           && WORKERS=8

install -d -m 0755 -o postgres -g postgres "$PG_CONF_DIR/conf.d"

# Debian déclare « include_dir = 'conf.d' » en fin de postgresql.conf, mais on
# ne s'appuie pas dessus : si la directive manque, le fichier ci-dessous serait
# écrit sans jamais être lu, et le dimensionnement passerait inaperçu.
if ! grep -qE "^\s*include_dir\s*=\s*'conf\.d'" "$PG_CONF"; then
    printf "\n# Ajouté par l'installeur JEIKO\ninclude_dir = 'conf.d'\n" >>"$PG_CONF"
    jeiko_log "ℹ️  include_dir = 'conf.d' ajouté à postgresql.conf"
fi

cat >"$PG_CONF_DIR/conf.d/50-jeiko.conf" <<PGCONF
# Dimensionnement JEIKO — ${RAM_MB} Mo de RAM, ${CPU} CPU.
# Fichier séparé : postgresql.conf reste celui de la distribution, et une
# réinstallation ne produit pas d'empilement de directives contradictoires.

shared_buffers = ${SHARED_BUFFERS}MB
effective_cache_size = ${EFFECTIVE_CACHE}MB
maintenance_work_mem = ${MAINTENANCE_MEM}MB
work_mem = ${WORK_MEM}MB

# SSD : la lecture aléatoire ne coûte pas 4 fois la lecture séquentielle.
random_page_cost = 1.1
effective_io_concurrency = 200

max_worker_processes = ${WORKERS}
max_parallel_workers = ${WORKERS}
max_parallel_workers_per_gather = $(( WORKERS > 2 ? 2 : 1 ))

# Journalisation des requêtes lentes : de quoi diagnostiquer une page qui
# traîne, sans noyer le journal.
log_min_duration_statement = 2000
log_line_prefix = '%m [%p] %q%u@%d '
log_checkpoints = on
log_autovacuum_min_duration = 10000
PGCONF

chown postgres:postgres "$PG_CONF_DIR/conf.d/50-jeiko.conf" 2>/dev/null || true
chmod 0644 "$PG_CONF_DIR/conf.d/50-jeiko.conf" 2>/dev/null || true
jeiko_ok "Dimensionné pour ${RAM_MB} Mo / ${CPU} CPU (shared_buffers ${SHARED_BUFFERS} Mo)"
CHANGED=1

if [[ $CHANGED -eq 1 ]]; then
    # restart plutôt que reload : listen_addresses ne se recharge pas à chaud.
    systemctl restart postgresql
else
    jeiko_log "ℹ️  Configuration PostgreSQL déjà conforme."
fi

sudo -u postgres psql -tAc 'SELECT 1' >/dev/null || jeiko_die "PostgreSQL ne répond pas après configuration."
jeiko_ok "PostgreSQL prêt (écoute locale, scram-sha-256)."
