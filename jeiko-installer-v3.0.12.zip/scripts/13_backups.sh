#!/bin/bash
set -euo pipefail
# shellcheck source=../lib/jeiko-common.sh
source /usr/local/lib/jeiko/common.sh

jeiko_step "[13] Sauvegardes (base, médias, configuration)"
jeiko_require_root

: "${SITE_NAME:?SITE_NAME manquant}"
: "${PROJECT_DIR:?PROJECT_DIR manquant}"
: "${DB_NAME:?DB_NAME manquant}"

BACKUP_DIR="$JEIKO_BACKUP_DIR/$SITE_NAME"
BACKUP_SCRIPT="/usr/local/sbin/jeiko-backup"
RESTORE_SCRIPT="/usr/local/sbin/jeiko-restore"

install -d -m 0700 -o root -g root "$BACKUP_DIR/daily" "$BACKUP_DIR/pre-update"

# --------------------------------------------------------------------------- #
# Script de sauvegarde — générique, un seul exemplaire pour tous les sites
#
# L'ancienne version générait un script par site avec le mot de passe
# PostgreSQL écrit en clair à l'intérieur. Ici les identifiants sont lus depuis
# la fiche du site (/etc/jeiko/sites/<site>.conf, 0600 root:root) au moment de
# l'exécution : ils n'existent qu'à un seul endroit sur le disque.
# --------------------------------------------------------------------------- #
cat >"$BACKUP_SCRIPT" <<'BACKUP'
#!/bin/bash
# jeiko-backup <site> — sauvegarde base + médias + configuration.
set -euo pipefail
source /usr/local/lib/jeiko/common.sh
jeiko_require_root

SITE="${1:?Usage: jeiko-backup <site>}"
jeiko_load_site "$SITE" || exit 1

RETENTION_DAYS="${JEIKO_BACKUP_RETENTION_DAYS:-30}"
DEST="$JEIKO_BACKUP_DIR/$SITE/daily/$(date +%Y%m%d_%H%M%S)"
install -d -m 0700 "$DEST"

# Une sauvegarde à moitié écrite est pire qu'aucune : si quoi que ce soit
# échoue, on efface le répertoire pour ne pas laisser croire à une archive
# valide, et le code de sortie non nul déclenche l'alerte cron.
trap 'rc=$?; [[ $rc -ne 0 ]] && rm -rf "$DEST" && echo "❌ Sauvegarde $SITE échouée, répertoire supprimé." >&2; exit $rc' EXIT

PGPASSWORD="$DB_PASS" pg_dump -h 127.0.0.1 -U "$DB_USER" -d "$DB_NAME" \
    --format=custom --compress=6 --file="$DEST/${DB_NAME}.dump"

# pg_restore --list échoue sur une archive tronquée : c'est une vérification
# bon marché qui distingue un dump exploitable d'un fichier de la bonne taille.
pg_restore --list "$DEST/${DB_NAME}.dump" >/dev/null

if [[ -d "$PROJECT_DIR/mediadir" ]]; then
    tar -czf "$DEST/media.tar.gz" -C "$PROJECT_DIR" mediadir
fi

tar -czf "$DEST/config.tar.gz" \
    -C / \
    "etc/jeiko/sites/$SITE.conf" \
    "etc/nginx/sites-available/$SITE.conf" \
    "${PROJECT_DIR#/}/$SITE/.env" 2>/dev/null || true

chmod -R go= "$DEST"
sha256sum "$DEST"/* >"$DEST/SHA256SUMS" 2>/dev/null || true

# ── Copie hors-site ─────────────────────────────────────────────────────────
#
# Sans elle, tout le dispositif protège contre l'intrusion mais rien contre la
# perte : un root compromis, un rançongiciel ou la disparition du VPS emporte
# les sauvegardes avec le site, puisqu'elles sont sur la même machine.
#
# Désactivée tant que JEIKO_OFFSITE_TARGET n'est pas renseignée dans la fiche
# du site. Deux formes acceptées :
#   · rclone   → "rclone:nom-du-remote:chemin"   (chiffrement côté remote)
#   · rsync    → "rsync:user@hote:/chemin"       (par SSH, clé sans phrase)
#
# Le dump est chiffré avant l'envoi si JEIKO_OFFSITE_PASSPHRASE_FILE pointe sur
# un fichier lisible par root seul : ce qui part hors de la machine ne doit pas
# être une base de données en clair.
if [[ -n "${JEIKO_OFFSITE_TARGET:-}" ]]; then
    SEND_DIR="$DEST"

    if [[ -n "${JEIKO_OFFSITE_PASSPHRASE_FILE:-}" && -r "$JEIKO_OFFSITE_PASSPHRASE_FILE" ]]; then
        if command -v gpg >/dev/null 2>&1; then
            SEND_DIR="$DEST.enc"
            mkdir -p "$SEND_DIR"; chmod 700 "$SEND_DIR"
            for f in "$DEST"/*; do
                [[ -f "$f" ]] || continue
                gpg --batch --yes --quiet --symmetric --cipher-algo AES256 \
                    --passphrase-file "$JEIKO_OFFSITE_PASSPHRASE_FILE" \
                    --output "$SEND_DIR/$(basename "$f").gpg" "$f"
            done
            echo "🔐 Archive chiffrée avant envoi."
        else
            echo "⚠️  gpg absent : envoi hors-site EN CLAIR." >&2
        fi
    else
        echo "⚠️  Pas de passphrase configurée : envoi hors-site en clair." >&2
    fi

    OFFSITE_KIND="${JEIKO_OFFSITE_TARGET%%:*}"
    OFFSITE_DEST="${JEIKO_OFFSITE_TARGET#*:}"
    REMOTE_PATH="$OFFSITE_DEST/$SITE/$(basename "$DEST")"

    case "$OFFSITE_KIND" in
        rclone)
            command -v rclone >/dev/null 2>&1 || { echo "❌ rclone absent." >&2; exit 1; }
            rclone copy --quiet "$SEND_DIR" "$REMOTE_PATH" \
                || { echo "❌ Envoi hors-site (rclone) échoué." >&2; exit 1; }
            ;;
        rsync)
            command -v rsync >/dev/null 2>&1 || { echo "❌ rsync absent." >&2; exit 1; }
            rsync -az --chmod=D700,F600 -e 'ssh -o BatchMode=yes -o StrictHostKeyChecking=accept-new' \
                "$SEND_DIR/" "$REMOTE_PATH/" \
                || { echo "❌ Envoi hors-site (rsync) échoué." >&2; exit 1; }
            ;;
        *)
            echo "❌ JEIKO_OFFSITE_TARGET mal formé : attendu 'rclone:…' ou 'rsync:…'." >&2
            exit 1
            ;;
    esac

    [[ "$SEND_DIR" != "$DEST" ]] && rm -rf "$SEND_DIR" || true
    echo "☁️  Copie hors-site : $REMOTE_PATH"
else
    echo "ℹ️  Pas de copie hors-site (JEIKO_OFFSITE_TARGET non renseignée dans la fiche du site)."
fi

# Rotation par ancienneté plutôt que par nombre : garder « les 30 derniers »
# ne dit rien de la fenêtre réellement couverte si le cron a été interrompu.
find "$JEIKO_BACKUP_DIR/$SITE/daily" -maxdepth 1 -type d -name '20*' \
     -mtime "+$RETENTION_DAYS" -exec rm -rf {} + 2>/dev/null || true

echo "✅ Sauvegarde de $SITE : $DEST ($(du -sh "$DEST" | cut -f1))"
BACKUP

chown root:root "$BACKUP_SCRIPT"
chmod 0700 "$BACKUP_SCRIPT"

# --------------------------------------------------------------------------- #
# Script de restauration
#
# Une sauvegarde qu'on ne sait pas restaurer n'est pas une sauvegarde. Ce
# script est le pendant explicite de jeiko-backup, à lancer à la main.
# --------------------------------------------------------------------------- #
cat >"$RESTORE_SCRIPT" <<'RESTORE'
#!/bin/bash
# jeiko-restore <site> <répertoire-de-sauvegarde> — restauration complète.
set -euo pipefail
source /usr/local/lib/jeiko/common.sh
jeiko_require_root

SITE="${1:?Usage: jeiko-restore <site> <répertoire>}"
SRC="${2:?Usage: jeiko-restore <site> <répertoire>}"
jeiko_load_site "$SITE" || exit 1

[[ -d "$SRC" ]] || jeiko_die "Répertoire de sauvegarde introuvable : $SRC"
DUMP="$(find "$SRC" -maxdepth 1 -name '*.dump' | head -n1)"
[[ -n "$DUMP" ]] || jeiko_die "Aucun dump dans $SRC"

echo "⚠️  Cette opération ÉCRASE la base '$DB_NAME' et les médias du site '$SITE'."
echo "    Source : $SRC"
read -rp "    Taper le nom du site pour confirmer : " confirm
[[ "$confirm" == "$SITE" ]] || { echo "Annulé."; exit 0; }

jeiko_log "⏸️  Arrêt de $GUNICORN_SERVICE…"
systemctl stop "$GUNICORN_SERVICE" || true

jeiko_log "🛢️  Restauration de la base…"
PGPASSWORD="$DB_PASS" pg_restore -h 127.0.0.1 -U "$DB_USER" -d "$DB_NAME" \
    --clean --if-exists --no-owner --role="$DB_USER" "$DUMP"

if [[ -f "$SRC/media.tar.gz" ]]; then
    jeiko_log "🖼️  Restauration des médias…"
    rm -rf "$PROJECT_DIR/mediadir.old"
    [[ -d "$PROJECT_DIR/mediadir" ]] && mv "$PROJECT_DIR/mediadir" "$PROJECT_DIR/mediadir.old" || true
    tar -xzf "$SRC/media.tar.gz" -C "$PROJECT_DIR"
fi

jeiko_fix_perms "$PROJECT_DIR" "$SITE_USER" "$SITE" "$VENV_DIR"
systemctl start "$GUNICORN_SERVICE"
jeiko_ok "Restauration terminée. Anciens médias conservés dans mediadir.old."
RESTORE

chmod 0700 "$RESTORE_SCRIPT"
chown root:root "$RESTORE_SCRIPT"

# --------------------------------------------------------------------------- #
# Planification
#
# Horaire décalé par site (dérivé du nom) : dix sites qui lancent leur pg_dump
# à 3 h 17 pile mettent la machine à genoux.
# --------------------------------------------------------------------------- #
MINUTE=$(( $(printf '%s' "$SITE_NAME" | cksum | cut -d' ' -f1) % 60 ))
HOUR=$(( 2 + $(printf '%s' "$SITE_NAME" | cksum | cut -d' ' -f1) % 3 ))

cat >"/etc/cron.d/jeiko-backup-$SITE_NAME" <<EOF
# Sauvegarde quotidienne du site $SITE_NAME
SHELL=/bin/bash
PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
$MINUTE $HOUR * * * root $BACKUP_SCRIPT $SITE_NAME >>/var/log/jeiko/$SITE_NAME/backup.log 2>&1
EOF
chmod 0644 "/etc/cron.d/jeiko-backup-$SITE_NAME"

cat >"/etc/logrotate.d/jeiko-$SITE_NAME" <<EOF
/var/log/jeiko/$SITE_NAME/*.log {
    weekly
    rotate 8
    compress
    missingok
    notifempty
    create 0640 root ${SITE_USER:-root}
}
EOF

# --------------------------------------------------------------------------- #
# Vérification immédiate
# --------------------------------------------------------------------------- #
jeiko_log "🧪 Sauvegarde de contrôle…"
if "$BACKUP_SCRIPT" "$SITE_NAME"; then
    jeiko_ok "Sauvegardes opérationnelles (quotidiennes à ${HOUR}h${MINUTE})."
else
    jeiko_warn "La sauvegarde de contrôle a échoué — à corriger avant la mise en production."
fi

jeiko_log "   Restauration : sudo jeiko-restore $SITE_NAME $BACKUP_DIR/daily/<horodatage>"

# --------------------------------------------------------------------------- #
# Surveillance
#
# Rien n'avertissait d'un disque qui se remplit ni d'un certificat qui approche
# de l'expiration. Les deux ne se manifestent qu'au moment où le site tombe :
# le premier fait échouer les écritures PostgreSQL, le second rend le domaine
# inaccessible d'un coup.
#
# Volontairement minimal : un contrôle quotidien qui écrit dans un journal et
# n'alerte que sur seuil franchi.
# --------------------------------------------------------------------------- #
cat >/usr/local/sbin/jeiko-verifier <<'CONTROLE'
#!/bin/bash
# jeiko-verifier — état de santé du serveur. Quotidien, ou à la demande.
set -uo pipefail
source /usr/local/lib/jeiko/common.sh

ALERTES=0
signaler() { printf '⚠️  %s\n' "$*"; ALERTES=$((ALERTES + 1)); }

printf '── Contrôle du %s ──\n' "$(date '+%d/%m/%Y %H:%M')"

# Disque : à 100 %, PostgreSQL cesse d'écrire et le site renvoie des erreurs.
while read -r pcent monte; do
    [[ "$pcent" -ge 90 ]] && signaler "Disque $monte à ${pcent}% — libérer de la place." || true
done < <(df -P --output=pcent,target / /var 2>/dev/null | tail -n +2 | tr -d '%' | awk '{print $1, $2}')

# Mémoire
DISPO=$(awk '/MemAvailable/ {print int($2/1024)}' /proc/meminfo)
[[ "$DISPO" -lt 150 ]] && signaler "Mémoire disponible : ${DISPO} Mo." || true

# Certificats
if [[ -d /etc/letsencrypt/live ]]; then
    for cert in /etc/letsencrypt/live/*/cert.pem; do
        [[ -f "$cert" ]] || continue
        FIN=$(date -d "$(openssl x509 -enddate -noout -in "$cert" | cut -d= -f2)" +%s 2>/dev/null || echo 0)
        [[ "$FIN" -eq 0 ]] && continue
        JOURS=$(( (FIN - $(date +%s)) / 86400 ))
        # Certbot renouvelle à 30 jours : en dessous de 20, il a échoué.
        [[ "$JOURS" -lt 20 ]] && signaler "Certificat $(basename "$(dirname "$cert")") expire dans ${JOURS} j — le renouvellement automatique ne fonctionne pas." || true
    done
fi

# Services
for site in $(jeiko_list_sites); do
    ( source "$(jeiko_site_conf_path "$site")"
      systemctl is-active --quiet "$GUNICORN_SERVICE" || signaler "Service $GUNICORN_SERVICE arrêté." ) || ALERTES=$((ALERTES + 1))
done
for svc in nginx postgresql memcached fail2ban; do
    systemctl is-active --quiet "$svc" || signaler "Service $svc arrêté."
done

# Sauvegardes : une sauvegarde qui a cessé de tourner ne se voit pas.
for site in $(jeiko_list_sites); do
    DERNIERE=$(find "/var/backups/jeiko/$site/daily" -maxdepth 1 -type d -name '20*' -mtime -2 2>/dev/null | head -n1)
    [[ -z "$DERNIERE" ]] && signaler "Aucune sauvegarde de « $site » depuis plus de 48 h." || true
done

if [[ $ALERTES -eq 0 ]]; then
    echo "✅ Rien à signaler."
else
    echo "❌ $ALERTES point(s) à traiter."
fi
exit 0
CONTROLE
chmod 0755 /usr/local/sbin/jeiko-verifier
chown root:root /usr/local/sbin/jeiko-verifier

install -d -m 0755 /var/log/jeiko
cat >/etc/cron.d/jeiko-verifier <<'CRON'
# Contrôle de santé quotidien — journal dans /var/log/jeiko/verification.log
SHELL=/bin/bash
PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
30 7 * * * root /usr/local/sbin/jeiko-verifier >>/var/log/jeiko/verification.log 2>&1
CRON
chmod 0644 /etc/cron.d/jeiko-verifier

cat >/etc/logrotate.d/jeiko-verifier <<'ROT'
/var/log/jeiko/verification.log {
    monthly
    rotate 6
    compress
    missingok
    notifempty
    create 0640 root root
}
ROT

jeiko_ok "Surveillance quotidienne : sudo jeiko-verifier (disque, mémoire, certificats, services, sauvegardes)"
