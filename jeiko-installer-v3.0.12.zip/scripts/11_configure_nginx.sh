#!/bin/bash
set -euo pipefail
# shellcheck source=../lib/jeiko-common.sh
source /usr/local/lib/jeiko/common.sh

jeiko_step "[11] Nginx (vhost HTTP, prêt pour Certbot)"
jeiko_require_root

: "${PROJECT_DIR:?PROJECT_DIR manquant}"
: "${SITE_NAME:?SITE_NAME manquant}"
: "${DOMAIN_NAME:?DOMAIN_NAME manquant}"

NGX_AVAIL="/etc/nginx/sites-available/$SITE_NAME.conf"
NGX_ENABLED="/etc/nginx/sites-enabled/$SITE_NAME.conf"
STATIC_ROOT="$PROJECT_DIR/staticdir"
MEDIA_ROOT="$PROJECT_DIR/mediadir"
SOCKET_PATH="/run/${GUNICORN_SERVICE:-gunicorn-$SITE_NAME}/gunicorn.sock"
ACME_ROOT="/var/www/acme"

if jeiko_is_apex "$DOMAIN_NAME"; then
    SERVER_NAMES="$DOMAIN_NAME www.$DOMAIN_NAME"
else
    SERVER_NAMES="$DOMAIN_NAME"
fi

install -d -m 0755 "$ACME_ROOT/.well-known/acme-challenge"
chown -R root:www-data "$ACME_ROOT"

# --------------------------------------------------------------------------- #
# 1) Réglages globaux partagés par tous les sites
#
# La zone limit_req doit vivre dans le contexte http{}, pas dans un server{}.
# L'ancienne configuration activait le jail fail2ban « nginx-req-limit » sans
# qu'aucune zone n'existe : le filtre ne pouvait rien matcher, la protection
# était purement décorative.
# --------------------------------------------------------------------------- #
GLOBAL_CONF="/etc/nginx/conf.d/00-jeiko-global.conf"

# --------------------------------------------------------------------------- #
# Sauvegarde de l'état PARTAGÉ, avant toute écriture
#
# Cette étape touche des fichiers communs à tous les sites de la machine. Si la
# configuration finale est invalide, retirer le seul vhost du nouveau site ne
# suffit pas : un fichier global cassé fait échouer « nginx -t », donc bloque
# tout rechargement, et les autres sites tombent au premier redémarrage. On
# restaure donc l'intégralité de l'état partagé en cas d'échec.
# --------------------------------------------------------------------------- #
NGX_STATE_BAK="$(mktemp -d /tmp/jeiko-nginx-state.XXXXXX)"
chmod 0700 "$NGX_STATE_BAK"
install -d "$NGX_STATE_BAK/conf.d" "$NGX_STATE_BAK/snippets"

jeiko_nginx_snapshot() {
    local f
    [[ -f "$GLOBAL_CONF" ]] && cp -a "$GLOBAL_CONF" "$NGX_STATE_BAK/conf.d/" || true
    for f in /etc/nginx/snippets/jeiko-*.conf; do
        [[ -f "$f" ]] && cp -a "$f" "$NGX_STATE_BAK/snippets/" || true
    done
}

jeiko_nginx_restore() {
    local f base
    # Fichiers globaux : restaurés s'ils existaient, supprimés sinon.
    if [[ -f "$NGX_STATE_BAK/conf.d/$(basename "$GLOBAL_CONF")" ]]; then
        cp -a "$NGX_STATE_BAK/conf.d/$(basename "$GLOBAL_CONF")" "$GLOBAL_CONF"
    else
        rm -f "$GLOBAL_CONF"
    fi
    for f in /etc/nginx/snippets/jeiko-*.conf; do
        [[ -f "$f" ]] || continue
        base="$(basename "$f")"
        if [[ -f "$NGX_STATE_BAK/snippets/$base" ]]; then
            cp -a "$NGX_STATE_BAK/snippets/$base" "$f"
        else
            rm -f "$f"          # créé par cette exécution
        fi
    done
}

trap 'rm -rf "$NGX_STATE_BAK"' EXIT
jeiko_nginx_snapshot

# Certaines directives ne tolèrent qu'une seule déclaration par contexte http{}.
# Debian en pose déjà plusieurs dans nginx.conf (server_tokens, gzip…), et une
# machine qui héberge d'autres sites peut en avoir ajouté. Les redéclarer fait
# échouer « nginx -t » — donc TOUS les sites de la machine, pas seulement celui
# qu'on installe. On ne pose que ce qui manque.
jeiko_nginx_has_directive() {
    local directive="$1" f
    grep -qE "^[[:space:]]*${directive}[[:space:]]" /etc/nginx/nginx.conf 2>/dev/null && return 0
    for f in /etc/nginx/conf.d/*.conf; do
        [[ -e "$f" ]] || continue
        [[ "$f" == "$GLOBAL_CONF" ]] && continue   # notre propre fichier
        grep -qE "^[[:space:]]*${directive}[[:space:]]" "$f" 2>/dev/null && return 0
    done
    return 1
}

# Émet « directive valeur; » seulement si la directive n'existe pas déjà.
jeiko_nginx_emit() {
    local directive="$1"; shift
    if jeiko_nginx_has_directive "$directive"; then
        jeiko_log "   nginx : $directive déjà défini ailleurs, conservé tel quel."
    else
        printf '%s %s;\n' "$directive" "$*" >>"$GLOBAL_CONF"
    fi
}

cat >"$GLOBAL_CONF" <<'EOF'
# Généré par l'installeur JEIKO — commun à tous les sites.
EOF

# Ne pas divulguer la version de nginx dans les en-têtes et pages d'erreur.
jeiko_nginx_emit server_tokens off

cat >>"$GLOBAL_CONF" <<'EOF'

# Zones de limitation. 'jeiko_general' protège l'ensemble du site,
# 'jeiko_login' cible les formulaires d'authentification, qui sont la vraie
# surface d'attaque par force brute.
limit_req_zone $binary_remote_addr zone=jeiko_general:10m rate=30r/s;
limit_req_zone $binary_remote_addr zone=jeiko_login:10m   rate=5r/m;
# Endpoints publics non authentifiés qui écrivent en base et envoient des
# e-mails (réservation de rendez-vous, formulaires de contact). Le débit
# général de 30 r/s était sans rapport avec leur coût réel.
limit_req_zone $binary_remote_addr zone=jeiko_write:10m   rate=10r/m;
limit_req_status 429;
limit_conn_zone $binary_remote_addr zone=jeiko_conn:10m;
EOF

# Compression. Debian active déjà « gzip on » dans nginx.conf : on ne la
# redéclare pas, on complète seulement ce qui manque.
printf '\n# Compression\n' >>"$GLOBAL_CONF"
jeiko_nginx_emit gzip            on
jeiko_nginx_emit gzip_vary       on
jeiko_nginx_emit gzip_proxied    any
jeiko_nginx_emit gzip_min_length 1024
jeiko_nginx_emit gzip_comp_level 5
jeiko_nginx_emit gzip_types \
    "text/plain text/css text/xml text/javascript" \
    "application/javascript application/json application/xml" \
    "application/rss+xml image/svg+xml font/woff font/woff2"

# Un upload d'image dépasse très vite le défaut de 1 Mo, qui se manifestait par
# un « 413 Request Entity Too Large » sans message côté application.
printf '\n# Tailles et délais\n' >>"$GLOBAL_CONF"
jeiko_nginx_emit client_max_body_size    25m
jeiko_nginx_emit client_body_timeout     60s
jeiko_nginx_emit client_header_timeout   20s
jeiko_nginx_emit send_timeout            60s

# --------------------------------------------------------------------------- #
# 2) Fragments réutilisés par le vhost HTTP et le vhost HTTPS (étape 12)
# --------------------------------------------------------------------------- #
install -d -m 0755 /etc/nginx/snippets

# En-têtes de sécurité.
#
# Ils sont dans un fichier à part et ré-inclus dans CHAQUE bloc location, car
# add_header ne s'hérite pas : dès qu'un bloc enfant déclare son propre
# add_header, tous ceux du parent sont ignorés. Des en-têtes posés au niveau
# server{} auraient donc disparu sur les pages de l'application — c'est-à-dire
# exactement là où ils comptent.
cat >/etc/nginx/snippets/jeiko-security-headers.conf <<'EOF'
add_header X-Content-Type-Options "nosniff" always;
add_header X-Frame-Options "SAMEORIGIN" always;
add_header Referrer-Policy "strict-origin-when-cross-origin" always;
add_header Permissions-Policy "accelerometer=(), geolocation=(), camera=(), microphone=(), payment=()" always;
add_header Cross-Origin-Opener-Policy "same-origin" always;
EOF

cat >"/etc/nginx/snippets/jeiko-$SITE_NAME.conf" <<EOF
# Corps commun du site $SITE_NAME — inclus par les vhosts HTTP et HTTPS.

# ── Médias exécutables ──────────────────────────────────────────────────────
# Location en expression régulière, donc évaluée AVANT le préfixe /media/.
# Un fichier téléversé ne doit jamais être interprété comme du contenu actif
# servi depuis l'origine du site : un .html ou un .svg déposé par un formulaire
# deviendrait sinon du XSS stocké sur le domaine principal, avec accès aux
# cookies de session.
#
# La capture nommée est indispensable : « alias » dans une location en regex
# doit recevoir le chemin complet, et une location imbriquée dans un bloc à
# alias n'en hérite pas de façon fiable.
location ~* ^/media/(?<jeiko_media_file>.+\.(?:html?|xht|xhtml|svgz?|xml|js|mjs|php|phtml|py|pl|sh|cgi))\$ {
    alias $MEDIA_ROOT/\$jeiko_media_file;
    types { }
    default_type application/octet-stream;
    add_header Content-Disposition "attachment" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Content-Security-Policy "sandbox" always;
}

# ── Statiques ───────────────────────────────────────────────────────────────
# ManifestStaticFilesStorage hache les noms de fichiers : le cache long est sûr,
# l'empreinte change à chaque déploiement.
location /static/ {
    alias $STATIC_ROOT/;
    try_files \$uri =404;
    access_log off;
    expires 1y;
    include /etc/nginx/snippets/jeiko-security-headers.conf;
    add_header Cache-Control "public, max-age=31536000, immutable" always;
}

# ── Médias ordinaires ───────────────────────────────────────────────────────
# Pas d'« immutable » ici : un média remplacé sous le même nom resterait gelé
# un an dans le cache des visiteurs.
location /media/ {
    alias $MEDIA_ROOT/;
    try_files \$uri =404;
    expires 7d;
    include /etc/nginx/snippets/jeiko-security-headers.conf;
    add_header Cache-Control "public, max-age=604800" always;
}

location = /favicon.ico { access_log off; log_not_found off; }
location = /robots.txt  { access_log off; log_not_found off; }

# Ni fichiers cachés, ni sauvegardes d'éditeur.
location ~ /\.        { deny all; }
location ~ ~\$         { deny all; }
location ~* \.(bak|old|orig|sql|dump|env)\$ { deny all; }

# ── Écritures publiques non authentifiées ───────────────────────────────────
# Réservation de rendez-vous : exempté de CSRF par conception (API publique),
# il écrit en base et déclenche des e-mails. Ses garde-fous applicatifs
# existent ; ce plafond réseau les complète.
location ~ ^/(calendars?|rendez-vous|api)/.*(book|reserve|appointment) {
    limit_req zone=jeiko_write burst=5 nodelay;
    include proxy_params;
    include /etc/nginx/snippets/jeiko-security-headers.conf;
    proxy_set_header Host \$host;
    proxy_set_header X-Forwarded-Host \$host;
    proxy_set_header X-Forwarded-Proto \$scheme;
    proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
    proxy_set_header X-Real-IP \$remote_addr;
    proxy_pass http://unix:$SOCKET_PATH;
}

# ── Authentification ────────────────────────────────────────────────────────
# Limitation stricte : c'est la vraie surface de force brute.
location ~ ^/(accounts|admin)/login {
    limit_req zone=jeiko_login burst=5 nodelay;
    include proxy_params;
    include /etc/nginx/snippets/jeiko-security-headers.conf;
    proxy_set_header Host \$host;
    proxy_set_header X-Forwarded-Host \$host;
    proxy_set_header X-Forwarded-Proto \$scheme;
    proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
    proxy_set_header X-Real-IP \$remote_addr;
    proxy_pass http://unix:$SOCKET_PATH;
}

# ── Application ─────────────────────────────────────────────────────────────
location / {
    limit_req zone=jeiko_general burst=60 nodelay;
    limit_conn jeiko_conn 30;

    include proxy_params;
    include /etc/nginx/snippets/jeiko-security-headers.conf;

    # Ces en-têtes sont RÉÉCRITS, jamais relayés depuis le client : Django se
    # fie à X-Forwarded-Proto pour savoir si la requête d'origine était en
    # HTTPS, un client ne doit pas pouvoir le forger.
    proxy_set_header Host \$host;
    proxy_set_header X-Forwarded-Host \$host;
    proxy_set_header X-Forwarded-Proto \$scheme;
    proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
    proxy_set_header X-Real-IP \$remote_addr;

    # 120 s : une mise à jour ne passe plus par une requête HTTP, mais un
    # import ou une génération de miniatures peut encore être long.
    proxy_read_timeout 120s;
    proxy_connect_timeout 30s;
    proxy_send_timeout 120s;
    proxy_buffering on;
    proxy_redirect off;

    proxy_pass http://unix:$SOCKET_PATH;
}
EOF

# --------------------------------------------------------------------------- #
# 3) Vhost HTTP
# --------------------------------------------------------------------------- #
[[ -f "$NGX_AVAIL" ]] && cp -a "$NGX_AVAIL" "$NGX_AVAIL.bak_$(date +%Y%m%d_%H%M%S)" || true

cat >"$NGX_AVAIL" <<EOF
# $SITE_NAME — vhost HTTP. Remplacé par l'étape 12 si TLS est activé.
server {
    listen 80;
    listen [::]:80;
    server_name $SERVER_NAMES;

    access_log /var/log/nginx/${SITE_NAME}_access.log;
    error_log  /var/log/nginx/${SITE_NAME}_error.log;

    # Doit rester servi en clair et sans redirection, y compris après passage
    # en HTTPS : c'est par là que Let's Encrypt valide les renouvellements.
    # « ^~ » empêche l'évaluation des locations en regex sur ce préfixe : le
    # défi ACME ne doit être intercepté ni par la règle « fichiers cachés »
    # (le chemin commence par /.well-known), ni par une redirection HTTPS.
    location ^~ /.well-known/acme-challenge/ {
        root $ACME_ROOT;
        default_type "text/plain";
        allow all;
    }

    include /etc/nginx/snippets/jeiko-$SITE_NAME.conf;
}
EOF

rm -f /etc/nginx/sites-enabled/default
ln -sfn "$NGX_AVAIL" "$NGX_ENABLED"

# --------------------------------------------------------------------------- #
# 4) Validation
#
# On teste AVANT de recharger : une configuration invalide rechargée met à
# terre tous les sites de la machine, pas seulement celui qu'on installe.
# --------------------------------------------------------------------------- #
if ! nginx -t 2>&1; then
    jeiko_err "nginx -t a échoué — la configuration N'A PAS été rechargée."
    jeiko_err "Vhosts actifs :"; ls -l /etc/nginx/sites-enabled/ || true

    # Retour à l'état d'avant : le vhost du site ET tout ce qui est partagé.
    rm -f "$NGX_ENABLED"
    jeiko_nginx_restore

    if nginx -t >/dev/null 2>&1; then
        jeiko_ok "État nginx d'origine restauré — les autres sites sont intacts."
    else
        jeiko_err "ATTENTION : nginx -t échoue encore APRÈS restauration."
        jeiko_err "Un problème préexistant affecte la configuration de la machine :"
        nginx -t || true
    fi
    jeiko_die "Vhost '$SITE_NAME' non installé, rien n'a été modifié durablement."
fi

if systemctl is-active --quiet nginx; then
    systemctl reload nginx
else
    systemctl enable --now nginx
fi

jeiko_ok "Nginx configuré pour $SERVER_NAMES (socket : $SOCKET_PATH)"
