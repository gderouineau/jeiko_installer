#!/bin/bash
set -euo pipefail
# shellcheck source=../lib/jeiko-common.sh
source /usr/local/lib/jeiko/common.sh

jeiko_step "[07] Environnement Python (venv)"
jeiko_require_root

: "${PROJECT_DIR:?PROJECT_DIR manquant}"
: "${SITE_NAME:?SITE_NAME manquant}"
: "${SITE_USER:?SITE_USER manquant}"
: "${VENV_DIR:?VENV_DIR manquant}"

PYTHON_BIN="$(command -v python3)"
[[ -x "$PYTHON_BIN" ]] || jeiko_die "python3 introuvable."

# --------------------------------------------------------------------------- #
# Création du venv
#
# Il est créé DIRECTEMENT sous l'identité du site. L'ancienne version le créait
# en root puis rattrapait la propriété après coup : entre les deux, pip laissait
# des fichiers root dans site-packages, et la mise à jour suivante échouait sur
# « permission denied » sans expliquer pourquoi.
# --------------------------------------------------------------------------- #
if [[ ! -x "$VENV_DIR/bin/python" ]]; then
    jeiko_log "📦 Création de l'environnement virtuel…"
    install -d -m "$JEIKO_DIR_MODE" -o "$SITE_USER" -g www-data "$VENV_DIR"
    jeiko_as_site "$SITE_USER" "$PYTHON_BIN" -m venv "$VENV_DIR"
else
    jeiko_log "ℹ️  venv déjà présent."
fi

PY="$VENV_DIR/bin/python"
[[ -x "$PY" ]] || jeiko_die "Le venv n'a pas produit d'interpréteur : $PY"

chown -R "$SITE_USER":www-data "$VENV_DIR"

PIP=(env PYTHONNOUSERSITE=1 PIP_DISABLE_PIP_VERSION_CHECK=1 "$PY" -m pip)

if ! jeiko_as_site "$SITE_USER" "${PIP[@]}" --version >/dev/null 2>&1; then
    jeiko_log "🧰 pip absent du venv → ensurepip…"
    jeiko_as_site "$SITE_USER" "$PY" -m ensurepip --upgrade
fi

jeiko_log "⬆️  Mise à jour de pip / setuptools / wheel…"
jeiko_as_site "$SITE_USER" "${PIP[@]}" install --no-input --upgrade pip setuptools wheel

# --------------------------------------------------------------------------- #
# Socle minimal. Le reste des dépendances arrive avec le package JEIKO (08),
# via son requirements.txt — une seule source de vérité pour les versions.
# --------------------------------------------------------------------------- #
jeiko_log "📥 Dépendances de base…"
jeiko_as_site "$SITE_USER" "${PIP[@]}" install --no-input \
    django gunicorn psycopg2-binary python-dotenv

jeiko_fix_perms "$PROJECT_DIR" "$SITE_USER" "$SITE_NAME" "$VENV_DIR"

jeiko_ok "Environnement Python prêt : $(jeiko_as_site "$SITE_USER" "$PY" -V 2>&1)"
