"""
Configuration Django — template JEIKO.

⚠️  Ce fichier est IDENTIQUE sur tous les sites et il est remplacé à chaque
    installation. Ne le personnalise pas : toute la variabilité passe par le
    fichier .env situé à côté. Si un site a besoin d'un réglage particulier,
    ajoute une variable d'environnement et lis-la ici — pas de fork local.
"""

import os
from pathlib import Path

from dotenv import load_dotenv

# ─────────────────────────────────────────────────────────────
# .env
# ─────────────────────────────────────────────────────────────
BASE_DIR = Path(__file__).resolve().parent

dotenv_path = BASE_DIR / ".env"
if dotenv_path.exists():
    load_dotenv(dotenv_path)
else:
    raise RuntimeError(
        f".env introuvable : {dotenv_path}. Le site ne peut pas démarrer sans "
        f"SECRET_KEY ni identifiants de base de données."
    )


def env_bool(name, default=False):
    return os.getenv(name, str(default)).strip().lower() in ("1", "true", "yes", "on")


# ─────────────────────────────────────────────────────────────
# Paramètres principaux
# ─────────────────────────────────────────────────────────────
SECRET_KEY = os.getenv("SECRET_KEY")
if not SECRET_KEY:
    # Une valeur par défaut « insecure-default » rendait un site silencieusement
    # vulnérable (signatures de session forgeables) sans jamais lever d'erreur.
    raise RuntimeError("SECRET_KEY absente du .env.")

DEBUG = env_bool("DEBUG", False)

SITE_NAME = os.getenv("JEIKO_SITE_NAME", BASE_DIR.name)
domain = os.getenv("DOMAIN_NAME", "").strip().lower()

ALLOWED_HOSTS = ["127.0.0.1", "localhost"]
if domain:
    ALLOWED_HOSTS += [domain, f".{domain}"]

# Derrière Nginx : c'est ce couple qui permet à Django de savoir que la requête
# d'origine était en HTTPS. Nginx doit impérativement écraser cet en-tête
# (proxy_set_header X-Forwarded-Proto $scheme), sinon un client peut le forger.
SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")
USE_X_FORWARDED_HOST = True

# ─────────────────────────────────────────────────────────────
# Applications
# ─────────────────────────────────────────────────────────────
INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.sites",
    "django.contrib.staticfiles",

    # JEIKO
    "jeiko",
    "jeiko.administration",
    "jeiko.administration_menu",
    "jeiko.administration_pages",
    "jeiko.calendars",
    "jeiko.cookies",
    "jeiko.courses",
    "jeiko.custom_objects",
    "jeiko.emailing",
    "jeiko.payments",
    "jeiko.questionnaires_expert",
    "jeiko.shop",
    "jeiko.stats",
    "jeiko.users",

    # Authentification
    "allauth",
    "allauth.account",
    "allauth.socialaccount",
    "allauth.socialaccount.providers.google",
    "allauth.socialaccount.providers.apple",
    "allauth.socialaccount.providers.facebook",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
    "allauth.account.middleware.AccountMiddleware",
    "jeiko.stats.middleware.PageViewCounterMiddleware",
]

ROOT_URLCONF = f"{BASE_DIR.name}.urls"
WSGI_APPLICATION = f"{BASE_DIR.name}.wsgi.application"
SITE_ID = 1
X_FRAME_OPTIONS = "SAMEORIGIN"

# ─────────────────────────────────────────────────────────────
# Cache
# ─────────────────────────────────────────────────────────────
CACHES = {
    "default": {
        # pymemcache et non pylibmc : ce dernier est une extension C qui n'a pas
        # suivi les évolutions de l'API C de CPython. Sous Python 3.13 (Debian
        # 13) son client ne s'instancie plus — « Exception ignored in
        # PyMapping_HasKeyString » puis servers=None — et toute page touchant au
        # cache renvoie une 500. pymemcache est du pur Python : rien à compiler,
        # rien à casser au prochain changement de version de Python.
        "BACKEND": "django.core.cache.backends.memcached.PyMemcacheCache",
        "LOCATION": "127.0.0.1:11211",
        # Le préfixe évite que deux sites de la même machine se lisent
        # mutuellement leurs entrées de cache.
        "KEY_PREFIX": domain or SITE_NAME,
        "TIMEOUT": 600,
        "OPTIONS": {
            # Un memcached arrêté ou saturé ne doit pas mettre le site à terre :
            # le cache devient inopérant, les pages sont simplement recalculées.
            "ignore_exc": True,
            "no_delay": True,
        },
    }
}

# ─────────────────────────────────────────────────────────────
# Templates
# ─────────────────────────────────────────────────────────────
TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.template.context_processors.i18n",
                "django.template.context_processors.media",
                "django.template.context_processors.static",
                "django.template.context_processors.tz",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

# ─────────────────────────────────────────────────────────────
# Base de données
# ─────────────────────────────────────────────────────────────
DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.postgresql",
        "NAME": os.getenv("DB_NAME"),
        "USER": os.getenv("DB_USER"),
        "PASSWORD": os.getenv("DB_PASS"),
        "HOST": "127.0.0.1",
        "PORT": "5432",
        # Garde les connexions ouvertes 60 s : sur un site à trafic modéré, la
        # reconnexion à chaque requête coûte plus cher que tout le reste.
        "CONN_MAX_AGE": 60,
    }
}

# ─────────────────────────────────────────────────────────────
# Authentification
# ─────────────────────────────────────────────────────────────
AUTHENTICATION_BACKENDS = [
    "django.contrib.auth.backends.ModelBackend",
    "jeiko.users.auth_backends.RolePermissionBackend",
    "allauth.account.auth_backends.AuthenticationBackend",
]

LOGIN_REDIRECT_URL = "/"
LOGOUT_REDIRECT_URL = "/"

ACCOUNT_EMAIL_REQUIRED = True
ACCOUNT_EMAIL_VERIFICATION = "none"
ACCOUNT_AUTHENTICATION_METHOD = "username_email"
ACCOUNT_USERNAME_REQUIRED = True
ACCOUNT_UNIQUE_EMAIL = True

ACCOUNT_FORMS = {
    "signup": "jeiko.users.forms.CustomSignupForm",
    "login": "jeiko.users.forms.CustomLoginForm",
}

AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator",
     "OPTIONS": {"min_length": 10}},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

# ─────────────────────────────────────────────────────────────
# Localisation
# ─────────────────────────────────────────────────────────────
LANGUAGE_CODE = "fr-fr"
TIME_ZONE = "Europe/Paris"
USE_I18N = True
USE_TZ = True

# ─────────────────────────────────────────────────────────────
# Fichiers statiques et médias
# ─────────────────────────────────────────────────────────────
STATIC_URL = "/static/"
MEDIA_URL = "/media/"

STATICFILES_DIRS = [BASE_DIR / "static"]
STATIC_ROOT = BASE_DIR.parent / "staticdir"
MEDIA_ROOT = BASE_DIR.parent / "mediadir"

STORAGES = {
    "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
    "staticfiles": {"BACKEND": "django.contrib.staticfiles.storage.ManifestStaticFilesStorage"},
}

# Django applique ces modes explicitement après écriture, indépendamment du
# umask du processus. C'est nécessaire ici : gunicorn tourne avec UMask=0007
# pour que nginx puisse ouvrir son socket, mais on ne veut pas pour autant que
# les fichiers uploadés soient inscriptibles par www-data — une faille dans
# nginx ne doit pas permettre de réécrire les médias du site.
FILE_UPLOAD_PERMISSIONS = 0o640
FILE_UPLOAD_DIRECTORY_PERMISSIONS = 0o2750

# ─────────────────────────────────────────────────────────────
# Sécurité HTTP
#
# Tout ce bloc est conditionné par JEIKO_SSL. Avec ces réglages actifs sur un
# site servi en HTTP, SECURE_SSL_REDIRECT renvoie une 301 vers une URL https
# qui n'existe pas encore : boucle de redirection et site injoignable.
# ─────────────────────────────────────────────────────────────
JEIKO_SSL = env_bool("JEIKO_SSL", False)

SECURE_SSL_REDIRECT = JEIKO_SSL
SESSION_COOKIE_SECURE = JEIKO_SSL
CSRF_COOKIE_SECURE = JEIKO_SSL
SECURE_HSTS_SECONDS = 31536000 if JEIKO_SSL else 0
SECURE_HSTS_INCLUDE_SUBDOMAINS = JEIKO_SSL
SECURE_HSTS_PRELOAD = JEIKO_SSL

SECURE_CONTENT_TYPE_NOSNIFF = True
SECURE_REFERRER_POLICY = "strict-origin-when-cross-origin"
SESSION_COOKIE_HTTPONLY = True
CSRF_COOKIE_HTTPONLY = False  # lu par le JS de l'admin pour les requêtes AJAX
SESSION_COOKIE_SAMESITE = "Lax"
CSRF_COOKIE_SAMESITE = "Lax"

CSRF_TRUSTED_ORIGINS = []
if domain:
    scheme = "https" if JEIKO_SSL else "http"
    CSRF_TRUSTED_ORIGINS.append(f"{scheme}://{domain}")
    # Le vhost www n'existe que pour un domaine apex ; l'ajouter pour un
    # sous-domaine produisait une origine du type https://www.admin.site.fr.
    if domain.count(".") == 1:
        CSRF_TRUSTED_ORIGINS.append(f"{scheme}://www.{domain}")

# ─────────────────────────────────────────────────────────────
# Journalisation
#
# Sans cette configuration, une exception en production n'apparaissait nulle
# part ailleurs que dans le log d'erreur de gunicorn, sans contexte.
# ─────────────────────────────────────────────────────────────
LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "verbose": {"format": "[{asctime}] {levelname} {name} {message}", "style": "{"},
    },
    "handlers": {
        "console": {"class": "logging.StreamHandler", "formatter": "verbose"},
        "file": {
            "class": "logging.handlers.RotatingFileHandler",
            "filename": str(BASE_DIR.parent / "logs" / "django.log"),
            "maxBytes": 10 * 1024 * 1024,
            "backupCount": 5,
            "formatter": "verbose",
        },
    },
    "root": {"handlers": ["console", "file"], "level": "INFO"},
    "loggers": {
        "django.request": {"handlers": ["console", "file"], "level": "ERROR", "propagate": False},
        "jeiko": {"handlers": ["console", "file"], "level": "INFO", "propagate": False},
    },
}

# ─────────────────────────────────────────────────────────────
# Divers JEIKO
# ─────────────────────────────────────────────────────────────
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"
EMAIL_BACKEND = "django.core.mail.backends.smtp.EmailBackend"

# Taille maximale d'un upload en mémoire avant bascule sur disque. Doit rester
# cohérent avec client_max_body_size dans le vhost nginx (25 Mo).
DATA_UPLOAD_MAX_MEMORY_SIZE = 25 * 1024 * 1024
FILE_UPLOAD_MAX_MEMORY_SIZE = 5 * 1024 * 1024

GUNICORN_SOCKET = os.getenv("GUNICORN_SOCKET")
JEIKO_IMAGES_ASYNC = True

# Assainissement du HTML saisi dans l'administration (jeiko/sanitize.py).
# À True, la mise en forme est conservée mais <script>, les attributs on* et
# les URL javascript: sont retirés. Ne passer à False que si les seuls
# rédacteurs sont de confiance et qu'aucun rôle n'est délégué à un tiers.
JEIKO_SANITIZE_HTML = env_bool("JEIKO_SANITIZE_HTML", True)

# Déclencher une mise à jour applique des migrations et redémarre le site :
# c'est plus lourd que « modifier les réglages », avec quoi cette action
# partageait sa permission. Réservé aux superutilisateurs par défaut.
JEIKO_UPDATE_REQUIRES_SUPERUSER = env_bool("JEIKO_UPDATE_REQUIRES_SUPERUSER", True)

JEIKO_RESERVED_ROOT_SLUGS = {
    "administration",
    "accounts",
    "api",
    "users",
    "pass-test",
    "jeiko",
    "robots.txt",
    "sitemap.xml",
}

# Statistiques
ADMIN_URL = "/admin/"
STATS_ENABLE_DWELL = True
STATS_IGNORE_PATH_PREFIXES = [
    "/static/", "/media/", "/favicon.ico", "/robots.txt",
    "/stats/",
]
