"""
Routage racine — template JEIKO.

Comme settings.py, ce fichier est identique sur tous les sites et remplacé à
chaque installation. Les routes spécifiques à un site se déclarent dans
l'administration (pages), pas ici.
"""

from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", include("jeiko.urls")),
]

# En production, /static/ et /media/ sont servis par nginx : le helper static()
# renvoie une liste vide dès que DEBUG vaut False, ces deux lignes ne servent
# donc qu'au développement local.
urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
