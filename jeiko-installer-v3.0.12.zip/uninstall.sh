#!/bin/bash
###############################################################################
# uninstall.sh — supprime un site JEIKO et tout ce que l'installeur a créé pour lui.
#
# Lit la fiche /etc/jeiko/sites/<site>.conf pour retrouver les chemins RÉELS :
# la version précédente supposait /var/www/<site> et laissait donc tout en place
# dès que la racine d'installation différait — en plus d'ignorer le compte Unix,
# la base PostgreSQL, le sudoers et les sauvegardes.
#
# Ce qui est PARTAGÉ par tous les sites n'est jamais touché : PostgreSQL, nginx,
# memcached, /usr/local/lib/jeiko, /usr/local/sbin/jeiko-*, la configuration SSH.
#
# Usage :
#   sudo ./uninstall.sh <site>              # demande confirmation
#   sudo ./uninstall.sh <site> --keep-db    # conserve la base et son rôle
#   sudo ./uninstall.sh <site> --dry-run    # montre sans rien supprimer
###############################################################################

set -euo pipefail

if [[ -r /usr/local/lib/jeiko/common.sh ]]; then
    # shellcheck source=lib/jeiko-common.sh
    source /usr/local/lib/jeiko/common.sh
else
    # Désinstallation possible même si la bibliothèque a déjà disparu.
    JEIKO_ETC_DIR="/etc/jeiko"; JEIKO_LIB_DIR="/var/lib/jeiko"
    JEIKO_LOG_DIR="/var/log/jeiko"; JEIKO_BACKUP_DIR="/var/backups/jeiko"
    jeiko_log()  { printf '   %s\n' "$*"; }
    jeiko_ok()   { printf '✅ %s\n' "$*"; }
    jeiko_warn() { printf '⚠️  %s\n' "$*"; }
    jeiko_err()  { printf '❌ %s\n' "$*" >&2; }
    jeiko_die()  { jeiko_err "$*"; exit 1; }
fi

[[ ${EUID} -eq 0 ]] || jeiko_die "À lancer avec sudo."

SITE=""; KEEP_DB=0; DRY_RUN=0
while [[ $# -gt 0 ]]; do
    case "$1" in
        --keep-db) KEEP_DB=1; shift ;;
        --dry-run) DRY_RUN=1; shift ;;
        -h|--help) sed -n '2,18p' "$0"; exit 0 ;;
        -*)        jeiko_die "Option inconnue : $1" ;;
        *)         SITE="$1"; shift ;;
    esac
done
[[ -n "$SITE" ]] || jeiko_die "Usage : sudo ./uninstall.sh <site> [--keep-db] [--dry-run]"
[[ "$SITE" =~ ^[a-z0-9][a-z0-9_-]{0,30}$ ]] || jeiko_die "Nom de site invalide : $SITE"

run() { if [[ $DRY_RUN -eq 1 ]]; then printf '   [simulation] %s\n' "$*"; else "$@"; fi; }

###############################################################################
# Chemins : la fiche du site fait foi, avec repli sur les conventions.
###############################################################################
CONF="$JEIKO_ETC_DIR/sites/$SITE.conf"
if [[ -r "$CONF" ]]; then
    # shellcheck disable=SC1090
    source "$CONF"
    jeiko_log "Fiche trouvée : $CONF"
else
    jeiko_warn "Fiche $CONF absente — repli sur les emplacements par défaut."
fi

PROJECT_DIR="${PROJECT_DIR:-/var/www/$SITE}"
SITE_USER="${SITE_USER:-jeiko-$SITE}"
GUNICORN_SERVICE="${GUNICORN_SERVICE:-gunicorn-$SITE}"
DB_NAME="${DB_NAME:-}"; DB_USER="${DB_USER:-}"

cat <<RECAP

╔══════════════════════════════════════════════════════════════╗
   Suppression du site « $SITE »
╚══════════════════════════════════════════════════════════════╝
  Projet        : $PROJECT_DIR
  Compte Unix   : $SITE_USER (et son home)
  Service       : $GUNICORN_SERVICE
  Base / rôle   : ${DB_NAME:-?} / ${DB_USER:-?}$( [[ $KEEP_DB -eq 1 ]] && echo "   [CONSERVÉS]" )
  Vhost nginx   : /etc/nginx/sites-{available,enabled}/$SITE.conf
  Timers cron   : jeiko-cron-*@$SITE
  Sauvegardes   : $JEIKO_BACKUP_DIR/$SITE
  Journaux      : /var/log/gunicorn/$SITE, /var/log/nginx/$SITE, $JEIKO_LOG_DIR/$SITE

  NON touchés : PostgreSQL, nginx, memcached, outillage /usr/local, config SSH.
RECAP

if [[ $DRY_RUN -eq 0 ]]; then
    read -rp "Confirmer la suppression définitive ? (tape le nom du site) : " c
    [[ "$c" == "$SITE" ]] || { echo "Annulé."; exit 0; }
fi

###############################################################################
# 1) Arrêt des services — avant toute suppression de fichiers
###############################################################################
jeiko_log "🛑 Arrêt des services…"
run systemctl stop "$GUNICORN_SERVICE.service" 2>/dev/null || true
run systemctl disable "$GUNICORN_SERVICE.service" 2>/dev/null || true

# Timers cron : instances du site, puis gabarits devenus orphelins.
for timer in /etc/systemd/system/jeiko-cron-*@.timer; do
    [[ -e "$timer" ]] || continue
    cad="$(basename "$timer")"; cad="${cad#jeiko-cron-}"; cad="${cad%@.timer}"
    run systemctl disable --now "jeiko-cron-$cad@$SITE.timer" 2>/dev/null || true
    run rm -rf "/etc/systemd/system/jeiko-cron-$cad@$SITE.service.d" \
               "/etc/systemd/system/jeiko-cron-$cad@$SITE.timer.d"
    if ! compgen -G "/etc/systemd/system/jeiko-cron-$cad@*.service.d" >/dev/null; then
        run rm -f "/etc/systemd/system/jeiko-cron-$cad@.timer" \
                  "/etc/systemd/system/jeiko-cron-$cad@.service"
    fi
done

run rm -f "/etc/systemd/system/$GUNICORN_SERVICE.service" \
          "/etc/systemd/system/$GUNICORN_SERVICE.socket"
run systemctl daemon-reload
run systemctl reset-failed 2>/dev/null || true

###############################################################################
# 2) Base de données
###############################################################################
if [[ $KEEP_DB -eq 1 ]]; then
    jeiko_warn "Base et rôle conservés (--keep-db)."
elif [[ -n "$DB_NAME" ]] && command -v psql >/dev/null 2>&1; then
    jeiko_log "🛢️  Suppression de la base $DB_NAME et du rôle $DB_USER…"
    # Les connexions résiduelles empêchent le DROP DATABASE.
    run su - postgres -c "psql -tAc \"SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname='$DB_NAME' AND pid <> pg_backend_pid();\"" >/dev/null 2>&1 || true
    run su - postgres -c "dropdb --if-exists '$DB_NAME'" || jeiko_warn "Échec du dropdb $DB_NAME"
    [[ -n "$DB_USER" ]] && run su - postgres -c "dropuser --if-exists '$DB_USER'" || true
else
    jeiko_warn "Base inconnue (fiche absente) — à supprimer à la main si nécessaire."
fi

###############################################################################
# 3) Fichiers
###############################################################################
jeiko_log "🗑️  Suppression des fichiers…"
run rm -rf "$PROJECT_DIR"
run rm -f  "/etc/nginx/sites-available/$SITE.conf" "/etc/nginx/sites-enabled/$SITE.conf"
run rm -f  "/etc/sudoers.d/jeiko-$SITE"
run rm -f  "/etc/cron.d/jeiko-backup-$SITE"
run rm -rf "/var/log/gunicorn/$SITE" "/var/log/nginx/$SITE" "$JEIKO_LOG_DIR/$SITE"
run rm -rf "/run/$GUNICORN_SERVICE"
run rm -rf "$JEIKO_LIB_DIR/$SITE"
run rm -rf "$JEIKO_BACKUP_DIR/$SITE"
run rm -f  "$CONF"

###############################################################################
# 4) Compte Unix
###############################################################################
if id "$SITE_USER" >/dev/null 2>&1; then
    jeiko_log "👤 Suppression du compte $SITE_USER…"
    run pkill -u "$SITE_USER" 2>/dev/null || true
    run userdel -r "$SITE_USER" 2>/dev/null \
        || jeiko_warn "userdel a échoué — supprime le compte à la main."
fi

###############################################################################
# 5) nginx
###############################################################################
if command -v nginx >/dev/null 2>&1; then
    if [[ $DRY_RUN -eq 1 ]]; then
        printf '   [simulation] nginx -t && systemctl reload nginx\n'
    elif nginx -t >/dev/null 2>&1; then
        systemctl reload nginx && jeiko_ok "nginx rechargé."
    else
        jeiko_warn "nginx -t échoue : un AUTRE site a un problème de configuration."
        nginx -t || true
    fi
fi

jeiko_ok "Site « $SITE » supprimé."
[[ $KEEP_DB -eq 1 ]] && jeiko_log "Rappel : la base $DB_NAME existe toujours." || true
