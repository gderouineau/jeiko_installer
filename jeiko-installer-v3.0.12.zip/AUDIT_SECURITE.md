# Audit de sécurité JEIKO

Périmètre : `INSTALLER/` (installeur, updater, lib partagée) et le package
`jeiko` installé dans `ENV/lib/python3.10/site-packages/jeiko`.

Aucune modification n'a été appliquée. Ce document est un constat.

Les constats marqués **vérifié** ont été reproduits par exécution réelle du
code, pas déduits à la lecture.

---

## Synthèse

| # | Constat | Gravité | État |
|---|---|---|---|
| 1 | XSS stocké via le filtre `tojson` (12 templates) | Élevée | vérifié |
| 2 | XSS stocké via l'attribut `title` des tokens d'icône | Élevée | vérifié |
| 3 | XSS stocké via le nom d'icône | Élevée | vérifié |
| 4 | Champ texte riche en HTML brut non assaini | Élevée | vérifié |
| 5 | `!syslog` efface la trace sudo du compte le plus exposé | Moyenne | vérifié |
| 6 | `requirements.txt` : seul intrant de la chaîne non vérifié | Moyenne | vérifié |
| 7 | Opérations root sur une arborescence écrite par le site | Moyenne | à confirmer |
| 8 | `.env` transite en 0640 à chaque passe de permissions | Moyenne | vérifié |
| 9 | ACL par défaut : l'admin SSH lit les fichiers créés ensuite | Moyenne | vérifié |
| 10 | `reload nginx` accordé au site sans nécessité | Faible | vérifié |
| 11 | Endpoint public de réservation faiblement limité | Faible | vérifié |
| 12 | Sauvegardes non chiffrées, sans copie hors-site | Faible | vérifié |
| 13 | L'empreinte vient du même canal que le package | Faible | par conception |
| 14 | Déclencher une mise à jour = permission délégable | Faible | vérifié |

---

## 1 — XSS stocké via `tojson` — **élevée, vérifié**

`jeiko/templatetags/json_extras.py`

```python
@register.filter
def tojson(value):
    return mark_safe(json.dumps(value, ensure_ascii=False))
```

`json.dumps` n'échappe ni `<` ni `>` ni `/`. Le résultat est injecté dans un
bloc `<script type="application/json">` :

```
templates/administration_pages/content/dyn/faq.html:4
    {{ content.data|tojson|safe }}
```

Reproduction :

```
Entrée  : {"titre": "</script><img src=x onerror=alert(document.cookie)>"}
Sortie  : {"titre": "</script><img src=x onerror=alert(document.cookie)>"}
```

Le navigateur ferme le bloc `<script>` sur la première occurrence littérale de
`</script>`, quel que soit le contexte JSON. Tout ce qui suit est analysé comme
du HTML.

**Portée** : 12 templates de blocs dynamiques — `faq`, `carousel`, `stepper`,
`tabs`, `rating`, `pricing_table`, `progress`, `live_filter`,
`gallery_filter`, `countdown`, `countdown_cta`, `accordion_adv`. Le contenu
provient de l'administration, donc d'un rédacteur authentifié. L'exécution a
lieu chez **tous les visiteurs**, y compris les administrateurs — ce qui permet
le vol de session d'un compte plus privilégié.

**Correctif** : `json_script` de Django, prévu exactement pour ça. Il échappe
`<`, `>` et `&` en séquences `\u00XX` et génère lui-même la balise.

```django
{{ content.data|json_script:"faq-data" }}
```

Le JavaScript existant lit déjà `JSON.parse(el.textContent)` : la migration est
mécanique.

---

## 2 — XSS stocké via l'attribut `title` des icônes — **élevée, vérifié**

`jeiko/templatetags/custom_tags.py`, `_parse_icon_attrs`

`size`, `color` et `class` **sont validés** par expression régulière. `title`
ne l'est pas :

```python
elif k in ("title", "label", "aria"):
    out["title"] = v[:80]        # tronqué, jamais échappé
```

Il est ensuite interpolé dans un attribut HTML sans échappement :

```python
title_attr = f' aria-label="{title}" role="img"'
```

Reproduction :

```
Entrée : [[mi:phone|title=x" onmouseover="alert(1)]]
Rendu  :  aria-label="x" onmouseover="alert(1)" role="img"
```

La validation des trois autres attributs montre que le besoin était identifié —
`title` a simplement été oublié.

**Correctif** : `django.utils.html.escape(title)` avant interpolation, ou
construire le fragment avec `format_html`.

---

## 3 — XSS stocké via le nom d'icône — **élevée, vérifié**

Même fichier. `ICON_PATTERN` n'exclut que `]` et `|` :

```python
ICON_PATTERN = re.compile(r'\[\[\s*([^\]\|]+)(?:\s*\|\s*([^\]]+))?\s*\]\]')
```

`<` et `>` passent donc, et le nom est injecté comme contenu d'élément :

```python
f'...{title_attr}>{name}</span>'
```

Reproduction :

```
Entrée : [[mi:<img src=x onerror=alert(1)>]]
name   : '<img src=x onerror=alert(1)>'
```

**Correctif** : valider le nom sur `[a-z0-9_]+` — c'est le format réel des
identifiants Material Icons, la restriction ne coûte aucune fonctionnalité.

---

## 4 — Champ texte riche en HTML brut — **élevée, vérifié**

`jeiko/templatetags/html_extras.py`

```python
@register.filter
def html_unescape(value):
    return mark_safe(html.unescape(value or ""))
```

Reproduction : `&lt;script&gt;alert(1)&lt;/script&gt;` ressort en
`<script>alert(1)</script>`.

Ce filtre **ré-active du HTML déjà neutralisé**. Utilisé dans
`administration_pages/content/partials/content_text.html`, il fait du champ
texte un champ HTML brut.

C'est peut-être voulu — un éditeur de contenu doit pouvoir mettre en forme.
Mais alors il manque un assainissement par liste blanche. `nh3` (binding Rust
d'`ammonia`, activement maintenu) autorise les balises de mise en forme et
retire `<script>`, les attributs `on*` et les `javascript:` :

```python
import nh3
return mark_safe(nh3.clean(html.unescape(value or "")))
```

**À trancher** : le rédacteur est-il de confiance ? Si le client final édite
son propre contenu, il l'est ; s'il existe des rôles délégués à des tiers, non.

---

## 5 — `!syslog` efface la trace sudo — **moyenne, vérifié**

`scripts/14_finalize.sh:119` et `migrate_site.sh`

```
Defaults:$SITE_USER !syslog
```

Cette ligne désactive la journalisation des appels sudo du compte applicatif —
précisément le compte le plus exposé du système, puisqu'il exécute le code web.
En cas de compromission, il ne resterait aucune trace de l'usage de sudo.

Elle avait été ajoutée pour réduire le bruit. Le bruit est de trois lignes par
mise à jour.

**Correctif** : supprimer la ligne. Garder `!requiretty`, qui est nécessaire.

---

## 6 — `requirements.txt` non vérifié — **moyenne, vérifié**

`release.sh` calcule et publie `requirements_sha256` dans `version.json`.
L'updater ne le lit jamais :

```bash
if jeiko_download "$CHANNEL_URL/requirements.txt" "$REQ_FILE" 2>/dev/null; then
    HAS_REQ=1
fi
```

C'est le **seul intrant de la chaîne de mise à jour qui échappe au contrôle
d'intégrité**, alors que le champ existe déjà. Un `requirements.txt` altéré
fait installer des paquets arbitraires depuis PyPI.

Portée réelle limitée : qui peut réécrire `requirements.txt` sur le canal peut
aussi réécrire `version.json`. Mais la vérification coûte trois lignes et
supprime une asymétrie inutile.

---

## 7 — Opérations root sur une arborescence écrite par le site — **moyenne, à confirmer**

`lib/jeiko-common.sh`, `jeiko_fix_perms`, exécuté en root sur
`/var/www/<site>` — un répertoire dont l'utilisateur du site est propriétaire
et où il peut créer des liens symboliques.

Trois opérations méritent vérification :

```bash
install -d -m 2750 "$project_dir/staticdir" …   # suit le lien s'il existe
chown -R "$site_user":www-data "$project_dir"
chmod -R u=rwX,g=rX,o= "$venv_dir"
```

Les `find … -type d` / `-type f` sont **sûrs** : un lien symbolique n'est ni
l'un ni l'autre, il est donc ignoré.

`install -d` sur un `staticdir` remplacé par un lien vers `/etc` appliquerait
le mode au répertoire cible. Impact : déni de service, pas d'élévation.

Pour `chown -R` : les coreutils GNU utilisent `FTS_PHYSICAL` et devraient
ignorer les liens en l'absence de `-h`, mais je ne l'ai pas vérifié sur la
machine cible. Test décisif, à jouer sur le serveur :

```bash
sudo install -d -o nobody /tmp/t/sub && sudo ln -s /etc/shadow /tmp/t/sub/lnk
sudo chown -R nobody:nogroup /tmp/t && ls -l /etc/shadow
```

Si le propriétaire de `/etc/shadow` change, c'est une élévation vers root et le
constat passe en critique.

**Correctif indépendant du résultat** : ajouter `-h` à `chown -R`, et remplacer
le `chmod -R` du venv par des `find -type`.

---

## 8 — Le `.env` transite en 0640 — **moyenne, vérifié**

Dans `jeiko_fix_perms`, l'ordre est :

```bash
find … -type f … | xargs -0r chmod 0640     # .env inclus
…
[[ -f …/.env ]] && chmod 0600 …/.env        # correction après coup
```

Entre les deux, le fichier contenant `DB_PASS` est lisible par le groupe
`www-data`, c'est-à-dire par nginx. La fenêtre est de quelques millisecondes et
suppose un processus déjà hostile — le risque réel est faible, mais l'exclure
du `find` est trivial et rend l'invariant vrai en permanence.

---

## 9 — ACL par défaut sur les fichiers créés ensuite — **moyenne, vérifié**

`jeiko_apply_admin_acl` pose une ACL **par défaut** :

```bash
setfacl -R -m "d:u:$admin_user:rX" "$project_dir"
```

Tout fichier créé ultérieurement dans l'arborescence hérite du droit de lecture
pour l'admin SSH. Le `setfacl -x` qui suit retire l'ACL du `.env` **actuel**,
mais un `.env` recréé plus tard la réhériterait — le mot de passe de la base
redeviendrait lisible sans sudo, en contradiction avec le 0600 affiché.

De plus ce `setfacl -x` est suivi de `2>/dev/null || true` : s'il échoue, rien
ne le signale.

---

## 10 — `reload nginx` accordé au site — **faible, vérifié**

```
$SITE_USER ALL=(root) NOPASSWD: /usr/bin/systemctl reload nginx.service
```

nginx est **partagé par tous les sites** de la machine. L'updater tourne déjà
en root et recharge nginx lui-même : l'application n'a aucun besoin de ce
droit. Le retirer réduit la surface sans rien casser.

---

## 11 — Endpoint public de réservation — **faible, vérifié**

`calendars/views.py:566`, `APIBookAppointmentView` : `csrf_exempt`, non
authentifié, écrit en base et déclenche vraisemblablement des e-mails. Ses
garde-fous applicatifs (leurre, plafonds par IP et par e-mail) sont documentés
dans le code.

Côté nginx il ne bénéficie que de la zone générale — 30 r/s, rafale 60. Une
zone dédiée, du niveau de `jeiko_login`, serait plus cohérente avec son coût.

Le webhook Stripe, lui, est correct : `construct_event(payload, sig_header)`
vérifie la signature, le `csrf_exempt` est justifié.

---

## 12 — Sauvegardes non chiffrées et locales — **faible, vérifié**

`/var/backups/jeiko/<site>/` en 0700 root. Les dumps contiennent l'intégralité
de la base, en clair. Aucune copie hors machine.

Un root compromis, un rançongiciel ou une perte du VPS emporte les sauvegardes
avec le site. C'est le plus gros écart opérationnel du dispositif : tout le
reste protège contre l'intrusion, rien ne protège contre la perte.

---

## 13 — L'empreinte vient du même canal que le package — **faible, par conception**

`version.json` et le wheel sont servis par le même dépôt. Le sha256 protège
contre l'altération en transit et contre la substitution du seul wheel, **pas
contre quelqu'un capable d'écrire dans le dépôt** — il réécrirait les deux.

C'est un compromis acceptable : une prise de contrôle du dépôt GitHub compromet
la chaîne de toute façon. Une signature détachée (`minisign`), avec la clé
publique déposée par l'installeur et la clé privée hors du dépôt, fermerait
l'écart si le besoin s'en fait sentir.

**À confirmer** : l'updater appelle `raw.githubusercontent.com` sans aucun
jeton. Cela n'est possible que si le dépôt `gderouineau/jeiko` est **public** —
donc si le code source de JEIKO l'est aussi. Si c'est délibéré, rien à faire ;
sinon, c'est le constat le plus important de ce document.

---

## 14 — Déclencher une mise à jour est une permission délégable — **faible, vérifié**

```python
permission_required = "users.admincfg_change_website"
```

Une mise à jour applique des migrations, redémarre le site et peut le laisser
indisponible. C'est plus lourd que « modifier les réglages du site », avec
lequel elle partage sa permission. `is_superuser` serait plus proche de
l'impact réel.

Par ailleurs le journal de mise à jour est exposé à tout compte détenant cette
permission. Il ne contient pas de secret — les mots de passe transitent par
l'environnement, jamais par la sortie standard — mais il révèle des chemins et
des versions.

---

## Ce qui est solide

Pour équilibrer le tableau, les points suivants ont été examinés et n'appellent
rien :

- **La chaîne de privilèges.** L'updater est `root:root` hors de l'arborescence
  du site, l'application ne peut que déclencher une unité systemd dont
  l'`ExecStart` est figé. Le nom de site est validé côté shell **et** côté
  Django (9 charges utiles d'injection rejetées à l'essai).
- **Aucun `shell=True`, `eval`, `os.system` ou `pickle`** dans le package.
- **SQL** : `format('%I', …)` / `%L` via `\gexec`, plus aucune interpolation de
  mot de passe dans une chaîne SQL.
- **Échappement shell** : les valeurs réinjectées dans la fiche du site passent
  par `jeiko_shell_quote`, testé en aller-retour sur 10 charges utiles dont
  `$(…)`, backticks et apostrophes — aucune exécution.
- **Le wheel n'exécute pas de code à l'installation** (contrairement à un sdist
  et à son `setup.py`), et `pip` tourne sous l'identité du site, jamais en root.
- **Webhook Stripe** : signature vérifiée.
- **PostgreSQL** : écoute locale, `scram-sha-256`, rôle applicatif
  `NOSUPERUSER NOCREATEDB NOCREATEROLE`.
- **Memcached** : écoute locale, UDP coupé.
- **TLS** : `options-ssl-nginx` inclus, HSTS uniquement sur le vhost TLS, défi
  ACME préservé de la redirection — le renouvellement à 90 jours tient.

---

## Ordre de traitement suggéré

1. **Constats 1 à 4** — les quatre XSS. Ce sont les seuls exploitables sans
   accès préalable au serveur, et ils touchent le code du package, donc ils se
   corrigent et se diffusent par la mise à jour côté client.
2. **Constat 13** — confirmer si le dépôt est public. Une réponse, pas un
   correctif, mais elle peut tout changer.
3. **Constats 5, 6, 7, 9** — durcissement de la chaîne serveur, à embarquer
   dans le script serveur.
4. **Constat 12** — la copie hors-site.
5. Le reste au fil de l'eau.
