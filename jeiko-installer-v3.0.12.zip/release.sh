#!/bin/bash
###############################################################################
# release.sh — publie une version du package JEIKO.
#
# ⚠️  Ce script est destiné au dépôt gderouineau/jeiko, PAS au serveur.
#     Copie-le à la racine du dépôt (à côté de pyproject.toml).
#
# Il produit ce que jeiko-update sait consommer :
#   dist/jeiko-<version>-py3-none-any.whl   le package construit
#   version.json                            version + nom du wheel + sha256
#   requirements.txt                        déjà présent, simplement vérifié
#
# La vérification d'intégrité côté serveur repose entièrement sur le sha256
# écrit dans version.json : c'est le seul lien entre ce que tu publies et ce
# qui s'exécute en production.
#
# Usage :
#   ./release.sh 1.4.0
#   ./release.sh 1.4.0 --dry-run
###############################################################################

set -euo pipefail

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
cd "$REPO_DIR"

VERSION="${1:-}"
DRY_RUN=0
[[ "${2:-}" == "--dry-run" ]] && DRY_RUN=1 || true

if [[ -z "$VERSION" ]]; then
    echo "Usage : ./release.sh <version> [--dry-run]"
    echo "Exemple : ./release.sh 1.4.0"
    exit 1
fi

# Versionnage sémantique strict : c'est ce qui permet à pip de comparer, et à
# jeiko-client-update de savoir s'il y a quelque chose à faire.
if [[ ! "$VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+([ab]|rc)?[0-9]*$ ]]; then
    echo "❌ Version invalide : '$VERSION' (attendu : 1.4.0, ou 1.4.0rc1)"
    exit 1
fi

[[ -f pyproject.toml ]] || { echo "❌ pyproject.toml introuvable. Lance ce script depuis la racine du dépôt jeiko."; exit 1; }

PY="${PYTHON:-python3}"
command -v "$PY" >/dev/null 2>&1 || { echo "❌ python3 introuvable."; exit 1; }

# Ce script tourne sur le poste de développement, pas sur le serveur Debian :
# ni grep -P, ni sed -ri, ni sha256sum n'existent sur macOS. Tout ce qui touche
# au texte et aux empreintes passe donc par Python, présent de toute façon
# puisqu'il faut construire le wheel.
sha256_of() { "$PY" -c 'import hashlib,sys;print(hashlib.sha256(open(sys.argv[1],"rb").read()).hexdigest())' "$1"; }

echo "📦 Publication de JEIKO $VERSION"
echo ""

###############################################################################
# 1) Contrôles préalables
###############################################################################
if git rev-parse --git-dir >/dev/null 2>&1; then
    if [[ -n "$(git status --porcelain -- ':!dist' ':!version.json')" ]]; then
        echo "⚠️  Le dépôt contient des modifications non committées :"
        git status --short -- ':!dist' ':!version.json'
        read -rp "    Continuer quand même ? (y/n) : " c
        [[ "$c" == "y" ]] || exit 0
    fi
    if git tag -l "v$VERSION" | grep -q .; then
        echo "❌ Le tag v$VERSION existe déjà. Choisis une version supérieure."
        exit 1
    fi
fi

CURRENT_VERSION="$("$PY" - <<'PY'
import re, pathlib
text = pathlib.Path("pyproject.toml").read_text(encoding="utf-8")
m = re.search(r'^\s*version\s*=\s*"([^"]+)"', text, re.M)
print(m.group(1) if m else "?")
PY
)"
echo "   Version actuelle : $CURRENT_VERSION"
echo "   Nouvelle version : $VERSION"

###############################################################################
# 2) Mise à jour de pyproject.toml
###############################################################################
if [[ $DRY_RUN -eq 0 ]]; then
    JEIKO_NEW_VERSION="$VERSION" "$PY" - <<'PY' || exit 1
import os, pathlib, re, sys

path = pathlib.Path("pyproject.toml")
text = path.read_text(encoding="utf-8")
version = os.environ["JEIKO_NEW_VERSION"]

pattern = re.compile(r'^(\s*version\s*=\s*")[^"]+(")', re.M)
if not pattern.search(text):
    sys.exit("❌ Aucune clé 'version' dans pyproject.toml — ajoute-la sous [project].")

# count=1 : ne remplacer que la version du projet, pas celle d'une dépendance
# qui suivrait la même forme plus bas dans le fichier.
path.write_text(pattern.sub(rf'\g<1>{version}\g<2>', text, count=1), encoding="utf-8")
PY
    echo "✅ pyproject.toml : version = $VERSION"
fi

###############################################################################
# 3) Le script de mise à jour ne doit PLUS être embarqué dans le package
#
# Il vivait dans jeiko/scripts/update_jeiko.sh et s'installait donc dans
# site-packages, où pip l'écrasait pendant sa propre exécution — et où
# l'application web pouvait le réécrire avant de le faire exécuter par sudo.
# L'updater est désormais déployé par l'installeur en /usr/local/sbin.
###############################################################################
if [[ -f jeiko/scripts/update_jeiko.sh ]]; then
    echo ""
    echo "⚠️  jeiko/scripts/update_jeiko.sh est encore présent dans le package."
    echo "    Il est remplacé par /usr/local/sbin/jeiko-update, déployé par"
    echo "    l'installeur. Le laisser réintroduirait la faille d'élévation de"
    echo "    privilèges (fichier inscriptible par le site, exécuté via sudo)."
    read -rp "    Le supprimer maintenant ? (y/n) : " rm_old
    if [[ "$rm_old" == "y" && $DRY_RUN -eq 0 ]]; then
        git rm -f jeiko/scripts/update_jeiko.sh 2>/dev/null || rm -f jeiko/scripts/update_jeiko.sh
        rmdir jeiko/scripts 2>/dev/null || true
        echo "✅ Supprimé."
    fi
fi

###############################################################################
# 4) Construction
###############################################################################
echo ""
echo "🔧 Construction du wheel…"

"$PY" -c 'import build' 2>/dev/null || {
    echo "   Installation de 'build'…"
    "$PY" -m pip install --quiet --upgrade build
}

rm -rf dist build ./*.egg-info
"$PY" -m build --wheel

WHEEL_PATH="$(find dist -name '*.whl' | head -n1)"
[[ -n "$WHEEL_PATH" ]] || { echo "❌ Aucun wheel produit."; exit 1; }
WHEEL_NAME="$(basename "$WHEEL_PATH")"

# Le nom du wheel encode la version : si elles divergent, jeiko-update
# installerait un package dont la version ne correspond pas au manifeste, et
# croirait ensuite le site à jour alors qu'il ne l'est pas.
if [[ "$WHEEL_NAME" != *"-$VERSION-"* ]]; then
    echo "❌ Le wheel produit ($WHEEL_NAME) ne porte pas la version $VERSION."
    echo "   pyproject.toml définit peut-être la version dynamiquement."
    exit 1
fi

SHA256="$(sha256_of "$WHEEL_PATH")"
SIZE="$(du -h "$WHEEL_PATH" | awk '{print $1}')"

echo "✅ $WHEEL_NAME ($SIZE)"
echo "   sha256 : $SHA256"

###############################################################################
# 4bis) Les gabarits du projet doivent être DANS le wheel
#
# jeiko-client-update réaligne settings.py sur jeiko/project_template/. Sans ces
# fichiers, une version qui ajoute une application à INSTALLED_APPS s'installe
# sans que le settings.py des sites ne la déclare : l'app est inerte, et le
# diagnostic est pénible. On vérifie plutôt que d'espérer.
###############################################################################
echo ""
echo "🧪 Gabarits du projet embarqués…"
WHEEL_PATH="$WHEEL_PATH" "$PY" - <<'PY' || exit 1
import os, sys, zipfile

required = ["jeiko/project_template/settings.py.txt", "jeiko/project_template/urls.py.txt"]
names = set(zipfile.ZipFile(os.environ["WHEEL_PATH"]).namelist())
missing = [r for r in required if r not in names]

if missing:
    print("❌ Absents du wheel :")
    for m in missing:
        print("   ", m)
    print()
    print("   Sans eux, la mise à jour côté client ne peut pas réaligner")
    print("   settings.py : une nouvelle application resterait non déclarée.")
    print()
    print("   Vérifier que les fichiers existent dans les sources, puis que")
    print("   MANIFEST.in les embarque. La règle existante")
    print("       recursive-include jeiko *.html *.txt *.js *.css *.sh")
    print("   suffit — c'est pour ça que l'extension est .txt.")
    print("   À défaut, ajouter :")
    print("       recursive-include jeiko/project_template *")
    sys.exit(1)

print("✅ settings.py.txt et urls.py.txt présents dans le wheel.")
PY

###############################################################################
# 5) Manifeste
###############################################################################
# Le requirements.txt vit dans jeiko/ et non à la racine du dépôt. Plutôt que
# de deviner côté serveur, on le copie à un emplacement fixe, publié à côté du
# wheel, et on inscrit son chemin dans le manifeste.
REQ_SRC=""
for candidate in requirements.txt jeiko/requirements.txt; do
    [[ -f "$candidate" ]] && { REQ_SRC="$candidate"; break; } || true
done

REQ_SHA=""
REQ_PUBLISHED=""
if [[ -n "$REQ_SRC" ]]; then
    cp -f "$REQ_SRC" dist/requirements.txt
    REQ_SHA="$(sha256_of dist/requirements.txt)"
    REQ_PUBLISHED="dist/requirements.txt"
    echo "✅ Dépendances publiées depuis $REQ_SRC → dist/requirements.txt"
else
    echo "⚠️  Aucun requirements.txt trouvé : les serveurs installeront les"
    echo "    dépendances déclarées dans le wheel, sans version figée."
fi

cat >version.json <<EOF
{
  "version": "$VERSION",
  "wheel": "$WHEEL_NAME",
  "sha256": "$SHA256",
  "requirements": "$REQ_PUBLISHED",
  "requirements_sha256": "$REQ_SHA",
  "released_at": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "min_python": "3.10"
}
EOF

echo "✅ version.json écrit."

###############################################################################
# 6) Vérification : relire ce qui vient d'être écrit, comme le fera le serveur
###############################################################################
echo ""
echo "🧪 Vérification du manifeste…"
"$PY" - <<'PY'
import hashlib, json, pathlib, sys

manifest = json.loads(pathlib.Path("version.json").read_text(encoding="utf-8"))
wheel = pathlib.Path("dist") / manifest["wheel"]

if not wheel.exists():
    sys.exit(f"❌ Wheel absent : {wheel}")

digest = hashlib.sha256(wheel.read_bytes()).hexdigest()
if digest != manifest["sha256"]:
    sys.exit(f"❌ Empreinte incohérente\n   manifeste : {manifest['sha256']}\n   fichier   : {digest}")

print(f"✅ {manifest['wheel']} — version {manifest['version']}, empreinte vérifiée.")
PY

###############################################################################
# 7) Suite
###############################################################################
cat <<EOF

═══════════════════════════════════════════════════════════
✅ JEIKO $VERSION prêt à être publié.

Fichiers à committer :
   pyproject.toml
   version.json
   dist/$WHEEL_NAME
   dist/requirements.txt

Commandes :

  git add -f pyproject.toml version.json dist/$WHEEL_NAME dist/requirements.txt
  git commit -m "Release $VERSION"
  git tag v$VERSION
  git push && git push --tags

Ensuite, sur un serveur :

  sudo jeiko-client-update <site> --check    # sans rien installer
  sudo jeiko-client-update <site>            # mise à jour effective

ou, sans terminal : Administration ▸ Mettre à jour JEIKO.

La configuration serveur ne bouge pas avec le package. Pour la faire converger
(nginx, sudoers, systemd, permissions) :

  sudo jeiko-server-update <site>
  sudo jeiko-server-update --all

⚠️  dist/ est souvent listé dans .gitignore — d'où le « git add -f ».
    Le wheel DOIT être committé : c'est ce que les serveurs téléchargent.
═══════════════════════════════════════════════════════════
EOF
