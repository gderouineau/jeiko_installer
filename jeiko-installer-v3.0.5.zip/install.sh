#!/bin/bash
###############################################################################
# JEIKO INSTALLER v2.0
#
# Installe un site JEIKO complet sur Debian 12 : durcissement système,
# PostgreSQL, Memcached, venv Python, package JEIKO, Gunicorn, Nginx, TLS,
# sauvegardes, et le mécanisme de mise à jour depuis l'interface admin.
#
# ⚠️  Ce script est prévu pour une INSTALLATION NEUVE.
#     Pour amener un site déjà en production sur ce schéma, utiliser
#     ./migrate_site.sh <site> — qui sauvegarde et vérifie avant d'appliquer.
#
# Auteur : Guillaume Derouineau
###############################################################################

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"

# Version de l'installeur, distincte de celle du package JEIKO : les deux
# évoluent séparément. Le fichier VERSION est la source unique — publier-installer.sh
# l'incrémente, et rien d'autre ne la recopie.
VERSION="$(cat "$SCRIPT_DIR/VERSION" 2>/dev/null || echo "inconnue")"
DEFAULT_INSTALL_ROOT="$(dirname "$SCRIPT_DIR")"          # parent de l'installeur, ex: /var/www
BASE_DIR="${INSTALL_ROOT:-$DEFAULT_INSTALL_ROOT}"

echo "📦 JEIKO INSTALLER v$VERSION"

if [[ ${EUID} -ne 0 ]]; then
    echo "❌ Ce script doit être exécuté avec sudo : sudo ./install.sh"
    exit 1
fi

###############################################################################
# 0) Déploiement de la bibliothèque partagée
#
# jeiko-common.sh doit être en place AVANT tout le reste : installeur et
# updater le partagent, c'est ce qui garantit qu'ils appliquent exactement le
# même modèle de permissions.
###############################################################################
install -d -m 0755 -o root -g root /usr/local/lib/jeiko
install -m 0644 -o root -g root "$SCRIPT_DIR/lib/jeiko-common.sh" /usr/local/lib/jeiko/common.sh

# shellcheck source=lib/jeiko-common.sh
source /usr/local/lib/jeiko/common.sh
jeiko_init_dirs

###############################################################################
# 1) Saisie
###############################################################################
read -rp "▶️  Nom du site (ex: monsite) : " SITE_NAME
jeiko_validate_site_name "$SITE_NAME" || exit 1

if [[ -f "$(jeiko_site_conf_path "$SITE_NAME")" ]]; then
    echo "⚠️  Un site nommé '$SITE_NAME' est déjà enregistré sur cette machine."
    echo "    Pour le mettre à jour : jeiko-update $SITE_NAME"
    echo "    Pour le migrer        : ./migrate_site.sh $SITE_NAME"
    read -rp "    Continuer quand même et écraser sa configuration ? (oui/non) : " force_overwrite
    [[ "$force_overwrite" == "oui" ]] || { echo "Installation annulée."; exit 0; }
fi

read -rp "▶️  Nom de domaine (ex: monsite.fr) : " DOMAIN_NAME
DOMAIN_NAME="${DOMAIN_NAME,,}"
jeiko_validate_domain "$DOMAIN_NAME" || exit 1

read -rp "▶️  Nom de la base PostgreSQL [${SITE_NAME}_db] : " DB_NAME
DB_NAME="${DB_NAME:-${SITE_NAME}_db}"
[[ "$DB_NAME" =~ ^[a-zA-Z_][a-zA-Z0-9_]{0,62}$ ]] || { echo "❌ Nom de base invalide."; exit 1; }

read -rp "▶️  Nom de l'utilisateur PostgreSQL [${SITE_NAME}_user] : " DB_USER
DB_USER="${DB_USER:-${SITE_NAME}_user}"
[[ "$DB_USER" =~ ^[a-zA-Z_][a-zA-Z0-9_]{0,62}$ ]] || { echo "❌ Nom d'utilisateur invalide."; exit 1; }

# Un mot de passe généré évite à la fois les mots de passe faibles et les
# caractères qui cassaient l'interpolation SQL de l'ancien script.
read -rsp "▶️  Mot de passe PostgreSQL (vide = généré automatiquement) : " DB_PASS; echo
if [[ -z "$DB_PASS" ]]; then
    DB_PASS="$(tr -dc 'A-Za-z0-9' </dev/urandom | head -c40)"
    echo "   🔑 Mot de passe généré (stocké dans la fiche du site, non affiché)."
fi

read -rp "▶️  Nom du superuser Django : " DJANGO_SUPERUSER
[[ -n "$DJANGO_SUPERUSER" ]] || { echo "❌ Nom requis."; exit 1; }
read -rp "▶️  Email du superuser Django : " DJANGO_SUPEREMAIL
read -rsp "▶️  Mot de passe superuser Django : " DJANGO_SUPERPASS; echo
[[ ${#DJANGO_SUPERPASS} -ge 12 ]] || { echo "❌ 12 caractères minimum."; exit 1; }

read -rp "▶️  Activer HTTPS avec Let's Encrypt ? (y/n) : " ENABLE_SSL
ENABLE_SSL="${ENABLE_SSL,,}"

# L'utilisateur humain qui pourra lire le projet en SSH sans sudo.
ADMIN_SSH_USER="${SUDO_USER:-debian}"
read -rp "▶️  Utilisateur SSH d'administration [$ADMIN_SSH_USER] : " _admin
ADMIN_SSH_USER="${_admin:-$ADMIN_SSH_USER}"

###############################################################################
# Clé SSH publique
#
# Sans clé sur la machine, le durcissement laisse l'authentification par mot de
# passe active — c'est le seul moyen de ne pas t'enfermer dehors. L'installeur
# affichait alors un avertissement te demandant de la déposer toi-même, plus
# tard, à la main. On la demande maintenant : c'est le seul moment où l'on est
# sûr que quelqu'un est devant l'écran.
###############################################################################
SSH_PUBKEY=""
KEEP_PW_MARKER="$JEIKO_ETC_DIR/keep-password-auth"

# La machine peut déjà porter une clé : celle de l'administrateur, ou celle que
# l'hébergeur dépose dans /root à la création du VPS. La seconde ne donne aucun
# accès à qui installe.
EXISTING_KEY=0
grep -Eqs 'ssh-(ed25519|rsa)|ecdsa-sha2' \
    /root/.ssh/authorized_keys "/home/$ADMIN_SSH_USER/.ssh/authorized_keys" 2>/dev/null \
    && EXISTING_KEY=1

if [[ -f "$KEEP_PW_MARKER" ]]; then
    # Choix déjà arrêté sur cette machine : on ne repose pas la question à
    # chaque nouveau site, et surtout on ne revient pas dessus en silence.
    JEIKO_KEEP_PASSWORD_AUTH=1
    echo "🔑 Mot de passe SSH conservé (choix enregistré sur cette machine)."
elif [[ $EXISTING_KEY -eq 1 ]]; then
    echo ""
    echo "🔐 Une clé SSH est déjà présente sur cette machine."
    echo ""
    echo "    L'installeur peut désactiver l'authentification par mot de passe."
    echo "    C'est plus sûr, MAIS tu ne pourras plus te connecter qu'avec cette"
    echo "    clé précise. Si elle appartient à ton hébergeur, ou si tu te"
    echo "    connectes depuis un poste qui ne l'a pas, tu seras enfermé dehors."
    echo ""
    read -rp "▶️  Désactiver le mot de passe SSH ? (y/N) : " _harden
    if [[ "${_harden,,}" == "y" ]]; then
        JEIKO_KEEP_PASSWORD_AUTH=0
        echo "   🔒 Mot de passe désactivé. Garde une session ouverte et vérifie"
        echo "      ta connexion par clé avant de la fermer."
    else
        JEIKO_KEEP_PASSWORD_AUTH=1
        echo "   ✅ Mot de passe conservé (fail2ban actif). Choix mémorisé pour"
        echo "      les prochaines installations sur cette machine."
    fi
else
    echo ""
    echo "⚠️  Aucune clé SSH publique trouvée sur cette machine."
    echo "    Sans clé, l'accès par mot de passe doit rester ouvert, ce qui est"
    echo "    la faiblesse principale d'un serveur exposé."
    echo ""
    echo "    Colle ta clé publique (le contenu de ~/.ssh/id_ed25519.pub sur ton"
    echo "    poste), ou laisse vide pour conserver l'accès par mot de passe :"
    read -rp "▶️  Clé publique : " SSH_PUBKEY
    SSH_PUBKEY="$(printf '%s' "$SSH_PUBKEY" | tr -d '\r')"

    if [[ -n "$SSH_PUBKEY" ]]; then
        if [[ ! "$SSH_PUBKEY" =~ ^(ssh-ed25519|ssh-rsa|ecdsa-sha2-[a-z0-9-]+)[[:space:]]+[A-Za-z0-9+/=]+ ]]; then
            echo "❌ Ce n'est pas une clé publique valide (attendu : « ssh-ed25519 AAAA… »)."
            exit 1
        fi
        JEIKO_KEEP_PASSWORD_AUTH=0
        echo "   ✅ Clé retenue — l'authentification par mot de passe sera désactivée."
    else
        JEIKO_KEEP_PASSWORD_AUTH=1
        echo "   ⚠️  Aucune clé : mot de passe conservé, protégé par fail2ban."
    fi
fi

###############################################################################
# 2) Variables dérivées
###############################################################################
PROJECT_DIR="$BASE_DIR/$SITE_NAME"
SITE_USER="jeiko-$SITE_NAME"
VENV_DIR="$PROJECT_DIR/venv"
GUNICORN_SERVICE="gunicorn-$SITE_NAME"
JEIKO_CHANNEL_URL="${JEIKO_CHANNEL_URL:-$JEIKO_DEFAULT_CHANNEL_URL}"
INSTALLED_AT="$(date -Is)"

TIMESTAMP="$(date +"%Y%m%d_%H%M%S")"
LOG_DIR="$SCRIPT_DIR/logs"
install -d -m 0750 "$LOG_DIR"
LOG_FILE="$LOG_DIR/install_${SITE_NAME}_$TIMESTAMP.log"
: >"$LOG_FILE"; chmod 0640 "$LOG_FILE"

echo "──────────── RÉCAPITULATIF ────────────"
echo "🧩 Site              : $SITE_NAME"
echo "🌍 Domaine           : $DOMAIN_NAME"
echo "🛢️  Base PostgreSQL   : $DB_NAME (rôle $DB_USER)"
echo "👤 Superuser Django  : $DJANGO_SUPERUSER <$DJANGO_SUPEREMAIL>"
echo "🔒 Let's Encrypt     : $ENABLE_SSL"
echo "📁 Dossier projet    : $PROJECT_DIR"
echo "🧑 Utilisateur système: $SITE_USER"
echo "🔑 Admin SSH (ACL)   : $ADMIN_SSH_USER"
if [[ "${JEIKO_KEEP_PASSWORD_AUTH:-1}" == "1" ]]; then
    echo "🔓 Mot de passe SSH  : CONSERVÉ (fail2ban actif)"
else
    echo "🔒 Mot de passe SSH  : DÉSACTIVÉ — connexion par clé uniquement"
fi
echo "📡 Canal de MAJ      : $JEIKO_CHANNEL_URL"
echo "───────────────────────────────────────"
read -rp "Confirmer l'installation ? (y/n) : " confirm
[[ "$confirm" == "y" ]] || { echo "Installation annulée."; exit 0; }

###############################################################################
# 3) Fiche du site
#
# Remplace le .env.<site> qui était écrit en 0644 dans le dossier de
# l'installeur — mot de passe PostgreSQL lisible par n'importe quel compte
# local. La fiche est en 0600 root:root et ne contient plus le mot de passe du
# superuser Django, qui ne sert qu'une fois (étape 14) et n'a aucune raison de
# survivre à l'installation.
###############################################################################
jeiko_write_site_conf "$SITE_NAME"
echo "🗃️  Fiche du site : $(jeiko_site_conf_path "$SITE_NAME") (0600 root:root)"

export SSH_PUBKEY JEIKO_KEEP_PASSWORD_AUTH
export SCRIPT_DIR BASE_DIR PROJECT_DIR SITE_NAME DOMAIN_NAME SITE_USER VENV_DIR
export GUNICORN_SERVICE DB_NAME DB_USER DB_PASS ENABLE_SSL ADMIN_SSH_USER
export DJANGO_SUPERUSER DJANGO_SUPEREMAIL DJANGO_SUPERPASS
export JEIKO_CHANNEL_URL LOG_FILE

###############################################################################
# 4) Exécution des étapes
###############################################################################
chmod +x "$SCRIPT_DIR"/scripts/*.sh

STEPS=(
    00_preflight
    01_security_baseline
    02_users_dirs
    03_check_dependencies
    04_install_postgres
    05_setup_database
    06_install_memcached
    07_install_python_env
    08_install_jeiko_package
    09_configure_django
    10_configure_gunicorn
    11_configure_nginx
)
[[ "$ENABLE_SSL" == "y" ]] && STEPS+=(12_setup_tls_letsencrypt) || true
STEPS+=(13_backups 14_finalize)

echo "🚀 Installation en cours… (journal : $LOG_FILE)"

for step in "${STEPS[@]}"; do
    if ! "$SCRIPT_DIR/scripts/$step.sh" 2>&1 | tee -a "$LOG_FILE"; then
        echo ""
        echo "❌ Échec à l'étape $step. Journal complet : $LOG_FILE"
        echo "   Les étapes sont idempotentes : corrige la cause et relance ./install.sh."
        exit 1
    fi
done

###############################################################################
# 5) Fin
###############################################################################
SCHEME="http"; [[ "$ENABLE_SSL" == "y" ]] && SCHEME="https" || true

cat <<EOF

═══════════════════════════════════════════════════════════
✅ Installation terminée.

🌐 Site           : $SCHEME://$DOMAIN_NAME
🔐 Administration : $SCHEME://$DOMAIN_NAME/administration/
📄 Journal        : $LOG_FILE

Mise à jour du site :
  · depuis l'interface  → Administration ▸ Mettre à jour JEIKO
  · depuis le serveur   → sudo jeiko-update $SITE_NAME
  · vérifier sans agir  → sudo jeiko-update $SITE_NAME --check
  · revenir en arrière  → sudo jeiko-update $SITE_NAME --rollback

Fiche du site : $(jeiko_site_conf_path "$SITE_NAME")
Sauvegardes   : $JEIKO_BACKUP_DIR/$SITE_NAME
═══════════════════════════════════════════════════════════
EOF

if [[ "$ENABLE_SSL" != "y" ]]; then
    cat <<EOF
⚠️  Le site tourne en HTTP. La redirection HTTPS et HSTS sont désactivées dans
    le .env (JEIKO_SSL="False") pour éviter la boucle de redirection.
    Pour activer TLS plus tard :
      sudo ENABLE_SSL=y $SCRIPT_DIR/scripts/12_setup_tls_letsencrypt.sh
    puis passer JEIKO_SSL="True" dans $PROJECT_DIR/$SITE_NAME/.env
    et redémarrer : sudo systemctl restart $GUNICORN_SERVICE
EOF
fi
