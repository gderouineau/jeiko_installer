#!/bin/bash
set -euo pipefail
# shellcheck source=../lib/jeiko-common.sh
source /usr/local/lib/jeiko/common.sh

jeiko_step "[14] Migrations, statiques, droits de mise à jour, contrôles"
jeiko_require_root

: "${PROJECT_DIR:?PROJECT_DIR manquant}"
: "${SITE_NAME:?SITE_NAME manquant}"
: "${SITE_USER:?SITE_USER manquant}"
: "${VENV_DIR:?VENV_DIR manquant}"
: "${DJANGO_SUPERUSER:?DJANGO_SUPERUSER manquant}"

SERVICE_NAME="${GUNICORN_SERVICE:-gunicorn-$SITE_NAME}"

# --------------------------------------------------------------------------- #
# 1) Base et fichiers statiques
# --------------------------------------------------------------------------- #
jeiko_log "🔄 Migrations…"
jeiko_manage "$PROJECT_DIR" "$VENV_DIR" "$SITE_USER" migrate --noinput

jeiko_log "📦 Collecte des fichiers statiques…"
jeiko_manage "$PROJECT_DIR" "$VENV_DIR" "$SITE_USER" collectstatic --noinput

# --------------------------------------------------------------------------- #
# 2) Superuser
#
# Le mot de passe transite par l'environnement du processus plutôt que par
# l'interpolation d'une chaîne dans un script shell : il n'apparaît ni dans le
# journal d'installation, ni dans l'historique des commandes, ni dans un
# fichier temporaire.
# --------------------------------------------------------------------------- #
jeiko_log "👤 Superuser Django…"
DJANGO_SU_NAME="$DJANGO_SUPERUSER" \
DJANGO_SU_EMAIL="${DJANGO_SUPEREMAIL:-}" \
DJANGO_SU_PASS="${DJANGO_SUPERPASS:-}" \
jeiko_manage "$PROJECT_DIR" "$VENV_DIR" "$SITE_USER" shell <<'PY'
import os
from django.contrib.auth import get_user_model

User = get_user_model()
name = os.environ["DJANGO_SU_NAME"]
email = os.environ.get("DJANGO_SU_EMAIL", "")
password = os.environ.get("DJANGO_SU_PASS", "")

user = User.objects.filter(username=name).first()
if user is None:
    User.objects.create_superuser(name, email, password)
    print(f"✅ Superuser « {name} » créé.")
else:
    # On ne réinitialise jamais le mot de passe d'un compte existant : une
    # réinstallation ne doit pas écraser silencieusement un identifiant en
    # service.
    changed = False
    if not user.is_superuser or not user.is_staff:
        user.is_superuser = user.is_staff = True
        changed = True
    if changed:
        user.save()
        print(f"✅ Droits d'administration rétablis pour « {name} ».")
    else:
        print(f"ℹ️  Superuser « {name} » déjà présent, mot de passe inchangé.")
PY

# --------------------------------------------------------------------------- #
# 3) django.contrib.sites
# --------------------------------------------------------------------------- #
jeiko_log "🌐 Synchronisation de django.contrib.sites…"
JEIKO_DOMAIN="$DOMAIN_NAME" JEIKO_SITENAME="$SITE_NAME" \
jeiko_manage "$PROJECT_DIR" "$VENV_DIR" "$SITE_USER" shell <<'PY'
import os
from django.contrib.sites.models import Site

domain = os.environ.get("JEIKO_DOMAIN", "")
name = os.environ.get("JEIKO_SITENAME") or domain

if domain:
    site, _ = Site.objects.get_or_create(id=1, defaults={"domain": domain, "name": name})
    site.domain, site.name = domain, name
    site.save()
    print(f"✅ Site(id=1) = {site.domain} ({site.name})")
else:
    print("⚠️  DOMAIN_NAME absent, django.contrib.sites non modifié.")
PY

# --------------------------------------------------------------------------- #
# 4) Droits de mise à jour — le correctif central
#
# L'interface d'administration lançait `sudo <script dans site-packages>`, alors
# que le fichier sudoers n'autorisait que systemctl : sudo réclamait un mot de
# passe, sans terminal pour le saisir, et la mise à jour échouait toujours.
#
# Deux corrections indissociables :
#   · la règle autorise exactement la commande émise par la vue Django ;
#   · cette commande ne fait que DÉCLENCHER une unité systemd dont l'ExecStart
#     pointe vers un binaire root:root. Le site ne peut plus choisir ce qui est
#     exécuté sous privilèges — il ne peut que demander son propre déclenchement.
#
# Le chemin est figé à /usr/bin/systemctl : sudo compare la ligne de commande
# telle qu'écrite, et /bin/systemctl — pourtant le même fichier via usrmerge —
# serait une chaîne différente, donc une règle qui ne s'applique pas.
# --------------------------------------------------------------------------- #
jeiko_require_systemctl_path || jeiko_die "Chemin de systemctl inattendu, sudoers non généré."
SYSTEMCTL="$JEIKO_SYSTEMCTL"
SUDOERS="/etc/sudoers.d/jeiko-$SITE_NAME"
SUDOERS_TMP="$(mktemp)"

cat >"$SUDOERS_TMP" <<EOF
# Droits accordés à l'application JEIKO du site « $SITE_NAME ».
# Généré par l'installeur — ne pas éditer à la main.
#
# Strictement limité au déclenchement de sa propre mise à jour et au
# redémarrage de son propre service. Aucune commande arbitraire, aucun
# caractère générique, aucun chemin situé dans une arborescence que
# l'application peut écrire.
#
# Ni « !syslog » (il effaçait la trace sudo du compte le plus exposé du
# système), ni « reload nginx » (nginx est partagé par tous les sites et
# l'updater tourne déjà en root).

Defaults:$SITE_USER !requiretty

$SITE_USER ALL=(root) NOPASSWD: $SYSTEMCTL start --no-block jeiko-update@$SITE_NAME.service
$SITE_USER ALL=(root) NOPASSWD: $SYSTEMCTL restart $SERVICE_NAME.service
EOF

# visudo -c AVANT de mettre le fichier en place : un sudoers invalide rend sudo
# inutilisable sur toute la machine, y compris pour le réparer.
if visudo -cqf "$SUDOERS_TMP"; then
    install -m 0440 -o root -g root "$SUDOERS_TMP" "$SUDOERS"
    rm -f "$SUDOERS_TMP"
    jeiko_ok "Droits de mise à jour accordés à $SITE_USER (2 commandes, rien d'autre)."
else
    rm -f "$SUDOERS_TMP"
    jeiko_die "Le fichier sudoers généré est invalide, il n'a pas été installé."
fi

# Purge d'une éventuelle règle héritée de l'ancien schéma, qui autorisait un
# script situé dans site-packages.
if [[ -f "/etc/sudoers.d/jeiko-$SITE_NAME.old" ]]; then
    rm -f "/etc/sudoers.d/jeiko-$SITE_NAME.old"
fi

systemctl daemon-reload

# --------------------------------------------------------------------------- #
# 5) Permissions finales et ACL
# --------------------------------------------------------------------------- #
jeiko_fix_perms "$PROJECT_DIR" "$SITE_USER" "$SITE_NAME" "$VENV_DIR"
jeiko_apply_admin_acl "$PROJECT_DIR" "${ADMIN_SSH_USER:-}"

# --------------------------------------------------------------------------- #
# 6) Redémarrage et contrôles
# --------------------------------------------------------------------------- #
jeiko_log "🔁 Redémarrage des services…"
systemctl restart "$SERVICE_NAME"
systemctl reload nginx || systemctl restart nginx

jeiko_log "🔎 Contrôle de déploiement Django…"
jeiko_manage "$PROJECT_DIR" "$VENV_DIR" "$SITE_USER" check --deploy 2>&1 || \
    jeiko_warn "Des avertissements subsistent (voir ci-dessus)."

# Contrôle de bout en bout, par la socket : c'est exactement le chemin
# qu'empruntera nginx.
SOCKET="/run/$SERVICE_NAME/gunicorn.sock"
HEALTHY=0
for _ in {1..15}; do
    sleep 1
    [[ -S "$SOCKET" ]] || continue
    CODE="$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 \
            --unix-socket "$SOCKET" \
            -H "Host: $DOMAIN_NAME" -H "X-Forwarded-Proto: https" \
            "http://localhost/" 2>/dev/null || echo 000)"
    if [[ "$CODE" =~ ^[123] ]]; then HEALTHY=1; break; fi
done

if [[ $HEALTHY -eq 1 ]]; then
    jeiko_ok "L'application répond (HTTP $CODE)."
else
    jeiko_warn "L'application ne répond pas encore correctement (dernier code : ${CODE:-aucun})."
    journalctl -u "$SERVICE_NAME" -n 30 --no-pager || true
fi

# --------------------------------------------------------------------------- #
# 7) Vérification du mécanisme de mise à jour
#
# On le teste maintenant, à vide. Découvrir qu'il ne fonctionne pas le jour
# d'une mise à jour urgente est exactement ce qu'on cherche à éviter.
# --------------------------------------------------------------------------- #
jeiko_log "🧪 Vérification du déclenchement de la mise à jour…"
if jeiko_as_site "$SITE_USER" sudo -n "$SYSTEMCTL" start --no-block "jeiko-update@$SITE_NAME.service" 2>/dev/null; then
    jeiko_ok "L'application peut déclencher sa mise à jour sans mot de passe."
    sleep 2
    systemctl stop "jeiko-update@$SITE_NAME.service" 2>/dev/null || true
else
    jeiko_warn "Le déclenchement de mise à jour depuis l'application ne fonctionne pas — vérifie $SUDOERS"
fi

jeiko_ok "Finalisation terminée."
