#!/bin/bash
set -euo pipefail
# shellcheck source=../lib/jeiko-common.sh
source /usr/local/lib/jeiko/common.sh

jeiko_step "[01] Durcissement de base (UFW, SSH, Fail2ban, sysctl, MAJ auto, temps)"
jeiko_require_root

export DEBIAN_FRONTEND=noninteractive

# --------------------------------------------------------------------------- #
# 1) Paquets
# --------------------------------------------------------------------------- #
apt-get update -y
apt-get install -y \
    ufw fail2ban \
    unattended-upgrades apt-listchanges \
    cron logrotate rsyslog \
    ca-certificates curl gnupg lsb-release jq \
    chrony

systemctl enable --now cron rsyslog chrony >/dev/null 2>&1 || true

# --------------------------------------------------------------------------- #
# 2) Heure
# --------------------------------------------------------------------------- #
timedatectl set-timezone Europe/Paris || true
timedatectl set-ntp true || true
systemctl restart chrony || true

# --------------------------------------------------------------------------- #
# 3) Swap
# --------------------------------------------------------------------------- #
if ! swapon --summary | grep -q '^[^ ]'; then
    jeiko_log "💾 Création d'un swapfile de 2 Go…"
    fallocate -l 2G /swapfile 2>/dev/null || dd if=/dev/zero of=/swapfile bs=1M count=2048 status=none
    chmod 600 /swapfile
    mkswap /swapfile >/dev/null
    swapon /swapfile
    grep -qE '^\s*/swapfile\s' /etc/fstab || echo '/swapfile none swap sw 0 0' >>/etc/fstab
    echo 'vm.swappiness=10' >/etc/sysctl.d/60-swap.conf
    sysctl -p /etc/sysctl.d/60-swap.conf >/dev/null || true
else
    jeiko_log "ℹ️  Swap déjà présent."
fi

# --------------------------------------------------------------------------- #
# 4) Pare-feu
#
# `ufw --force reset` désactivait le pare-feu de tous les sites déjà hébergés
# le temps de le reconstruire. On travaille désormais en ajout idempotent.
# --------------------------------------------------------------------------- #
jeiko_log "🧱 Configuration UFW…"
sed -ri 's/^#?IPV6=.*/IPV6=yes/' /etc/default/ufw 2>/dev/null || true

ufw default deny incoming >/dev/null
ufw default allow outgoing >/dev/null
ufw allow 22/tcp  comment 'SSH'   >/dev/null
ufw allow 80/tcp  comment 'HTTP'  >/dev/null
ufw allow 443/tcp comment 'HTTPS' >/dev/null

if ufw status | grep -q "Status: inactive"; then
    ufw --force enable >/dev/null
fi
ufw status verbose || true

# --------------------------------------------------------------------------- #
# 5) SSH
#
# L'ancienne version ne cherchait une clé publique que dans /root/.ssh. Sur un
# VPS Debian standard, la clé est déposée chez l'utilisateur 'debian' et root
# n'en a aucune : le test échouait toujours et l'authentification par mot de
# passe restait active en permanence.
# --------------------------------------------------------------------------- #
SSHD_CONF="/etc/ssh/sshd_config"
cp -n "$SSHD_CONF" "${SSHD_CONF}.jeiko.bak" 2>/dev/null || true

sed -ri 's/^#?PermitRootLogin .*/PermitRootLogin prohibit-password/' "$SSHD_CONF"

# Clé fournie pendant la saisie : on l'installe pour l'administrateur, ce qui
# permet de couper l'authentification par mot de passe dans la foulée.
ADMIN_HOME="$(getent passwd "${ADMIN_SSH_USER:-debian}" 2>/dev/null | cut -d: -f6)"
if [[ -n "${SSH_PUBKEY:-}" && -n "$ADMIN_HOME" && -d "$ADMIN_HOME" ]]; then
    install -d -m 0700 -o "$ADMIN_SSH_USER" -g "$ADMIN_SSH_USER" "$ADMIN_HOME/.ssh"
    AUTH_KEYS="$ADMIN_HOME/.ssh/authorized_keys"
    touch "$AUTH_KEYS"
    # Idempotent : réinstaller ne duplique pas la ligne.
    grep -qxF "$SSH_PUBKEY" "$AUTH_KEYS" 2>/dev/null || printf '%s\n' "$SSH_PUBKEY" >>"$AUTH_KEYS"
    chown "$ADMIN_SSH_USER":"$ADMIN_SSH_USER" "$AUTH_KEYS"
    chmod 0600 "$AUTH_KEYS"
    jeiko_ok "Clé SSH installée pour $ADMIN_SSH_USER"
fi

key_found=0
for home in /root "/home/${ADMIN_SSH_USER:-debian}" $(getent passwd | awk -F: '$3>=1000 && $3<65534 {print $6}'); do
    if grep -Eqs 'ssh-(ed25519|rsa)|ecdsa-sha2' "$home/.ssh/authorized_keys" 2>/dev/null; then
        key_found=1
        jeiko_log "🔐 Clé SSH détectée dans $home/.ssh/authorized_keys"
        break
    fi
done

if [[ $key_found -eq 1 ]]; then
    sed -ri 's/^#?PasswordAuthentication .*/PasswordAuthentication no/' "$SSHD_CONF"
    sed -ri 's/^#?KbdInteractiveAuthentication .*/KbdInteractiveAuthentication no/' "$SSHD_CONF"
    # Sur Debian 12, ces réglages peuvent être écrasés par un fragment de
    # /etc/ssh/sshd_config.d/ chargé APRÈS le fichier principal — typiquement
    # celui que déposent certains hébergeurs pour réactiver le mot de passe.
    # On pose le nôtre avec un préfixe qui passe en dernier.
    install -d -m 0755 /etc/ssh/sshd_config.d
    cat >/etc/ssh/sshd_config.d/99-jeiko.conf <<'SSHD'
# Généré par l'installeur JEIKO. Chargé après les autres fragments.
PasswordAuthentication no
KbdInteractiveAuthentication no
PermitRootLogin prohibit-password
SSHD
    jeiko_ok "SSH : authentification par mot de passe désactivée (clé requise)."
else
    sed -ri 's/^#?PasswordAuthentication .*/PasswordAuthentication yes/' "$SSHD_CONF"
    rm -f /etc/ssh/sshd_config.d/99-jeiko.conf
    jeiko_warn "SSH : aucune clé publique, mot de passe laissé actif (fail2ban actif)."
    jeiko_warn "     Pour durcir plus tard, sans éditer de fichier :"
    jeiko_warn "       sudo jeiko-ssh-key 'ssh-ed25519 AAAA…'"
fi

for directive in 'MaxAuthTries 3' 'LoginGraceTime 30' 'ClientAliveInterval 300' 'ClientAliveCountMax 2' 'X11Forwarding no'; do
    key="${directive%% *}"
    if grep -qE "^\s*${key}\b" "$SSHD_CONF"; then
        sed -ri "s|^\s*${key}\b.*|${directive}|" "$SSHD_CONF"
    else
        echo "$directive" >>"$SSHD_CONF"
    fi
done

sshd -t || jeiko_die "Configuration SSH invalide, rien n'a été rechargé (sauvegarde : ${SSHD_CONF}.jeiko.bak)"
systemctl reload ssh 2>/dev/null || systemctl restart ssh || true

# --------------------------------------------------------------------------- #
# Outil pour ajouter une clé après coup, sans éditer de fichier ni se souvenir
# de la syntaxe sshd. C'est la seule action d'administration qui restait
# manuelle après une installation sans clé.
# --------------------------------------------------------------------------- #
cat >/usr/local/sbin/jeiko-ssh-key <<'OUTIL'
#!/bin/bash
# jeiko-ssh-key '<clé publique>' [utilisateur]
#
# Installe une clé publique et coupe l'authentification par mot de passe.
# Vérifie la configuration avant de recharger : impossible de s'enfermer dehors.
set -euo pipefail
[[ $EUID -eq 0 ]] || { echo "À exécuter avec sudo."; exit 1; }

CLE="${1:?Usage: jeiko-ssh-key 'ssh-ed25519 AAAA…' [utilisateur]}"
UTILISATEUR="${2:-${SUDO_USER:-debian}}"

[[ "$CLE" =~ ^(ssh-ed25519|ssh-rsa|ecdsa-sha2-[a-z0-9-]+)[[:space:]]+[A-Za-z0-9+/=]+ ]] \
    || { echo "❌ Clé publique invalide."; exit 1; }

MAISON="$(getent passwd "$UTILISATEUR" | cut -d: -f6)"
[[ -n "$MAISON" && -d "$MAISON" ]] || { echo "❌ Utilisateur inconnu : $UTILISATEUR"; exit 1; }

install -d -m 0700 -o "$UTILISATEUR" -g "$UTILISATEUR" "$MAISON/.ssh"
touch "$MAISON/.ssh/authorized_keys"
grep -qxF "$CLE" "$MAISON/.ssh/authorized_keys" || printf '%s\n' "$CLE" >>"$MAISON/.ssh/authorized_keys"
chown "$UTILISATEUR":"$UTILISATEUR" "$MAISON/.ssh/authorized_keys"
chmod 0600 "$MAISON/.ssh/authorized_keys"
echo "✅ Clé installée pour $UTILISATEUR"

install -d -m 0755 /etc/ssh/sshd_config.d
cat >/etc/ssh/sshd_config.d/99-jeiko.conf <<'SSHD'
# Généré par jeiko-ssh-key. Chargé après les autres fragments.
PasswordAuthentication no
KbdInteractiveAuthentication no
PermitRootLogin prohibit-password
SSHD

if sshd -t; then
    systemctl reload ssh 2>/dev/null || systemctl restart ssh
    echo "✅ Authentification par mot de passe désactivée."
    echo "   Vérifie une nouvelle connexion AVANT de fermer celle-ci."
else
    rm -f /etc/ssh/sshd_config.d/99-jeiko.conf
    echo "❌ Configuration SSH invalide — rien n'a été changé."
    exit 1
fi
OUTIL
chmod 0755 /usr/local/sbin/jeiko-ssh-key
chown root:root /usr/local/sbin/jeiko-ssh-key

# --------------------------------------------------------------------------- #
# 6) Fail2ban
#
# Les jails nginx-* ne s'activent que si le filtre existe ET si un log est
# présent. L'ancienne configuration activait « nginx-req-limit » alors
# qu'aucune zone limit_req n'était déclarée dans nginx : le jail ne matchait
# jamais rien. La zone est maintenant créée à l'étape 11.
# --------------------------------------------------------------------------- #
install -d -m 0755 /etc/fail2ban/jail.d

cat >/etc/fail2ban/jail.d/jeiko-hardening.conf <<'JAIL'
[DEFAULT]
backend  = systemd
findtime = 10m
bantime  = 1h

[sshd]
enabled  = true
port     = ssh
maxretry = 3

[nginx-http-auth]
enabled  = true
logpath  = /var/log/nginx/error.log
JAIL

# Ces deux jails dépendent de filtres qui ne sont pas fournis par toutes les
# versions du paquet : on ne les active que s'ils existent réellement.
for jail in nginx-botsearch nginx-limit-req; do
    if [[ -f "/etc/fail2ban/filter.d/${jail}.conf" ]]; then
        cat >>/etc/fail2ban/jail.d/jeiko-hardening.conf <<JAIL

[$jail]
enabled = true
logpath = /var/log/nginx/error.log
maxretry = 10
JAIL
        jeiko_log "🚨 Jail activé : $jail"
    fi
done

# --------------------------------------------------------------------------- #
# Bannissement sur dépassement répété du débit
#
# Nginx renvoie 429 quand une limite limit_req est franchie. Un visiteur normal
# n'en déclenche jamais ; une adresse qui en accumule est en train de forcer un
# formulaire de connexion ou de moissonner le site. Le rate limiting ralentit,
# ce jail écarte.
#
# C'est aussi la seule protection contre la force brute sur la connexion
# Django : celle-ci répond 200 sur un échec, donc aucun filtre lisant les codes
# d'accès ne peut la détecter.
# --------------------------------------------------------------------------- #
cat >/etc/fail2ban/filter.d/jeiko-nginx-429.conf <<'FILTRE'
[Definition]
failregex = ^<HOST> - .* "(GET|POST|HEAD).*" 429
ignoreregex =
datepattern = ^[^\[]*\[({DATE})
FILTRE

cat >>/etc/fail2ban/jail.d/jeiko-hardening.conf <<'JAIL'

[jeiko-nginx-429]
enabled  = true
port     = http,https
filter   = jeiko-nginx-429
backend  = auto
logpath  = /var/log/nginx/*_access.log
findtime = 5m
maxretry = 20
bantime  = 2h
JAIL
jeiko_log "🚨 Jail activé : jeiko-nginx-429 (dépassements de débit répétés)"

# Sans ce fichier, fail2ban refuse de démarrer sur une machine fraîche où nginx
# n'a encore rien journalisé.
install -d -m 0755 /var/log/nginx
touch /var/log/nginx/error.log /var/log/nginx/access.log

systemctl enable --now fail2ban || true
if ! systemctl is-active --quiet fail2ban; then
    jeiko_warn "fail2ban n'a pas démarré :"
    journalctl -u fail2ban -n 20 --no-pager || true
fi

# --------------------------------------------------------------------------- #
# 7) Mises à jour de sécurité automatiques
# --------------------------------------------------------------------------- #
cat >/etc/apt/apt.conf.d/20auto-upgrades <<'APT'
APT::Periodic::Update-Package-Lists "1";
APT::Periodic::Download-Upgradeable-Packages "1";
APT::Periodic::Unattended-Upgrade "1";
APT::Periodic::AutocleanInterval "7";
APT

# Redémarrage automatique après une mise à jour du noyau.
#
# Sans lui, les correctifs de sécurité du noyau sont installés mais jamais
# actifs : la machine tourne indéfiniment sur l'ancien, et rien ne le signale.
# On le fait à 4h20, en dehors des heures de trafic. Les services redémarrent
# seuls (systemd enable), le site revient sans intervention.
cat >/etc/apt/apt.conf.d/51jeiko-unattended <<'APT'
Unattended-Upgrade::Automatic-Reboot "true";
Unattended-Upgrade::Automatic-Reboot-WithUsers "false";
Unattended-Upgrade::Automatic-Reboot-Time "04:20";
Unattended-Upgrade::Remove-Unused-Kernel-Packages "true";
Unattended-Upgrade::Remove-Unused-Dependencies "true";
APT

# needrestart en mode automatique.
#
# En mode interactif — le défaut sur Debian 12 — il ouvre un dialogue plein
# écran demandant quels services redémarrer. Sous unattended-upgrades, ça
# bloque la mise à jour indéfiniment, sans que rien ne l'indique.
if dpkg -s needrestart &>/dev/null; then
    install -d -m 0755 /etc/needrestart/conf.d
    cat >/etc/needrestart/conf.d/99-jeiko.conf <<'NR'
# Redémarrage automatique des services, sans dialogue.
$nrconf{restart} = 'a';
$nrconf{kernelhints} = 0;
NR
    jeiko_ok "needrestart en mode automatique (il bloquait les mises à jour)."
fi

# --------------------------------------------------------------------------- #
# 8) sysctl
# --------------------------------------------------------------------------- #
cat >/etc/sysctl.d/99-jeiko-hardening.conf <<'SYSCTL'
net.ipv4.conf.all.rp_filter = 1
net.ipv4.conf.default.rp_filter = 1
net.ipv4.tcp_syncookies = 1
net.ipv4.conf.all.accept_redirects = 0
net.ipv4.conf.default.accept_redirects = 0
net.ipv4.conf.all.send_redirects = 0
net.ipv4.conf.default.send_redirects = 0
net.ipv4.conf.all.accept_source_route = 0
net.ipv6.conf.all.accept_redirects = 0
net.ipv6.conf.default.accept_redirects = 0
net.ipv4.icmp_echo_ignore_broadcasts = 1
kernel.kptr_restrict = 2
kernel.dmesg_restrict = 1
fs.protected_hardlinks = 1
fs.protected_symlinks = 1
SYSCTL
sysctl --system >/dev/null || true

jeiko_ok "Baseline sécurité appliquée."
