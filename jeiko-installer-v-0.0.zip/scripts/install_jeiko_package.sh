#!/bin/bash

set -e

echo "📦 Installation du package JEIKO..."

# Chemins
PROJECT_DIR="$BASE_DIR/$SITE_NAME"
VENV_DIR="$PROJECT_DIR/venv"
TMP_ZIP="/tmp/jeiko_latest.zip"
ZIP_URL="https://github.com/gderouineau/jeiko/raw/refs/heads/main/jeiko-latest.zip"

# 1. Activer le venv
source "$VENV_DIR/bin/activate"

# 2. Télécharger le zip depuis GitHub (ou autre source)
echo "🔽 Téléchargement du package depuis GitHub..."
curl -L "$ZIP_URL" -o "$TMP_ZIP"

# 3. Extraire le zip dans un dossier temporaire
TMP_EXTRACT="/tmp/jeiko_extracted"
rm -rf "$TMP_EXTRACT"
mkdir -p "$TMP_EXTRACT"

echo "📂 Extraction du zip dans $TMP_EXTRACT..."
unzip -o "$TMP_ZIP" -d "$TMP_EXTRACT"

# 4. Localiser le dossier contenant pyproject.toml (le réel package)
PACKAGE_DIR=$(find "$TMP_EXTRACT" -name "pyproject.toml" -exec dirname {} \; | head -n 1)
if [[ -z "$PACKAGE_DIR" ]]; then
    echo "❌ Impossible de localiser le dossier du package (pyproject.toml manquant)"
    exit 1
fi

# 4.1 Initialiser le dossier dist après avoir trouvé PACKAGE_DIR
DIST_DIR="$PACKAGE_DIR/dist"

# 5. Installer les dépendances du requirements.txt si présent
REQUIREMENTS_FILE=$(find "$TMP_EXTRACT" -name "requirements.txt" | head -n 1)
if [[ -n "$REQUIREMENTS_FILE" ]]; then
    echo "📥 Installation des dépendances depuis $REQUIREMENTS_FILE..."
    pip install -r "$REQUIREMENTS_FILE"
else
    echo "⚠️ Aucun requirements.txt trouvé."
fi

# 6. Installer le module build si nécessaire
if ! python -m build --version &>/dev/null; then
    echo "📚 Installation du module 'build'..."
    pip install --quiet build
else
    echo "📚 Module 'build' déjà disponible."
fi

# 6-1 S'assurer que setuptools est présent
if ! python -c "import setuptools" &>/dev/null; then
    echo "📚 Installation du module 'setuptools'..."
    pip install setuptools
else
    echo "📚 Module 'setuptools' déjà disponible."
fi

# 7. Nettoyer ancien dossier dist s’il existe
echo "🧹 Nettoyage de $DIST_DIR..."
rm -rf "$DIST_DIR"

# 8. Construire le package
echo "🔧 Construction du package JEIKO..."
cd "$PACKAGE_DIR"
python -m build > /dev/null

# 9. Installer le package construit
cd "$DIST_DIR"
WHEEL_FILE=$(ls *.whl 2>/dev/null | head -n 1)
TAR_FILE=$(ls *.tar.gz 2>/dev/null | head -n 1)

if [[ -n "$WHEEL_FILE" ]]; then
    echo "📦 Installation via wheel : $WHEEL_FILE"
    pip install --force-reinstall --no-cache-dir "$DIST_DIR/$WHEEL_FILE"
elif [[ -n "$TAR_FILE" ]]; then
    echo "📦 Installation via archive source : $TAR_FILE"
    pip install --force-reinstall --no-cache-dir "$DIST_DIR/$TAR_FILE"
else
    echo "❌ Aucun package .whl ou .tar.gz trouvé dans $DIST_DIR"
    exit 1
fi

# 10. Déplacement du script de mise à jour s’il est présent dans le dossier des scripts
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
UPDATE_SCRIPT_SRC="$SCRIPT_DIR/update_jeiko.sh"
UPDATE_SCRIPT_DEST="$PROJECT_DIR/update_jeiko.sh"
echo "📍 Script dir: $SCRIPT_DIR"
echo "📍 Expected update script path: $UPDATE_SCRIPT_SRC"
if [[ -f "$UPDATE_SCRIPT_SRC" ]]; then
    echo "📁 Déplacement du script de mise à jour vers $UPDATE_SCRIPT_DEST"
    cp "$UPDATE_SCRIPT_SRC" "$UPDATE_SCRIPT_DEST"
    chmod +x "$UPDATE_SCRIPT_DEST"
    echo "✅ Script update_jeiko.sh installé avec succès."
else
    echo "⚠️ Script update_jeiko.sh introuvable dans $SCRIPT_DIR"
fi

# 11. Nettoyage des fichiers temporaires
echo "🧹 Suppression des fichiers temporaires..."
rm -rf "$TMP_ZIP" "$TMP_EXTRACT"


echo "✅ Package JEIKO installé avec succès."
