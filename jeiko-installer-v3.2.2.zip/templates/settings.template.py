"""
Configuration Django — template JEIKO.

⚠️  Ce fichier est IDENTIQUE sur tous les sites et il est remplacé à chaque
    installation. Ne le personnalise pas : toute la variabilité passe par le
    fichier .env situé à côté. Si un site a besoin d'un réglage particulier,
    ajoute une variable d'environnement et lis-la ici — pas de fork local.
"""

import os
from pathlib import Path

from dotenv import load_dotenv

# ─────────────────────────────────────────────────────────────
# .env
# ─────────────────────────────────────────────────────────────
BASE_DIR = Path(__file__).resolve().parent

dotenv_path = BASE_DIR / ".env"
if dotenv_path.exists():
    load_dotenv(dotenv_path)
else:
    raise RuntimeError(
        f".env introuvable : {dotenv_path}. Le site ne peut pas démarrer sans "
        f"SECRET_KEY ni identifiants de base de données."
    )


def env_bool(name, default=False):
    return os.getenv(name, str(default)).strip().lower() in ("1", "true", "yes", "on")


# ─────────────────────────────────────────────────────────────
# Paramètres principaux
# ─────────────────────────────────────────────────────────────
SECRET_KEY = os.getenv("SECRET_KEY")
if not SECRET_KEY:
    # Une valeur par défaut « insecure-default » rendait un site silencieusement
    # vulnérable (signatures de session forgeables) sans jamais lever d'erreur.
    raise RuntimeError("SECRET_KEY absente du .env.")

DEBUG = env_bool("DEBUG", False)

SITE_NAME = os.getenv("JEIKO_SITE_NAME", BASE_DIR.name)
domain = os.getenv("DOMAIN_NAME", "").strip().lower()

ALLOWED_HOSTS = ["127.0.0.1", "localhost"]
if domain:
    ALLOWED_HOSTS += [domain, f".{domain}"]

# Derrière Nginx : c'est ce couple qui permet à Django de savoir que la requête
# d'origine était en HTTPS. Nginx doit impérativement écraser cet en-tête
# (proxy_set_header X-Forwarded-Proto $scheme), sinon un client peut le forger.
SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")
USE_X_FORWARDED_HOST = True

# L'application est servie par gunicorn sur une SOCKET UNIX (voir
# scripts/11_configure_nginx.sh : proxy_pass http://unix:…). Sur une socket,
# il n'y a pas d'adresse distante : `REMOTE_ADDR` arrive vide, et JEIKO n'a
# donc AUCUNE adresse de client s'il ne lit pas les en-têtes du proxy.
#
# Les conséquences n'étaient pas théoriques :
#   * le journal des appels d'agents restait vide — l'adresse « unknown » est
#     refusée par le type `inet` de PostgreSQL, et l'écriture échouait en
#     silence ;
#   * toutes les limites par IP (formulaires, réservations, agents) tombaient
#     dans un seul et même compteur : un visiteur abusif épuisait le quota de
#     tous les autres ;
#   * la liste d'IP autorisées d'un agent ne pouvait jamais correspondre.
#
# Faire confiance aux en-têtes du proxy n'est sûr QUE si gunicorn n'est
# joignable que par nginx — c'est le cas ici : il n'écoute que la socket.
# JEIKO lit `X-Real-IP`, que nginx ÉCRASE avec l'adresse qu'il voit, puis à
# défaut le DERNIER élément de `X-Forwarded-For`. Pas le premier : nginx pose
# `$proxy_add_x_forwarded_for`, qui AJOUTE son adresse à ce que le client a
# envoyé — le premier élément est celui du client, donc forgeable (rapport
# Fable 1, §1.2). Un déploiement qui exposerait gunicorn directement doit
# repasser ce réglage à False.
JEIKO_TRUST_X_FORWARDED_FOR = env_bool("JEIKO_TRUST_X_FORWARDED_FOR", True)

# ─────────────────────────────────────────────────────────────
# Plafonds de l'API des agents
#
# Le défaut du site. Chaque agent peut porter le sien, réglé sur sa fiche —
# c'est le bon endroit, parce que construire un site et l'entretenir n'ont pas
# le même coût : monter une dizaine de pages demande plusieurs centaines
# d'appels, chaque bloc en coûtant deux ou trois.
#
# `echecs_ip` compte les jetons INVALIDES par adresse : c'est lui qui arrête
# quelqu'un qui en essaie au hasard. Le relever affaiblit cette garde ; le
# plafond par jeton, lui, ne protège que d'un emballement.
# ─────────────────────────────────────────────────────────────
JEIKO_AGENTS_LIMITS = {
    "jeton": (int(os.getenv("JEIKO_AGENTS_APPELS_PAR_HEURE", "600")), 3600),
    "echecs_ip": (int(os.getenv("JEIKO_AGENTS_ECHECS_PAR_IP", "20")), 900),
}

# ─────────────────────────────────────────────────────────────
# Applications
# ─────────────────────────────────────────────────────────────
INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.sites",
    "django.contrib.staticfiles",

    # JEIKO
    "jeiko",
    "jeiko.administration",
    "jeiko.administration_menu",
    "jeiko.administration_pages",
    "jeiko.agents",
    "jeiko.calendars",
    "jeiko.cookies",
    "jeiko.courses",
    "jeiko.custom_objects",
    "jeiko.emailing",
    "jeiko.payments",
    "jeiko.questionnaires_expert",
    "jeiko.shop",
    "jeiko.stats",
    "jeiko.users",

    # Authentification
    "allauth",
    "allauth.account",
    "allauth.mfa",
    "allauth.socialaccount",
    "allauth.socialaccount.providers.google",
    "allauth.socialaccount.providers.apple",
    "allauth.socialaccount.providers.facebook",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    # APRÈS la session, AVANT CommonMiddleware : l'ordre est imposé par Django.
    # La session porte la langue choisie par l'utilisateur ; CommonMiddleware
    # peut rediriger, et le ferait vers la mauvaise langue s'il passait avant.
    "django.middleware.locale.LocaleMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    # APRÈS l'authentification : la préférence de langue vit sur le
    # compte, et `request.user` n'existe pas avant.
    "jeiko.i18n.LangueDeLAdministrationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
    "allauth.account.middleware.AccountMiddleware",
    "jeiko.stats.middleware.PageViewCounterMiddleware",
]

ROOT_URLCONF = f"{BASE_DIR.name}.urls"
WSGI_APPLICATION = f"{BASE_DIR.name}.wsgi.application"
SITE_ID = 1
# Aucune page du site ne peut être encadrée — pas même par le site lui-même.
# C'est la parade au détournement de clic : une page tierce ne peut pas
# superposer un cadre invisible du site sous le curseur du visiteur.
#
# Le réglage était à "SAMEORIGIN" pour un seul besoin : les deux écrans
# d'aperçu d'e-mail, qui affichent le rendu dans une iframe interne. Une
# exception globale pour deux écrans laissait toutes les autres pages
# encadrables. Ces deux vues portent désormais `xframe_options_sameorigin`
# (jeiko/emailing/views/admin.py) et sont les seules à y déroger.
X_FRAME_OPTIONS = "DENY"

# ─────────────────────────────────────────────────────────────
# Cache
# ─────────────────────────────────────────────────────────────
CACHES = {
    "default": {
        # pymemcache et non pylibmc : ce dernier est une extension C qui n'a pas
        # suivi les évolutions de l'API C de CPython. Sous Python 3.13 (Debian
        # 13) son client ne s'instancie plus — « Exception ignored in
        # PyMapping_HasKeyString » puis servers=None — et toute page touchant au
        # cache renvoie une 500. pymemcache est du pur Python : rien à compiler,
        # rien à casser au prochain changement de version de Python.
        #
        # `CacheDuSite` et non `PyMemcacheCache` directement : le `clear()` de
        # ce dernier envoie `flush_all`, qui vide le memcached de TOUS les
        # sites de la machine, compteurs anti-abus compris (rapport Fable 1,
        # §1.7). Celui-ci change de génération, pour ce site seulement.
        "BACKEND": "jeiko.cache.CacheDuSite",
        "LOCATION": "127.0.0.1:11211",
        # Le préfixe évite que deux sites de la même machine se lisent
        # mutuellement leurs entrées de cache.
        "KEY_PREFIX": domain or SITE_NAME,
        "TIMEOUT": 600,
        "OPTIONS": {
            # Un memcached arrêté ou saturé ne doit pas mettre le site à terre :
            # le cache devient inopérant, les pages sont simplement recalculées.
            "ignore_exc": True,
            "no_delay": True,
        },
    },
    # Cache dédié au rate-limiting (jeiko.throttling). Le préfixe distinct
    # isole les compteurs anti-abus du cache de contenu : vider le contenu
    # (vue « vider le cache », mise à jour) ne les remet pas à zéro — ce qui
    # n'est vrai que parce que ce vidage ne passe plus par `flush_all`.
    # On garde ignore_exc=True : un memcached indisponible ne doit pas faire
    # planter le tunnel de réservation (la limitation devient simplement
    # inopérante, comportement identique à avant ce cache dédié).
    "jeiko_throttle": {
        "BACKEND": "jeiko.cache.CacheDuSite",
        "LOCATION": "127.0.0.1:11211",
        "KEY_PREFIX": f"{domain or SITE_NAME}:throttle",
        "TIMEOUT": 3600,
        "OPTIONS": {
            "ignore_exc": True,
            "no_delay": True,
        },
    },
}

# ─────────────────────────────────────────────────────────────
# Templates
# ─────────────────────────────────────────────────────────────
TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.template.context_processors.i18n",
                "django.template.context_processors.media",
                "django.template.context_processors.static",
                "django.template.context_processors.tz",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

# ─────────────────────────────────────────────────────────────
# Base de données
# ─────────────────────────────────────────────────────────────
DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.postgresql",
        "NAME": os.getenv("DB_NAME"),
        "USER": os.getenv("DB_USER"),
        "PASSWORD": os.getenv("DB_PASS"),
        "HOST": "127.0.0.1",
        "PORT": "5432",
        # Garde les connexions ouvertes 60 s : sur un site à trafic modéré, la
        # reconnexion à chaque requête coûte plus cher que tout le reste.
        "CONN_MAX_AGE": 60,
    }
}

# ─────────────────────────────────────────────────────────────
# Authentification
# ─────────────────────────────────────────────────────────────
AUTHENTICATION_BACKENDS = [
    "django.contrib.auth.backends.ModelBackend",
    "jeiko.users.auth_backends.RolePermissionBackend",
    "allauth.account.auth_backends.AuthenticationBackend",
]

LOGIN_REDIRECT_URL = "/"
LOGOUT_REDIRECT_URL = "/"

# django-allauth 65.x a remplacé trois réglages par deux, et émet un
# avertissement de dépréciation tant que les anciens sont présents :
#   ACCOUNT_AUTHENTICATION_METHOD          -> ACCOUNT_LOGIN_METHODS
#   ACCOUNT_EMAIL_REQUIRED + _USERNAME_..  -> ACCOUNT_SIGNUP_FIELDS
# Comportement identique : connexion par identifiant OU adresse, et les quatre
# champs d'inscription obligatoires (l'astérisque marque le caractère requis).
ACCOUNT_LOGIN_METHODS = {"username", "email"}
ACCOUNT_SIGNUP_FIELDS = ["email*", "username*", "password1*", "password2*"]
# L'adresse doit être confirmée avant que le compte serve.
#
# Le réglage était à "none" : n'importe qui pouvait créer un compte avec
# l'adresse d'un tiers, sur un site qui vend et qui ouvre des accès à des
# formations. Rien ne rattachait le compte à quelqu'un de joignable, et les
# e-mails de commande partaient vers une boîte qui n'avait rien demandé.
#
# "mandatory" : allauth envoie un lien de confirmation à l'inscription et
# refuse la connexion tant qu'il n'a pas été suivi. Le mail passe par le
# catalogue éditable (`account_email_verify`, voir users/adapters.py).
#
# Conséquence côté notifications : l'e-mail de bienvenue et l'alerte à
# l'exploitant ne partent plus à l'inscription mais à la CONFIRMATION — voir
# users/signals.py. Souhaiter la bienvenue à un compte qui n'existera peut-être
# jamais n'a pas de sens, et prévenir l'exploitant non plus.
ACCOUNT_EMAIL_VERIFICATION = "mandatory"
ACCOUNT_UNIQUE_EMAIL = True

# L'adaptateur de JEIKO, sans lequel rien de ce qui précède ne tient (S-22).
# C'est lui qui fait partir la confirmation par les réglages SMTP du SITE
# (administration → e-mails), comme l'e-mail de test et le rapport journalier.
# Absent — c'était le cas jusqu'au 28/09/2026 —, allauth passait par la
# connexion globale de Django, sans hôte configuré ici, donc `localhost:25` :
# la confirmation ne partait pas, et l'inscription restait bloquée. Il porte
# aussi le second facteur (`pre_login`) : sans lui, le mot de passe seul
# ouvrait la session (rapport Fable 1, §1.1). `manage.py check` le signale
# s'il manque (jeiko.W003) — avertissement : une erreur bloquerait `migrate`.
ACCOUNT_ADAPTER = "jeiko.users.adapters.JeikoAccountAdapter"

# Double authentification forte (allauth.mfa, 28/09/2026) : application
# d'authentification (TOTP), codes de secours, clés de sécurité et passkeys
# (WebAuthn). Gérée par chaque utilisateur depuis son profil → « Sécurité ».
#
# Elle COEXISTE avec le code par e-mail de JEIKO (users/twofactor.py) : un
# compte qui a activé une méthode allauth.mfa ne reçoit plus le code par
# e-mail — jamais deux seconds facteurs (voir JeikoAccountAdapter.pre_login).
#
# Une passkey est liée au DOMAINE : enregistrée sur un site, elle ne sert pas
# sur un autre. WebAuthn exige HTTPS ; l'origine non sécurisée n'est tolérée
# qu'en développement.
MFA_SUPPORTED_TYPES = ["totp", "recovery_codes", "webauthn"]
MFA_PASSKEY_LOGIN_ENABLED = True
MFA_WEBAUTHN_ALLOW_INSECURE_ORIGIN = DEBUG
MFA_TOTP_ISSUER = SITE_NAME

ACCOUNT_FORMS = {
    "signup": "jeiko.users.forms.CustomSignupForm",
    "login": "jeiko.users.forms.CustomLoginForm",
}

# Les secrets des connexions sociales vivent chiffrés dans l'écran de JEIKO ;
# cet adaptateur les donne à allauth en mémoire, sans copie en clair dans sa
# table (rapport Fable 1, §1.5). Sans lui, les boutons Google/Apple/Facebook
# échouent. `manage.py check` le signale (jeiko.W005).
SOCIALACCOUNT_ADAPTER = "jeiko.users.adapters.JeikoSocialAccountAdapter"

AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator",
     "OPTIONS": {"min_length": 10}},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

# ─────────────────────────────────────────────────────────────
# Localisation
# ─────────────────────────────────────────────────────────────
# ─────────────────────────────────────────────────────────────
# Langues
#
# `LANGUAGE_CODE` est la langue par DÉFAUT du site — celle servie à qui n'a
# rien demandé. Elle se règle par le `.env` : la plupart des sites sont
# monolingues, mais pas forcément en français, et un exploitant hispanophone
# ne doit pas avoir à éditer ce fichier.
#
# `LANGUAGES` borne ce qui est proposé. En ajouter une sans fournir sa
# traduction ne casse rien — Django retombe sur la langue par défaut — mais
# donne un choix qui ne change rien, ce qui déroute plus que ça n'aide.
#
# `LOCALE_PATHS` désigne les traductions du PROJET, chargées avant celles du
# paquet : un exploitant peut donc corriger un libellé sans toucher à JEIKO.
# ─────────────────────────────────────────────────────────────
LANGUAGE_CODE = os.getenv("JEIKO_LANGUAGE", "fr-fr")
TIME_ZONE = os.getenv("JEIKO_TIMEZONE", "Europe/Paris")
USE_I18N = True

LANGUAGES = [
    ("fr", "Français"),
    ("en", "English"),
    ("es", "Español"),
    ("de", "Deutsch"),
]

LOCALE_PATHS = [BASE_DIR / "locale"]
USE_TZ = True

# ─────────────────────────────────────────────────────────────
# Fichiers statiques et médias
# ─────────────────────────────────────────────────────────────
STATIC_URL = "/static/"
MEDIA_URL = "/media/"

STATICFILES_DIRS = [BASE_DIR / "static"]
STATIC_ROOT = BASE_DIR.parent / "staticdir"
MEDIA_ROOT = BASE_DIR.parent / "mediadir"

# Le backend statique minifie le CSS avant d'apposer son empreinte : voir
# jeiko/staticfiles.py. Il remplace les fichiers .min.css maintenus à la main,
# qui avaient pris jusqu'à onze mois de retard sur leurs sources — l'éditeur
# affichait une mise en forme, le site public une autre.
#
# La minification n'a lieu qu'à collectstatic, donc jamais en développement :
# les sources restent lisibles sous DEBUG.
STORAGES = {
    "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
    "staticfiles": {"BACKEND": "jeiko.staticfiles.MinifyingManifestStaticFilesStorage"},
}

# Django applique ces modes explicitement après écriture, indépendamment du
# umask du processus. C'est nécessaire ici : gunicorn tourne avec UMask=0007
# pour que nginx puisse ouvrir son socket, mais on ne veut pas pour autant que
# les fichiers uploadés soient inscriptibles par www-data — une faille dans
# nginx ne doit pas permettre de réécrire les médias du site.
FILE_UPLOAD_PERMISSIONS = 0o640
FILE_UPLOAD_DIRECTORY_PERMISSIONS = 0o2750

# Contenu de formation (vidéos/PDF de cours) servi par Django après contrôle
# des droits, puis délégué à nginx via X-Accel-Redirect. La valeur doit
# correspondre à la location « internal » de la conf nginx
# (11_configure_nginx.sh). Ne PAS servir ces fichiers directement sur /media/ :
# une URL devinée contournerait l'authentification.
COURSES_XACCEL_MEDIA_PREFIX = "/protected-media"

# ─────────────────────────────────────────────────────────────
# Sécurité HTTP
#
# Tout ce bloc est conditionné par JEIKO_SSL. Avec ces réglages actifs sur un
# site servi en HTTP, SECURE_SSL_REDIRECT renvoie une 301 vers une URL https
# qui n'existe pas encore : boucle de redirection et site injoignable.
# ─────────────────────────────────────────────────────────────
# django-allauth ≥ 65.4 limite le débit des vues d'authentification et exige
# pour cela l'IP du client. Gunicorn écoutant sur une socket Unix, REMOTE_ADDR
# est VIDE : sans ce réglage, allauth ne peut pas la déterminer et lève
# PermissionDenied sur CHAQUE POST de connexion. La page s'affiche (le GET
# n'est pas limité) mais plus personne ne peut se connecter, quel que soit le
# compte — panne constatée en production le 15/08/2026 après le passage
# d'allauth 65.3 à 65.19.
#
# Le bug est invisible en développement : runserver reçoit en TCP, donc
# REMOTE_ADDR vaut 127.0.0.1 et allauth est satisfait. Il ne se manifeste que
# derrière gunicorn en socket Unix.
#
# On déclare UN proxy de confiance (nginx), ce qui autorise allauth à lire la
# dernière adresse de X-Forwarded-For — en-tête posé par
# « proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for » dans les
# blocs de 11_configure_nginx.sh.
#
# ⚠️ Ne PAS utiliser ALLAUTH_TRUSTED_CLIENT_IP_HEADER = "X-Real-IP" à la place :
# essayé en production, l'en-tête n'atteignait pas Django et le 403 persistait,
# alors que X-Forwarded-For fonctionne. Le réglage ci-dessous prime de toute
# façon sur l'autre s'ils sont tous deux définis.
ALLAUTH_TRUSTED_PROXY_COUNT = 1

JEIKO_SSL = env_bool("JEIKO_SSL", False)

SECURE_SSL_REDIRECT = JEIKO_SSL
SESSION_COOKIE_SECURE = JEIKO_SSL
CSRF_COOKIE_SECURE = JEIKO_SSL
SECURE_HSTS_SECONDS = 31536000 if JEIKO_SSL else 0
SECURE_HSTS_INCLUDE_SUBDOMAINS = JEIKO_SSL
SECURE_HSTS_PRELOAD = JEIKO_SSL

SECURE_CONTENT_TYPE_NOSNIFF = True
SECURE_REFERRER_POLICY = "strict-origin-when-cross-origin"
SESSION_COOKIE_HTTPONLY = True
CSRF_COOKIE_HTTPONLY = False  # lu par le JS de l'admin pour les requêtes AJAX
SESSION_COOKIE_SAMESITE = "Lax"
CSRF_COOKIE_SAMESITE = "Lax"

CSRF_TRUSTED_ORIGINS = []
if domain:
    scheme = "https" if JEIKO_SSL else "http"
    CSRF_TRUSTED_ORIGINS.append(f"{scheme}://{domain}")
    # Le vhost www n'existe que pour un domaine apex ; l'ajouter pour un
    # sous-domaine produisait une origine du type https://www.admin.site.fr.
    if domain.count(".") == 1:
        CSRF_TRUSTED_ORIGINS.append(f"{scheme}://www.{domain}")

# ─────────────────────────────────────────────────────────────
# Journalisation
#
# Sans cette configuration, une exception en production n'apparaissait nulle
# part ailleurs que dans le log d'erreur de gunicorn, sans contexte.
# ─────────────────────────────────────────────────────────────
LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "verbose": {"format": "[{asctime}] {levelname} {name} {message}", "style": "{"},
    },
    "handlers": {
        "console": {"class": "logging.StreamHandler", "formatter": "verbose"},
        "file": {
            "class": "logging.handlers.RotatingFileHandler",
            "filename": str(BASE_DIR.parent / "logs" / "django.log"),
            "maxBytes": 10 * 1024 * 1024,
            "backupCount": 5,
            "formatter": "verbose",
        },
    },
    "root": {"handlers": ["console", "file"], "level": "INFO"},
    "loggers": {
        "django.request": {"handlers": ["console", "file"], "level": "ERROR", "propagate": False},
        "jeiko": {"handlers": ["console", "file"], "level": "INFO", "propagate": False},
    },
}

# ─────────────────────────────────────────────────────────────
# Divers JEIKO
# ─────────────────────────────────────────────────────────────
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"
EMAIL_BACKEND = "django.core.mail.backends.smtp.EmailBackend"

# Taille maximale d'un upload en mémoire avant bascule sur disque. Doit rester
# cohérent avec client_max_body_size dans le vhost nginx (25 Mo).
DATA_UPLOAD_MAX_MEMORY_SIZE = 25 * 1024 * 1024
FILE_UPLOAD_MAX_MEMORY_SIZE = 5 * 1024 * 1024

GUNICORN_SOCKET = os.getenv("GUNICORN_SOCKET")
JEIKO_IMAGES_ASYNC = True

# Assainissement du HTML saisi dans l'administration (jeiko/sanitize.py).
# À True, la mise en forme est conservée mais <script>, les attributs on* et
# les URL javascript: sont retirés. Ne passer à False que si les seuls
# rédacteurs sont de confiance et qu'aucun rôle n'est délégué à un tiers.
JEIKO_SANITIZE_HTML = env_bool("JEIKO_SANITIZE_HTML", True)

# ─────────────────────────────────────────────────────────────
# Chiffrement des secrets stockés en base
# ─────────────────────────────────────────────────────────────
# Clé secrète Stripe, secret de webhook, mot de passe SMTP, secret OAuth,
# identifiants des fournisseurs vidéo : tous étaient stockés en clair. Une
# lecture de la base — sauvegarde égarée, disque de VPS revendu, accès en
# lecture seule — livrait de quoi émettre des remboursements et envoyer du
# courrier signé du domaine.
#
# La clé de chiffrement est dérivée de SECRET_KEY (PBKDF2), qui vit dans le
# .env en 0600 et JAMAIS dans la base : c'est ce qui rend un dump volé
# inexploitable seul. Le sel est dérivé de SECRET_KEY à défaut d'être fourni,
# pour ne pas imposer une nouvelle clé .env obligatoire aux sites existants —
# il reste ainsi propre à chaque site sans rien casser.
#
# ⚠️ Changer SECRET_KEY rend les secrets chiffrés ILLISIBLES. En cas de
# rotation, renseigner l'ancienne valeur dans SECRET_KEY_FALLBACKS le temps de
# réenregistrer les écrans concernés (la bibliothèque essaie chaque clé).
SALT_KEY = os.getenv("JEIKO_SALT_KEY") or SECRET_KEY[:32]

# Déclencher une mise à jour applique des migrations et redémarre le site :
# c'est plus lourd que « modifier les réglages », avec quoi cette action
# partageait sa permission. Réservé aux superutilisateurs par défaut.
JEIKO_UPDATE_REQUIRES_SUPERUSER = env_bool("JEIKO_UPDATE_REQUIRES_SUPERUSER", True)

JEIKO_RESERVED_ROOT_SLUGS = {
    "administration",
    "accounts",
    "api",
    "users",
    "pass-test",
    "jeiko",
    "robots.txt",
    "sitemap.xml",
    # Connecteur MCP par OAuth (P-04) : /oauth/… et /.well-known/oauth-….
    "oauth",
    ".well-known",
}

# Statistiques
ADMIN_URL = "/admin/"
STATS_ENABLE_DWELL = True
STATS_IGNORE_PATH_PREFIXES = [
    "/static/", "/media/", "/favicon.ico", "/robots.txt",
    "/stats/",
]
