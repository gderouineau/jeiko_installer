# JEIKO — TODO / évolutions

Fonctionnalités à venir. Convention de statut : `[ ]` à faire · `[~]` en cours · `[x]` fait.

---

## [ ] MAJ-1 — Notification quotidienne de mise à jour disponible

**But** : détecter chaque jour si une version de `jeiko` **supérieure** à celle
installée a été publiée, et l'annoncer dans le *quick admin menu* par un lien
« Mise à jour en attente » (ex. « Mise à jour 1 ») qui renvoie vers la page de
mise à jour de l'administration. Le message disparaît une fois la mise à jour
réussie.

### Pourquoi passer par un cron (et pas un check à chaque requête)
Le canal de publication est distant (`version.json` sur
`raw.githubusercontent.com/gderouineau/jeiko`). Interroger le réseau à chaque
chargement de page serait lent et exposé au rate-limiting. On respecte aussi la
frontière de privilèges existante : **l'application ne fait pas d'appel réseau
sortant**. Un job root écrit le résultat dans un fichier d'état (comme
`update.state`), l'app le lit en local, sans coût ni droit particulier.

### Points d'ancrage existants (à réutiliser, ne pas réécrire)
- Version installée : `_jeiko_installed_version()` — `administration/views.py`
  (`importlib.metadata.version("jeiko")`).
- État de mise à jour : `_jeiko_update_state(site)` — lit
  `/var/lib/jeiko/<site>/update.state` (écrit par `jeiko-client-update`, root,
  non falsifiable par le site). Statuts déjà gérés : `idle` / `unknown` / …
- Version publiée : `jeiko_read_manifest` (`lib/jeiko-common.sh`) lit
  `version.json` sur `JEIKO_CHANNEL_URL`
  (défaut `JEIKO_DEFAULT_CHANNEL_URL`) → `JEIKO_PKG_VERSION`.
- Emplacement du badge : `templates/includes/quick_admin_menu.html`.
- Page cible du lien : la vue de mise à jour de l'administration
  (`administration/views.py`, autour de `JEIKO_CLIENT_UPDATER` /
  `_jeiko_update_state`) — reprendre son nom d'URL réel.

### Sous-tâches

- [ ] **Cron/timer côté serveur** (installeur). Ajouter un script d'étape +
  une unité systemd `timer` quotidienne (modèle : `scripts/13_backups.sh` et les
  unités `jeiko-update@`). Le job, en root :
  1. lit la version installée du site,
  2. `jeiko_read_manifest` sur le canal pour la version publiée,
  3. écrit `/var/lib/jeiko/<site>/update.available` (root, groupe du site, `0640`)
     avec `{ "latest": "<x.y.z>", "checked_at": "<iso>" }`.
  Déployé/convergé par `jeiko-server-update` (ajouter une étape), et déposé par
  `migrate_site.sh --tools-only`. Idempotent, échec réseau silencieux (dégrade,
  ne casse pas).

- [ ] **Lecture côté package.** Fonction `_jeiko_update_available(site)` qui lit
  `update.available` façon `_jeiko_update_state` (tolérante aux
  `FileNotFoundError` / `PermissionError`). Exposer au template via context
  processor ou tag, en réutilisant `_jeiko_site_name()`.

- [ ] **Badge dans le quick admin menu.** Dans `quick_admin_menu.html`, si
  `latest` > version installée (comparaison **sémantique**, pas lexicale : « 3.0.10 »
  > « 3.0.9 »), afficher un `<li>` « Mise à jour en attente » (compteur possible)
  pointant vers la page de mise à jour. N'afficher qu'aux comptes ayant le droit
  de lancer la mise à jour.

- [ ] **Disparition automatique.** Le badge est **dérivé** de
  `latest > installée` : après un `jeiko-client-update` réussi, la version
  installée rejoint `latest` → le badge s'efface sans action explicite. Gérer en
  plus l'état transitoire : si `_jeiko_update_state` est « en cours », afficher
  « Mise à jour en cours… » plutôt que le lien.

### Critères d'acceptation
1. Une version publiée supérieure fait apparaître le lien dans les 24 h (ou
   immédiatement après un passage manuel du cron).
2. Le lien mène à la page de mise à jour de l'administration.
3. Après une mise à jour réussie, le message disparaît de lui-même.
4. Aucun appel réseau depuis le processus web ; panne réseau du cron = pas de
   message, jamais d'erreur 500.
5. Le site ne peut pas se déclarer « à jour » en falsifiant un fichier
   (fichier d'état root, lecture seule pour le site).

---

# Défauts relevés en production — migration de `ah_new` (15/08/2026)

Première migration d'un site en production vers le schéma v3. Elle a provoqué
**deux interruptions de service** et une mise à jour en échec. Tout est
consigné ici : `ah_pro` rencontrera les mêmes pièges à l'identique.

Statut : `[x]` corrigé dans `Art/INSTALLER` · `[ ]` à faire.

## Ceux qui ont causé ou aggravé une panne

### [x] BUG-1 — Les logs préexistants ne sont pas réattribués → gunicorn refuse de démarrer
`scripts/10_configure_gunicorn.sh`

`install -d -m 0750 -o "$SITE_USER" -g www-data "$LOG_DIR"` corrige le
**dossier** mais pas les fichiers qu'il contient. Sur `ah_new`, `access.log` et
`error.log` appartenaient à `www-data` en `0644` alors que le nouveau service
tourne sous `debian` : `PermissionError` sur `error.log`, gunicorn sort
immédiatement. **Le site est tombé.**

Correctif : `chown -R "$SITE_USER":www-data "$LOG_DIR"` et `chmod 0640` sur les
fichiers, après le `install -d`. Concerne tout site migré dont les logs
préexistent — donc tous.

### [x] BUG-2 — Le rollback ne restaure pas le `.socket` qu'il vient de supprimer
`scripts/10_configure_gunicorn.sh` + `updater/jeiko-server-update` [1/8]

L'étape 10 supprime `gunicorn-<site>.socket` (nettoyage d'une socket-activation
héritée), mais la sauvegarde `[1/8]` ne couvre que le `.service`, le sudoers, le
vhost et le `.env`. Quand l'étape échoue, le rollback restaure un `.service` qui
réclame une socket désormais inexistante : `Failed to schedule restart job`.
**C'est ce qui a transformé un échec de convergence en panne réelle.**

Correctif : sauvegarder `*.socket` dans `[1/8]`, et le restaurer avec le
`.service`. Règle générale : un rollback doit restaurer tout ce qu'il détruit.

### [x] BUG-3 — `SITE_USER` non transmis aux scripts 11 et 12
`updater/jeiko-server-update` — **corrigé**

`12_setup_tls_letsencrypt.sh:211` fait
`chown "${SITE_USER:-jeiko-$SITE_NAME}"`. La convergence appelait les scripts 11
et 12 sans passer `SITE_USER` : le repli `jeiko-<site>` s'appliquait, ce compte
n'existe pas sur un site migré, `chown` échouait, `set -e` sortait, et **tout le
bloc nginx était annulé** alors que le vhost venait d'être écrit correctement.
Gunicorn se retrouvait sur la nouvelle socket et nginx sur l'ancienne → **502**.

### [x] BUG-4 — Vhost en doublon non détecté
`scripts/11_configure_nginx.sh`

Le script écrit `sites-available/<site>.conf` et l'active en
`sites-enabled/<site>.conf`, sans vérifier qu'un vhost servant le **même
`server_name`** existe déjà. Sur `ah_new`, un fichier `sites-enabled/ah_new`
(sans extension, non symbolique) subsistait, pointait sur l'ancienne socket, et
primait en ordre ASCII sur `ah_new.conf`. Résultat : **502 pour les visiteurs**,
alors que `nginx -t` ne produisait qu'un avertissement `conflicting server name`
et que le contrôle `[8/8]` affichait « ✅ Le site répond (HTTP 200) », puisqu'il
teste le backend et non le trafic public.

Correctif : détecter les `server_name` en conflit (`nginx -T`), refuser ou
signaler bruyamment, et faire porter le contrôle final sur l'URL publique.

### [x] BUG-5 — Le wheel de secours n'est pas vérifié avant la mise à jour
`updater/jeiko-client-update`

Le rollback réinstalle `/var/lib/jeiko/<site>/wheels/<précédent>.whl`. Sur un
site migré, ce fichier n'existe pas (l'ancien mécanisme ne l'y déposait pas) :

    ERROR: Could not install packages due to an OSError: [Errno 13]
    Permission denied: '.../jeiko-3.0.5-py3-none-any.whl'

La base a été restaurée mais **le paquet est resté en version neuve** : code
récent sur schéma ancien, l'état le plus incohérent possible. Le script promet
un filet de sécurité qu'il n'a pas, et ne s'en aperçoit qu'au pire moment.

Correctif : vérifier présence **et** lisibilité du wheel de secours **avant**
d'installer quoi que ce soit ; refuser de démarrer sinon, `--force` pour
outrepasser en connaissance de cause.

### [x] BUG-6 — Le cache n'est pas purgé après changement de version
`updater/jeiko-client-update`

La 3.0.5 mettait en cache une **instance** `Menu` ; la 3.1.0 n'y met que son
`pk`, sous la même clé. Après mise à jour, le nouveau code relit l'ancienne
valeur et lève
`TypeError: Field 'id' expected a number but got <Menu: Principal>` :
**site entier en 500**, alors que code, base et configuration étaient corrects.

Correctif : purger le cache après installation du paquet et **avant** le
contrôle de santé. Plus fin et sans purge partagée : intégrer la version du
paquet dans `KEY_PREFIX`, ce qui invalide naturellement à chaque montée.
C'est probablement le correctif le plus rentable de cette liste — il aurait à
lui seul évité l'échec de la mise à jour.

### [x] BUG-7 — Le rollback de base laisse les tables créées par les migrations
`updater/jeiko-client-update`

La restauration utilise `pg_restore --clean --if-exists`, qui ne supprime que
les objets **présents dans le dump**. Les tables créées par les migrations de la
version neuve (`administration_socialprovider`, `administration_favicon`,
`users_adminpermission`) survivent, tandis que `django_migrations` revient en
arrière. `migrate` échoue alors sur `DuplicateTable` et **la base ne peut plus
avancer** sans intervention manuelle.

Correctif : restaurer dans un schéma vide (`DROP SCHEMA public CASCADE` puis
restauration), ou redescendre les migrations (`migrate <app> <précédente>`)
avant de restaurer les données.

## Configuration manquante

### [x] CONF-1 — `ALLAUTH_TRUSTED_PROXY_COUNT` absent → connexion impossible
`templates/settings.template.py` — **corrigé**

django-allauth ≥ 65.4 limite le débit des vues d'authentification et exige l'IP
du client. Gunicorn écoutant sur une socket Unix, `REMOTE_ADDR` est vide :
allauth lève `PermissionDenied` sur **chaque POST** de connexion. La page
s'affiche (le GET n'est pas limité) mais **plus personne ne peut se connecter**,
quel que soit le compte.

Invisible en développement (runserver reçoit en TCP, `REMOTE_ADDR=127.0.0.1`).
Apparu au passage d'allauth 65.3 → 65.19 pendant la mise à jour.

⚠️ `ALLAUTH_TRUSTED_CLIENT_IP_HEADER = "X-Real-IP"` a été essayé sans succès en
production ; c'est `ALLAUTH_TRUSTED_PROXY_COUNT = 1` (lecture de
`X-Forwarded-For`) qui fonctionne.

## Contrôles trop permissifs

### [x] CTRL-1 — Le contrôle `[8/8]` ne teste qu'un `GET`
`updater/jeiko-server-update`

Il a affiché « ✅ Le site répond (HTTP 200) » et « ✅ L'interface
d'administration peut déclencher la mise à jour » alors que, simultanément, les
visiteurs recevaient des 502 (BUG-4) et que personne ne pouvait se connecter
(CONF-1). Le test sudo est lancé depuis le shell **root** de la convergence, pas
depuis le cgroup de gunicorn : il ne valide donc jamais le vrai chemin (BUG-8).

Correctif : contrôler l'**URL publique**, et vérifier qu'un `POST` sur la page
de connexion aboutit. Ces deux ajouts auraient détecté les deux pannes
immédiatement, et déclenché le rollback.

### [x] BUG-8 — `NoNewPrivileges` réactivé par implication
`scripts/10_configure_gunicorn.sh` — **corrigé**

L'unité posait `NoNewPrivileges=no` avec un commentaire expliquant que c'était
délibéré (sudo est setuid), puis `ProtectKernelTunables=`,
`ProtectKernelModules=`, `RestrictSUIDSGID=` et `LockPersonality=` — quatre
options qui, d'après systemd.exec(5), **impliquent** `NoNewPrivileges=yes`.
L'implication l'emportait, et la mise à jour depuis l'administration échouait
avec « the "no new privileges" flag is set ».

Piste de fond : ne plus dépendre de `sudo` depuis le processus web. L'appli
déposerait un jeton dans un dossier surveillé par une unité `systemd.path`, et
le service resterait pleinement durci.

## Points mineurs

### [x] MIN-1 — `HOME` non défini dans l'unité gunicorn
`[ERROR] Control server error: [Errno 13] Permission denied: '/home/debian'` à
chaque démarrage (gunicorn 26 + `ProtectHome=yes`). Sans conséquence, mais
pollue les logs. Ajouter `Environment=HOME=$PROJECT_DIR`.

### [ ] MIN-2 — `HEAD` sur les pages de connexion renvoie 403
`GET /accounts/login/` → 200, `HEAD` → 403. Sans effet pour les navigateurs,
mais la plupart des sondes de disponibilité interrogent en `HEAD` et
signaleraient la page comme cassée.

### [x] MIN-3 — `migrate_site.sh --dry-run` inutilisable sur un site non enregistré
En simulation la fiche n'est pas écrite, mais le script enchaîne quand même sur
`jeiko-server-update`, qui exige cette fiche : l'essai se termine toujours par
`❌ Fiche de site introuvable`. Le `--dry-run` ne peut donc jamais aboutir dans
le cas précis où il serait le plus utile.

### [ ] MIN-4 — Dépendances non déclarées
`setfacl` absent → « ACL non appliquées » (paquet `acl`). Ajouter au contrôle
des dépendances de l'étape 03.

## Remarque transverse

Le compte de service de `ah_new` est `debian`, c'est-à-dire l'utilisateur SSH
d'administration, détecté par `migrate_site.sh` à partir du propriétaire du
dossier projet. Le modèle d'isolation v2 (« l'application ne peut que déclencher
sa propre mise à jour ») perd alors sa portée : ce compte dispose déjà de `sudo`
complet. Préexistant, sans lien avec la migration, mais à traiter si on veut que
le durcissement ait un sens sur ce site.

---

# État du serveur après la migration de `ah_new`

Site fonctionnel au 15/08/2026 : public en 200, médias de formation protégés
(404 en accès direct), paquet 3.1.0, base à jour, connexion et mise à jour
depuis l'administration opérationnelles.

## Interventions manuelles en place — à ne pas perdre

| Intervention | Emplacement | Survit à une maj ? |
|---|---|---|
| `ALLAUTH_TRUSTED_PROXY_COUNT = 1` | `/var/www/ah_new/ah_new/settings.py` | ❌ **écrasé** par le réalignement du gabarit |
| `ALLAUTH_TRUSTED_CLIENT_IP_HEADER` (commenté, sans effet) | idem | ❌ idem |
| Override systemd (`NoNewPrivileges`) | `/etc/systemd/system/gunicorn-ah_new.service.d/override.conf` | ✅ les drop-ins survivent |
| Permissions des logs corrigées | `/var/log/gunicorn/ah_new/` | ⚠️ à refaire si les logs sont recréés |
| Ancien vhost écarté | déplacé en `/root/vhost-ah_new-ancien-2026-08-15.conf` | ✅ |

⚠️ **Republier l'installeur est impératif** : tant que le gabarit corrigé n'est
pas publié, le prochain `jeiko-client-update` réécrira `settings.py` sans
`ALLAUTH_TRUSTED_PROXY_COUNT` et **recassera la connexion sur tout le site**.

    cd ~/Documents/Projects/packages/jeiko && ./publier-installer.sh

## Reste à faire sur `ah_new`

- [ ] Renseigner les **hash Vimeo** dans l'admin (champ « Hash / clé privée de
      la vidéo »). Les vidéos non listées renvoient 403 sans leur hash ;
      laisser vide pour les vidéos publiques. Commande de listing en section G
      de `AUDIT_COURSES.md`.
- [ ] Remonter **`dev.accompagnementhumain.com`** : le bloc `server` est dans
      `/root/vhost-ah_new-ancien-2026-08-15.conf` et proxifie vers l'ancienne
      socket ; le repointer sur `/run/gunicorn-ah_new/gunicorn.sock`.
- [ ] Adresse e-mail d'expiration du certificat (aucune alerte aujourd'hui).
- [ ] `JEIKO_OFFSITE_TARGET` : les sauvegardes (973 Mo) restent uniquement sur
      la machine.

---

# Avant de migrer `ah_pro`

Il cumule les mêmes conditions que `ah_new` : logs préexistants, socket
historique, vhost possiblement en doublon, même saut d'allauth. Sans
préparation, il subira la **même série de pannes**.

## Ordre recommandé

1. **Publier l'installeur corrigé** (apporte CONF-1, BUG-3, BUG-8 et le blocage
   nginx des médias). Sans cette étape, tout le reste est à refaire à la main.
2. **Corriger au minimum BUG-1, BUG-2 et BUG-5** — ce sont eux qui ont
   transformé des échecs récupérables en interruptions de service.
3. **Contrôles préalables**, avant toute commande :

       ls -la /var/log/gunicorn/ah_pro/            # propriétaire des logs (BUG-1)
       ls -l /etc/systemd/system/gunicorn-ah_pro.* # présence d'un .socket (BUG-2)
       ls -l /etc/nginx/sites-enabled/             # vhost en doublon (BUG-4)
       sudo nginx -T | grep -n server_name         # server_name en conflit
       ls -l /var/lib/jeiko/ah_pro/wheels/         # wheel de secours (BUG-5)

4. **Prendre un dump** avant de commencer.
5. `sudo ./migrate_site.sh ah_pro` puis
   `sudo jeiko-server-update ah_pro --with-client`.
6. **Vérifier la connexion** (`POST` sur la page de connexion), pas seulement
   que la page d'accueil répond — c'est la leçon de CTRL-1.

## Leçon générale

Sur `ah_new`, tous les voyants de la convergence étaient au vert pendant que les
visiteurs recevaient des 502 et que plus personne ne pouvait se connecter. Un
contrôle qui teste le backend depuis la machine, en `GET`, sur la page
d'accueil, ne dit rien de ce que vit un utilisateur. C'est le correctif de fond
à apporter à l'outillage.
