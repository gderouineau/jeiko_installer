# shellcheck shell=bash
###############################################################################
# jeiko-common.sh — fonctions partagées JEIKO
#
# Déployé en /usr/local/lib/jeiko/common.sh (root:root 0644).
# Sourcé par l'installeur ET par /usr/local/sbin/jeiko-update.
#
# ⚠️  Il ne doit exister qu'UN SEUL exemplaire de ce fichier sur la machine.
#     La divergence de permissions entre installation et mise à jour venait
#     précisément d'avoir deux implémentations du même modèle de droits.
#
# Ce fichier ne fait pas `set -euo pipefail` : c'est au script appelant de le
# décider.
###############################################################################

JEIKO_COMMON_VERSION="2.0"

# --------------------------------------------------------------------------- #
# Emplacements canoniques
# --------------------------------------------------------------------------- #
JEIKO_ETC_DIR="/etc/jeiko"
JEIKO_SITES_DIR="$JEIKO_ETC_DIR/sites"     # registre des sites (root:root 0700)
JEIKO_LIB_DIR="/var/lib/jeiko"             # état + cache des wheels
JEIKO_LOG_DIR="/var/log/jeiko"             # logs de mise à jour, par site
JEIKO_BACKUP_DIR="/var/backups/jeiko"      # dumps DB + media
JEIKO_LOCK_DIR="/run/lock"

# Canal de distribution par défaut (surchargeable par site dans sa fiche).
JEIKO_DEFAULT_CHANNEL_URL="https://raw.githubusercontent.com/gderouineau/jeiko/main"

# --------------------------------------------------------------------------- #
# Modèle de permissions canonique
#
#  Répertoires  2750  setgid → le groupe www-data est hérité par tout nouveau
#                     fichier, donc nginx peut lire sans intervention manuelle
#  Fichiers     0640  propriétaire lit/écrit, nginx lit via le groupe,
#                     les autres utilisateurs locaux ne voient rien
#  .env         0600  jamais lisible par le groupe (contient DB_PASS)
#  Exécutables  0750
#
# Le socket gunicorn fait exception : nginx doit pouvoir y ÉCRIRE pour s'y
# connecter, il est donc en 0660 group=www-data (géré par UMask dans l'unité
# systemd). C'est la raison pour laquelle les uploads Django sont, eux, forcés
# explicitement via FILE_UPLOAD_PERMISSIONS dans settings.py plutôt que laissés
# au umask du processus.
# --------------------------------------------------------------------------- #
JEIKO_DIR_MODE="2750"
JEIKO_FILE_MODE="0640"
JEIKO_EXEC_MODE="0750"
JEIKO_SECRET_MODE="0600"

# --------------------------------------------------------------------------- #
# Journalisation
# --------------------------------------------------------------------------- #
jeiko_log()  { printf '%s\n' "$*"; }
jeiko_step() { printf '\n▶ %s\n' "$*"; }
jeiko_ok()   { printf '✅ %s\n' "$*"; }
jeiko_warn() { printf '⚠️  %s\n' "$*" >&2; }
jeiko_err()  { printf '❌ %s\n' "$*" >&2; }
jeiko_die()  { jeiko_err "$*"; exit 1; }

jeiko_require_root() {
    [[ ${EUID:-$(id -u)} -eq 0 ]] || jeiko_die "Cette opération doit être exécutée en root."
}

# --------------------------------------------------------------------------- #
# Validation
#
# Le nom de site sert à construire des noms d'unités systemd, des chemins et
# des entrées sudoers : il doit être strictement contraint. Cette fonction est
# la seule barrière entre une valeur fournie par l'utilisateur et un ExecStart.
# --------------------------------------------------------------------------- #
jeiko_validate_site_name() {
    local name="${1:-}"
    [[ -n "$name" ]] || { jeiko_err "Nom de site vide."; return 1; }
    [[ "$name" =~ ^[a-z0-9][a-z0-9_-]{0,30}$ ]] || {
        jeiko_err "Nom de site invalide : '$name' (minuscules, chiffres, - et _, 31 max, commence par un alphanumérique)."
        return 1
    }
    # Un nom de site devient aussi un nom de paquet Python de projet Django.
    [[ "$name" != *-* ]] || {
        jeiko_err "Nom de site invalide : '$name' contient un tiret, or il sert de nom de module Python (utilise _)."
        return 1
    }
    return 0
}

jeiko_validate_domain() {
    local domain="${1:-}"
    [[ "$domain" =~ ^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$ ]] || {
        jeiko_err "Domaine invalide : '$domain'"
        return 1
    }
    [[ ${#domain} -le 253 ]] || { jeiko_err "Domaine trop long."; return 1; }
    return 0
}

# Un domaine « apex » (exemple.fr) mérite un vhost www ; un sous-domaine non.
jeiko_is_apex() {
    [[ "${1:-}" =~ ^[^.]+\.[^.]+$ ]]
}

# --------------------------------------------------------------------------- #
# Registre des sites
#
# /etc/jeiko/sites/<site>.conf (root:root 0600) est la source de vérité unique
# pour l'updater, les backups et les scripts de maintenance. Il remplace le
# .env.<site> qui traînait dans le dossier de l'installeur en 0644.
# --------------------------------------------------------------------------- #
jeiko_site_conf_path() { printf '%s/%s.conf' "$JEIKO_SITES_DIR" "$1"; }

jeiko_init_dirs() {
    jeiko_require_root
    install -d -m 0755 -o root -g root "$JEIKO_ETC_DIR"
    install -d -m 0700 -o root -g root "$JEIKO_SITES_DIR"

    # 0755 et non 0750 : chaque site doit pouvoir TRAVERSER cette racine pour
    # lire son propre /var/lib/jeiko/<site>/update.state — c'est ce qui alimente
    # la page de mise à jour de son administration. Le cloisonnement est porté
    # par les sous-dossiers, en 0750 root:<compte du site> ; la racine ne
    # contient rien d'autre que des noms de sites.
    # 0750 root:root ici rendait l'état illisible pour TOUS les sites, et
    # « install -d -m » réapplique le mode même à un dossier existant : chaque
    # migrate_site.sh recassait donc les sites déjà en place.
    install -d -m 0755 -o root -g root "$JEIKO_LIB_DIR"
    install -d -m 0755 -o root -g root "$JEIKO_LOG_DIR"
    install -d -m 0700 -o root -g root "$JEIKO_BACKUP_DIR"
}

# Écrit (ou réécrit) la fiche d'un site. Toutes les valeurs sont échappées.
jeiko_write_site_conf() {
    jeiko_require_root
    local site="$1"
    jeiko_validate_site_name "$site" || return 1

    local conf; conf="$(jeiko_site_conf_path "$site")"
    local tmp;  tmp="$(mktemp "${conf}.XXXXXX")"
    chmod 0600 "$tmp"

    {
        echo "# Fiche du site '$site' — générée par l'installeur JEIKO."
        echo "# Source de vérité pour jeiko-update et les sauvegardes. Ne pas éditer à la main"
        echo "# sans relancer 'nginx -t' et 'systemctl restart gunicorn-$site'."
        echo "SITE_NAME=$(jeiko_shell_quote "$site")"
        echo "DOMAIN_NAME=$(jeiko_shell_quote "${DOMAIN_NAME:-}")"
        echo "BASE_DIR=$(jeiko_shell_quote "${BASE_DIR:-}")"
        echo "PROJECT_DIR=$(jeiko_shell_quote "${PROJECT_DIR:-${BASE_DIR:-}/$site}")"
        echo "SITE_USER=$(jeiko_shell_quote "${SITE_USER:-jeiko-$site}")"
        echo "VENV_DIR=$(jeiko_shell_quote "${VENV_DIR:-${BASE_DIR:-}/$site/venv}")"
        echo "GUNICORN_SERVICE=$(jeiko_shell_quote "${GUNICORN_SERVICE:-gunicorn-$site}")"
        echo "DB_NAME=$(jeiko_shell_quote "${DB_NAME:-}")"
        echo "DB_USER=$(jeiko_shell_quote "${DB_USER:-}")"
        echo "DB_PASS=$(jeiko_shell_quote "${DB_PASS:-}")"
        echo "ENABLE_SSL=$(jeiko_shell_quote "${ENABLE_SSL:-n}")"
        echo "ADMIN_SSH_USER=$(jeiko_shell_quote "${ADMIN_SSH_USER:-}")"
        # Canal de distribution : d'où proviennent les mises à jour.
        echo "JEIKO_CHANNEL_URL=$(jeiko_shell_quote "${JEIKO_CHANNEL_URL:-$JEIKO_DEFAULT_CHANNEL_URL}")"
        echo "INSTALLED_AT=$(jeiko_shell_quote "${INSTALLED_AT:-$(date -Is)}")"
        echo ""
        echo "# Copie hors-site des sauvegardes. Vide = désactivée : les"
        echo "# sauvegardes restent alors sur la même machine que le site, et"
        echo "# disparaissent avec lui."
        echo "#   rclone:mon-remote:/jeiko    ou    rsync:user@hote:/sauvegardes"
        echo "JEIKO_OFFSITE_TARGET=$(jeiko_shell_quote "${JEIKO_OFFSITE_TARGET:-}")"
        echo "# Fichier contenant la phrase secrète GPG (root:root 0600). Sans"
        echo "# elle, la base part en clair hors de la machine."
        echo "JEIKO_OFFSITE_PASSPHRASE_FILE=$(jeiko_shell_quote "${JEIKO_OFFSITE_PASSPHRASE_FILE:-}")"
    } >"$tmp"

    mv -f "$tmp" "$conf"
    chown root:root "$conf"
    chmod 0600 "$conf"
}

# Charge une fiche de site dans l'environnement courant.
jeiko_load_site() {
    local site="$1"
    jeiko_validate_site_name "$site" || return 1
    local conf; conf="$(jeiko_site_conf_path "$site")"
    [[ -r "$conf" ]] || {
        jeiko_err "Fiche de site introuvable : $conf"
        jeiko_err "Site jamais installé, ou pas encore migré (voir migrate_site.sh)."
        return 1
    }
    # shellcheck disable=SC1090
    source "$conf"
    : "${PROJECT_DIR:?PROJECT_DIR absent de $conf}"
    : "${SITE_USER:?SITE_USER absent de $conf}"
    : "${VENV_DIR:?VENV_DIR absent de $conf}"
    return 0
}

jeiko_list_sites() {
    [[ -d "$JEIKO_SITES_DIR" ]] || return 0
    find "$JEIKO_SITES_DIR" -maxdepth 1 -name '*.conf' -printf '%f\n' 2>/dev/null \
        | sed 's/\.conf$//' | sort
}

# Quoting sûr pour réinjection dans un fichier sourcé par bash.
#
# Le motif de remplacement passe par des variables plutôt que par une cascade
# d'échappements littéraux : écrite en une seule expression, la substitution
# produisait une chaîne mal formée dès que la valeur contenait une apostrophe —
# un mot de passe PostgreSQL avec une apostrophe rendait la fiche du site
# illisible, donc le site immettable à jour.
jeiko_shell_quote() {
    local s="${1-}"
    local quote="'"
    local escaped="'\\''"
    printf "'%s'" "${s//$quote/$escaped}"
}

# --------------------------------------------------------------------------- #
# Exécution sous l'identité du site
#
# On passe par `runuser -u <user> -- cmd args…` : la commande est exécutée par
# execvp, sans shell intermédiaire. L'ancienne implémentation construisait une
# chaîne injectée dans `bash -s <<EOF`, ce qui exposait chaque variable
# (chemins, URL, nom de site) à une interprétation shell.
# --------------------------------------------------------------------------- #
jeiko_as_site() {
    local user="$1"; shift
    [[ $# -gt 0 ]] || { jeiko_err "jeiko_as_site: aucune commande fournie."; return 2; }
    if command -v runuser >/dev/null 2>&1; then
        runuser -u "$user" -- "$@"
    else
        sudo -n -u "$user" -- "$@"
    fi
}

# Lance manage.py sous l'identité du site, avec le python du venv.
# Usage : jeiko_manage <project_dir> <venv_dir> <site_user> migrate --noinput
jeiko_manage() {
    local project_dir="$1" venv_dir="$2" site_user="$3"; shift 3
    local py="$venv_dir/bin/python"
    [[ -x "$py" ]] || { jeiko_err "Python du venv introuvable : $py"; return 1; }
    # PYTHONNOUSERSITE empêche un ~/.local/lib parasite de masquer le venv.
    jeiko_as_site "$site_user" env \
        PYTHONNOUSERSITE=1 \
        PYTHONUNBUFFERED=1 \
        HOME="$project_dir" \
        "$py" "$project_dir/manage.py" "$@"
}

# --------------------------------------------------------------------------- #
# Permissions — implémentation unique
# --------------------------------------------------------------------------- #

# Applique le modèle canonique à l'arborescence d'un site.
# Le venv est traité à part : ses binaires doivent rester exécutables.
jeiko_fix_perms() {
    jeiko_require_root
    local project_dir="$1" site_user="$2" site_name="$3"
    local venv_dir="${4:-$project_dir/venv}"

    [[ -d "$project_dir" ]] || { jeiko_err "Dossier projet introuvable : $project_dir"; return 1; }

    jeiko_log "🔐 Application des permissions sur $project_dir…"

    local env_path="$project_dir/$site_name/.env"

    # ─────────────────────────────────────────────────────────────────────────
    # Ces commandes s'exécutent en root sur une arborescence dont l'utilisateur
    # du site est propriétaire : il peut y créer des liens symboliques à tout
    # moment. Chaque opération est donc écrite pour ne jamais suivre un lien.
    #
    #   · install -d refuse de travailler sur un lien symbolique, qu'on efface
    #     au préalable — sans ça, un « staticdir » remplacé par un lien vers
    #     /etc aurait fait appliquer le mode au répertoire cible ;
    #   · chown -R reçoit -h, donc il agit sur le lien et jamais sur sa cible ;
    #   · les chmod passent tous par find -type d / -type f, et un lien
    #     symbolique n'est ni l'un ni l'autre : il est ignoré.
    # ─────────────────────────────────────────────────────────────────────────
    local d
    for d in staticdir mediadir logs; do
        if [[ -L "$project_dir/$d" ]]; then
            jeiko_warn "$project_dir/$d est un lien symbolique : remplacé par un vrai répertoire."
            rm -f "$project_dir/$d"
        fi
        install -d -m "$JEIKO_DIR_MODE" "$project_dir/$d"
    done

    chown -Rh "$site_user":www-data "$project_dir"

    # Hors venv : dossiers 2750, fichiers 0640.
    find "$project_dir" -path "$venv_dir" -prune -o -type d -print0 \
        | xargs -0r chmod "$JEIKO_DIR_MODE"
    # Le .env est exclu : il transitait sinon par 0640, donc lisible par
    # www-data, entre ce chmod et la correction en 0600 plus bas. La fenêtre
    # était courte, mais l'invariant est désormais vrai en permanence.
    find "$project_dir" -path "$venv_dir" -prune -o -type f ! -path "$env_path" -print0 \
        | xargs -0r chmod "$JEIKO_FILE_MODE"

    # Venv : lecture/exécution pour le propriétaire et le groupe, rien au-delà.
    if [[ -d "$venv_dir" ]]; then
        find "$venv_dir" -type d -print0 | xargs -0r chmod u=rwx,g=rx,o=
        find "$venv_dir" -type f -print0 | xargs -0r chmod u=rw,g=r,o=
        if [[ -d "$venv_dir/bin" ]]; then
            chmod "$JEIKO_EXEC_MODE" "$venv_dir/bin"
            find "$venv_dir/bin" -maxdepth 1 -type f -print0 | xargs -0r chmod "$JEIKO_EXEC_MODE"
        fi
    fi

    # Exceptions explicites.
    [[ -f "$project_dir/manage.py" ]] && chmod "$JEIKO_EXEC_MODE" "$project_dir/manage.py" || true
    [[ -f "$env_path" ]] && chmod "$JEIKO_SECRET_MODE" "$env_path" || true

    # /var/www doit rester traversable par nginx.
    local base_dir; base_dir="$(dirname "$project_dir")"
    chmod o+x "$base_dir" 2>/dev/null || true

    return 0
}

# Confort SSH : l'administrateur humain peut lire le projet sans sudo.
#
# Aucune ACL « par défaut » (d:u:) n'est posée. La version précédente en
# mettait une sur toute l'arborescence : tout fichier créé ensuite héritait du
# droit de lecture pour l'administrateur, y compris un .env recréé plus tard —
# le mot de passe de la base redevenait lisible sans sudo, en contradiction
# avec le 0600 affiché. Le confort de lecture ne justifiait pas cet écart.
jeiko_apply_admin_acl() {
    local project_dir="$1" admin_user="${2:-}"
    [[ -n "$admin_user" ]] || return 0
    id -u "$admin_user" >/dev/null 2>&1 || return 0
    command -v setfacl >/dev/null 2>&1 || { jeiko_warn "setfacl absent, ACL non appliquées."; return 0; }

    local base_dir; base_dir="$(dirname "$project_dir")"
    local site_name; site_name="$(basename "$project_dir")"

    setfacl -m "u:$admin_user:rx" "$base_dir" 2>/dev/null || true
    setfacl -R -m "u:$admin_user:rX" "$project_dir" 2>/dev/null || true

    # Les secrets restent des secrets, ACL ou pas. L'échec est signalé plutôt
    # que silencieusement avalé : si le retrait ne prend pas, l'administrateur
    # conserve un accès en lecture au mot de passe de la base.
    local env_path="$project_dir/$site_name/.env"
    if [[ -f "$env_path" ]]; then
        if ! setfacl -x "u:$admin_user" "$env_path" 2>/dev/null; then
            jeiko_warn "ACL non retirée de $env_path — vérifier : getfacl $env_path"
        fi
    fi
}

# --------------------------------------------------------------------------- #
# Réseau / intégrité
# --------------------------------------------------------------------------- #

# Télécharge dans un fichier, sans pipe vers un interpréteur.
jeiko_download() {
    local url="$1" dest="$2"
    curl -fsSL --proto '=https' --tlsv1.2 \
         --retry 4 --retry-connrefused --retry-delay 2 \
         --max-time 300 --speed-time 30 --speed-limit 1024 \
         -o "$dest" "$url"
}

# Vérifie un sha256 attendu. C'est le seul garde-fou entre le dépôt distant et
# l'exécution de code sur la machine : ne jamais rendre cet appel optionnel.
jeiko_verify_sha256() {
    local file="$1" expected="$2"
    [[ -s "$file" ]] || { jeiko_err "Fichier vide ou absent : $file"; return 1; }
    [[ "$expected" =~ ^[a-f0-9]{64}$ ]] || { jeiko_err "Empreinte sha256 malformée : '$expected'"; return 1; }

    local actual
    actual="$(sha256sum "$file" | awk '{print $1}')"
    if [[ "$actual" != "$expected" ]]; then
        jeiko_err "Empreinte sha256 incorrecte pour $(basename "$file")."
        jeiko_err "  attendue : $expected"
        jeiko_err "  obtenue  : $actual"
        return 1
    fi
    jeiko_ok "Empreinte sha256 vérifiée ($(basename "$file"))."
    return 0
}

# --------------------------------------------------------------------------- #
# Récupération vérifiée du package JEIKO
#
# Deux fonctions, utilisées par l'installation initiale (script 08) comme par
# jeiko-update. Une seule implémentation, donc pas de chemin « rapide » où le
# sha256 serait contourné — c'est le point où un package altéré entrerait dans
# le système.
# --------------------------------------------------------------------------- #

# Lit version.json et renseigne JEIKO_PKG_VERSION / _WHEEL_NAME / _WHEEL_SHA.
# Ne télécharge pas le package : permet à `--check` de comparer les versions
# sans rapatrier plusieurs mégaoctets.
jeiko_read_manifest() {
    local channel="$1" tmp="$2"

    # Le python SYSTÈME, jamais celui du venv : ce dernier appartient à
    # l'utilisateur du site, et l'exécuter en root lui rendrait précisément les
    # privilèges qu'on cherche à lui retirer.
    local system_py; system_py="$(command -v python3 || true)"
    [[ -x "$system_py" ]] || { jeiko_err "python3 système introuvable."; return 1; }

    local manifest="$tmp/version.json"
    jeiko_download "$channel/version.json" "$manifest" || {
        jeiko_err "version.json introuvable sur $channel"
        jeiko_err "Génère-le depuis le dépôt jeiko avec : ./release.sh <version>"
        return 1
    }

    local version wheel sha
    read -r version wheel sha < <("$system_py" - "$manifest" <<'PY'
import json, sys
try:
    d = json.load(open(sys.argv[1], encoding="utf-8"))
except (OSError, ValueError):
    d = {}
print(d.get("version", ""), d.get("wheel", ""), d.get("sha256", ""))
PY
)

    [[ -n "$version" && -n "$wheel" && -n "$sha" ]] || {
        jeiko_err "Manifeste incomplet ou illisible : version, wheel et sha256 sont requis."
        return 1
    }
    # Le nom du wheel provient du réseau et sert à construire un chemin local :
    # sans ce bornage, un manifeste hostile écrirait où il veut sur le disque.
    [[ "$wheel" =~ ^[A-Za-z0-9._+-]+\.whl$ ]] || {
        jeiko_err "Nom de wheel refusé : '$wheel'"
        return 1
    }

    JEIKO_PKG_VERSION="$version"
    JEIKO_PKG_WHEEL_NAME="$wheel"
    JEIKO_PKG_WHEEL_SHA="$sha"
    return 0
}

# Télécharge le wheel décrit par le manifeste et vérifie son empreinte.
# Renseigne JEIKO_PKG_WHEEL (chemin local). À appeler après jeiko_read_manifest.
jeiko_fetch_wheel() {
    local channel="$1" tmp="$2"
    : "${JEIKO_PKG_WHEEL_NAME:?jeiko_read_manifest doit être appelé avant}"

    local dest="$tmp/$JEIKO_PKG_WHEEL_NAME"
    jeiko_download "$channel/dist/$JEIKO_PKG_WHEEL_NAME" "$dest" \
        || { jeiko_err "Téléchargement du wheel impossible."; return 1; }
    jeiko_verify_sha256 "$dest" "$JEIKO_PKG_WHEEL_SHA" || return 1

    JEIKO_PKG_WHEEL="$dest"
    return 0
}

# Enchaînement des deux, pour l'installation initiale.
jeiko_fetch_package() {
    jeiko_read_manifest "$1" "$2" && jeiko_fetch_wheel "$1" "$2"
}

# --------------------------------------------------------------------------- #
# Chemin de systemctl
#
# La règle sudoers et la commande émise par la vue Django doivent correspondre
# AU CARACTÈRE PRÈS : sudo compare la ligne de commande complète, pas seulement
# le binaire. /bin/systemctl et /usr/bin/systemctl désignent le même fichier sur
# Debian (usrmerge) mais sont deux chaînes différentes pour sudo.
# On fige donc /usr/bin/systemctl des deux côtés.
# --------------------------------------------------------------------------- #
JEIKO_SYSTEMCTL="/usr/bin/systemctl"

jeiko_require_systemctl_path() {
    if [[ ! -x "$JEIKO_SYSTEMCTL" ]]; then
        local found; found="$(command -v systemctl || true)"
        jeiko_err "systemctl attendu en $JEIKO_SYSTEMCTL, trouvé : ${found:-nulle part}."
        jeiko_err "La règle sudoers et la vue Django doivent viser le même chemin."
        return 1
    fi
    return 0
}

# --------------------------------------------------------------------------- #
# systemd
# --------------------------------------------------------------------------- #
jeiko_unit_exists() {
    systemctl list-unit-files "$1" >/dev/null 2>&1 && \
    systemctl list-unit-files --no-legend "$1" | grep -q .
}

jeiko_restart_if_exists() {
    local unit="$1"
    if jeiko_unit_exists "$unit"; then
        jeiko_log "🔁 Redémarrage de $unit…"
        systemctl restart "$unit"
    else
        jeiko_warn "Unité absente, ignorée : $unit"
    fi
}

# --------------------------------------------------------------------------- #
# Tâches planifiées
#
# Le serveur ne connaît aucune cadence à l'avance : il demande la liste au
# package (`manage.py jeiko_cron_units --json`) et s'y conforme. Ajouter un
# fichier `cron_<cadence>.py` dans jeiko fait donc apparaître le timer à la
# prochaine mise à jour serveur ; le retirer fait disparaître le timer.
#
# Une unité modèle par cadence, instanciée par site :
#   jeiko-cron-5m@monsite.timer  ->  jeiko-cron-5m@monsite.service
# --------------------------------------------------------------------------- #

# Liste les cadences actuellement installées POUR UN SITE.
#
# On s'appuie sur les drop-ins plutôt que sur les gabarits : ces derniers sont
# partagés entre tous les sites de la machine, alors que le drop-in est la
# marque qu'une cadence a bien été déployée pour ce site-là.
# Usage : jeiko_installed_cron_cadences <site>
jeiko_installed_cron_cadences() {
    local site="$1" dir base
    for dir in "/etc/systemd/system/jeiko-cron-"*"@$site.service.d"; do
        [[ -d "$dir" ]] || continue
        base="$(basename "$dir")"           # jeiko-cron-5m@monsite.service.d
        base="${base#jeiko-cron-}"
        printf '%s\n' "${base%%@*}"
    done
}

# Écrit (ou met à jour) le couple service+timer d'une cadence.
#
# Les gabarits sont PARTAGÉS par tous les sites de la machine : ils ne doivent
# donc contenir que ce qui est commun à tous. Rien de propre à un site — ni les
# chemins, ni l'horaire — ne peut y figurer, sinon deux sites installés sur des
# versions différentes de JEIKO se voleraient mutuellement leur configuration,
# le dernier convergé imposant la sienne aux autres.
#
# D'où l'absence délibérée de ExecStart/User côté service et de OnCalendar côté
# timer : tout cela vient des drop-ins par site. Une unité incomplète est un
# choix — si son drop-in manquait, systemd refuserait de la démarrer, ce qui
# est un échec visible plutôt qu'un cron tournant sur la mauvaise cadence.
#
# Usage : jeiko_write_cron_unit <cadence>
jeiko_write_cron_unit() {
    local cadence="$1"
    local service="/etc/systemd/system/jeiko-cron-$cadence@.service"
    local timer="/etc/systemd/system/jeiko-cron-$cadence@.timer"

    cat >"$service" <<EOF
# Généré par jeiko-server-update — ne pas éditer à la main.
# Gabarit PARTAGÉ : cadence « $cadence », toutes instances de site confondues.
# Le contenu des jobs vit dans le package (commande manage.py cron_$cadence).
# ExecStart, User et WorkingDirectory sont fournis par
# /etc/systemd/system/jeiko-cron-$cadence@<site>.service.d/site.conf
[Unit]
Description=Tâches planifiées $cadence — site %i
After=network-online.target postgresql.service
Wants=network-online.target

[Service]
Type=oneshot
Environment=PYTHONNOUSERSITE=1
Environment=PYTHONUNBUFFERED=1

# Un job qui traîne ne doit pas chevaucher le déclenchement suivant.
TimeoutStartSec=900

StandardOutput=journal
StandardError=journal
# %i dans l'identifiant : les journaux de deux sites ne doivent pas se mélanger.
SyslogIdentifier=jeiko-cron-$cadence-%i

# ProtectHome n'est volontairement pas activé : le projet et son venv vivent
# sous /home/<compte du site>, et certains jobs y écrivent (médias, journaux).
NoNewPrivileges=yes
PrivateTmp=yes
ProtectSystem=full
ProtectKernelTunables=yes
ProtectKernelModules=yes
ProtectControlGroups=yes
RestrictRealtime=yes
LockPersonality=yes
EOF

    cat >"$timer" <<EOF
# Généré par jeiko-server-update — ne pas éditer à la main.
# Gabarit PARTAGÉ. L'horaire est propre à chaque site : il est défini dans
# /etc/systemd/system/jeiko-cron-$cadence@<site>.timer.d/site.conf
[Unit]
Description=Déclenchement $cadence des tâches planifiées — site %i

[Timer]
Unit=jeiko-cron-$cadence@%i.service

[Install]
WantedBy=timers.target
EOF

    chmod 0644 "$service" "$timer"
}

# Fixe tout ce qui est propre à un site pour une cadence donnée : ses chemins
# et son horaire. C'est ce qui permet à deux sites de la même machine de tourner
# sur des versions différentes de JEIKO sans se marcher dessus.
#
# Usage : jeiko_write_cron_dropin <cadence> <site> <project_dir> <venv_dir> \
#                                 <site_user> <on_calendar> <persistent> <delay> \
#                                 [description]
jeiko_write_cron_dropin() {
    local cadence="$1" site="$2" project_dir="$3" venv_dir="$4" site_user="$5"
    local on_calendar="$6" persistent="$7" delay="$8"
    local description="${9:-Tâches planifiées $cadence}"
    local svc_dir="/etc/systemd/system/jeiko-cron-$cadence@$site.service.d"
    local tmr_dir="/etc/systemd/system/jeiko-cron-$cadence@$site.timer.d"

    install -d -m 0755 -o root -g root "$svc_dir" "$tmr_dir"

    # La description vient du package installé SUR CE SITE : `systemctl status`
    # affiche donc ce que fait réellement la cadence dans sa version à lui.
    cat >"$svc_dir/site.conf" <<EOF
# Généré par jeiko-server-update — ne pas éditer à la main.
# Chemins du site « $site », relus à chaque convergence depuis sa fiche.
[Unit]
Description=$description — site $site

[Service]
User=$site_user
WorkingDirectory=$project_dir
ExecStart=$venv_dir/bin/python $project_dir/manage.py cron_$cadence
EOF

    # OnCalendar s'ACCUMULE d'un fragment à l'autre : la ligne vide remet le
    # compteur à zéro avant de poser la valeur du site. Sans elle, une cadence
    # modifiée dans le package s'ajouterait à l'ancienne au lieu de la remplacer.
    cat >"$tmr_dir/site.conf" <<EOF
# Généré par jeiko-server-update — ne pas éditer à la main.
# Horaire du site « $site », tel que déclaré par SA version du package.
[Timer]
OnCalendar=
OnCalendar=$on_calendar
# Étalement : plusieurs sites cohabitent, leurs timers ne doivent pas partir
# à la même seconde et se disputer la base.
RandomizedDelaySec=$delay
Persistent=$persistent
EOF

    chmod 0644 "$svc_dir/site.conf" "$tmr_dir/site.conf"
}

# Converge les timers d'un site sur ce que déclare le package.
# Usage : jeiko_sync_cron_timers <site> <project_dir> <venv_dir> <site_user> [dry_run]
jeiko_sync_cron_timers() {
    jeiko_require_root
    local site="$1" project_dir="$2" venv_dir="$3" site_user="$4" dry_run="${5:-0}"

    local specs
    if ! specs="$(jeiko_manage "$project_dir" "$venv_dir" "$site_user" \
                    jeiko_cron_units --json 2>/dev/null)"; then
        jeiko_warn "Impossible d'interroger les cadences (jeiko_cron_units absent ?) — timers inchangés."
        return 0
    fi
    [[ -n "$specs" ]] || { jeiko_warn "Aucune cadence retournée par le package."; return 0; }

    # Le python du venv sert aussi à lire le JSON : pas de dépendance à jq.
    local parsed
    if ! parsed="$(printf '%s' "$specs" | "$venv_dir/bin/python" -c '
import json, sys
try:
    specs = json.load(sys.stdin)
except Exception:
    sys.exit(1)
for s in specs:
    print("\t".join([
        str(s["cadence"]),
        str(s["on_calendar"]),
        "true" if s.get("persistent") else "false",
        str(int(s.get("randomized_delay_sec") or 0)),
        str(s.get("description") or "").replace("\t", " "),
    ]))
')"; then
        jeiko_warn "Réponse de jeiko_cron_units illisible — timers inchangés."
        return 0
    fi

    local wanted=() cadence on_calendar persistent delay description
    while IFS=$'\t' read -r cadence on_calendar persistent delay description; do
        [[ -n "$cadence" ]] || continue
        wanted+=("$cadence")

        if [[ $dry_run -eq 1 ]]; then
            jeiko_log "   [simulation] cadence $cadence → $on_calendar (délai ${delay}s)"
            continue
        fi

        jeiko_write_cron_unit "$cadence"
        jeiko_write_cron_dropin "$cadence" "$site" "$project_dir" "$venv_dir" \
                                "$site_user" "$on_calendar" "$persistent" "$delay" \
                                "$description"
        jeiko_log "   cadence $cadence → $on_calendar (délai ${delay}s)"
    done <<<"$parsed"

    [[ ${#wanted[@]} -gt 0 ]] || { jeiko_warn "Aucune cadence exploitable."; return 0; }

    if [[ $dry_run -eq 1 ]]; then
        return 0
    fi

    systemctl daemon-reload

    # Activation de ce qui est déclaré.
    for cadence in "${wanted[@]}"; do
        systemctl enable --now "jeiko-cron-$cadence@$site.timer" >/dev/null 2>&1 \
            || jeiko_warn "Activation impossible : jeiko-cron-$cadence@$site.timer"
    done

    # Retrait de ce qui ne l'est plus. On ne supprime que l'instance du site ;
    # le gabarit reste tant qu'un autre site l'utilise.
    local installed keep
    for installed in $(jeiko_installed_cron_cadences "$site"); do
        keep=0
        for cadence in "${wanted[@]}"; do
            [[ "$installed" == "$cadence" ]] && { keep=1; break; }
        done
        if [[ $keep -eq 0 ]]; then
            jeiko_log "   cadence $installed retirée du package → désactivation"
            systemctl disable --now "jeiko-cron-$installed@$site.timer" >/dev/null 2>&1 || true
            rm -rf "/etc/systemd/system/jeiko-cron-$installed@$site.service.d" \
                   "/etc/systemd/system/jeiko-cron-$installed@$site.timer.d"

            # Le gabarit est partagé : on ne le supprime que si plus aucun site
            # ne l'utilise, sinon on casserait les autres sites de la machine.
            if ! compgen -G "/etc/systemd/system/jeiko-cron-$installed@*.service.d" >/dev/null; then
                rm -f "/etc/systemd/system/jeiko-cron-$installed@.timer" \
                      "/etc/systemd/system/jeiko-cron-$installed@.service"
            fi
        fi
    done

    systemctl daemon-reload
    jeiko_ok "Tâches planifiées synchronisées (${#wanted[@]} cadence(s))."
}
