#!/bin/bash
set -euo pipefail
# shellcheck source=../lib/jeiko-common.sh
source /usr/local/lib/jeiko/common.sh

jeiko_step "[09] Configuration Django (.env, settings, urls)"
jeiko_require_root

: "${PROJECT_DIR:?PROJECT_DIR manquant}"
: "${SITE_NAME:?SITE_NAME manquant}"
: "${DOMAIN_NAME:?DOMAIN_NAME manquant}"
: "${SITE_USER:?SITE_USER manquant}"
: "${VENV_DIR:?VENV_DIR manquant}"
: "${SCRIPT_DIR:?SCRIPT_DIR manquant}"

SETTINGS_DIR="$PROJECT_DIR/$SITE_NAME"
SETTINGS_PATH="$SETTINGS_DIR/settings.py"
URLS_PATH="$SETTINGS_DIR/urls.py"
ENV_PATH="$SETTINGS_DIR/.env"

PY="$VENV_DIR/bin/python"
[[ -x "$PY" ]] || jeiko_die "venv introuvable : $PY"

# --------------------------------------------------------------------------- #
# Localisation des gabarits
#
# Source de vérité : ceux embarqués dans le package (jeiko/project_template).
# C'est ce qui permet à la mise à jour côté client de réaligner settings.py
# quand une nouvelle version ajoute une application — le gabarit voyage avec le
# code qu'il déclare, les deux ne peuvent pas diverger.
#
# Repli sur les copies de l'installeur si le package n'en embarque pas encore
# (version antérieure au découpage serveur/client).
#
# L'ancienne version les recopiait dans $BASE_DIR/templates, soit
# /var/www/templates, partagé par tous les sites : deux installations de
# versions différentes se contaminaient mutuellement.
# --------------------------------------------------------------------------- #
PKG_TEMPLATE_DIR="$(jeiko_as_site "$SITE_USER" env PYTHONNOUSERSITE=1 "$PY" - <<'PYEOF' 2>/dev/null || true
import os
try:
    import jeiko
    path = os.path.join(os.path.dirname(jeiko.__file__), "project_template")
    print(path if os.path.isdir(path) else "")
except Exception:
    print("")
PYEOF
)"

if [[ -n "$PKG_TEMPLATE_DIR" ]] \
   && jeiko_as_site "$SITE_USER" test -f "$PKG_TEMPLATE_DIR/settings.py.txt"; then
    TEMPLATE_SETTINGS="$PKG_TEMPLATE_DIR/settings.py.txt"
    TEMPLATE_URLS="$PKG_TEMPLATE_DIR/urls.py.txt"
    jeiko_log "ℹ️  Gabarits lus depuis le package : $PKG_TEMPLATE_DIR"
else
    TEMPLATE_SETTINGS="$SCRIPT_DIR/templates/settings.template.py"
    TEMPLATE_URLS="$SCRIPT_DIR/templates/urls.template.py"
    jeiko_warn "Le package n'embarque pas de gabarits, repli sur ceux de l'installeur."
    jeiko_warn "La mise à jour côté client ne pourra pas réaligner settings.py."
fi

# --------------------------------------------------------------------------- #
# 1) Squelette du projet Django
# --------------------------------------------------------------------------- #
if [[ ! -f "$PROJECT_DIR/manage.py" ]]; then
    jeiko_log "📁 Création du projet Django « $SITE_NAME »…"
    jeiko_as_site "$SITE_USER" env PYTHONNOUSERSITE=1 \
        "$PY" -m django startproject "$SITE_NAME" "$PROJECT_DIR"
else
    jeiko_log "ℹ️  Projet Django déjà présent."
fi
[[ -d "$SETTINGS_DIR" ]] || jeiko_die "Dossier de configuration absent : $SETTINGS_DIR"

# --------------------------------------------------------------------------- #
# 2) .env — toute la variabilité par site vit ici
#
# settings.py reste strictement identique d'un site à l'autre, ce qui permet de
# le remplacer sans réfléchir à chaque mise à jour. Si tu dois personnaliser un
# site, ajoute une variable au .env, ne modifie pas settings.py.
# --------------------------------------------------------------------------- #
JEIKO_SSL="False"
[[ "${ENABLE_SSL:-n}" == "y" ]] && JEIKO_SSL="True" || true

# Le dossier de configuration appartient au site (startproject tourne sous son
# compte) : le .env y est lu et écrit SOUS CE COMPTE, jamais par root à travers
# un lien (audit du 04/10/2026, I-01 — ici, la réinstallation d'un site
# existant). L'ordre compte : on refuse un lien, on répare le propriétaire, et
# ALORS seulement on lit. Lire d'abord sous le compte du site un .env resté à
# root échouerait, ferait croire à un fichier sans SECRET_KEY, et en
# régénérerait un : sessions perdues, secrets chiffrés en base devenus
# illisibles.
if [[ -L "$ENV_PATH" ]]; then
    jeiko_die ".env est un lien symbolique ($ENV_PATH) : refusé. Un site JEIKO n'en pose jamais."
fi
jeiko_reparer_proprietaire "$SITE_USER" "$PROJECT_DIR" "$SITE_NAME"

if [[ -f "$ENV_PATH" ]] && jeiko_site_a_la_cle "$SITE_USER" "$ENV_PATH" SECRET_KEY; then
    jeiko_log "ℹ️  .env déjà présent, SECRET_KEY conservée."
    # On complète les clés manquantes sans toucher à l'existant : une
    # réinstallation ne doit jamais invalider les sessions en place.
    add_if_missing() {
        jeiko_site_a_la_cle "$SITE_USER" "$ENV_PATH" "$1" && return 0
        jeiko_site_ajouter "$SITE_USER" "$ENV_PATH" "$1=\"$2\"" \
            || jeiko_die "Impossible de compléter le .env ($1)."
        jeiko_log "   + $1"
    }
    add_if_missing JEIKO_SSL       "$JEIKO_SSL"
    add_if_missing JEIKO_SITE_NAME "$SITE_NAME"
    add_if_missing DOMAIN_NAME     "$DOMAIN_NAME"
    # La langue n'est connue qu'à l'INSTALLATION (I-08) : une convergence ne
    # la touche pas, et un .env qui en porte déjà une la garde.
    if [[ -n "${SITE_LANGUE:-}" ]]; then
        add_if_missing JEIKO_LANGUAGE "$(jeiko_code_de_langue "$SITE_LANGUE")"
    fi
    add_if_missing GUNICORN_SOCKET "/run/${GUNICORN_SERVICE:-gunicorn-$SITE_NAME}/gunicorn.sock"
else
    # 54 octets d'entropie brute : exactement 72 caractères base64, sans « = »
    # à retirer ni `head` final qui couperait le tube (SIGPIPE sous pipefail).
    SECRET_KEY="$(head -c 54 /dev/urandom | base64 -w0)"

    # Un .env présent mais dont SECRET_KEY reste illisible ne doit JAMAIS être
    # écrasé : ce serait perdre la clé, donc les secrets chiffrés en base.
    if [[ -f "$ENV_PATH" ]]; then
        jeiko_die ".env présent mais sans SECRET_KEY lisible ($ENV_PATH) : rien n'est écrasé. À examiner."
    fi

    jeiko_site_ecrire "$SITE_USER" "$ENV_PATH" "$JEIKO_SECRET_MODE" <<EOF
# ─────────────────────────────────────────────────────────────
# Configuration du site « $SITE_NAME »
# Généré par l'installeur JEIKO le $(date '+%d/%m/%Y à %H:%M')
#
# Ce fichier est le SEUL endroit où un site diffère d'un autre.
# settings.py est identique partout et remplacé à chaque mise à jour.
# ─────────────────────────────────────────────────────────────

DEBUG="False"
SECRET_KEY="$SECRET_KEY"

JEIKO_SITE_NAME="$SITE_NAME"
DOMAIN_NAME="$DOMAIN_NAME"

# Langue servie par défaut aux visiteurs (LANGUAGE_CODE). Choisie à
# l'installation ; la langue de l'ADMINISTRATION se règle, elle, dans
# Réglages › Général.
JEIKO_LANGUAGE="$(jeiko_code_de_langue "${SITE_LANGUE:-fr}")"

# Bascule HTTPS. À "False", ni redirection SSL ni HSTS ni cookies Secure :
# c'est indispensable tant que le certificat n'est pas en place, faute de quoi
# le site boucle en 301 et devient inaccessible.
JEIKO_SSL="$JEIKO_SSL"

DB_NAME="$DB_NAME"
DB_USER="$DB_USER"
DB_PASS="$DB_PASS"

# Doit correspondre aux étapes 10 (gunicorn) et 11 (nginx).
GUNICORN_SOCKET="/run/${GUNICORN_SERVICE:-gunicorn-$SITE_NAME}/gunicorn.sock"

# PayPal (facultatif) : les clés de l'application REST du compte PayPal
# Business, puis Paiements › Moyens de paiement pour l'allumer. Le bac à
# sable reste la règle tant que JEIKO_PAYPAL_SANDBOX n'est pas à "False".
# JEIKO_PAYPAL_CLIENT_ID=""
# JEIKO_PAYPAL_SECRET=""
# JEIKO_PAYPAL_WEBHOOK_ID=""
# JEIKO_PAYPAL_SANDBOX="True"
EOF
    [[ -f "$ENV_PATH" ]] || jeiko_die ".env non écrit : $ENV_PATH"
    jeiko_ok ".env généré : $ENV_PATH"
fi

jeiko_reparer_proprietaire "$SITE_USER" "$PROJECT_DIR" "$SITE_NAME"
jeiko_as_site "$SITE_USER" chmod -- "$JEIKO_SECRET_MODE" "$ENV_PATH" \
    || jeiko_die "Mode 0600 non appliqué à $ENV_PATH."

# --------------------------------------------------------------------------- #
# 3) settings.py et urls.py
# --------------------------------------------------------------------------- #
# Le gabarit du PAQUET est dans le venv du site : lu sous son compte. Celui de
# l'INSTALLEUR est dans un dossier root : lu par root. La destination, elle,
# est toujours écrite sous le compte du site (audit du 04/10/2026, I-04) —
# root suivait sinon un lien posé à la place de settings.py ou sous le nom,
# prévisible, d'une sauvegarde .bak_.
gabarit_du_paquet() { [[ -n "$PKG_TEMPLATE_DIR" && "$1" == "$PKG_TEMPLATE_DIR"/* ]]; }

lire_gabarit() {
    if gabarit_du_paquet "$1"; then
        jeiko_as_site "$SITE_USER" cat -- "$1"
    else
        cat -- "$1"
    fi
}

gabarit_present() {
    if gabarit_du_paquet "$1"; then
        jeiko_as_site "$SITE_USER" test -f "$1"
    else
        [[ -f "$1" ]]
    fi
}

# Le contenu passe par un fichier temporaire de root, lu en entier avant toute
# écriture : une lecture interrompue ne laisse pas un fichier tronqué.
poser_gabarit() {
    local gabarit="$1" destination="$2" libelle="$3" contenu
    contenu="$(mktemp)"
    if ! lire_gabarit "$gabarit" >"$contenu"; then
        rm -f "$contenu"
        jeiko_die "Gabarit illisible : $gabarit"
    fi
    if jeiko_as_site "$SITE_USER" test -f "$destination"; then
        if jeiko_as_site "$SITE_USER" cmp -s - "$destination" <"$contenu"; then
            rm -f "$contenu"
            jeiko_ok "$libelle déjà conforme au template."
            return 0
        fi
        if ! jeiko_as_site "$SITE_USER" cp -- "$destination" "$destination.bak_$(date +%Y%m%d_%H%M%S)"; then
            rm -f "$contenu"
            jeiko_die "Sauvegarde de $libelle impossible — rien n'a été remplacé."
        fi
        jeiko_log "🗄️  Ancien $libelle sauvegardé."
    fi
    if ! jeiko_site_ecrire "$SITE_USER" "$destination" "$JEIKO_FILE_MODE" <"$contenu"; then
        rm -f "$contenu"
        jeiko_die "Écriture de $libelle impossible."
    fi
    rm -f "$contenu"
    jeiko_ok "$libelle posé depuis le template."
}

gabarit_present "$TEMPLATE_SETTINGS" || jeiko_die "Template introuvable : $TEMPLATE_SETTINGS"
poser_gabarit "$TEMPLATE_SETTINGS" "$SETTINGS_PATH" "settings.py"

if gabarit_present "$TEMPLATE_URLS"; then
    poser_gabarit "$TEMPLATE_URLS" "$URLS_PATH" "urls.py"
fi

# --------------------------------------------------------------------------- #
# 4) Dossiers attendus par Django
# --------------------------------------------------------------------------- #
install -d -m "$JEIKO_DIR_MODE" -o "$SITE_USER" -g "$(jeiko_groupe_du_site "$SITE_USER")" \
    "$SETTINGS_DIR/static" "$SETTINGS_DIR/templates" \
    "$PROJECT_DIR/staticdir" "$PROJECT_DIR/mediadir"

jeiko_fix_perms "$PROJECT_DIR" "$SITE_USER" "$SITE_NAME" "$VENV_DIR"

# --------------------------------------------------------------------------- #
# 5) Vérification : la configuration se charge-t-elle ?
#
# Mieux vaut échouer ici, avec un message Django lisible, qu'à l'étape 14 sous
# la forme d'un gunicorn qui refuse de démarrer.
# --------------------------------------------------------------------------- #
if ! jeiko_manage "$PROJECT_DIR" "$VENV_DIR" "$SITE_USER" check 2>&1; then
    jeiko_die "django check a échoué — la configuration est invalide (voir ci-dessus)."
fi

# --------------------------------------------------------------------------- #
# 6) La base et les statiques AVANT que le site soit servi
#
# Gunicorn démarre à l'étape 10 et nginx publie le site aux étapes 11-12 ;
# les migrations n'avaient lieu qu'à l'étape 14. Pendant ces minutes-là,
# chaque visiteur — les robots passent sans arrêt — recevait une erreur 500
# (« relation administration_website does not exist ») et une alerte
# technique partait pour rien : 23 en deux minutes sur le serveur de test de
# kojei.fr (20/10/2026). L'étape 14 les relance : sans effet si rien n'a
# changé. Ici et non à l'étape 10, que la mise à jour du serveur rejoue pour
# les sites existants : une convergence de configuration ne migre pas.
# --------------------------------------------------------------------------- #
jeiko_log "🔄 Migrations et fichiers statiques, avant d'ouvrir le site…"
jeiko_manage "$PROJECT_DIR" "$VENV_DIR" "$SITE_USER" migrate --noinput \
    || jeiko_die "Les migrations ont échoué (voir ci-dessus)."
jeiko_manage "$PROJECT_DIR" "$VENV_DIR" "$SITE_USER" collectstatic --noinput >/dev/null \
    || jeiko_die "La collecte des fichiers statiques a échoué."

jeiko_ok "Django configuré."
