# cookies/urls.py
from django.urls import path
from .views import (
    ConsentStatusView,
    BannerConfigView,
    ConsentPersistView,
    CookiePolicyPageView,
)

app_name = "jeiko_cookies"

urlpatterns = [
    # API publique
    path("api/cookies/status", ConsentStatusView.as_view(), name="consent_status"),
    path("api/cookies/banner", BannerConfigView.as_view(), name="banner_config"),
    path("api/cookies/consent", ConsentPersistView.as_view(), name="consent_persist"),

    # Page documentaire (optionnelle)
    path("cookies/", CookiePolicyPageView.as_view(), name="policy_page"),
]
