from jeiko.calendars.views import (
    APIAvailabilitiesView,
    APIBookAppointmentView
                                   )
from django.urls import path

app_name = "api_calendars"

urlpatterns = [
    path("availabilities/", APIAvailabilitiesView.as_view(), name="api_availabilities"),
    path("book/", APIBookAppointmentView.as_view(), name="api_book_appointment"),
    ]

