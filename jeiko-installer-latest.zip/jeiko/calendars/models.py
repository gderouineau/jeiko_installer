# jeiko/calendars/models.py

from django.db import models, transaction
from django.contrib.auth import get_user_model
from django.utils import timezone
from datetime import timedelta, datetime, time
from dateutil.rrule import rrulestr

import logging
logger = logging.getLogger(__name__)

WEEKDAY_TOKENS = ["MO","TU","WE","TH","FR","SA","SU"]


class GoogleCalendarConfig(models.Model):
    name = models.CharField(
        max_length=100,
        default="Primary"
    )
    credentials_json = models.JSONField(
        help_text="Copier-coller ici le JSON de credentials Google",
        default=dict,
    )
    updated_at = models.DateTimeField(
        auto_now=True
    )

    calendar_id = models.CharField(

        max_length=300,
        default="",
        null=True,
        blank=True,
    )

    def __str__(self):
        return self.name


class AppointmentType(models.Model):
    name = models.CharField(
        "Nom du type",
        max_length=50
    )
    duration = models.DurationField(
        "Durée",
    )
    is_paid = models.BooleanField(
        "Payant",
        default=False
    )
    is_registration_required = models.BooleanField(
        "Réservation uniquement pour inscrits",
        default=False,
    )
    color = models.CharField(
        "Couleur",
        max_length=7,
        default="#2ecc40",
    )
    font = models.CharField(
        "Police",
        max_length=50,
        default="Inter"
    )
    description = models.TextField(
        "Description",
        blank=True
    )
    capacity = models.PositiveIntegerField(
        default=1,
        verbose_name="Nombre de places par créneau"
    )


    def __str__(self):
        return self.name


class Availability(models.Model):
    appointment_types = models.ManyToManyField(
        AppointmentType,
        related_name='availabilities',
        verbose_name="Types de rendez-vous possibles"
    )
    start = models.DateTimeField(
        "Début de disponibilité",
    )
    end = models.DateTimeField(
        "Fin de disponibilité",
    )
    recurring_rule = models.TextField(
        "Règle de récurrence iCal (optionnel)",
        blank=True,
        help_text="Inclut éventuellement DTSTART, RRULE, EXDATE (une par ligne)."
    )
    is_available = models.BooleanField(
        "Disponible",
        default=True,
    )
    recurrence_exdates = models.JSONField(
        default=list, blank=True,
        help_text="Liste de dates à exclure, au format YYYY-MM-DD."
    )

    google_event_id = models.CharField(
        max_length=128,
        null=True,
        blank=True,
        db_index=True
    )

    def __str__(self):
        types = ", ".join([str(t) for t in self.appointment_types.all()])
        return f"{types}: {self.start} - {self.end}"


    def update_slots_availability(self):
        """
        Désactive les slots qui sont en conflit avec un slot déjà réservé.
        Réactive ceux qui ne sont plus en conflit.
        """
        from django.db.models import Q, F

        # 1. On récupère tous les slots déjà réservés (plus de places)
        booked_slots = self.slots.filter(is_available=False, remaining_places=0)

        # 2. Désactive les slots en conflit avec un slot réservé (conflit = chevauchement)
        for bslot in booked_slots:
            conflicting_slots = self.slots.filter(
                is_available=True,
                start__lt=bslot.end,
                end__gt=bslot.start
            ).exclude(pk=bslot.pk)
            conflicting_slots.update(is_available=False)

        # 3. Réactive les slots non réservés et non en conflit
        for slot in self.slots.filter(is_available=False, remaining_places__gt=0):
            # Si aucun slot réservé ne le chevauche, on réactive
            conflit = self.slots.filter(
                is_available=False,
                remaining_places=0,
                start__lt=slot.end,
                end__gt=slot.start
            ).exclude(pk=slot.pk).exists()
            if not conflit:
                slot.is_available = True
                slot.save(update_fields=["is_available"])

    def _duration(self):
        return self.end - self.start

    def _as_rruleset(self):
        """
        Construit un rruleset (ou rrule) à partir de recurring_rule + DTSTART.
        Supporte RRULE/EXDATE multiples (forceset=True).
        """
        rule_str = (self.recurring_rule or "").strip()
        if not rule_str:
            return None
        # IMPORTANT: on fournit dtstart=self.start pour aligner la 1re occurrence
        return rrulestr(rule_str, forceset=True, dtstart=self.start)

    def iter_occurrences(self, start_from=None, until=None):
        """
        Génère les fenêtres (start,end) d’Availability pour chaque occurrence.
        - Si pas de récurrence: une seule fenêtre self.start/self.end.
        - Sinon: on expanse via rruleset().between().
        """
        dur = self._duration()
        if not (self.recurring_rule or "").strip():
            yield (self.start, self.end)
            return

        rs = self._as_rruleset()
        if not rs:
            yield (self.start, self.end)
            return

        if start_from is None:
            start_from = self.start

        if until is None:
            # horizon par défaut : 90 jours
            until = timezone.now() + timedelta(days=90)

        for occ_start in rs.between(start_from, until, inc=True):
            occ_end = occ_start + dur
            # Si tu as JSONField recurrence_exdates ET que tu préfères un double filet de sécurité:
            exdates = getattr(self, 'recurrence_exdates', []) or []
            if exdates:
                # compare la date uniquement
                if occ_start.date().isoformat() in exdates:
                    continue
            yield (occ_start, occ_end)


    def generate_slots(self, horizon_days=90):
        """
        Génère tous les slots pour CHAQUE occurrence (quotidienne/hebdomadaire),
        pour TOUS les types associés (durées différentes OK),
        puis met à jour les conflits et nettoie les slots hors plage.
        """
        types = list(self.appointment_types.all())
        if not types:
            return

        type_ids = {t.id for t in types}
        horizon_end = timezone.now() + timedelta(days=horizon_days)
        windows = list(self.iter_occurrences(until=horizon_end))

        # Si aucune occurrence dans l'horizon -> on nettoie simplement
        if not windows:
            to_delete = []
            to_update = []
            for slot in self.slots.all():
                if slot.remaining_places == slot.capacity:
                    to_delete.append(slot.id)
                elif slot.is_available:
                    slot.is_available = False
                    to_update.append(slot)
            if to_delete:
                self.slots.filter(id__in=to_delete).delete()
            if to_update:
                Slot.objects.bulk_update(to_update, ["is_available"])
            return

        # Index des slots existants
        existing_qs = self.slots.select_related("type")
        existing = {(s.start, s.end, s.type_id): s for s in existing_qs}

        to_create = []
        to_update = []

        def in_any_window(s, e):
            for ws, we in windows:
                if ws <= s and e <= we and e > s:
                    return True
            return False

        # Tessellation des fenêtres en pas = duration de chaque type
        for appt_type in types:
            step = appt_type.duration
            capacity = appt_type.capacity
            for ws, we in windows:
                cur = ws
                while cur + step <= we:
                    se = cur + step
                    key = (cur, se, appt_type.id)
                    slot = existing.get(key)
                    if slot is None:
                        to_create.append(Slot(
                            availability=self,
                            type=appt_type,
                            start=cur,
                            end=se,
                            capacity=capacity,
                            remaining_places=capacity,
                            is_available=True,
                        ))
                    else:
                        changed = False
                        # Maintien de la capacité (et clamp du remaining)
                        if slot.capacity != capacity:
                            slot.capacity = capacity
                            if slot.remaining_places > slot.capacity:
                                slot.remaining_places = slot.capacity
                            changed = True
                        # Si non complet et désactivé → réactive
                        if slot.remaining_places > 0 and not slot.is_available:
                            slot.is_available = True
                            changed = True
                        if changed:
                            to_update.append(slot)
                    cur = se

        if to_create:
            Slot.objects.bulk_create(to_create)
        if to_update:
            Slot.objects.bulk_update(to_update, ["capacity", "remaining_places", "is_available"])

        # 1) Mise à jour de la dispo vs RDV pris (chevauchements avec slots complets)
        self.update_slots_availability()

        # 2) Nettoyage: tout slot qui ne tombe plus dans une fenêtre active ou dont le type a été retiré
        type_ids_set = type_ids  # alias lisible
        to_delete = []
        to_deactivate = []
        for slot in self.slots.all():
            if not in_any_window(slot.start, slot.end) or (slot.type_id not in type_ids_set):
                if slot.remaining_places == slot.capacity:
                    to_delete.append(slot.id)
                else:
                    if slot.is_available:
                        slot.is_available = False
                        to_deactivate.append(slot)

        if to_delete:
            self.slots.filter(id__in=to_delete).delete()
        if to_deactivate:
            Slot.objects.bulk_update(to_deactivate, ["is_available"])


    def save(self, *args, **kwargs):
        with transaction.atomic():

            super().save(*args, **kwargs)

            self.generate_slots()

        def _push(av_id):
            try:
                from .google_api import upsert_availability_event
                a = Availability.objects.get(pk=av_id)
                eid = upsert_availability_event(a)
                if eid and eid != a.google_event_id:
                    Availability.objects.filter(pk=av_id).update(google_event_id=eid)
            except Exception:
                logger.exception("Failed pushing availability to Google (id=%s)", av_id)

        transaction.on_commit(lambda av_id=self.id: _push(av_id))



class Slot(models.Model):
    availability = models.ForeignKey(
        'Availability',
        on_delete=models.CASCADE,
        related_name='slots',
        verbose_name="Plage de disponibilité"
    )
    type = models.ForeignKey(
        AppointmentType,
        on_delete=models.CASCADE,
        related_name="slots"
    )

    start = models.DateTimeField(
        verbose_name="Début du créneau"
    )
    end = models.DateTimeField(
        verbose_name="Fin du créneau"
    )
    is_available = models.BooleanField(
        default=False,
        verbose_name="Est disponible"
    )
    capacity = models.PositiveIntegerField(
        default=1
    )
    remaining_places = models.PositiveIntegerField(
        default=1
    )


    class Meta:
        ordering = ["start"]
        unique_together = (('availability', 'start', 'end', 'type'),)
        indexes = [
            models.Index(fields=["availability", "start"]),
            models.Index(fields=["start"]),
            models.Index(fields=["type", "start"]),
        ]

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        if not self.is_available:
            self.availability.update_slots_availability()

    def __str__(self):
        return f"{self.type.name}: {self.start} - {self.end} ({self.remaining_places}/{self.capacity})"


class Appointment(models.Model):
    type = models.ForeignKey(
        AppointmentType,
        on_delete=models.PROTECT,
    )
    slot = models.ForeignKey(
        Slot,
        on_delete=models.CASCADE,
        related_name="appointments",
        null=True,
        blank=True
    )
    user = models.ForeignKey(
        get_user_model(),
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
    )
    start = models.DateTimeField(
        "Début"
    )
    end = models.DateTimeField(
        "Fin",
    )
    created = models.DateTimeField(
        auto_now_add=True
    )
    is_paid = models.BooleanField(
        default=False,
    )  # utile si tu veux vérifier le paiement
    email = models.EmailField(
        "Email du client",
        blank=True,
    )

    google_event_id = models.CharField(
        max_length=128, blank=True, null=True, db_index=True
    )

    def __str__(self):
        return f"{self.type.name} - {self.start:%Y-%m-%d %H:%M}"

    def cancel(self):
        """
        Annule ce rendez-vous :
        - Libère le slot associé.
        - Met à jour la dispo des slots en conflit.
        - Supprime le rendez-vous.
        """
        slot = self.slot
        if slot:
            slot.appointment = None
            slot.remaining_places += 1
            if slot.remaining_places > 0:
                slot.is_available = True
            slot.save(update_fields=["remaining_places", "is_available"])
            # Met à jour la dispo des autres slots de la même plage
            slot.availability.update_slots_availability()
        self.delete()