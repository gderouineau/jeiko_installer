# jeiko/calendars/recurrence.py
from datetime import datetime, date, time
from datetime import timezone as dt_timezone  # <-- UTC ici
from django.utils import timezone as dj_tz

WEEKDAY_TOKENS = ["MO","TU","WE","TH","FR","SA","SU"]

def _to_utc_str(dt: datetime) -> str:
    """
    Convertit un datetime (naïf ou aware) en string UTC iCal (YYYYMMDDTHHMMSSZ).
    - Si naïf: on le rend aware avec la timezone courante Django.
    - Puis on convertit en UTC.
    """
    if dj_tz.is_naive(dt):
        dt = dj_tz.make_aware(dt, dj_tz.get_current_timezone())
    return dt.astimezone(dt_timezone.utc).strftime("%Y%m%dT%H%M%SZ")

def build_rrulestr(*, start: datetime, freq: str, until_date=None,
                   byday=None, exdates=None) -> str:
    """
    Construit un bloc iCal multi-lignes: DTSTART + RRULE + EXDATE...
    - freq: "DAILY" ou "WEEKLY"
    - until_date: date -> UNTIL à 23:59:59 de ce jour
    - byday: liste ["MO","TU",...]
    - exdates: liste "YYYY-MM-DD" (reprend l'heure de start)
    """
    lines = [f"DTSTART:{_to_utc_str(start)}"]
    rrule = f"RRULE:FREQ={freq}"
    if byday:
        rrule += f";BYDAY={','.join(byday)}"
    if until_date:
        until_dt = datetime.combine(until_date, time(23, 59, 59))
        lines.append(rrule + f";UNTIL={_to_utc_str(until_dt)}")
    else:
        lines.append(rrule)

    if exdates:
        for day in exdates:
            y, m, d = map(int, day.split("-"))
            # Exdate: reprend l'heure de début 'start'
            ex_dt = datetime(y, m, d, start.hour, start.minute, start.second, tzinfo=start.tzinfo)
            lines.append(f"EXDATE:{_to_utc_str(ex_dt)}")

    return "\n".join(lines)
