from django.template import Library, Node
from django.db.models import Prefetch
from django.core.cache import cache

from jeiko.administration_menu.models import Menu, MenuItem

register = Library()

class AllMenus(Node):
    def render(self, context):
        cache_key = "menu:place:MAIN"
        items = cache.get(cache_key)

        if items is None:
            menu = Menu.objects.filter(place="MAIN").first()
            if not menu:
                context['all_menus'] = []
                return ''

            sub_qs = (
                MenuItem.objects
                .filter(active=True)
                .order_by('position', 'pk')
            )

            items = (
                MenuItem.objects
                .filter(menu=menu, main_menu__isnull=True, active=True)
                .prefetch_related(Prefetch('submenus', queryset=sub_qs, to_attr='active_submenus'))
                .order_by('position', 'pk')
            )
            cache.set(cache_key, list(items), 300)  # 5 min

        context['all_menus'] = items
        return ''

@register.tag(name="get_all_menus")
def get_all_menus(parser, token):
    return AllMenus()
