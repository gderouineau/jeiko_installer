from django import template
from django.utils.safestring import mark_safe
import html

register = template.Library()

@register.filter
def html_unescape(value):
    return mark_safe(html.unescape(value or ""))
