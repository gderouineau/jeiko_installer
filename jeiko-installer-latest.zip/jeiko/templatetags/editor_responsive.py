# jeiko/templatetags/editor_responsive.py
import re
from django import template

register = template.Library()

# Regex simple pour détecter les blocs @media
_MEDIA_RE = re.compile(
    r'@media\s*(\([^)]+\)(?:\s*and\s*\([^)]+\))*)\s*\{',
    flags=re.IGNORECASE
)

@register.filter(name="mq_to_cq")
def mq_to_cq(css: str, request=None) -> str:
    """
    Duplique les règles @media en @container editor-body,
    uniquement si on est dans l’éditeur (page_editor).
    """
    if not css:
        return css

    # Par défaut, renvoyer tel quel
    if not request:
        return css

    match = getattr(request, "resolver_match", None)
    if not match:
        return css

    if not (match.namespace == "jeiko_administration_pages"):
        return css

    # On est bien dans l’éditeur → dupliquer
    def _replace_to_container(m: re.Match) -> str:
        cond = m.group(1)
        return f"@container editor-body {cond} {{"

    container_css = _MEDIA_RE.sub(_replace_to_container, css)
    return f"{css}\n\n/* === container equivalents === */\n{container_css}"
