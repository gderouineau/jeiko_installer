import re
from django import template
from django.utils.safestring import mark_safe

register = template.Library()

# 1) Pattern pour matcher [% key %]
TAG_PATTERN = re.compile(r'\[\%\s*(\w+)\s*\%\]')

@register.simple_tag(takes_context=True)
def render_custom_tags(context, text):
    """
    Remplace chaque [% key %] par la valeur context['key'] si elle existe,
    sinon laisse la balise inchangée.
    """
    def _replace(match):
        key = match.group(1)
        # context est un dict-like (contexte du template)
        if key in context:
            return str(context[key])
        return match.group(0)  # la balise d'origine

    rendered = TAG_PATTERN.sub(_replace, text or "")
    return mark_safe(rendered)

@register.filter
def concat(value, arg):
    return str(value) + str(arg)