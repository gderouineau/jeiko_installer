# jeiko/administration_menu/templatetags/menu_tags.py
from django import template
from django.core.cache import cache
from django.template.loader import render_to_string
from django.db.models import Prefetch
from django.utils.html import mark_safe

from jeiko.administration_menu.models import Menu, MenuItem, MenuPlace

register = template.Library()

MENU_RENDER_TTL = 60 * 60 * 24 * 30  # 30 jours

@register.simple_tag
def get_menu(place="MAIN"):
    """
    Usage : {% get_menu 'MAIN' as main_menu %}
    """
    place = place or MenuPlace.MAIN
    cache_key = f"menu:place:{place}"
    menu = cache.get(cache_key)
    if menu is not None:
        return menu

    items_qs = (
        MenuItem.objects
        .filter(active=True)
        .select_related('page')
        .order_by('position', 'pk')
    )
    menu = (
        Menu.objects
        .filter(place=place)
        .select_related('menu_style')
        .prefetch_related(Prefetch('menu_items', queryset=items_qs))
        .first()
    )
    cache.set(cache_key, menu, 60 * 60)  # 1 h pour la liste du menu par place
    return menu

@register.simple_tag
def get_main_menu():
    return get_menu(MenuPlace.MAIN)

@register.simple_tag
def render_main_menu():
    """
    Rendu HTML du menu MAIN, avec cache long : menu:render:{menu.id}
    Invalider cette clé quand Menu/MenuItem/MenuStyle changent.
    """
    menu = get_menu(MenuPlace.MAIN)
    if not menu:
        return ""

    render_key = f"menu:render:{menu.id}"
    html = cache.get(render_key)
    if html is not None:
        return mark_safe(html)

    html = render_to_string("menu/main.html", {"menu": menu})
    cache.set(render_key, html, MENU_RENDER_TTL)
    return mark_safe(html)
