from django.template import Library, Node
from django.db.models import Prefetch

from jeiko.administration_menu.models import Menu, MenuItem

register = Library()

class FooterMenus(Node):
    def render(self, context):
        menu = Menu.objects.filter(place="FOOTER").first()
        if not menu:
            context['footer_menus'] = []
            return ''

        sub_qs = (
            MenuItem.objects
            .filter(active=True)
            .order_by('position', 'pk')
        )

        items = (
            MenuItem.objects
            .filter(menu=menu, main_menu__isnull=True, active=True)
            .prefetch_related(Prefetch('submenus', queryset=sub_qs, to_attr='active_submenus'))
            .order_by('position', 'pk')
        )

        context['footer_menus'] = items
        return ''

@register.tag(name="get_footer_menus")
def get_footer_menus(parser, token):
    return FooterMenus()
