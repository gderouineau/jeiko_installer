# blog/templatetags/blog_extras.py

from django.template import Library, Node

from jeiko.administration.models import WebSite

register = Library()

class GetWebSiteData(Node):
    def render(self, context):
        context['website_data'] = WebSite.objects.all().first()
        return ''

@register.tag(name="get_website_data")
def get_all_menus(parser, token):

    return GetWebSiteData()

