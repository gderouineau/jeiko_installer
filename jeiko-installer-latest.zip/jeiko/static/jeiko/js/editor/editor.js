import {
    getCookie,
    fetchHtml,
    showModal,
    showToast,
    showConfirmModal,
    closeModal
} from './utils.js';

const csrftoken = getCookie('csrftoken');

/* =========================
 *  Unification re-init UI
 * ========================= */
function reinitAlpine(root = document) {
    try {
        if (window.Alpine && typeof Alpine.initTree === 'function') {
            Alpine.initTree(root);
        }
    } catch (e) {
        console.warn('[reinitAlpine] Alpine.initTree a échoué:', e);
    }
}
window.executeInlineScripts = function(root) {
  if (!root) return;
  const scripts = root.querySelectorAll('script');
  scripts.forEach(old => {
    const s = document.createElement('script');
    // copy attributes (type/module etc.)
    for (const attr of old.attributes) s.setAttribute(attr.name, attr.value);
    s.textContent = old.textContent;
    old.replaceWith(s);
  });
};

window.initAlpineOn = function(root) {
  if (!window.Alpine || !root) return;
  // Alpine v3
  if (Alpine.initTree) Alpine.initTree(root);
};
function attachAjaxFormHandler(formId, updateDOMCallback, successMsg = "Opération réussie") {
    const form = document.getElementById(formId);
    if (!form || form._handlerAttached) return;

    form._handlerAttached = true;

    form.addEventListener('submit', async e => {
        e.preventDefault();


        const formData = new FormData(form);
        const url = form.action || form.dataset.url;

        const res = await fetch(url, {
            method: 'POST',
            headers: {
                'X-CSRFToken': csrftoken,
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: formData,
        });

        let data, isJson = false;
        try {
            data = await res.clone().json();
            isJson = true;
        } catch {
            data = await res.text();
        }

        if (res.ok && isJson && (data.status === 'success' || data.status === 'ok')) {

            closeModal();
            // Laisse le callback faire le remplacement DOM ciblé
            updateDOMCallback(data);
            // Re-init UI (global au doc, ou mieux: sur la cible remplacée par le callback)
            reinitUI(document);
            showToast(successMsg);


        } else if (!isJson) {
            // Ré-injection du formulaire (avec erreurs) dans le modal
            const container = document.querySelector('.modal-body') || document.querySelector('.modal-content');
            if (container) container.innerHTML = data;
            // Re-attacher le handler et re-init le sous-arbre du modal
            setTimeout(() => {
                attachAjaxFormHandler(formId, updateDOMCallback, successMsg);
                reinitUI(container || document);
            }, 0);

        } else {
            showToast(data.message || 'Erreur serveur');
        }
    });
}


export function initOverlayHandlers(root = document) {
  const scope = root instanceof Element ? root : document;
  const GAP = 6;            // espace entre contrôles
  const FIRST_LINE_TOL = 10; // tolérance "collée en haut"

  const isHover = el => !!(el && el.matches(':hover'));

  const hideLineUI = (lineEl) => {
    lineEl.querySelector(':scope > .overlay-line-bg')?.classList.remove('visible');
    const lc = lineEl.querySelector(':scope > .overlay-line-controls');
    lc?.classList.remove('visible');
    if (lc) lc.style.setProperty('--line-x', '0px'); // reset X
    lineEl.querySelectorAll(':scope .overlay-block-bg.visible, :scope .overlay-block-controls.visible')
      .forEach(el => el.classList.remove('visible'));
  };

  const hideBlockUI = (itemEl) => {
    itemEl.querySelector(':scope > .overlay-block-bg')?.classList.remove('visible');
    itemEl.querySelector(':scope > .overlay-block-controls')?.classList.remove('visible');
  };

  // Place la barre ligne (X dynamique quand collision avec la section)
  const placeLineControls = (section, sectionCtrls, line, lineCtrls) => {
    if (!lineCtrls) return;
    const secRect  = section.getBoundingClientRect();
    const lineRect = line.getBoundingClientRect();
    const first = Math.abs(lineRect.top - secRect.top) <= FIRST_LINE_TOL;

    if (first && sectionCtrls && sectionCtrls.classList.contains('visible')) {
      const x = (sectionCtrls.offsetWidth || 0) + GAP;
      lineCtrls.style.setProperty('--line-x', `${x}px`);
    } else {
      lineCtrls.style.setProperty('--line-x', '0px');
    }
  };

  scope.querySelectorAll('.section').forEach(section => {
    if (section.dataset.overlayBound === '1') return;
    section.dataset.overlayBound = '1';

    const overlaySectionBg = section.querySelector(':scope > .overlay-section-bg');
    const sectionCtrls     = section.querySelector(':scope > .overlay-section-controls');

    const showSection = () => {
      overlaySectionBg?.classList.add('visible');
      sectionCtrls?.classList.add('visible');
    };
    const hideSectionSelf = () => {
      overlaySectionBg?.classList.remove('visible');
      sectionCtrls?.classList.remove('visible');
    };
    const isOverSection = () => isHover(section) || isHover(sectionCtrls);

    section.addEventListener('mouseenter', showSection);
    section.addEventListener('mouseleave', () => {
      const anyLineActive = [...section.querySelectorAll(':scope .line')].some(ln => {
        const lnCtrls = ln.querySelector(':scope > .overlay-line-controls');
        return isHover(ln) || isHover(lnCtrls);
      });
      if (!isOverSection() && !anyLineActive) {
        section.querySelectorAll('.overlay-line-bg.visible, .overlay-line-controls.visible, .overlay-block-bg.visible, .overlay-block-controls.visible')
          .forEach(el => el.classList.remove('visible'));
        hideSectionSelf();
      }
    });

    // ---------- LINES
    section.querySelectorAll(':scope .line').forEach(line => {
      if (line.dataset.overlayBound === '1') return;
      line.dataset.overlayBound = '1';

      const overlayLineBg = line.querySelector(':scope > .overlay-line-bg');
      const lineCtrls     = line.querySelector(':scope > .overlay-line-controls');

      const showLine = () => {
        showSection();
        // Masque les autres lignes
        section.querySelectorAll(':scope .line').forEach(sib => {
          if (sib !== line) hideLineUI(sib);
        });
        overlayLineBg?.classList.add('visible');
        lineCtrls?.classList.add('visible');
        placeLineControls(section, sectionCtrls, line, lineCtrls);
      };

      const hideLine = () => {
        // si la souris est sur la barre de section ET que line est la 1re, on ne cache pas
        const secRect  = section.getBoundingClientRect();
        const lineRect = line.getBoundingClientRect();
        const first = Math.abs(lineRect.top - secRect.top) <= FIRST_LINE_TOL;
        const keepBecauseSectionCtrls = first && isHover(sectionCtrls);

        if (!isHover(line) && !isHover(lineCtrls) && !keepBecauseSectionCtrls) {
          overlayLineBg?.classList.remove('visible');
          lineCtrls?.classList.remove('visible');
          if (lineCtrls) lineCtrls.style.setProperty('--line-x', '0px');
        }
        const anyLineActive = [...section.querySelectorAll(':scope .line')].some(ln => {
          const lnCtrls = ln.querySelector(':scope > .overlay-line-controls');
          return isHover(ln) || isHover(lnCtrls);
        });
        if (!anyLineActive && !isHover(section) && !isHover(sectionCtrls)) hideSectionSelf();
      };

      line.addEventListener('mouseenter', showLine);
      line.addEventListener('mouseleave', hideLine);
      lineCtrls?.addEventListener('mouseenter', showLine);
      lineCtrls?.addEventListener('mouseleave', hideLine);
      // quand on survole/quite la barre section, on recalcule le X pour éviter tout clignotement
      sectionCtrls?.addEventListener('mouseenter', () => placeLineControls(section, sectionCtrls, line, lineCtrls));
      sectionCtrls?.addEventListener('mouseleave', () => placeLineControls(section, sectionCtrls, line, lineCtrls));

      // ---------- BLOCKS
      line.querySelectorAll(':scope .column-item').forEach(item => {
        if (item.dataset.overlayBound === '1') return;
        item.dataset.overlayBound = '1';

        const blockBg    = item.querySelector(':scope > .overlay-block-bg');
        const blockCtrls = item.querySelector(':scope > .overlay-block-controls');

        const showBlock = () => {
          showLine();
          line.querySelectorAll(':scope .column-item').forEach(sib => {
            if (sib !== item) hideBlockUI(sib);
          });
          blockBg?.classList.add('visible');
          blockCtrls?.classList.add('visible');
        };

        const hideBlock = () => {
          if (!isHover(item) && !isHover(blockCtrls)) {
            blockBg?.classList.remove('visible');
            blockCtrls?.classList.remove('visible');
          }
          const anyBlockActive = [...line.querySelectorAll(':scope .column-item')].some(it => {
            const itCtrls = it.querySelector(':scope > .overlay-block-controls');
            return isHover(it) || isHover(itCtrls);
          });
          if (!anyBlockActive && !isHover(line) && !isHover(lineCtrls)) {
            overlayLineBg?.classList.remove('visible');
            lineCtrls?.classList.remove('visible');
            if (lineCtrls) lineCtrls.style.setProperty('--line-x', '0px');
          }
          const anyLineActive = [...section.querySelectorAll(':scope .line')].some(ln => {
            const lnCtrls = ln.querySelector(':scope > .overlay-line-controls');
            return isHover(ln) || isHover(lnCtrls);
          });
          if (!anyLineActive && !isHover(section) && !isHover(sectionCtrls)) hideSectionSelf();
        };

        item.addEventListener('mouseenter', showBlock);
        item.addEventListener('mouseleave', hideBlock);
        blockCtrls?.addEventListener('mouseenter', showBlock);
        blockCtrls?.addEventListener('mouseleave', hideBlock);
      });

      // re-calcul si resize (largeur barre section peut changer)
      window.addEventListener('resize', () => {
        if (lineCtrls?.classList.contains('visible')) {
          placeLineControls(section, sectionCtrls, line, lineCtrls);
        }
      });
    });
  });
}



function refreshOverlays(root = document) {
    initOverlayHandlers(root);
}


export function reinitUI(root = document) {
    reinitAlpine(root);

    // Overlays (UI d’édition) — toujours relancé après update
    refreshOverlays(root);

    try {
        if (window.ResponsiveImg && typeof window.ResponsiveImg.refresh === 'function') {
            window.ResponsiveImg.refresh(root);
        }
    } catch (e) {
        console.warn('[reinitUI] ResponsiveImg.refresh a échoué:', e);
    }

    try {
        if (window.Formsets && Formsets.Countdown) {
            Formsets.Countdown.boot(root);
        }
    } catch (e) {
        console.warn('[reinitUI] Countdown.boot a échoué:', e);
    }

    return root;
}



// === Helpers QUILL (ajout de pickers natifs + utilitaires) ====================

// === Helpers QUILL (color utils + pickers natifs) ============================

// rgb/rgba/#abc → #rrggbb
function toHex(color, current = '#000000') {
    if (!color) return current;
    if (/^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(color)) {
        if (color.length === 4) {
            return (
                '#' +
                color[1] + color[1] +
                color[2] + color[2] +
                color[3] + color[3]
            ).toLowerCase();
        }
        return color.toLowerCase();
    }
    const m = color.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/i);
    if (m) {
        const r = Math.max(0, Math.min(255, parseInt(m[1], 10)));
        const g = Math.max(0, Math.min(255, parseInt(m[2], 10)));
        const b = Math.max(0, Math.min(255, parseInt(m[3], 10)));
        return (
            '#' +
            r.toString(16).padStart(2, '0') +
            g.toString(16).padStart(2, '0') +
            b.toString(16).padStart(2, '0')
        ).toLowerCase();
    }
    return current;
}

// Ajoute deux <input type="color"> (Texte + Fond) dans la toolbar Quill

function addQuillColorPickers(quill) {
    try {
        const toolbar = quill.getModule('toolbar');
        const bar = toolbar && toolbar.container;
        if (!bar) return;
        if (bar.querySelector('.ql-color-pickers')) return; // déjà injecté

        const group = document.createElement('span');
        group.className = 'ql-formats ql-color-pickers';

        // --- Picker couleur de TEXTE
        const colorWrap = document.createElement('label');
        colorWrap.className = 'ql-color-picker';
        colorWrap.title = 'Couleur du texte';
        colorWrap.style.display = 'inline-flex';
        colorWrap.style.alignItems = 'center';

        const colorIcon = document.createElement('span');
        colorIcon.className = 'ql-picker-label';
        colorIcon.textContent = 'A';
        colorIcon.style.cssText = 'display:inline-block;font-weight:700;margin-right:6px;';

        const colorInput = document.createElement('input');
        colorInput.type = 'color';
        colorInput.value = '#333333';
        colorInput.style.cssText = 'width:28px;height:28px;padding:0;border:none;background:transparent;cursor:pointer;';
        colorInput.addEventListener('input', () => {
            // → couleur du TEXTE
            quill.format('color', colorInput.value || null);
        });

        colorWrap.appendChild(colorIcon);
        colorWrap.appendChild(colorInput);
        group.appendChild(colorWrap);

        // --- Picker couleur de FOND
        const bgWrap = document.createElement('label');
        bgWrap.className = 'ql-bg-picker';
        bgWrap.title = 'Couleur de fond';
        bgWrap.style.display = 'inline-flex';
        bgWrap.style.alignItems = 'center';

        const bgIcon = document.createElement('span');
        bgIcon.className = 'ql-picker-label';
        bgIcon.textContent = '▧';
        bgIcon.style.cssText = 'display:inline-block;margin:0 6px 0 12px;';

        const bgInput = document.createElement('input');
        bgInput.type = 'color';
        bgInput.value = '#ffffff';
        bgInput.style.cssText = 'width:28px;height:28px;padding:0;border:none;background:transparent;cursor:pointer;';
        bgInput.addEventListener('input', () => {
            // → couleur de FOND
            quill.format('background', bgInput.value || null);
        });

        bgWrap.appendChild(bgIcon);
        bgWrap.appendChild(bgInput);
        group.appendChild(bgWrap);

        // Pas de palette Quill → on append à la fin du toolbar
        bar.appendChild(group);

        // synchro inverse (formats Quill -> inputs)
        const sync = () => {
            try {
                const range = quill.getSelection();
                if (!range) return;
                const fmt = quill.getFormat(range);
                if (fmt.color) colorInput.value = toHex(fmt.color, colorInput.value);
                if (fmt.background) bgInput.value = toHex(fmt.background, bgInput.value);
            } catch {}
        };
        quill.on('selection-change', sync);
        quill.on('text-change', sync);

    } catch (e) {
        console.warn('[addQuillColorPickers] échec:', e);
    }
}

function unwrapQuoted(s) {
    if (typeof s !== 'string') return s;
    const t = s.trim();
    if ((t.startsWith('"') && t.endsWith('"')) || (t.startsWith("'") && t.endsWith("'"))) {
        return t.slice(1, -1);
    }
    return s;
}
// === Initialisation QUILL dans le modal ======================================

export function initQuillInModal(body, blocId) {
    body.querySelectorAll('#text-editor').forEach(editorEl => {
        if (!window.Quill) return;

        // éviter double init
        if (editorEl.classList.contains('ql-container') || editorEl.querySelector('.ql-editor')) return;

        // 1) CAPTURER le contenu initial AVANT d'instancier Quill
        const initialHtmlRaw = unwrapQuoted(editorEl.innerHTML?.trim() || '');

        // 2) Instancier Quill
        const toolbarOptions = [
            [{
                header: [1, 2, 3, 4, 5, 6, false]
            }],
            ['bold', 'italic', 'underline', 'strike'],
            ['link', 'blockquote', 'code-block'],
            [{
                list: 'ordered'
            }, {
                list: 'bullet'
            }, {
                list: 'check'
            }],
            [{
                script: 'sub'
            }, {
                script: 'super'
            }],
            [{
                align: []
            }],
            [{
                size: ['small', false, 'large', 'huge']
            }]
        ];
        const quill = new Quill(editorEl, {
            theme: 'snow',
            modules: {
                toolbar: toolbarOptions
            }
        });

        // 3) Récup de l'input caché (avec suffixe -text)
        const input = editorEl.parentNode.querySelector('input[type="hidden"][name$="-text"]') ||
            body.querySelector('input[type="hidden"][name$="-text"]');

        // util: détecter "vide" (p, br, espaces)
        const isEmptyHtml = (html) => {
            if (!html) return true;
            const clean = html.replace(/\s+/g, ' ').trim().toLowerCase();
            return clean === '' || clean === '<p><br></p>' || clean === '<p></p>';
        };

        // 4) Déterminer la valeur initiale à injecter
        let inputContent = (input?.value || '').trim();
        inputContent = unwrapQuoted(inputContent);
        const hasInitialDom = !isEmptyHtml(initialHtmlRaw);
        const hasInputValue = !isEmptyHtml(inputContent);

        if (hasInitialDom) {
            quill.root.innerHTML = initialHtmlRaw;
            if (input) input.value = quill.root.innerHTML;
        } else if (hasInputValue) {
            quill.root.innerHTML = inputContent;
        } // sinon, on garde l’état vide de Quill

        // 5) Sync en permanence vers l’input hidden
        if (input) {
            quill.on('text-change', () => {
                input.value = quill.root.innerHTML;
            });
        }

        // 6) Ajout des pickers couleur
        addQuillColorPickers(quill);

        // 7) Coller en texte brut (Alt = garder la mise en forme)
        quill.root.addEventListener('paste', (e) => {
            if (e.altKey) return;
            e.preventDefault();
            e.stopPropagation();
            const text = (e.clipboardData || window.clipboardData)?.getData('text/plain') || '';
            if (!text) return;
            const sel = quill.getSelection(true);
            quill.deleteText(sel.index, sel.length, 'user');
            quill.insertText(sel.index, text, 'user');
            quill.setSelection(sel.index + text.length, 0, 'silent');
        }, true);
    });

    const form = body.querySelector('#content-edit-form');


    reinitUI(body);
}




// ===================== Menu section et lignes ======================


// ---- Menu header pour SECTIONS/LIGNES ----
async function fetchEditingMenuStructure() {
  // À adapter côté serveur : renvoie le fragment <nav class="editing-menu">…</nav>
  // ex: templates/administration_pages/structure/editing_menu.html
  const url = '/jeiko/administration/pages/editing-menu-section-line/';
  try {
    const res = await fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' }});
    if (res.ok) return await res.text();
  } catch (e) {
    console.warn('Impossible de charger le menu d’édition (structure) :', e);
  }
  return '';
}

// ===================== CRUD Sections ======================


// ——— helper optionnel pour insérer le fragment section dans le DOM

function insertSectionFragment(fragHtml, parentSelector, emptyText = "") {

    if (!fragHtml) return;
    const parent = document.querySelector(parentSelector);
    if (!parent) return;

    // Supprimer le message "Aucune ..." si présent
    if (emptyText) {
        const noMsg = parent.querySelector('h4');
        if (noMsg && noMsg.textContent.includes(emptyText)) noMsg.remove();
    }

    // Insertion avant bouton .add si trouvé, sinon à la fin
    const addBtn = parent.querySelector('.section-add, .line-add, .bloc-add');
    let inserted = null;
    if (addBtn) {
        addBtn.insertAdjacentHTML('beforebegin', fragHtml);
        inserted = addBtn.previousElementSibling;
    } else {
        parent.insertAdjacentHTML('beforeend', fragHtml);
        inserted = parent.lastElementChild;
    }

    reinitUI(inserted || parent);
}


export async function createSection(pageId) {
    const url = `/jeiko/administration/pages/${pageId}/sections/add/`;

    const res = await fetch(url, {
        method: 'GET',
        headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'X-CSRFToken': csrftoken
        }
    });

    if (!res.ok) {
        showToast('Erreur serveur');
        return;
    }

    let data;
    try {
        data = await res.json();
    } catch {
        data = {};
    }

    if (data.status === 'choose_type' && data.html) {
        showModal(data.html, 'Créer une section');
        setTimeout(() => {
            attachAjaxFormHandler('choose-section-form', postData => {
                const frag = postData.html || postData.section_html || postData.content_html || '';
                insertSectionFragment(frag, '#content', "Aucune section");
                showToast('Section créée');
            });
        }, 0);
    } else if (data.status === 'success') {
        const frag = data.html || data.section_html || data.content_html || '';
        insertSectionFragment(frag, '#content', "Aucune section");
    }
}


export async function editSection(pageId, sectionId) {
  const url = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/update/`;
  const html = await fetchHtml(url);

  const headerMenu = await fetchEditingMenuStructure();
  showModal(html, headerMenu || 'Modifier la section');

  const body = document.querySelector('#editor-modal .modal-body');

  // Si le template serveur contenait encore un <nav.editing-menu> dans le body → on le vire
  body?.querySelector('.editing-menu')?.remove();

  // Onglet par défaut (si tes IDs sont ceux-là)
  try { showEditingParameters('global-parameters'); } catch {}

  setTimeout(() => {
    attachAjaxFormHandler('section-form', data => {
      const frag = data.html || data.section_html || data.content_html || '';
      const old = document.getElementById(`section-${sectionId}`);
      if (frag && old) {
        old.outerHTML = frag;
        reinitUI(document.getElementById(`section-${sectionId}`) || document);
      }
    });
    reinitUI(body);
  }, 0);
}


export function removeSection(pageId, sectionId) {
    showConfirmModal("Es-tu sûr de vouloir supprimer cette section ?", async () => {
        const url = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/delete/`;
        const res = await fetch(url, {
            method: 'POST',
            headers: {
                'X-CSRFToken': csrftoken,
                'X-Requested-With': 'XMLHttpRequest'
            }
        });
        if (!res.ok) {
            showToast("Erreur lors de la suppression");
            return;
        }

        const data = await res.json();
        if (data.status === 'success') {
            document.getElementById(`section-${sectionId}`)?.remove();
            showToast("Section supprimée");
            const content = document.getElementById('content');
            if (content && !content.querySelector('.section')) {
                const msg = document.createElement('h4');
                msg.textContent = "Aucune section créée pour l'instant";
                content.querySelector('.section-add')?.insertAdjacentElement('beforebegin', msg);
            }
            reinitUI(document);
        } else {
            showToast(data.message || "Erreur lors de la suppression");
        }
    });
}


export async function moveSectionUp(pageId, sectionId) {
    const url = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/move_up/`;
    const res = await fetch(url, {
        method: 'POST',
        headers: {
            'X-CSRFToken': csrftoken,
            'X-Requested-With': 'XMLHttpRequest'
        }
    });
    if (!res.ok) {
        showToast('Erreur serveur');
        return;
    }

    const data = await res.json();
    if (data.status === 'success') {
        const container = document.getElementById('content');
        const secs = Array.from(container.querySelectorAll('.section'));
        const idx = secs.findIndex(el => el.id === `section-${sectionId}`);
        if (idx > 0) {
            container.insertBefore(secs[idx], secs[idx - 1]);
            showToast('Section déplacée vers le haut');
            reinitUI(container);
        }
    } else {
        showToast(data.message || 'Erreur');
    }
}


export async function moveSectionDown(pageId, sectionId) {
    const url = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/move_down/`;
    const res = await fetch(url, {
        method: 'POST',
        headers: {
            'X-CSRFToken': csrftoken,
            'X-Requested-With': 'XMLHttpRequest'
        }
    });
    if (!res.ok) {
        showToast('Erreur serveur');
        return;
    }

    const data = await res.json();
    if (data.status === 'success') {
        const container = document.getElementById('content');
        const secs = Array.from(container.querySelectorAll('.section'));
        const idx = secs.findIndex(el => el.id === `section-${sectionId}`);
        if (idx < secs.length - 1) {
            container.insertBefore(secs[idx + 1], secs[idx]);
            showToast('Section déplacée vers le bas');
            reinitUI(container);
        }
    } else {
        showToast(data.message || 'Erreur');
    }
}


export async function makeSectionModel(sectionId) {
    const input = document.getElementById('model-name-input');
    const feedback = document.getElementById('model-feedback');
    const name = (input?.value || '').trim();

    const paint = (msg, ok) => {
        if (!feedback) return;
        feedback.textContent = msg;
        feedback.style.color = ok ? '#0a7d32' : '#b00020';
    };

    if (!name) {
        paint("Merci de saisir un nom de modèle.", false);
        return;
    }

    try {
        const res = await fetch(`/api/pages/sections/${sectionId}/make_model/`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': csrftoken,
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify({
                model_name: name
            })
        });

        if (!res.ok) {
            const txt = await res.text();
            paint(txt || "Erreur lors de la création du modèle.", false);
            showToast("Erreur lors de la création du modèle");
            return;
        }

        const data = await res.json();
        if (data.success) {
            paint("Modèle créé avec succès.", true);
            showToast("Modèle créé");
        } else {
            paint(data.message || "Erreur lors de la création du modèle.", false);
            showToast(data.message || "Erreur");
        }
    } catch {
        paint("Erreur réseau.", false);
        showToast("Erreur réseau");
    }
}


// ===================== CRUD Lines ======================

export async function createLine(pageId, sectionId) {
    const url = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/lines/add/`;
    const res = await fetch(url, {
        method: 'GET',
        headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'X-CSRFToken': csrftoken
        }
    });

    if (!res.ok) {
        showToast('Erreur serveur');
        return;
    }

    let payload, isJson = false;
    try {
        payload = await res.clone().json();
        isJson = true;
    } catch {
        payload = await res.text();
    }

    if (isJson && payload.status === 'choose_type' && payload.html) {
        showModal(payload.html, 'Créer une ligne');
        setTimeout(() => {
            attachAjaxFormHandler('choose-line-form', data => {
                const frag = data.section_html || data.line_html || data.html || '';
                insertSectionFragment(frag, `#section-${sectionId}`, "Aucune ligne");
                showToast('Ligne créée');
            });
        }, 0);
    } else {
        showModal(payload, 'Créer une ligne');
        setTimeout(() => {
            attachAjaxFormHandler('choose-line-form', data => {
                const frag = data.section_html || data.line_html || data.html || '';
                insertSectionFragment(frag, `#section-${sectionId}`, "Aucune ligne");
                showToast('Ligne créée');
            });
        }, 0);
    }
}


export async function editLine(pageId, sectionId, lineId) {
  const url = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/lines/${lineId}/update/`;
  const html = await fetchHtml(url);

  const headerMenu = await fetchEditingMenuStructure();
  showModal(html, headerMenu || 'Modifier la ligne');

  const body = document.querySelector('#editor-modal .modal-body');
  body?.querySelector('.editing-menu')?.remove();

  try { showEditingParameters('global-parameters'); } catch {}

  setTimeout(() => {
    attachAjaxFormHandler('line-form', data => {
      const frag = data.section_html || data.line_html || data.html || '';
      const old = document.getElementById(`section-${sectionId}`);
      if (frag && old) {
        old.outerHTML = frag;
        reinitUI(document.getElementById(`section-${sectionId}`) || document);
      }
    });
    reinitUI(body);
  }, 0);
}


export function removeLine(pageId, sectionId, lineId) {
    showConfirmModal("Es-tu sûr de vouloir supprimer cette ligne ?", async () => {
        const url = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/lines/${lineId}/delete/`;
        const res = await fetch(url, {
            method: 'POST',
            headers: {
                'X-CSRFToken': csrftoken,
                'X-Requested-With': 'XMLHttpRequest'
            }
        });
        if (!res.ok) {
            showToast("Erreur lors de la suppression");
            return;
        }

        const data = await res.json();
        if (data.status === 'success') {
            document.getElementById(`line-${lineId}`)?.remove();
            showToast("Ligne supprimée");
            const sectionEl = document.getElementById(`section-${sectionId}`);
            if (sectionEl && !sectionEl.querySelector('.line')) {
                const msg = document.createElement('h4');
                msg.textContent = "Aucune ligne créée pour l'instant";
                sectionEl.querySelector('.overlay-section')?.insertAdjacentElement('beforebegin', msg);
            }
            reinitUI(document);
        } else {
            showToast(data.message || "Erreur lors de la suppression");
        }
    });
}


export async function moveLineUp(pageId, sectionId, lineId) {
    const url = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/lines/${lineId}/move_up/`;
    const res = await fetch(url, {
        method: 'POST',
        headers: {
            'X-CSRFToken': csrftoken,
            'X-Requested-With': 'XMLHttpRequest'
        }
    });
    if (!res.ok) {
        showToast('Erreur serveur');
        return;
    }

    const data = await res.json();
    if (data.status === 'success') {
        const sectionEl = document.getElementById(`section-${sectionId}`);
        const lines = Array.from(sectionEl.querySelectorAll('.line'));
        const idx = lines.findIndex(el => el.id === `line-${lineId}`);
        if (idx > 0) {
            sectionEl.insertBefore(lines[idx], lines[idx - 1]);
            showToast('Ligne déplacée vers le haut');
            reinitUI(sectionEl);
        }
    } else {
        showToast(data.message || 'Erreur');
    }
}


export async function moveLineDown(pageId, sectionId, lineId) {
    const url = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/lines/${lineId}/move_down/`;
    const res = await fetch(url, {
        method: 'POST',
        headers: {
            'X-CSRFToken': csrftoken,
            'X-Requested-With': 'XMLHttpRequest'
        }
    });
    if (!res.ok) {
        showToast('Erreur serveur');
        return;
    }

    const data = await res.json();
    if (data.status === 'success') {
        const sectionEl = document.getElementById(`section-${sectionId}`);
        const lines = Array.from(sectionEl.querySelectorAll('.line'));
        const idx = lines.findIndex(el => el.id === `line-${lineId}`);
        if (idx < lines.length - 1) {
            sectionEl.insertBefore(lines[idx + 1], lines[idx]);
            showToast('Ligne déplacée vers le bas');
            reinitUI(sectionEl);
        }
    } else {
        showToast(data.message || 'Erreur');
    }
}


export async function makeLineModel(lineId) {
    const input = document.getElementById('line-model-name-input');
    const feedback = document.getElementById('line-model-feedback');
    const name = (input?.value || '').trim();

    const paint = (msg, ok) => {
        if (!feedback) return;
        feedback.textContent = msg;
        feedback.style.color = ok ? '#0a7d32' : '#b00020';
    };

    if (!lineId) {
        paint("ID de ligne manquant.", false);
        return;
    }
    if (!name) {
        paint("Merci de saisir un nom de modèle.", false);
        return;
    }

    try {
        const res = await fetch(`/api/pages/lines/${lineId}/make_model/`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': csrftoken,
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify({
                model_name: name
            })
        });

        if (!res.ok) {
            const txt = await res.text();
            paint(txt || "Erreur lors de la création du modèle.", false);
            showToast("Erreur lors de la création du modèle");
            return;
        }

        const data = await res.json();
        if (data.success) {
            paint("Modèle créé avec succès.", true);
            showToast("Modèle de ligne créé");
        } else {
            paint(data.message || "Erreur lors de la création du modèle.", false);
            showToast(data.message || "Erreur");
        }
    } catch {
        paint("Erreur réseau.", false);
        showToast("Erreur réseau");
    }
}


// ===================== CRUD Content (Blocs) ======================

export async function chooseContentType(pageId, sectionId, lineId, blocId) {
    const url = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/lines/${lineId}/blocs/${blocId}/content/add/`;
    const res = await fetch(url, {
        method: 'GET',
        headers: {
            'X-CSRFToken': csrftoken,
            'X-Requested-With': 'XMLHttpRequest'
        }
    });
    if (!res.ok) {
        showToast('Erreur serveur');
        return;
    }
    const data = await res.json();

    if (data.status === 'choose_type') {
        showModal(data.html, '<h1>Choisir le type de contenu</h1>');
        setTimeout(() => {
            attachAjaxFormHandler('choose-content-form', chooseData => {
                if (chooseData.status === 'success') {
                    editContent(pageId, sectionId, lineId, blocId);
                } else {
                    showToast(chooseData.message || 'Erreur inattendue');
                }
            });
            attachBlocModelHandler('choose-bloc-model-form', pageId, sectionId, lineId, blocId);

            reinitUI(document.querySelector('.modal-body') || document);
        }, 0);

    } else if (data.status === 'success') {
        editContent(pageId, sectionId, lineId, blocId);

    } else {
        showToast(data.message || 'Erreur inattendue');
    }
}


export async function showEditingParameters(id) {
  // toggle panneaux
  document.querySelectorAll('.editing-parameters').forEach(section => {
    section.style.display = (section.id === id) ? '' : 'none';
  });

  // toggle actif sur les boutons du menu du modal
  const modal = document.getElementById('editor-modal');
  if (!modal) return;

  modal.querySelectorAll('.editing-menu button').forEach(btn => {
    const target =
      btn.getAttribute('data-target') ||
      ((btn.getAttribute('onclick') || '').match(/showEditingParameters\('([^']+)'\)/) || [])[1];

    const isActive = target === id;
    btn.classList.toggle('active', isActive);
    btn.setAttribute('aria-selected', isActive ? 'true' : 'false');
  });
}


async function fetchEditingMenu() {
    try {
        const response = await fetch(
            '/jeiko/administration/pages/editing-menu/', {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            }
        );
        if (response.ok) {
            return await response.text();
        }
    } catch (e) {
        console.warn('Impossible de charger le menu d’édition :', e);
    }
    return '';
}


export async function editContent(pageId, sectionId, lineId, blocId) {
  const url = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/lines/${lineId}/blocs/${blocId}/content/edit/`;

  const res = await fetch(url, {
    method: 'GET',
    headers: {
      'X-CSRFToken': csrftoken,
      'X-Requested-With': 'XMLHttpRequest'
    }
  });

  if (!res.ok) {
    showToast('Erreur serveur');
    return;
  }

  const data = await res.json();

  // Le GET renvoie {status:"ok", html: "..."}.
  // On accepte "ok" OU "success" et on vérifie la présence de html/section_html.
  const hasHtml = !!(data.html || data.section_html);
  const isOk = (data.status === 'ok' || data.status === 'success');

  if (isOk && hasHtml) {
    const menuHtml = await fetchEditingMenu();

    // Injecte le HTML
    showModal(data.html, menuHtml || 'Édition du contenu');

    // Récupère le corps du modal et l’élément racine du modal
    const body = document.querySelector('.modal-body');
    const modalEl = body?.closest('#editor-modal') || document.getElementById('editor-modal') || document;

    // Inits spécifiques
    initQuillInModal(body, blocId);
    showEditingParameters('content-parameters');

    // 🔧 Init du preview + sauvegarde de style (formulaire)
    if (window.InitFormulaireStyle) {
      window.InitFormulaireStyle(modalEl);
    } else if (window.jeikoInitFormulaireStyle) {
      // compat si tu avais gardé l’ancien nom
      window.jeikoInitFormulaireStyle(modalEl);
    }

    // Re-init UI divers (drag, formsets, etc.)
    reinitUI(body);

    // Brancher la soumission AJAX du form d'édition
    setTimeout(() => {
      attachAjaxFormHandler('content-edit-form', editData => {
        const frag = editData.section_html || editData.line_html || editData.html || '';
        if (frag) {
          const old = document.getElementById(`section-${sectionId}`);
          if (old) {
            old.outerHTML = frag;
            const newSection = document.getElementById(`section-${sectionId}`) || document;
            executeInlineScripts(newSection);
            initAlpineOn(newSection);
            reinitUI(newSection);
          }
        }
      });
    }, 0);

  } else {
    showToast(data.message || 'Erreur inattendue');
  }
}



export function resetContent(pageId, sectionId, lineId, blocId) {
    showConfirmModal("Remettre le contenu à zéro ?", async () => {
        const url = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/lines/${lineId}/blocs/${blocId}/content/reset/`;
        const res = await fetch(url, {
            method: 'POST',
            headers: {
                'X-CSRFToken': csrftoken,
                'X-Requested-With': 'XMLHttpRequest'
            },
        });
        if (!res.ok) {
            showToast("Erreur");
            return;
        }

        const data = await res.json();
        if (data.status === 'reset' && (data.section_html || data.html)) {
            if (data.section_html || data.html) {
                const frag = data.section_html || data.line_html || data.html || '';
                const old = document.getElementById(`section-${sectionId}`);
                if (frag && old) {
                    old.outerHTML = frag;
                    reinitUI(document.getElementById(`section-${sectionId}`) || document);
                }
            }

            showToast("Contenu réinitialisé");

            // ⚡️ Ensuite on relance directement la sélection de type de contenu
            chooseContentType(pageId, sectionId, lineId, blocId);

        } else {
            showToast(data.message || "Erreur");
        }
    });
}


export async function addBloc(pageId, sectionId, lineId, blocId) {
    const url = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/lines/${lineId}/blocs/${blocId}/add/`;
    fetch(url, {
            method: 'POST',
            headers: {
                'X-CSRFToken': csrftoken,
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(res => res.json())
        .then(data => {
            if (data.status === "success") {
                if (data.section_html || data.html) {
                    const frag = data.section_html || data.line_html || data.html || '';
                    const old = document.getElementById(`section-${sectionId}`);
                    if (frag && old) {
                        old.outerHTML = frag;
                        reinitUI(document.getElementById(`section-${sectionId}`) || document);

                    }
                }
                reinitUI(document);
                // ouvrir directement le choix de contenu
                chooseContentType(pageId, sectionId, lineId, data.new_bloc_id);
            } else {
                showToast(data.message || "Erreur serveur");
            }
        });
}


export function removeBloc(pageId, sectionId, lineId, blocId) {
    showConfirmModal("Es-tu sûr de vouloir supprimer ce bloc ?", async () => {
        const url = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/lines/${lineId}/blocs/${blocId}/delete/`;

        try {
            const res = await fetch(url, {
                method: 'POST',
                headers: {
                    'X-CSRFToken': csrftoken,
                    'X-Requested-With': 'XMLHttpRequest'
                }
            });

            if (!res.ok) {
                showToast("Erreur lors de la suppression");
                return;
            }

            const data = await res.json();
            if (data.status === "success") {
                if (data.section_html || data.html) {
                    const frag = data.section_html || data.line_html || data.html || '';
                    const old = document.getElementById(`section-${sectionId}`);
                    if (frag && old) {
                        old.outerHTML = frag;
                        reinitUI(document.getElementById(`section-${sectionId}`) || document);

                    }
                }
                reinitUI(document);
            } else {
                showToast(data.message || "Erreur lors de la suppression");
            }
        } catch (err) {
            console.error("removeBloc error:", err);
            showToast("Erreur réseau lors de la suppression");
        }
    });
}


export async function moveBlocUp(pageId, sectionId, lineId, blocId) {
    const url = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/lines/${lineId}/blocs/${blocId}/move_up/`;
    fetch(url, {
            method: 'POST',
            headers: {
                'X-CSRFToken': csrftoken,
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(res => res.json())
        .then(data => {
            if (data.status === "success") {
                if (data.section_html) {
                    const old = document.getElementById(`section-${sectionId}`);
                    if (old) {
                        old.outerHTML = data.section_html;
                        reinitUI(document.getElementById(`section-${sectionId}`) || document);
                    }
                }
                reinitUI(document);
            } else {
                showToast(data.message || "Erreur serveur");
            }
        });
}


export async function moveBlocDown(pageId, sectionId, lineId, blocId) {
    const url = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/lines/${lineId}/blocs/${blocId}/move_down/`;
    fetch(url, {
            method: 'POST',
            headers: {
                'X-CSRFToken': csrftoken,
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(res => res.json())
        .then(data => {
            if (data.status === "success") {
                if (data.section_html) {
                    const old = document.getElementById(`section-${sectionId}`);
                    if (old) {
                        old.outerHTML = data.section_html;
                        reinitUI(document.getElementById(`section-${sectionId}`) || document);
                    }
                }
                reinitUI(document);
            } else {
                showToast(data.message || "Erreur serveur");
            }
        });
}


export async function moveBlocLeft(pageId, sectionId, lineId, blocId) {
    const url = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/lines/${lineId}/blocs/${blocId}/move_left/`;
    fetch(url, {
            method: 'POST',
            headers: {
                'X-CSRFToken': csrftoken,
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(res => res.json())
        .then(data => {
            if (data.status === "success") {
                if (data.section_html) {
                    const old = document.getElementById(`section-${sectionId}`);
                    if (old) {
                        old.outerHTML = data.section_html;
                        reinitUI(document.getElementById(`section-${sectionId}`) || document);
                    }
                }
                reinitUI(document);
            } else {
                showToast(data.message || "Erreur serveur");
            }
        });
}


export async function moveBlocRight(pageId, sectionId, lineId, blocId) {
    const url = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/lines/${lineId}/blocs/${blocId}/move_right/`;
    fetch(url, {
            method: 'POST',
            headers: {
                'X-CSRFToken': csrftoken,
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(res => res.json())
        .then(data => {
            if (data.status === "success") {
                if (data.section_html) {
                    const old = document.getElementById(`section-${sectionId}`);
                    if (old) {
                        old.outerHTML = data.section_html;
                        reinitUI(document.getElementById(`section-${sectionId}`) || document);
                    }
                }
                reinitUI(document);
            } else {
                showToast(data.message || "Erreur serveur");
            }
        });
}


// ---- Content -> modèle ----
export async function makeContentModel(contentId) {
    const input = document.getElementById('content-model-name-input');
    const feedback = document.getElementById('content-model-feedback');
    const name = (input?.value || '').trim();

    const paint = (msg, ok) => {
        if (!feedback) return;
        feedback.textContent = msg;
        feedback.style.color = ok ? '#0a7d32' : '#b00020';
    };

    if (!contentId) {
        paint("ID de contenu manquant.", false);
        return;
    }
    if (!name) {
        paint("Donne un nom au modèle ;)", false);
        return;
    }

    try {
        const res = await fetch(`/api/pages/contents/${contentId}/make_model/`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest',
                'X-CSRFToken': getCookie('csrftoken'),
            },
            body: JSON.stringify({
                model_name: name
            })
        });

        if (!res.ok) {
            const msg = await res.text();
            paint(msg || "Erreur serveur.", false);
            return;
        }
        const data = await res.json();
        if (data.success) {
            paint("Modèle de contenu créé : " + (data.model?.name || "OK"), true);
            showToast?.("Modèle de contenu créé");
        } else {
            paint(data.message || "Erreur lors de la création du modèle.", false);
        }
    } catch (e) {
        paint("Erreur réseau.", false);
    }
}

// ---- Bloc -> modèle ----

export async function makeBlocModel(blocId) {
    const input = document.getElementById('bloc-model-name-input');
    const feedback = document.getElementById('bloc-model-feedback');
    const name = (input?.value || '').trim();

    const paint = (msg, ok) => {
        if (!feedback) return;
        feedback.textContent = msg;
        feedback.style.color = ok ? '#0a7d32' : '#b00020';
    };

    if (!blocId) {
        paint("ID de bloc manquant.", false);
        return;
    }
    if (!name) {
        paint("Donne un nom au modèle ;)", false);
        return;
    }

    try {
        const res = await fetch(`/api/pages/blocs/${blocId}/make_model/`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest',
                'X-CSRFToken': getCookie('csrftoken'),
            },
            body: JSON.stringify({
                model_name: name
            })
        });

        if (!res.ok) {
            const msg = await res.text();
            paint(msg || "Erreur serveur.", false);
            return;
        }
        const data = await res.json();
        if (data.success) {
            paint("Modèle de bloc créé : " + (data.model?.name || "OK"), true);
            showToast?.("Modèle de bloc créé");
        } else {
            paint(data.message || "Erreur lors de la création du modèle.", false);
        }
    } catch (e) {
        paint("Erreur réseau.", false);
    }
}


// ---- Remplacement par un bloc modèle ----
export function attachBlocModelHandler(formId, pageId, sectionId, lineId, blocId) {
    const form = document.getElementById(formId);
    if (!form) return;

    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        const url = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/lines/${lineId}/blocs/${blocId}/content/add_from_model/`;
        const formData = new FormData(form);

        try {
            const res = await fetch(url, {
                method: 'POST',
                headers: {
                    'X-CSRFToken': csrftoken,
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: formData
            });
            if (!res.ok) {
                showToast("Erreur lors de l’insertion du modèle");
                return;
            }
            const data = await res.json();

            if (data.status === 'success' && (data.section_html || data.html)) {
                // Remplacer le bloc actuel par le nouveau HTML
                const old = document.getElementById(`section-${sectionId}`);
                const frag = data.section_html || data.line_html || data.html || '';
                if (old && frag) {
                    old.outerHTML = frag;

                    reinitUI(document.getElementById(`section-${sectionId}`) || document);
                }
                closeModal();
                showToast("Bloc inséré depuis modèle");
                reinitUI(document);
            } else {
                showToast(data.message || "Erreur lors de l’insertion du modèle");
            }
        } catch (err) {
            console.error(err);
            showToast("Erreur réseau");
        }
    });
}


// ===================== CRUD Formulaire (inline, sans nested <form>) ======================

function getFormulaireId() {
    const holder = document.querySelector('[data-formulaire-id]');
    if (holder?.dataset.formulaireId) return holder.dataset.formulaireId;
    const ul = document.getElementById('fields-list');
    if (ul?.dataset.formulaireId) return ul.dataset.formulaireId;
    return null;
}
function csrfHeaders(json = false) {
    const h = { 'X-Requested-With': 'XMLHttpRequest', 'X-CSRFToken': getCookie('csrftoken') };
    if (json) h['Content-Type'] = 'application/json';
    return h;
}

function fieldEditorHtml(initial = {}, mode = 'add') {
    const types = ['text','email','phone','textarea','select','checkbox','date','number'];
    const optsStr = Array.isArray(initial.options) ? initial.options.join(', ')
        : (typeof initial.options === 'object' ? JSON.stringify(initial.options) : (initial.options || ''));
    return `
        <div class="field-inline-editor" data-mode="${mode}" style="border:1px dashed #bbb; padding:1em; margin-top:1em; border-radius:6px;">
            <h5 style="margin:0 0 .75em;">${mode === 'add' ? 'Ajouter un champ' : 'Éditer le champ'}</h5>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:.75rem;">
                <label>Label
                    <input type="text" name="label" value="${(initial.label||'').replace(/"/g,'&quot;')}" required>
                </label>
                <label>Nom technique
                    <input type="text" name="name" value="${(initial.name||'').replace(/"/g,'&quot;')}" required>
                </label>
                <label>Type
                    <select name="type">
                        ${types.map(t => `<option value="${t}" ${t===(initial.type||'')?'selected':''}>${t}</option>`).join('')}
                    </select>
                </label>
                <label>Obligatoire
                    <input type="checkbox" name="required" ${initial.required ? 'checked' : ''}>
                </label>
            </div>
            <div style="margin-top:.75rem;">
                <label>Options (JSON ou valeurs séparées par virgule pour select/checkbox)
                    <input type="text" name="options" placeholder='["Option A","Option B"] ou A, B' value="${(optsStr||'').replace(/"/g,'&quot;')}">
                </label>
            </div>
            <div style="display:flex; gap:.5rem; margin-top:1rem;">
                <button type="button" class="btn btn-primary" data-action="save">${mode === 'add' ? 'Ajouter' : 'Enregistrer'}</button>
                <button type="button" class="btn" data-action="cancel">Annuler</button>
            </div>
        </div>
    `;
}
function mountEditor(container, html, onSave) {
    container.innerHTML = html;
    container.style.display = '';
    const $ = sel => container.querySelector(sel);
    const getPayload = () => {
        const p = {
            label: $('input[name="label"]').value.trim(),
            name: $('input[name="name"]').value.trim(),
            type: $('select[name="type"]').value,
            required: $('input[name="required"]').checked,
            options: $('input[name="options"]').value
        };
        if (p.options && (p.type === 'select' || p.type === 'checkbox')) {
            const txt = String(p.options).trim();
            if (txt.startsWith('[') || txt.startsWith('{')) { try { p.options = JSON.parse(txt); } catch {} }
            if (typeof p.options === 'string') p.options = txt.split(',').map(s => s.trim()).filter(Boolean);
        } else {
            delete p.options;
        }
        return p;
    };
    $('button[data-action="save"]').onclick = async () => {
        await onSave(getPayload());
        container.innerHTML = '';
        container.style.display = 'none';
    };
    $('button[data-action="cancel"]').onclick = () => {
        container.innerHTML = '';
        container.style.display = 'none';
    };
    container.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && e.target.tagName !== 'TEXTAREA') {
            e.preventDefault();
            $('button[data-action="save"]').click();
        }
    });
}

/* ---- ADD (inline) ---- */
function showAddFieldInline(formulaireId) {
    const container = document.getElementById('field-inline-editor');
    if (!container) return alert("Zone d'édition introuvable (#field-inline-editor).");
    mountEditor(container, fieldEditorHtml({}, 'add'), async (payload) => {
        const res = await fetch(`/api/pages/formulaires/${formulaireId}/fields/`, {
            method: 'POST',
            headers: csrfHeaders(true),
            credentials: 'same-origin',
            body: JSON.stringify(payload)
        });
        if (!res.ok) { alert("Échec de l'ajout du champ."); return; }
        await reloadFieldsList(formulaireId);
    });
}
/* compat : conserve le nom attendu par le bouton */
function showAddFieldForm(formulaireId) { showAddFieldInline(formulaireId); }

/* ---- EDIT ---- */
async function editField(fieldId) {
    const formulaireId = getFormulaireId();
    if (!formulaireId) return alert("Formulaire introuvable.");
    const res = await fetch(`/api/pages/formulaires/${formulaireId}/fields/${fieldId}/`, {
        headers: csrfHeaders(),
        credentials: 'same-origin'
    });
    if (!res.ok) return alert("Impossible de charger le champ.");
    const field = await res.json();

    const container = document.getElementById('field-inline-editor');
    if (!container) return alert("Zone d'édition introuvable (#field-inline-editor).");

    mountEditor(container, fieldEditorHtml(field, 'edit'), async (payload) => {
        const res2 = await fetch(`/api/pages/formulaires/${formulaireId}/fields/${fieldId}/`, {
            method: 'PUT',
            headers: csrfHeaders(true),
            credentials: 'same-origin',
            body: JSON.stringify(payload)
        });
        if (!res2.ok) { alert("Échec de la mise à jour du champ."); return; }
        await reloadFieldsList(formulaireId);
    });
}

/* ---- DELETE ---- */
async function deleteField(fieldId) {
    if (!confirm("Supprimer ce champ ?")) return;
    const formulaireId = getFormulaireId();
    if (!formulaireId) return alert("Formulaire introuvable.");
    const res = await fetch(`/api/pages/formulaires/${formulaireId}/fields/${fieldId}/`, {
        method: 'DELETE',
        headers: csrfHeaders(),
        credentials: 'same-origin'
    });
    if (!res.ok) return alert("Suppression impossible.");
    await reloadFieldsList(formulaireId);
}

/* ---- MOVE ---- */
async function moveFieldUp(id){ return moveField(id,-1); }
async function moveFieldDown(id){ return moveField(id,1); }
async function moveField(fieldId, direction) {
    const fieldsList = Array.from(document.querySelectorAll('#fields-list li'));
    const idx = fieldsList.findIndex(li => li.dataset.fieldId == fieldId);
    if (idx === -1) return;
    const newIdx = idx + direction;
    if (newIdx < 0 || newIdx >= fieldsList.length) return;
    [fieldsList[idx], fieldsList[newIdx]] = [fieldsList[newIdx], fieldsList[idx]]; // swap visuel

    const formulaireId = getFormulaireId();
    if (!formulaireId) return alert("Formulaire introuvable.");
    const newOrder = fieldsList.map((li, i) => ({ id: li.dataset.fieldId, order: i }));

    const res = await fetch(`/api/pages/formulaires/${formulaireId}/fields/`, {
        method: 'PATCH',
        headers: csrfHeaders(true),
        credentials: 'same-origin',
        body: JSON.stringify({ fields: newOrder })
    });
    if (!res.ok) return alert("Réordonnancement impossible.");
    await reloadFieldsList(formulaireId);
}

/* ---- RELOAD LIST ---- */
async function reloadFieldsList(formulaireId) {
    const res = await fetch(`/api/pages/formulaires/${formulaireId}/`, {
        headers: { 'X-Requested-With': 'XMLHttpRequest' },
        credentials: 'same-origin'
    });
    if (!res.ok) return;
    const data = await res.json();
    const ul = document.getElementById('fields-list');
    if (!ul) return;
    ul.innerHTML = "";
    for (const field of (data.fields || [])) {
        ul.insertAdjacentHTML('beforeend', `
            <li data-field-id="${field.id}" style="margin:0 0 .5em 0; display:flex; align-items:center; gap:.5em; flex-wrap:wrap;">
                <span>
                    <strong>${field.label}</strong> <em>(${field.type})</em>${field.required ? ' <span style="color:red;">*</span>' : ''}
                    ${field.name ? `<span style="color:#888;"> — nom : ${field.name}</span>` : ''}
                </span>
                <span style="flex:1 1 auto;"></span>
                <button type="button" class="btn btn-xs" onclick="editField(${field.id})">éditer</button>
                <button type="button" class="btn btn-xs btn-danger" onclick="deleteField(${field.id})">supprimer</button>
                <button type="button" class="btn btn-xs" title="Monter" onclick="moveFieldUp(${field.id})">&#x25B2;</button>
                <button type="button" class="btn btn-xs" title="Descendre" onclick="moveFieldDown(${field.id})">&#x25BC;</button>

            </li>
        `);
    }
}


function closeFieldForm() {
  // cache l’éditeur inline s’il existe
  const inline = document.getElementById('field-inline-editor');
  if (inline) {
    inline.innerHTML = '';
    inline.style.display = 'none';
  }
  // cache l’ancien conteneur modal s’il traîne encore
  const legacy = document.getElementById('add-edit-field-modal');
  if (legacy) {
    legacy.innerHTML = '';
    legacy.style.display = 'none';
  }
}
window.closeFieldForm = closeFieldForm;


// Initialisation du preview + sauvegarde du style
window.InitFormulaireStyle = function(scopeRoot) {
  const root = scopeRoot || document;
  const wrap = root.querySelector('#form-style-preview');
  if (!wrap) return;

  const API_URL = wrap.dataset.apiUrl;
  const $fs   = wrap.querySelector('#style_title_font_size_px');
  const $tc   = wrap.querySelector('#style_title_color');
  const $bfg  = wrap.querySelector('#style_btn_bg');
  const $bfgH = wrap.querySelector('#style_btn_bg_hover');
  const $btx  = wrap.querySelector('#style_btn_text_color');
  const $br   = wrap.querySelector('#style_btn_radius_px');

  const $btnPreview = wrap.querySelector('.btn-preview');
  const $styleTag   = wrap.querySelector('#btn-preview-style');
  const $feedback   = wrap.querySelector('#style-save-feedback');

  const readVal = (el, fallback=null) => {
    if (!el) return fallback;
    const v = (el.value ?? '').trim();
    return v === '' ? fallback : v;
  };

  const paintPreview = () => {
    if ($btnPreview) {
      $btnPreview.style.backgroundColor = readVal($bfg,  '#ff4e0f');
      $btnPreview.style.color           = readVal($btx,  '#ffffff');
      const rad = parseInt(readVal($br, 20), 10);
      $btnPreview.style.borderRadius    = (isNaN(rad) ? 20 : rad) + 'px';
      $btnPreview.style.borderColor     = 'transparent';
      $btnPreview.style.borderWidth     = '1px';
      $btnPreview.style.borderStyle     = 'solid';
    }
    const hov = readVal($bfgH, '#e3450e');
    if ($styleTag) {
      $styleTag.textContent =
        "#form-style-preview .btn-preview:hover{background:"+ hov +" !important;}";
    }
  };

  const debounce = (fn, ms=400) => {
    let t; return (...args) => { clearTimeout(t); t = setTimeout(() => fn.apply(null,args), ms); };
  };

  const saveStyle = async () => {
    if (!API_URL) return;
    const payload = {
      style: {
        title_font_size_px: parseInt(readVal($fs, 24), 10),
        title_color:        readVal($tc,  '#111111'),
        btn_text_color:     readVal($btx, '#ffffff'),
        btn_bg:             readVal($bfg, '#ff4e0f'),
        btn_bg_hover:       readVal($bfgH,'#e3450e'),
        btn_radius_px:      parseInt(readVal($br, 20), 10),
      }
    };
    try {
      const res = await fetch(API_URL, {
        method: 'POST',
        headers: {'Content-Type': 'application/json','X-Requested-With':'XMLHttpRequest'},
        body: JSON.stringify(payload)
      });
      if (!res.ok) {
        const txt = await res.text().catch(()=> '');
        if ($feedback) $feedback.textContent = "Erreur d'enregistrement" + (txt ? ` : ${txt}` : '');
        return;
      }
      if ($feedback) {
        $feedback.textContent = 'Style enregistré ✔︎';
        setTimeout(() => { $feedback.textContent = ''; }, 1200);
      }
    } catch {
      if ($feedback) $feedback.textContent = "Erreur réseau";
    }
  };
  const saveStyleDebounced = debounce(saveStyle, 400);

  const bindInputs = () => {
    [$fs,$tc,$bfg,$bfgH,$btx,$br].forEach(el => {
      if (!el) return;
      el.addEventListener('input',  () => { paintPreview(); saveStyleDebounced(); });
      el.addEventListener('change', () => { paintPreview(); saveStyleDebounced(); });
    });
  };

  const initFromAPI = async () => {
    if (!API_URL) { paintPreview(); bindInputs(); return; }
    try {
      const res = await fetch(API_URL, { headers: { 'X-Requested-With': 'XMLHttpRequest' } });
      if (res.ok) {
        const data = await res.json();
        const st = data.style || {};
        if ($fs  && st.title_font_size_px != null) $fs.value  = st.title_font_size_px;
        if ($tc  && st.title_color)                $tc.value  = st.title_color;
        if ($btx && st.btn_text_color)             $btx.value = st.btn_text_color;
        if ($bfg && st.btn_bg)                     $bfg.value = st.btn_bg;
        if ($bfgH&& st.btn_bg_hover)               $bfgH.value= st.btn_bg_hover;
        if ($br  && st.btn_radius_px != null)      $br.value  = st.btn_radius_px;
      }
    } catch {}
    paintPreview();
    bindInputs();
  };

  initFromAPI();
};

/* ——— Exposer pour les onclick du template ——— */
window.showAddFieldForm  = showAddFieldForm;   // alias inline
window.editField         = editField;
window.deleteField       = deleteField;
window.moveFieldUp       = moveFieldUp;
window.moveFieldDown     = moveFieldDown;
window.reloadFieldsList  = reloadFieldsList;




// ===================== Exports globaux ======================

window.createSection = createSection;
window.editSection = editSection;
window.removeSection = removeSection;
window.moveSectionUp = moveSectionUp;
window.moveSectionDown = moveSectionDown;
window.makeSectionModel = makeSectionModel;

window.createLine = createLine;
window.editLine = editLine;
window.removeLine = removeLine;
window.moveLineUp = moveLineUp;
window.moveLineDown = moveLineDown;
window.makeLineModel = makeLineModel;

window.chooseContentType = chooseContentType;
window.editContent = editContent;
window.resetContent = resetContent;
window.showEditingParameters = showEditingParameters;
window.makeBlocModel = makeBlocModel;
window.addBloc = addBloc;
window.removeBloc = removeBloc;
window.moveBlocUp = moveBlocUp;
window.moveBlocDown = moveBlocDown;
window.moveBlocLeft = moveBlocLeft;
window.moveBlocRight = moveBlocRight;

window.showAddFieldForm = showAddFieldForm;
window.closeFieldForm = closeFieldForm;
window.deleteField = deleteField;
window.moveFieldUp = moveFieldUp;
window.moveFieldDown = moveFieldDown;
window.reloadFieldsList = reloadFieldsList;

// utile pour debug
window.reinitUI = reinitUI;

document.addEventListener('DOMContentLoaded', () => {
    reinitUI(document);
});