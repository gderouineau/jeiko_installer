from django.core.validators import MinValueValidator, MaxValueValidator

from io import BytesIO
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage
import os
from PIL import Image
from django.db import models
from django.core.exceptions import ValidationError

from jeiko.administration_pages.models import Page

class Font(models.Model):
    size = models.CharField(
        default="20px",
        max_length=20,
        verbose_name="Taille de la police",
        help_text="Ex: 18px, 1.2em, etc."
    )
    family = models.CharField(
        default="Georgia",
        max_length=100,
        verbose_name="Famille de police",
        help_text="Ex: Roboto, Playfair Display, Arial, etc."
    )
    fallback = models.CharField(
        default="serif",
        max_length=100,
        verbose_name="Police de secours",
        help_text="Ex: serif, sans-serif, monospace, Arial… (sera utilisée si la police principale n’est pas chargée)"
    )
    stretch = models.CharField(
        default="100%",
        max_length=100,
        verbose_name="Étirement",
        help_text="Ex: 100%, condensed, expanded (optionnel)"
    )
    color = models.CharField(
        default="rgba(0,0,0,1)",
        max_length=30,
        verbose_name="Couleur de la police",
        help_text="Ex: #333, rgba(0,0,0,1)"
    )
    POLICE_STYLE_CHOICES = [
        ("normal", "normal"),
        ("italic", "italic"),
        ("oblique", "oblique"),
    ]
    style = models.CharField(
        default="normal",
        max_length=10,
        choices=POLICE_STYLE_CHOICES,
        verbose_name="Style"
    )
    variant = models.CharField(
        default="normal",
        max_length=20,
        verbose_name="Variante",
        help_text="Ex: small-caps, normal"
    )
    weight = models.CharField(
        default="normal",
        max_length=50,
        verbose_name="Épaisseur de la police",
        help_text="Ex: normal, bold, 700"
    )
    line_height = models.CharField(
        default="normal",
        max_length=50,
        verbose_name="Hauteur de ligne",
        help_text="Ex: 1.2, normal, 32px"
    )
    google_fonts_url = models.URLField(
        blank=True,
        null=True,
        verbose_name="URL Google Fonts",
        help_text="Optionnel : colle ici l’URL Google Fonts si besoin (sinon sera générée automatiquement)."
    )

    def __str__(self):
        return f"{self.family} ({self.size})"

    class Meta:
        verbose_name = "Police"
        verbose_name_plural = "Polices"


class Fonts(models.Model):

    links = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="links"
    )

    links_hover = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="links_hover"
    )
    menu = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="menu"
    )

    menu_hover = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="menu_hover"
    )

    sub_menu = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="sub_menu"
    )

    sub_menu_hover = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="sub_menu_hover"
    )

    text = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="text"
    )

    h1 = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="h1"
    )

    h2 = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="h2"
    )

    h3 = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="h3"
    )

    h4 = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="h4"
    )

    h5 = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="h5"
    )

    h6 = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="h6"
    )


class Logo(models.Model):
    full_size = models.ImageField(upload_to="images/logo", null=True, blank=True, verbose_name="Logo")
    computer_size = models.ImageField(upload_to="images/logo", null=True, blank=True, verbose_name="Logo")
    tablet_size   = models.ImageField(upload_to="images/logo", null=True, blank=True, verbose_name="Logo")
    mobile_size   = models.ImageField(upload_to="images/logo", null=True, blank=True, verbose_name="Logo")

    updated_at = models.DateTimeField(auto_now=True)

    # ---------- helpers ----------
    def _variant_name(self, base_name: str, suffix: str) -> str:
        # base_name = self.full_size.name (chemin relatif au storage)
        name_no_ext, _ = os.path.splitext(base_name)  # ex: images/logo/monfichier
        return f"{name_no_ext}-{suffix}.webp"          # ex: images/logo/monfichier-computer.webp

    def _save_webp(self, img: Image.Image, size: tuple[int, int], target_name: str) -> str:
        # préserver l’alpha
        if img.mode not in ("RGBA", "LA"):
            img = img.convert("RGBA")
        # copier l’original avant thumbnail (pour éviter cascade de thumbnails)
        variant = img.copy()
        variant.thumbnail(size, Image.LANCZOS)

        buf = BytesIO()
        # WebP supporte la transparence ; ajuste quality/method si besoin
        variant.save(buf, format="WEBP", quality=85, method=6)
        buf.seek(0)

        # Écrire via le storage (portable: local, S3…)
        if default_storage.exists(target_name):
            default_storage.delete(target_name)
        default_storage.save(target_name, ContentFile(buf.read()))
        return target_name  # chemin relatif (à assigner à .name)

    # ---------- save ----------
    def save(self, *args, **kwargs):
        # 1) sauvegarder d’abord pour garantir full_size.path/.name
        super().save(*args, **kwargs)

        # 2) régénérer les variantes si on a un original
        if self.full_size and self.full_size.name:
            base_name = self.full_size.name   # chemin relatif, ex: images/logo/monfichier.png
            base_img  = Image.open(self.full_size.path)

            computer_name = self._variant_name(base_name, "computer")
            tablet_name   = self._variant_name(base_name, "tablet")
            mobile_name   = self._variant_name(base_name, "mobile")

            comp_rel = self._save_webp(base_img, (150, 150), computer_name)
            tab_rel  = self._save_webp(base_img, (100, 100), tablet_name)
            mob_rel  = self._save_webp(base_img, (75, 75),  mobile_name)

            # 3) assigner .name (PAS .url)
            self.computer_size.name = comp_rel
            self.tablet_size.name   = tab_rel
            self.mobile_size.name   = mob_rel

            # 4) sauver uniquement les champs modifiés (updated_at bouge aussi)
            super().save(update_fields=["computer_size", "tablet_size", "mobile_size", "updated_at"])


class MailSettings(models.Model):
    # Utilisation d’un singleton, une seule config par site
    host = models.CharField(max_length=200, verbose_name="Serveur SMTP")
    port = models.PositiveIntegerField(
        default=587, validators=[MinValueValidator(1), MaxValueValidator(65535)],
        verbose_name="Port SMTP"
    )
    use_tls = models.BooleanField(default=True, verbose_name="Utiliser TLS")
    use_ssl = models.BooleanField(default=False, verbose_name="Utiliser SSL")
    host_user = models.CharField(max_length=200, blank=True, verbose_name="Nom d’utilisateur SMTP")
    host_password = models.CharField(max_length=200, blank=True, verbose_name="Mot de passe SMTP")
    default_from_email = models.CharField(max_length=200, blank=True, verbose_name="Adresse expéditeur par défaut")
    reply_to_email = models.CharField(max_length=200, blank=True, verbose_name="Adresse reply-to (optionnelle)")
    active = models.BooleanField(default=True, verbose_name="Actif")
    test_receiver = models.CharField(max_length=200, blank=True, verbose_name="Email de test (pour bouton 'Tester')")

    class Meta:
        verbose_name = "Configuration Email"
        verbose_name_plural = "Configuration Email"

    def __str__(self):
        return f"Mail SMTP ({self.host}:{self.port}) pour {self.website.name}"


class WebSite(models.Model):

    name = models.CharField(
        max_length=100,
        blank=True,
        null=True,
        default="Jeiko",
    )
    fonts_phone = models.OneToOneField(
        Fonts,
        on_delete=models.CASCADE,
        related_name='site_phone',
        null=True
    )

    fonts_tablet = models.OneToOneField(
        Fonts,
        on_delete=models.CASCADE,
        related_name='site_tablet',
        null=True
    )

    fonts_computer = models.OneToOneField(
        Fonts,
        on_delete=models.CASCADE,
        related_name='site_computer',
        null=True
    )

    logo = models.OneToOneField(
        Logo,
        on_delete=models.CASCADE,
        related_name='site',
        null=True,
    )

    mail_settings = models.OneToOneField(
        "MailSettings",
        on_delete=models.CASCADE,
        blank=True,
        null=True,
        related_name="website",
        verbose_name="Configuration Email"
    )

    assets_version = models.IntegerField(
        default=1
    )



class GoogleApi(models.Model):
    """
    Réglages globaux pour les APIs Google (clé PSI, Search Console...).
    On ne garde qu'une seule configuration.
    """
    name = models.CharField(
        max_length=100,
        default="Default"
    )
    psi_api_key = models.CharField(
        "PageSpeed Insights API key",
        max_length=300,
        blank=True,
        default="",
    )

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Configuration Google API"
        verbose_name_plural = "Configuration Google API"

    def __str__(self):
        return self.name

    @classmethod
    def get_solo(cls):
        obj, _ = cls.objects.get_or_create(pk=1, defaults={"name": "Default"})
        return obj



class Legals(models.Model):
    """
    Un jeu de pages légales par site.
    Les FK sont PROTECT pour empêcher la suppression d'une Page liée.
    """
    site = models.OneToOneField(
        WebSite,
        on_delete=models.CASCADE,
        related_name="legals",
        verbose_name="Site",
    )

    privacy_page = models.ForeignKey(
        Page, on_delete=models.PROTECT,
        blank=True,
        null=True,
        related_name="as_privacy_page_for",
        verbose_name="Page RGPD/Privacy",

    )
    cgv_page = models.ForeignKey(
        Page, on_delete=models.PROTECT,
        blank=True,
        null=True,
        related_name="as_cgv_page_for",
        verbose_name="Page CGV",
    )
    cgu_page = models.ForeignKey(
        Page, on_delete=models.PROTECT,
        blank=True,
        null=True,
        related_name="as_cgu_page_for",
        verbose_name="Page CGU",
    )
    mentions_page = models.ForeignKey(
        Page, on_delete=models.PROTECT,
        blank=True,
        null=True,
        related_name="as_mentions_page_for",
        verbose_name="Page Mentions légales",
    )

    class Meta:
        verbose_name = "Pages légales"
        verbose_name_plural = "Pages légales"
        ordering = ["site__name"]

    def __str__(self):
        return f"Pages légales — {self.site.name}"


    @property
    def all_links(self):
        return {
            "privacy": getattr(self.privacy_page, "get_absolute_url", lambda: None)(),
            "cgv": getattr(self.cgv_page, "get_absolute_url", lambda: None)(),
            "cgu": getattr(self.cgu_page, "get_absolute_url", lambda: None)(),
            "mentions": getattr(self.mentions_page, "get_absolute_url", lambda: None)(),
        }