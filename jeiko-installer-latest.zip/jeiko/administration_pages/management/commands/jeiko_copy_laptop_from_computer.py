from django.core.management.base import BaseCommand
from django.db import transaction
from jeiko.administration_pages.models import Section, Line, Bloc

def _clone_instance(obj):
    """Clone générique (copie champs simples, sans PK)."""
    if not obj:
        return None
    Model = obj.__class__
    data = {}
    for f in Model._meta.fields:
        if f.primary_key:
            continue
        data[f.name] = getattr(obj, f.name)
    return Model.objects.create(**data)

def _parse_px(value):
    if value is None:
        return None
    s = str(value).lower().strip().replace(" ", "")
    num = "".join(ch for ch in s if ch.isdigit())
    try:
        return int(num) if num else None
    except ValueError:
        return None

class Command(BaseCommand):
    help = (
        "Clone *computer* -> *laptop* pour margins/paddings/sizes "
        "et fixe size_computer.width à 1144px si 990/991/992 (Section/Line)."
    )

    def add_arguments(self, parser):
        parser.add_argument("--overwrite", action="store_true",
                            help="Écrase les champs *_laptop existants.")
        parser.add_argument("--dry-run", action="store_true",
                            help="Affiche les actions sans écrire en base.")
        parser.add_argument("--verbose", action="store_true",
                            help="Logs détaillés par objet.")

    @transaction.atomic
    def handle(self, *args, **opts):
        overwrite = opts["overwrite"]
        dry = opts["dry_run"]
        verbose = opts["verbose"]

        # Stats
        stats = {
            "Section": {"planned": 0, "written": 0, "skipped_no_source": 0, "skipped_already_set": 0},
            "Line":    {"planned": 0, "written": 0, "skipped_no_source": 0, "skipped_already_set": 0},
            "Bloc":    {"planned": 0, "written": 0, "skipped_no_source": 0, "skipped_already_set": 0},
        }
        width_fix = {"Section": 0, "Line": 0}

        def process_model(Model):
            name = Model.__name__
            qs = Model.objects.select_related(
                "margin_computer", "padding_computer", "size_computer",
                "margin_laptop", "padding_laptop", "size_laptop"
            )

            for obj in qs.iterator():
                planned = False
                changed_fields = []

                # margin
                if obj.margin_computer:
                    if overwrite or obj.margin_laptop_id is None:
                        planned = True
                        if not dry:
                            obj.margin_laptop = _clone_instance(obj.margin_computer)
                            changed_fields.append("margin_laptop")
                    else:
                        stats[name]["skipped_already_set"] += 1
                else:
                    stats[name]["skipped_no_source"] += 1

                # padding
                if obj.padding_computer:
                    if overwrite or obj.padding_laptop_id is None:
                        planned = True
                        if not dry:
                            obj.padding_laptop = _clone_instance(obj.padding_computer)
                            changed_fields.append("padding_laptop")
                    else:
                        stats[name]["skipped_already_set"] += 1
                else:
                    stats[name]["skipped_no_source"] += 1

                # size
                if obj.size_computer:
                    if overwrite or obj.size_laptop_id is None:
                        planned = True
                        if not dry:
                            obj.size_laptop = _clone_instance(obj.size_computer)
                            changed_fields.append("size_laptop")
                    else:
                        stats[name]["skipped_already_set"] += 1
                # size_computer peut être None sans que ce soit une anomalie

                if planned:
                    stats[name]["planned"] += 1
                    if verbose and dry:
                        self.stdout.write(f"[DRY] {name}#{obj.pk}: clone computer→laptop")
                    if changed_fields and not dry:
                        obj.save(update_fields=changed_fields)
                        stats[name]["written"] += 1
                        if verbose:
                            self.stdout.write(f"[OK]  {name}#{obj.pk}: {', '.join(changed_fields)}")

        for M in (Section, Line, Bloc):
            process_model(M)

        # Fix width sur size_computer (Section & Line)
        for Model in (Section, Line):
            name = Model.__name__
            qs = Model.objects.select_related("size_computer")
            for obj in qs.iterator():
                sz = obj.size_computer
                if not sz:
                    continue
                w = _parse_px(sz.width)
                if w in (990, 991, 992):
                    width_fix[name] += 1
                    if verbose:
                        self.stdout.write(f"{'[DRY] ' if dry else ''}[FIX] {name}#{obj.pk}: {sz.width} → 1144px")
                    if not dry:
                        sz.width = "1144px"
                        sz.save(update_fields=["width"])

        # Résumé
        self.stdout.write(
            f"Planned clones -> laptop : "
            f"{{'Section': {stats['Section']['planned']}, 'Line': {stats['Line']['planned']}, 'Bloc': {stats['Bloc']['planned']}}}"
        )
        if not dry:
            self.stdout.write(
                f"Written clones -> laptop : "
                f"{{'Section': {stats['Section']['written']}, 'Line': {stats['Line']['written']}, 'Bloc': {stats['Bloc']['written']}}}"
            )
        self.stdout.write(
            f"Skipped (no source): "
            f"{{'Section': {stats['Section']['skipped_no_source']}, 'Line': {stats['Line']['skipped_no_source']}, 'Bloc': {stats['Bloc']['skipped_no_source']}}}"
        )
        self.stdout.write(
            f"Skipped (already set): "
            f"{{'Section': {stats['Section']['skipped_already_set']}, 'Line': {stats['Line']['skipped_already_set']}, 'Bloc': {stats['Bloc']['skipped_already_set']}}}"
        )
        self.stdout.write(f"Width fixes (computer→1144px): {width_fix} {'(dry-run)' if dry else ''}")
