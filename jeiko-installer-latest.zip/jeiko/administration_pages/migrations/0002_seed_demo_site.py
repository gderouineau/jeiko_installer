from django.db import migrations, models

def seed_demo_site(apps, schema_editor):
    # Récupère les modèles dynamiquement (important pour migrations)
    Category = apps.get_model('administration_pages', 'Category')
    Page = apps.get_model('administration_pages', 'Page')
    Section = apps.get_model('administration_pages', 'Section')
    Line = apps.get_model('administration_pages', 'Line')
    Bloc = apps.get_model('administration_pages', 'Bloc')
    Content = apps.get_model('administration_pages', 'Content')
    ContentText = apps.get_model('administration_pages', 'ContentText')
    ContentButton = apps.get_model('administration_pages', 'ContentButton')
    ContentFormulaire = apps.get_model('administration_pages', 'ContentFormulaire')
    ContentFormField = apps.get_model('administration_pages', 'ContentFormField')

    StyleBox = apps.get_model('administration_pages', 'StyleBox')
    Size = apps.get_model('administration_pages', 'Size')

    MenuItem = apps.get_model('administration_menu', 'MenuItem')  # adapte si app diff

    # 1. StyleBox et Size par défaut (1 fois pour tout, réutilisés)
    style = StyleBox.objects.create(top="0", right="0", bottom="0", left="0")
    size_full = Size.objects.create(width="100%", height="")

    # 2. Pages (Accueil = root)
    page_accueil = Page.objects.create(
        title="Accueil",
        active=True,
        url_tag="accueil",
        is_root=True,
        category=None,
        sub_category=None,
    )
    page_fonction = Page.objects.create(
        title="Fonctionnalités",
        active=True,
        url_tag="fonctionnalites",
        is_root=False,
        category=None,
        sub_category=None,
    )
    page_contact = Page.objects.create(
        title="Contact",
        active=True,
        url_tag="contact",
        is_root=False,
        category=None,
        sub_category=None,
    )

    # 3. Sections/Lignes/Blocs/Contenus - Accueil
    section_hero = Section.objects.create(
        page=page_accueil,
        position=1,
        margin_phone=style,
        margin_tablet=style,
        margin_computer=style,
        padding_phone=style,
        padding_tablet=style,
        padding_computer=style,
        size_phone=size_full,
        size_tablet=size_full,
        size_computer=size_full,
        background_color="#f5f7fa"
    )
    line_hero = Line.objects.create(
        section=section_hero,
        position=1,
        columns_type="12",
        columns_type_tablet="12",
        columns_type_phone="12",
        columns_number=1,
        margin_phone=style,
        margin_tablet=style,
        margin_computer=style,
        padding_phone=style,
        padding_tablet=style,
        padding_computer=style,
        size_phone=size_full,
        size_tablet=size_full,
        size_computer=size_full,
        background_color="#f5f7fa"
    )
    bloc_hero = Bloc.objects.create(
        line=line_hero,
        position=1,
        margin_phone=style,
        margin_tablet=style,
        margin_computer=style,
        padding_phone=style,
        padding_tablet=style,
        padding_computer=style,
        size_phone=size_full,
        size_tablet=size_full,
        size_computer=size_full,
        background_color="#f5f7fa",
        horizontal_align="center"
    )
    content_hero_txt = ContentText.objects.create(
        text="<h1>Jeiko, le CRM & Éditeur de site clé-en-main</h1>"
             "<p>Gérez vos clients et créez un site pro en 5 minutes !</p>"
    )
    Content.objects.create(
        bloc=bloc_hero,
        content_type="TEXT",
        content_text=content_hero_txt
    )
    # Bouton "Découvrir Jeiko"
    bloc_btn = Bloc.objects.create(
        line=line_hero,
        position=2,
        margin_phone=style,
        margin_tablet=style,
        margin_computer=style,
        padding_phone=style,
        padding_tablet=style,
        padding_computer=style,
        size_phone=size_full,
        size_tablet=size_full,
        size_computer=size_full,
        background_color="#f5f7fa",
        horizontal_align="center"
    )
    btn = ContentButton.objects.create(
        label="Découvrir Jeiko",
        page_target=page_fonction,
        background_color="#2957FF",
        text_color="#FFF",
        padding="0.8em 2em",
        border_radius="6px",
        font_weight="bold",
        font_size="1.2em",
        text_transform="none"
    )
    Content.objects.create(
        bloc=bloc_btn,
        content_type="BUTTON",
        content_button=btn
    )

    # Section atouts (3 colonnes)
    section_atouts = Section.objects.create(
        page=page_accueil,
        position=2,
        margin_phone=style,
        margin_tablet=style,
        margin_computer=style,
        padding_phone=style,
        padding_tablet=style,
        padding_computer=style,
        size_phone=size_full,
        size_tablet=size_full,
        size_computer=size_full,
        background_color="#fff"
    )
    line_atouts = Line.objects.create(
        section=section_atouts,
        position=1,
        columns_type="4-4-4",
        columns_type_tablet="12-12-12",
        columns_type_phone="12-12-12",
        columns_number=3,
        margin_phone=style,
        margin_tablet=style,
        margin_computer=style,
        padding_phone=style,
        padding_tablet=style,
        padding_computer=style,
        size_phone=size_full,
        size_tablet=size_full,
        size_computer=size_full,
        background_color="#fff"
    )
    # 3 Blocs Atouts
    atouts = [
        ("⚡️", "Simplicité", "Prise en main ultra rapide."),
        ("🎨", "Personnalisable", "Vos sections, vos couleurs, vos pages."),
        ("🚀", "Open Source", "100% ouvert, aucune limite de pages."),
    ]
    for pos, (icon, titre, desc) in enumerate(atouts, start=1):
        bloc = Bloc.objects.create(
            line=line_atouts,
            position=pos,
            margin_phone=style,
            margin_tablet=style,
            margin_computer=style,
            padding_phone=style,
            padding_tablet=style,
            padding_computer=style,
            size_phone=size_full,
            size_tablet=size_full,
            size_computer=size_full,
            background_color="#fff",
            horizontal_align="center"
        )
        txt = ContentText.objects.create(
            text=f"<div style='font-size:2em'>{icon}</div>"
                 f"<h3>{titre}</h3>"
                 f"<p>{desc}</p>"
        )
        Content.objects.create(
            bloc=bloc,
            content_type="TEXT",
            content_text=txt
        )

    # Section "Qui sommes-nous ?"
    section_about = Section.objects.create(
        page=page_accueil,
        position=3,
        margin_phone=style,
        margin_tablet=style,
        margin_computer=style,
        padding_phone=style,
        padding_tablet=style,
        padding_computer=style,
        size_phone=size_full,
        size_tablet=size_full,
        size_computer=size_full,
        background_color="#f5f7fa"
    )
    line_about = Line.objects.create(
        section=section_about,
        position=1,
        columns_type="12",
        columns_type_tablet="12",
        columns_type_phone="12",
        columns_number=1,
        margin_phone=style,
        margin_tablet=style,
        margin_computer=style,
        padding_phone=style,
        padding_tablet=style,
        padding_computer=style,
        size_phone=size_full,
        size_tablet=size_full,
        size_computer=size_full,
        background_color="#f5f7fa"
    )
    bloc_about = Bloc.objects.create(
        line=line_about,
        position=1,
        margin_phone=style,
        margin_tablet=style,
        margin_computer=style,
        padding_phone=style,
        padding_tablet=style,
        padding_computer=style,
        size_phone=size_full,
        size_tablet=size_full,
        size_computer=size_full,
        background_color="#f5f7fa",
        horizontal_align="center"
    )
    txt_about = ContentText.objects.create(
        text="<h2>Qui sommes-nous&nbsp;?</h2>"
             "<p>Jeiko est développé par des entrepreneurs pour les entrepreneurs. "
             "Notre mission : rendre la gestion client et la création de site aussi simple que possible, pour tous !</p>"
    )
    Content.objects.create(
        bloc=bloc_about,
        content_type="TEXT",
        content_text=txt_about
    )

    # 4. Fonctionnalités
    section_fonction = Section.objects.create(
        page=page_fonction,
        position=1,
        margin_phone=style,
        margin_tablet=style,
        margin_computer=style,
        padding_phone=style,
        padding_tablet=style,
        padding_computer=style,
        size_phone=size_full,
        size_tablet=size_full,
        size_computer=size_full,
        background_color="#f5f7fa"
    )
    line_fonction = Line.objects.create(
        section=section_fonction,
        position=1,
        columns_type="12",
        columns_type_tablet="12",
        columns_type_phone="12",
        columns_number=1,
        margin_phone=style,
        margin_tablet=style,
        margin_computer=style,
        padding_phone=style,
        padding_tablet=style,
        padding_computer=style,
        size_phone=size_full,
        size_tablet=size_full,
        size_computer=size_full,
        background_color="#f5f7fa"
    )
    bloc_fonction = Bloc.objects.create(
        line=line_fonction,
        position=1,
        margin_phone=style,
        margin_tablet=style,
        margin_computer=style,
        padding_phone=style,
        padding_tablet=style,
        padding_computer=style,
        size_phone=size_full,
        size_tablet=size_full,
        size_computer=size_full,
        background_color="#f5f7fa",
        horizontal_align="center"
    )
    txt_fonction = ContentText.objects.create(
        text="<h1>Fonctionnalités de Jeiko</h1>"
             "<p>Structurez, gérez et éditez tout votre site depuis une interface visuelle intuitive.</p>"
    )
    Content.objects.create(
        bloc=bloc_fonction,
        content_type="TEXT",
        content_text=txt_fonction
    )

    # Liste fonctionnalités + image
    section_mod = Section.objects.create(
        page=page_fonction,
        position=2,
        margin_phone=style,
        margin_tablet=style,
        margin_computer=style,
        padding_phone=style,
        padding_tablet=style,
        padding_computer=style,
        size_phone=size_full,
        size_tablet=size_full,
        size_computer=size_full,
        background_color="#fff"
    )
    line_mod = Line.objects.create(
        section=section_mod,
        position=1,
        columns_type="8-4",
        columns_type_tablet="12-12",
        columns_type_phone="12-12",
        columns_number=2,
        margin_phone=style,
        margin_tablet=style,
        margin_computer=style,
        padding_phone=style,
        padding_tablet=style,
        padding_computer=style,
        size_phone=size_full,
        size_tablet=size_full,
        size_computer=size_full,
        background_color="#fff"
    )
    # Bloc gauche (texte)
    bloc_mod_g = Bloc.objects.create(
        line=line_mod,
        position=1,
        margin_phone=style,
        margin_tablet=style,
        margin_computer=style,
        padding_phone=style,
        padding_tablet=style,
        padding_computer=style,
        size_phone=size_full,
        size_tablet=size_full,
        size_computer=size_full,
        background_color="#fff"
    )
    txt_mod_g = ContentText.objects.create(
        text="""
        <ul>
        <li><strong>Pages</strong> : Créateur visuel, glisser-déposer, sections & blocs</li>
        <li><strong>Menus</strong> : Menus dynamiques, multi-niveaux</li>
        <li><strong>Utilisateurs</strong> : Gestion des accès et des rôles</li>
        <li><strong>Formulaires</strong> : Contact, inscription, sur-mesure</li>
        <li><strong>Statistiques</strong> : Suivi des visites et actions</li>
        <li><strong>Responsive</strong> : Site adapté mobile & tablette</li>
        <li><strong>Et plus !</strong></li>
        </ul>
        """
    )
    Content.objects.create(
        bloc=bloc_mod_g,
        content_type="TEXT",
        content_text=txt_mod_g
    )
    # Bloc droit (image fake)
    bloc_mod_d = Bloc.objects.create(
        line=line_mod,
        position=2,
        margin_phone=style,
        margin_tablet=style,
        margin_computer=style,
        padding_phone=style,
        padding_tablet=style,
        padding_computer=style,
        size_phone=size_full,
        size_tablet=size_full,
        size_computer=size_full,
        background_color="#fff"
    )
    txt_mod_d = ContentText.objects.create(
        text="<img src='https://placehold.co/200x220/2957FF/FFF?text=Jeiko' alt='Aperçu Jeiko' style='border-radius:12px;box-shadow:0 2px 8px #eee;'>"
    )
    Content.objects.create(
        bloc=bloc_mod_d,
        content_type="TEXT",
        content_text=txt_mod_d
    )

    # Exemples de sites créés
    section_exemples = Section.objects.create(
        page=page_fonction,
        position=3,
        margin_phone=style,
        margin_tablet=style,
        margin_computer=style,
        padding_phone=style,
        padding_tablet=style,
        padding_computer=style,
        size_phone=size_full,
        size_tablet=size_full,
        size_computer=size_full,
        background_color="#f5f7fa"
    )
    line_exemples = Line.objects.create(
        section=section_exemples,
        position=1,
        columns_type="4-4-4",
        columns_type_tablet="12-12-12",
        columns_type_phone="12-12-12",
        columns_number=3,
        margin_phone=style,
        margin_tablet=style,
        margin_computer=style,
        padding_phone=style,
        padding_tablet=style,
        padding_computer=style,
        size_phone=size_full,
        size_tablet=size_full,
        size_computer=size_full,
        background_color="#f5f7fa"
    )
    exemples = [
        ("Site de consultant", "A"),
        ("Boutique artisan", "B"),
        ("Page événement", "C"),
    ]
    for pos, (title, img) in enumerate(exemples, start=1):
        bloc = Bloc.objects.create(
            line=line_exemples,
            position=pos,
            margin_phone=style,
            margin_tablet=style,
            margin_computer=style,
            padding_phone=style,
            padding_tablet=style,
            padding_computer=style,
            size_phone=size_full,
            size_tablet=size_full,
            size_computer=size_full,
            background_color="#fff",
            horizontal_align="center"
        )
        txt = ContentText.objects.create(
            text=f"<h3>{title}</h3><img src='https://placehold.co/100x60?text={img}' alt='' style='display:block;margin:auto;'>"
        )
        Content.objects.create(
            bloc=bloc,
            content_type="TEXT",
            content_text=txt
        )

    # FAQ rapide
    section_faq = Section.objects.create(
        page=page_fonction,
        position=4,
        margin_phone=style,
        margin_tablet=style,
        margin_computer=style,
        padding_phone=style,
        padding_tablet=style,
        padding_computer=style,
        size_phone=size_full,
        size_tablet=size_full,
        size_computer=size_full,
        background_color="#fff"
    )
    line_faq = Line.objects.create(
        section=section_faq,
        position=1,
        columns_type="12",
        columns_type_tablet="12",
        columns_type_phone="12",
        columns_number=1,
        margin_phone=style,
        margin_tablet=style,
        margin_computer=style,
        padding_phone=style,
        padding_tablet=style,
        padding_computer=style,
        size_phone=size_full,
        size_tablet=size_full,
        size_computer=size_full,
        background_color="#fff"
    )
    bloc_faq = Bloc.objects.create(
        line=line_faq,
        position=1,
        margin_phone=style,
        margin_tablet=style,
        margin_computer=style,
        padding_phone=style,
        padding_tablet=style,
        padding_computer=style,
        size_phone=size_full,
        size_tablet=size_full,
        size_computer=size_full,
        background_color="#fff",
        horizontal_align="center"
    )
    txt_faq = ContentText.objects.create(
        text="""
        <h2>FAQ rapide</h2>
        <p><strong>Jeiko est-il open-source&nbsp;?</strong><br>
        Oui, Jeiko est 100% open-source, modifiable et auto-hébergeable.</p>
        <p><strong>Puis-je l’utiliser pour plusieurs clients&nbsp;?</strong><br>
        Bien sûr, gérez autant de sites/pages que vous voulez.</p>
        <p><strong>Est-ce adapté aux débutants&nbsp;?</strong><br>
        Oui, aucune connaissance technique n’est requise pour utiliser l’éditeur visuel.</p>
        """
    )
    Content.objects.create(
        bloc=bloc_faq,
        content_type="TEXT",
        content_text=txt_faq
    )

    # 5. Contact
    section_contact_hero = Section.objects.create(
        page=page_contact,
        position=1,
        margin_phone=style,
        margin_tablet=style,
        margin_computer=style,
        padding_phone=style,
        padding_tablet=style,
        padding_computer=style,
        size_phone=size_full,
        size_tablet=size_full,
        size_computer=size_full,
        background_color="#f5f7fa"
    )
    line_contact_hero = Line.objects.create(
        section=section_contact_hero,
        position=1,
        columns_type="12",
        columns_type_tablet="12",
        columns_type_phone="12",
        columns_number=1,
        margin_phone=style,
        margin_tablet=style,
        margin_computer=style,
        padding_phone=style,
        padding_tablet=style,
        padding_computer=style,
        size_phone=size_full,
        size_tablet=size_full,
        size_computer=size_full,
        background_color="#f5f7fa"
    )
    bloc_contact_hero = Bloc.objects.create(
        line=line_contact_hero,
        position=1,
        margin_phone=style,
        margin_tablet=style,
        margin_computer=style,
        padding_phone=style,
        padding_tablet=style,
        padding_computer=style,
        size_phone=size_full,
        size_tablet=size_full,
        size_computer=size_full,
        background_color="#f5f7fa",
        horizontal_align="center"
    )
    txt_contact_hero = ContentText.objects.create(
        text="<h1>Contactez Jeiko</h1><p>Une question, une demande de démo ? Écrivez-nous !</p>"
    )
    Content.objects.create(
        bloc=bloc_contact_hero,
        content_type="TEXT",
        content_text=txt_contact_hero
    )

    # Formulaire contact
    section_form = Section.objects.create(
        page=page_contact,
        position=2,
        margin_phone=style,
        margin_tablet=style,
        margin_computer=style,
        padding_phone=style,
        padding_tablet=style,
        padding_computer=style,
        size_phone=size_full,
        size_tablet=size_full,
        size_computer=size_full,
        background_color="#fff"
    )
    line_form = Line.objects.create(
        section=section_form,
        position=1,
        columns_type="12",
        columns_type_tablet="12",
        columns_type_phone="12",
        columns_number=1,
        margin_phone=style,
        margin_tablet=style,
        margin_computer=style,
        padding_phone=style,
        padding_tablet=style,
        padding_computer=style,
        size_phone=size_full,
        size_tablet=size_full,
        size_computer=size_full,
        background_color="#fff"
    )
    bloc_form = Bloc.objects.create(
        line=line_form,
        position=1,
        margin_phone=style,
        margin_tablet=style,
        margin_computer=style,
        padding_phone=style,
        padding_tablet=style,
        padding_computer=style,
        size_phone=size_full,
        size_tablet=size_full,
        size_computer=size_full,
        background_color="#fff"
    )
    formulaire = ContentFormulaire.objects.create(
        name="Contact",
        description="Formulaire de contact",
        to_email="contact@jeiko.dev",
        from_email="",
        mail_subject="Message de contact",
        success_message="Merci pour votre message !"
    )
    ContentFormField.objects.create(
        formulaire=formulaire, label="Nom", name="nom", type="text", required=True, order=1
    )
    ContentFormField.objects.create(
        formulaire=formulaire, label="Email", name="email", type="email", required=True, order=2
    )
    ContentFormField.objects.create(
        formulaire=formulaire, label="Message", name="message", type="textarea", required=True, order=3
    )
    Content.objects.create(
        bloc=bloc_form,
        content_type="FORM",
        content_formulaire=formulaire
    )

    # Infos/réseaux
    section_infos = Section.objects.create(
        page=page_contact,
        position=3,
        margin_phone=style,
        margin_tablet=style,
        margin_computer=style,
        padding_phone=style,
        padding_tablet=style,
        padding_computer=style,
        size_phone=size_full,
        size_tablet=size_full,
        size_computer=size_full,
        background_color="#f5f7fa"
    )
    line_infos = Line.objects.create(
        section=section_infos,
        position=1,
        columns_type="6-6",
        columns_type_tablet="12-12",
        columns_type_phone="12-12",
        columns_number=2,
        margin_phone=style,
        margin_tablet=style,
        margin_computer=style,
        padding_phone=style,
        padding_tablet=style,
        padding_computer=style,
        size_phone=size_full,
        size_tablet=size_full,
        size_computer=size_full,
        background_color="#f5f7fa"
    )
    # Bloc gauche (infos)
    bloc_infos_g = Bloc.objects.create(
        line=line_infos,
        position=1,
        margin_phone=style,
        margin_tablet=style,
        margin_computer=style,
        padding_phone=style,
        padding_tablet=style,
        padding_computer=style,
        size_phone=size_full,
        size_tablet=size_full,
        size_computer=size_full,
        background_color="#f5f7fa"
    )
    txt_infos_g = ContentText.objects.create(
        text="<h3>Nous contacter</h3><p><b>Email</b> : contact@jeiko.dev<br>"
             "<b>Adresse</b> : 12 rue de Paris, 75007 Paris</p>"
    )
    Content.objects.create(
        bloc=bloc_infos_g,
        content_type="TEXT",
        content_text=txt_infos_g
    )
    # Bloc droit (réseaux)
    bloc_infos_d = Bloc.objects.create(
        line=line_infos,
        position=2,
        margin_phone=style,
        margin_tablet=style,
        margin_computer=style,
        padding_phone=style,
        padding_tablet=style,
        padding_computer=style,
        size_phone=size_full,
        size_tablet=size_full,
        size_computer=size_full,
        background_color="#f5f7fa"
    )
    txt_infos_d = ContentText.objects.create(
        text="<h3>Réseaux sociaux</h3><p>"
             "<a href='https://twitter.com/jeiko' target='_blank'>Twitter</a><br>"
             "<a href='https://github.com/jeiko' target='_blank'>GitHub</a></p>"
    )
    Content.objects.create(
        bloc=bloc_infos_d,
        content_type="TEXT",
        content_text=txt_infos_d
    )

    # 6. Menu principal (MenuItem)
    # Place = "U" (haut), active=True pour accueil par défaut
    MenuItem.objects.create(
        title="Accueil",
        position=1,
        place="U",
        active=True,
        is_sub_menu=False,
        page=page_accueil
    )
    MenuItem.objects.create(
        title="Fonctionnalités",
        position=2,
        place="U",
        active=False,
        is_sub_menu=False,
        page=page_fonction
    )
    MenuItem.objects.create(
        title="Contact",
        position=3,
        place="U",
        active=False,
        is_sub_menu=False,
        page=page_contact
    )


class Migration(migrations.Migration):

    dependencies = [
        ('administration_pages', '0001_initial'),
        ('administration_menu', '0001_initial'),  # adapte si besoin !
    ]

    operations = [
        migrations.RunPython(seed_demo_site),
    ]
