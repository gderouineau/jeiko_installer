from django.apps import AppConfig


class PagesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'jeiko.administration_pages'

    def ready(self):
        from . import signals