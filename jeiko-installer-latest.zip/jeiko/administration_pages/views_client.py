from django.contrib.auth.decorators import permission_required
from django.contrib.auth.mixins import PermissionRequiredMixin
from django.core.cache import cache
from django.http import Http404
from django.shortcuts import render, redirect, get_object_or_404

from django.views import View
from django.views.generic.base import TemplateView
from django.views.generic.edit import DeleteView

from django.utils.decorators import method_decorator
from django.views.decorators.csrf import ensure_csrf_cookie
from django.core.cache import cache
from django.views.decorators.cache import never_cache
from django.views.decorators.clickjacking import xframe_options_exempt


from jeiko.administration_pages.models import Page, Metadata, Section, Line, Margin, Padding, Size, ImageContent, Bloc, Content, \
    ContentImage, ContentText, CSSParameters

decorators = [never_cache]


@method_decorator(ensure_csrf_cookie, name='get')
class RootPage(View):

    template_name = 'pages/main.html'

    def get(self, request, *args, **kwargs):

        page = get_object_or_404(
            Page,
            is_root=True,
        )
        context = {
            'page': page,
        }

        return render(request, self.template_name, context)


@method_decorator(ensure_csrf_cookie, name='get')
class OtherPage(View):

    template_name = 'pages/main.html'


    def get(self, request, *args, **kwargs):

        page_url_tag = kwargs['url_tag']
        page = get_object_or_404(
            Page,
            url_tag=page_url_tag
        )

        context = {
            'page': page,
        }
        return render(request, self.template_name, context)

