from django.http import JsonResponse, HttpResponse


class AsyncRequestMixin:
    def is_fetch(self, request):
        return request.headers.get('X-Requested-With') == 'XMLHttpRequest'

    def render_json(self, *, html=None, status=200, **kwargs):
        data = {
            'status': 'success',     # <-- on ajoute un status par défaut
            **kwargs
        }
        if html is not None:
            data['html'] = html
        return JsonResponse(data, status=status)
