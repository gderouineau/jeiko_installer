from django.urls import path
import jeiko.administration_pages.views_client as views

app_name = 'jeiko_pages'
urlpatterns = [

    path(
        '',
        views.RootPage.as_view(),
        name='root_page'
    ),

    path(
        '<str:url_tag>/',
        views.OtherPage.as_view(),
        name='view'
    ),

]


