from django.contrib.auth.decorators import permission_required
from django.contrib.auth.mixins import PermissionRequiredMixin
from django.core.cache import cache
from django.http import Http404
from django.shortcuts import render, redirect, get_object_or_404

from django.views import View
from django.views.generic.base import TemplateView

from django.utils.decorators import method_decorator
from django.core.cache import cache
from django.views.decorators.cache import never_cache

from django.db import transaction, IntegrityError

from django.core.cache import cache
from django.db import IntegrityError
from django.core.exceptions import ValidationError

from jeiko.administration_menu.forms import (
    MenuItemForm, MenuForm, MenuStyleForm
)
from jeiko.administration_menu.models import (
    Menu, MenuItem, MenuPlace, MenuLayout, MenuStyle
)

from jeiko.administration.models import WebSite


decorators = [never_cache]


@method_decorator(never_cache, name='dispatch')
class Main(View):

    template_name = 'administration_menu/main.html'

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):

        menu_items_up = MenuItem.objects.filter(
            is_sub_menu=False,
            place="U",
        )
        menu_items_down = MenuItem.objects.filter(
            is_sub_menu=False,
            place="D",
        )

        context = {
            'menu_items_up': menu_items_up,
            'menu_items_down': menu_items_down,
        }

        return render(request, self.template_name, context)


@method_decorator(never_cache, name='dispatch')
class All(View):

    template_name = 'administration_menu/view.html'

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):

        place = kwargs['place']

        menu_items = MenuItem.objects.filter(
            place=place,
            is_sub_menu=False,

        )

        context = {
            'place': place,
            'menu_items': menu_items,
        }

        return render(request, self.template_name, context)


@method_decorator(never_cache, name='dispatch')
class MenuList(View):
    template_name = 'administration_menu/menu/list.html'

    def get(self, request):
        menus = Menu.objects.all().order_by('name')
        ctx = {
            'menus': menus,
            'menus_main': Menu.objects.filter(place='MAIN'),
            'menus_footer': Menu.objects.filter(place='FOOTER'),
            'menus_neutral': Menu.objects.filter(place__isnull=True),
        }
        return render(request, self.template_name, ctx)


@method_decorator(never_cache, name='dispatch')
class MenuDetail(View):
    """
    Détail d’un menu : montre les items top-level + leurs sous-menus
    """
    template_name = 'administration_menu/menu/view.html'

    def get(self, request, pk):
        menu = get_object_or_404(Menu, pk=pk)
        items = (
            MenuItem.objects
            .filter(menu=menu, main_menu__isnull=True)
            .order_by('position', 'pk')
            .prefetch_related('submenus')
        )
        ctx = {
            'menu': menu,
            'items': items,
        }
        return render(request, self.template_name, ctx)


def _invalidate_menu_cache(menu: Menu):
    # Invalide les clés ciblées (évite cache.clear())
    cache.delete(f"menu:{menu.pk}")
    cache.delete(f"menu:place:{menu.place}")


@method_decorator(never_cache, name='dispatch')
class MenuCreate(View):
    template_name = 'administration_menu/menu/form.html'
    form_class = MenuForm
    style_form_class = MenuStyleForm

    def get(self, request):
        form = self.form_class()
        style_form = self.style_form_class()
        return render(
            request,
            self.template_name,
            {
                'form': form,
                'style_form': style_form,
                'update': False,
                'submit_text': 'Créer',
                'website_data': WebSite.objects.first(),
            },
        )

    def post(self, request):
        form = self.form_class(request.POST)
        style_form = self.style_form_class(request.POST)

        if form.is_valid() and style_form.is_valid():
            try:
                with transaction.atomic():
                    style = style_form.save()  # crée le style
                    menu = form.save(commit=False)
                    menu.menu_style = style     # un style par menu (ton choix)
                    menu.save()
                _invalidate_menu_cache(menu)
                return redirect('jeiko_administration_menu:menu_list')

            except IntegrityError as e:
                msg = str(e)
                if "uq_single_menu_main" in msg:
                    form.add_error('place', "Un menu principal (MAIN) existe déjà.")
                elif "uq_single_menu_footer" in msg:
                    form.add_error('place', "Un menu de pied de page (FOOTER) existe déjà.")
                elif "menu_layout_required_for_main_only" in msg:
                    form.add_error('layout', "Incohérence place/layout : MAIN ⇒ layout requis, FOOTER/NULL ⇒ pas de layout.")
                else:
                    form.add_error(None, "Contrainte de base de données violée.")

            except ValidationError as e:
                form.add_error(None, e)

        return render(
            request,
            self.template_name,
            {
                'form': form,
                'style_form': style_form,
                'update': False,
                'submit_text': 'Créer',
            },
        )


@method_decorator(never_cache, name='dispatch')
class MenuUpdate(View):
    template_name = 'administration_menu/menu/form.html'
    form_class = MenuForm
    style_form_class = MenuStyleForm

    def get(self, request, pk):
        menu = get_object_or_404(Menu, pk=pk)
        form = self.form_class(instance=menu)
        style_form = self.style_form_class(instance=menu.menu_style or None)
        ctx = {
            'form': form,
            'style_form': style_form,
            'update': True,
            'menu': menu,
            'submit_text': 'Modifier',
            'website_data': WebSite.objects.first()
        }
        return render(request, self.template_name, ctx)

    def post(self, request, pk):
        menu = get_object_or_404(Menu, pk=pk)
        form = self.form_class(request.POST, instance=menu)
        style_form = self.style_form_class(request.POST, instance=menu.menu_style or None)

        if form.is_valid() and style_form.is_valid():
            try:
                with transaction.atomic():
                    style = style_form.save()  # crée ou met à jour le style
                    # Lier le style au menu si pas encore fait
                    menu_obj = form.save(commit=False)
                    if not menu_obj.menu_style_id:
                        menu_obj.menu_style = style
                    menu_obj.save()
                _invalidate_menu_cache(menu_obj)
                return redirect('jeiko_administration_menu:menu_list')
            except IntegrityError as e:
                # Conflit d’unicité place (MAIN/FOOTER) ou autre contrainte DB
                msg = str(e)
                if "uq_single_menu_main" in msg:
                    form.add_error('place', "Un menu principal (MAIN) existe déjà.")
                elif "uq_single_menu_footer" in msg:
                    form.add_error('place', "Un menu de pied de page (FOOTER) existe déjà.")
                elif "menu_layout_required_for_main_only" in msg:
                    form.add_error('layout', "Incohérence place/layout : MAIN ⇒ layout requis, FOOTER/NULL ⇒ pas de layout.")
                else:
                    form.add_error(None, "Contrainte de base de données violée.")
            except ValidationError as e:
                # Validation côté modèle
                form.add_error(None, e)

        ctx = {
            'form': form,
            'style_form': style_form,
            'update': True,
            'menu': menu,
            'submit_text': 'Modifier',
        }
        return render(request, self.template_name, ctx)


@method_decorator(never_cache, name='dispatch')
class MenuDelete(View):
    template_name = 'administration_menu/menu_confirm_delete.html'

    def get(self, request, pk):
        menu = get_object_or_404(Menu, pk=pk)
        return render(request, self.template_name, {'menu': menu})

    def post(self, request, pk):
        menu = get_object_or_404(Menu, pk=pk)
        menu.delete()
        cache.clear()
        return redirect('jeiko_administration_menu:menu_list')


# ========= CRÉATION / MÀJ / SUPPRESSION — ITEM TOP-LEVEL =========
@method_decorator(never_cache, name='dispatch')
class MenuItemCreate(View):
    template_name = 'administration_menu/menu_item/form.html'
    form_class = MenuItemForm

    def get(self, request, menu_id):
        menu = get_object_or_404(Menu, pk=menu_id)
        instance = MenuItem(menu=menu, main_menu=None)
        form = self.form_class(prefix='menu_item_', instance=instance)
        return render(request, self.template_name, {
            'menu': menu,
            'form': form,
            'update': False,
            'submit_text': 'Créer',
        })

    def post(self, request, menu_id):
        menu = get_object_or_404(Menu, pk=menu_id)
        instance = MenuItem(menu=menu, main_menu=None)
        form = self.form_class(request.POST, request.FILES, prefix='menu_item_', instance=instance)

        if form.is_valid():
            item = form.save(commit=False)
            try:
                item.save()  # full_clean() + position auto via save()
            except ValidationError as e:
                if hasattr(e, "message_dict"):
                    for field, msgs in e.message_dict.items():
                        for msg in msgs:
                            if field in form.fields:
                                form.add_error(field, msg)
                            else:
                                form.add_error(None, msg)
                else:
                    for msg in e.messages:
                        form.add_error(None, msg)

                return render(request, self.template_name, {
                    'menu': menu,
                    'form': form,
                    'update': False,
                    'submit_text': 'Créer',
                })

            cache.clear()
            return redirect('jeiko_administration_menu:menu_detail', pk=menu.pk)

        return render(request, self.template_name, {
            'menu': menu,
            'form': form,
            'update': False,
            'submit_text': 'Créer',
        })



@method_decorator(never_cache, name='dispatch')
class MenuItemUpdate(View):
    template_name = 'administration_menu/menu_item/form.html'
    form_class = MenuItemForm

    def get(self, request, pk):
        item = get_object_or_404(MenuItem, pk=pk)
        form = self.form_class(instance=item, prefix='menu_item_')
        return render(request, self.template_name, {
            'menu': item.menu,
            'item': item,
            'form': form,
            'update': True,
            'submit_text': 'Modifier',
        })

    def post(self, request, pk):
        item = get_object_or_404(MenuItem, pk=pk)
        form = self.form_class(request.POST, instance=item, prefix='menu_item_')
        if form.is_valid():
            # on NE modifie PAS menu/main_menu ici
            form.save()
            cache.clear()
            return redirect('jeiko_administration_menu:menu_detail', pk=item.menu.pk)
        return render(request, self.template_name, {
            'menu': item.menu,
            'item': item,
            'form': form,
            'update': True,
            'submit_text': 'Modifier',
        })


@method_decorator(never_cache, name='dispatch')
class MenuItemDelete(View):
    template_name = 'administration_menu/menu_item/confirm_delete.html'

    def get(self, request, pk):
        item = get_object_or_404(MenuItem, pk=pk)
        return render(request, self.template_name, {'item': item, 'menu': item.menu})

    def post(self, request, pk):
        item = get_object_or_404(MenuItem, pk=pk)
        item.delete()
        cache.clear()
        return redirect('jeiko_administration_menu:menu_detail', pk=item.menu.pk)


@method_decorator(never_cache, name='dispatch')
class MenuItemMoveUp(View):

    def post(self, request, pk):
        item = get_object_or_404(MenuItem, pk=pk)
        item.move_up()
        cache.clear()
        return redirect('jeiko_administration_menu:menu_detail', pk=item.menu_id)

    def get(self, request, pk):
        # fallback pratique pour les liens <a>, uniquement en admin
        return self.post(request, pk)


@method_decorator(never_cache, name='dispatch')
class MenuItemMoveDown(View):

    def post(self, request, pk):
        item = get_object_or_404(MenuItem, pk=pk)
        item.move_down()
        cache.clear()
        return redirect('jeiko_administration_menu:menu_detail', pk=item.menu_id)

    def get(self, request, pk):
        return self.post(request, pk)


# ========= CRÉATION / MÀJ / SUPPRESSION — SOUS-MENU =========
# ========= CRÉATION — SOUS-MENU =========
@method_decorator(never_cache, name='dispatch')
class SubMenuCreate(View):
    template_name = 'administration_menu/menu_sub_item/form.html'
    form_class = MenuItemForm

    def get(self, request, parent_id):
        parent = get_object_or_404(MenuItem, pk=parent_id)
        # On pré-remplit l'instance avec le menu et le parent
        instance = MenuItem(menu=parent.menu, main_menu=parent)
        form = self.form_class(prefix='menu_item_', instance=instance)
        return render(request, self.template_name, {
            'parent': parent,
            'menu': parent.menu,
            'form': form,
            'update': False,
            'submit_text': 'Créer',
        })

    def post(self, request, parent_id):
        parent = get_object_or_404(MenuItem, pk=parent_id)
        # Idem en POST : l'instance porte déjà menu & main_menu
        instance = MenuItem(menu=parent.menu, main_menu=parent)
        form = self.form_class(request.POST, request.FILES, prefix='menu_item_', instance=instance)

        if form.is_valid():
            sub = form.save(commit=False)
            # Optionnel: sub._assign_position_if_needed() (save() le fait déjà)
            try:
                sub.save()  # appelle full_clean() -> cohérence parent/menu vérifiée
            except ValidationError as e:
                # Réinjecte proprement les erreurs éventuelles
                if hasattr(e, "message_dict"):
                    for field, msgs in e.message_dict.items():
                        for msg in msgs:
                            if field in form.fields:
                                form.add_error(field, msg)
                            else:
                                form.add_error(None, msg)
                else:
                    for msg in e.messages:
                        form.add_error(None, msg)

                return render(request, self.template_name, {
                    'parent': parent,
                    'menu': parent.menu,
                    'form': form,
                    'update': False,
                    'submit_text': 'Créer',
                })

            cache.clear()
            return redirect('jeiko_administration_menu:menu_detail', pk=parent.menu_id)

        return render(request, self.template_name, {
            'parent': parent,
            'menu': parent.menu,
            'form': form,
            'update': False,
            'submit_text': 'Créer',
        })



@method_decorator(never_cache, name='dispatch')
class SubMenuUpdate(View):
    template_name = 'administration_menu/menu_sub_item/form.html'
    form_class = MenuItemForm

    def get(self, request, pk):
        sub = get_object_or_404(MenuItem, pk=pk)
        if not sub.main_menu_id:
            return redirect('jeiko_administration_menu:menu_detail', pk=sub.menu_id)

        form = self.form_class(instance=sub, prefix='menu_item_')
        return render(request, self.template_name, {
            'parent': sub.main_menu,
            'menu': sub.menu,
            'sub': sub,
            'form': form,
            'update': True,
            'submit_text': 'Modifier',
        })

    def post(self, request, pk):
        sub = get_object_or_404(MenuItem, pk=pk)
        if not sub.main_menu_id:
            return redirect('jeiko_administration_menu:menu_detail', pk=sub.menu_id)

        form = self.form_class(request.POST, instance=sub, prefix='menu_item_')
        if form.is_valid():
            sub = form.save(commit=False)

            sub.menu_id = sub.menu_id
            sub.main_menu_id = sub.main_menu_id
            try:
                sub.full_clean()
                sub.save()
            except ValidationError as e:
                form.add_error(None, e.messages)
                return render(request, self.template_name, {
                    'parent': sub.main_menu,
                    'menu': sub.menu,
                    'sub': sub,
                    'form': form,
                    'update': True,
                    'submit_text': 'Modifier',
                })

            cache.clear()
            return redirect('jeiko_administration_menu:menu_detail', pk=sub.menu_id)

        return render(request, self.template_name, {
            'parent': sub.main_menu,
            'menu': sub.menu,
            'sub': sub,
            'form': form,
            'update': True,
            'submit_text': 'Modifier',
        })


@method_decorator(never_cache, name='dispatch')
class SubMenuDelete(View):
    template_name = 'administration_menu/menu_sub_item/confirm_delete.html'

    def get(self, request, pk):
        sub = get_object_or_404(MenuItem, pk=pk)
        return render(request, self.template_name, {
            'sub': sub,
            'menu': sub.menu,
            'parent': sub.main_menu
        })

    def post(self, request, pk):
        sub = get_object_or_404(MenuItem, pk=pk)
        menu_id = sub.menu_id
        sub.delete()
        cache.clear()
        return redirect('jeiko_administration_menu:menu_detail', pk=menu_id)


@method_decorator(never_cache, name='dispatch')
class SubMenuMoveUp(View):
    def post(self, request, pk):
        sub = get_object_or_404(MenuItem, pk=pk)
        sub.move_up()
        cache.clear()
        return redirect('jeiko_administration_menu:menu_detail', pk=sub.menu_id)

    def get(self, request, pk):
        # fallback pratique pour les liens <a> en admin
        return self.post(request, pk)


@method_decorator(never_cache, name='dispatch')
class SubMenuMoveDown(View):
    def post(self, request, pk):
        sub = get_object_or_404(MenuItem, pk=pk)
        sub.move_down()
        cache.clear()
        return redirect('jeiko_administration_menu:menu_detail', pk=sub.menu_id)

    def get(self, request, pk):
        return self.post(request, pk)

