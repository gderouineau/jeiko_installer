# blog/templatetags/blog_extras.py

from django.template import Library, Node

from jeiko.administration_menu.models import MenuItem

register = Library()



class FooterMenus(Node):
    def render(self, context):
        context['footer_menus'] = MenuItem.objects.filter(
            active=True,
            place="D",
        ).order_by('position')
        return ''

@register.tag(name="get_footer_menus")
def get_footer_menus(parser, toker):
    return FooterMenus()