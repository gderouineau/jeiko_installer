from django.urls import path
import jeiko.administration_menu.views

app_name = 'jeiko_administration_menu'


urlpatterns = [


    # ---- Menus (CRUD) ----
    path('menus/', jeiko.administration_menu.views.MenuList.as_view(), name='menu_list'),
    path('menus/add/', jeiko.administration_menu.views.MenuCreate.as_view(), name='menu_add'),
    path('menus/<int:pk>/', jeiko.administration_menu.views.MenuDetail.as_view(), name='menu_detail'),
    path('menus/<int:pk>/update/', jeiko.administration_menu.views.MenuUpdate.as_view(), name='menu_update'),
    path('menus/<int:pk>/delete/', jeiko.administration_menu.views.MenuDelete.as_view(), name='menu_delete'),


    # ---- Items d’un menu ----
    path('menus/<int:menu_id>/items/add/', jeiko.administration_menu.views.MenuItemCreate.as_view(), name='item_add'),

    path('items/<int:pk>/update/', jeiko.administration_menu.views.MenuItemUpdate.as_view(), name='item_update'),
    path('items/<int:pk>/delete/', jeiko.administration_menu.views.MenuItemDelete.as_view(), name='item_delete'),
    path('items/<int:pk>/move_up/', jeiko.administration_menu.views.MenuItemMoveUp.as_view(), name='item_move_up'),
    path('items/<int:pk>/move_down/', jeiko.administration_menu.views.MenuItemMoveDown.as_view(), name='item_move_down'),

    # ---- Sous-menus ----
    path('subitems/<int:parent_id>/add/', jeiko.administration_menu.views.SubMenuCreate.as_view(), name='subitem_add'),
    path('subitems/<int:pk>/update/', jeiko.administration_menu.views.SubMenuUpdate.as_view(), name='subitem_update'),
    path('subitems/<int:pk>/delete/', jeiko.administration_menu.views.SubMenuDelete.as_view(), name='subitem_delete'),
    path('subitems/<int:pk>/move_up/', jeiko.administration_menu.views.SubMenuMoveUp.as_view(), name='subitem_move_up'),
    path('subitems/<int:pk>/move_down/', jeiko.administration_menu.views.SubMenuMoveDown.as_view(),
         name='subitem_move_down'),
]


