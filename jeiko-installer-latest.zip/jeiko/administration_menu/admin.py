from django.contrib import admin

from jeiko.administration_menu.models import MenuItem, Menu

# Register your models here.

admin.site.register(MenuItem)
admin.site.register(Menu)
