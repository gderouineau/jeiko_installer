from django.contrib import admin

# Register your models here.

from jeiko.questionnaires_expert.models import (
    ExpertProfileType, ExpertTest, ExpertQuestion, ExpertAnswer, ExpertProfileCombination,
    ExpertProfileCriterion,
    Prospect, ExpertTestData

)

admin.site.register(ExpertProfileType)
admin.site.register(ExpertTest)
admin.site.register(ExpertQuestion)
admin.site.register(ExpertAnswer)
admin.site.register(ExpertProfileCombination)
admin.site.register(ExpertProfileCriterion)
admin.site.register(Prospect)
admin.site.register(ExpertTestData)
