# users/views.py

from django.urls import reverse_lazy
from django.contrib.auth.mixins import LoginRequiredMixin
from allauth.account.views import SignupView, LoginView, LogoutView
from django.views.generic import DetailView, UpdateView

from jeiko.users.forms import CustomSignupForm, ProfileForm, CustomLoginForm

class CustomSignupView(SignupView):
    form_class = CustomSignupForm
    template_name = 'users/client/signup.html'
    success_url = reverse_lazy('jeiko_users:profile-detail')


class CustomLoginView(LoginView):
    form_class = CustomLoginForm
    template_name = 'users/client/login.html'


class CustomLogoutView(LogoutView):
    template_name = 'users/client/logout.html'
