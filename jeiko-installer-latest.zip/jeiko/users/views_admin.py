# users/views_admin.py

from django.contrib import messages
from django.contrib.auth import get_user_model
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin, PermissionRequiredMixin
from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse, reverse_lazy
from django.utils.decorators import method_decorator
from django.views.decorators.cache import never_cache
from django.views.generic import (
    ListView, DetailView, UpdateView, CreateView, DeleteView, FormView
)

from jeiko.questionnaires_expert.models import ExpertTestData, Prospect

# --- Forms (site-admin) ---
from jeiko.users.forms_admin import (
    # Users
    AdminUserFilterForm, AdminUserEditForm,
    # Roles & perms
    RoleForm, RolePermissionForm, RoleAssignmentForm,
    BulkAssignRoleForm, BulkRevokeRoleForm,
    # Providers
    ProviderConfigForm,
    # Sécurité & sessions
    TwoFactorDeviceForm, TwoFactorToggleForm, UserSessionRevokeForm, SecurityEventFilterForm,
    # Consent & prefs
    ConsentForm, MarketingPreferenceForm,
    # Notifications
    NotificationChannelForm, NotificationComposeForm, BulkNotificationForm,
    # Bridge
    ProspectLinkForm,
)

# --- Models ---
from jeiko.users.models import (
    Role, RolePermission, RoleAssignment,
    ProviderConfig,
    TwoFactorDevice, SecurityEvent, UserSession,
    Consent, MarketingPreference,
    NotificationChannel, Notification,
    ProspectLink,
)

User = get_user_model()

decorators = [never_cache]
# ----------------------------------------------------------
#  Mixins & helpers
# ----------------------------------------------------------

class StaffOnlyMixin(UserPassesTestMixin):
    def test_func(self):
        return bool(self.request.user.is_staff)

def back(request, fallback_name, **kwargs):
    """
    Redirige vers referer sinon vers une named url fallback.
    """
    return redirect(request.META.get("HTTP_REFERER") or reverse(fallback_name, kwargs=kwargs))


# ----------------------------------------------------------
#  Utilisateurs (ta base existante)
# ----------------------------------------------------------

@method_decorator(never_cache, name='dispatch')
class AdminUserListView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    model = User
    template_name = "users/admin/user/list.html"
    context_object_name = "users"
    paginate_by = 25

    permission_required = 'users.view_user'
    raise_exception = True

    def get_queryset(self):
        qs = super().get_queryset().prefetch_related('groups')
        form = AdminUserFilterForm(self.request.GET)
        if form.is_valid():
            cd = form.cleaned_data
            if cd.get('search'):
                qs = qs.filter(Q(username__icontains=cd['search']) | Q(email__icontains=cd['search']))
            if cd.get('is_active') in ('0', '1'):
                qs = qs.filter(is_active=bool(int(cd['is_active'])))
            if cd.get('group'):
                qs = qs.filter(groups=cd['group'])
            if cd.get('role'):
                qs = qs.filter(role_assignments__role=cd['role'])
            if cd.get('date_joined_from'):
                qs = qs.filter(date_joined__gte=cd['date_joined_from'])
            if cd.get('date_joined_to'):
                qs = qs.filter(date_joined__lte=cd['date_joined_to'])
        return qs.order_by('-date_joined')

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx['form'] = AdminUserFilterForm(self.request.GET)
        ctx['roles'] = Role.objects.filter(is_active=True)
        return ctx


@method_decorator(never_cache, name='dispatch')
class AdminUserDetailView(LoginRequiredMixin, PermissionRequiredMixin, DetailView):
    model = User
    context_object_name = 'user_obj'
    template_name = 'users/admin/user/detail.html'

    permission_required = 'users.view_user'
    raise_exception = True

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx['test_datas'] = ExpertTestData.objects.filter(user=self.object)
        ctx['role_assignments'] = RoleAssignment.objects.filter(user=self.object).select_related('role')
        ctx['prospect_links'] = ProspectLink.objects.filter(user=self.object).select_related('prospect')
        ctx['sessions'] = UserSession.objects.filter(user=self.object, is_active=True).order_by('-last_seen')
        ctx['twofa_devices'] = TwoFactorDevice.objects.filter(user=self.object, is_active=True)
        return ctx


@method_decorator(never_cache, name='dispatch')
class AdminUserUpdateView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    model = User
    form_class = AdminUserEditForm
    context_object_name = 'user_obj'
    template_name = 'users/admin/user/form.html'
    success_url = reverse_lazy('jeiko_administration_users:user_list')

    permission_required = 'users.change_user'
    raise_exception = True

# ----------------------------------------------------------
#  Rôles & permissions
# ----------------------------------------------------------

@method_decorator(never_cache, name='dispatch')
class RoleListView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    model = Role
    template_name = "users/admin/roles/list.html"
    context_object_name = "roles"

    permission_required = 'users.view_role'
    raise_exception = True

    def get_queryset(self):
        return Role.objects.all().order_by("name")


@method_decorator(never_cache, name='dispatch')
class RoleCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    model = Role
    form_class = RoleForm
    template_name = "users/admin/roles/form.html"

    permission_required = 'users.add_role'
    raise_exception = True

    def get_form_kwargs(self):
        kw = super().get_form_kwargs()
        kw["request"] = self.request
        return kw

    def get_success_url(self):
        messages.success(self.request, "Rôle créé.")
        return reverse('jeiko_administration_users:role_list')


@method_decorator(never_cache, name='dispatch')
class RoleUpdateView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    model = Role
    form_class = RoleForm
    template_name = "users/admin/roles/form.html"

    permission_required = 'users.change_role'
    raise_exception = True

    def get_form_kwargs(self):
        kw = super().get_form_kwargs()
        kw["request"] = self.request
        return kw

    def get_success_url(self):
        messages.success(self.request, "Rôle mis à jour.")
        return reverse('jeiko_administration_users:role_list')



@method_decorator(never_cache, name='dispatch')
class RoleDeleteView(LoginRequiredMixin, PermissionRequiredMixin, DeleteView):
    model = Role
    template_name = "users/admin/roles/confirm_delete.html"

    permission_required = 'users.delete_role'
    raise_exception = True

    def get_success_url(self):
        messages.success(self.request, "Rôle supprimé.")
        return reverse('jeiko_administration_users:role_list')


@method_decorator(never_cache, name='dispatch')
class RolePermissionCreateView(LoginRequiredMixin, StaffOnlyMixin, CreateView):
    model = RolePermission
    form_class = RolePermissionForm
    template_name = "users/admin/roles/role_permission_form.html"

    def get_initial(self):
        initial = super().get_initial()
        role_id = self.request.GET.get('role')
        if role_id:
            initial['role'] = get_object_or_404(Role, pk=role_id)
        return initial

    def get_success_url(self):
        messages.success(self.request, "Permission ajoutée au rôle.")
        return reverse('jeiko_administration_users:role_list')


@method_decorator(never_cache, name='dispatch')
class RolePermissionDeleteView(LoginRequiredMixin, StaffOnlyMixin, DeleteView):
    model = RolePermission
    template_name = "users/admin/roles/role_permission_confirm_delete.html"

    def get_success_url(self):
        messages.success(self.request, "Permission retirée du rôle.")
        return reverse('jeiko_administration_users:role_list')


@method_decorator(never_cache, name='dispatch')
class RoleAssignmentCreateView(LoginRequiredMixin, StaffOnlyMixin, CreateView):
    model = RoleAssignment
    form_class = RoleAssignmentForm
    template_name = "users/admin/roles/role_assignment_form.html"

    def get_initial(self):
        initial = super().get_initial()
        user_id = self.request.GET.get('user')
        role_id = self.request.GET.get('role')
        if user_id:
            initial['user'] = get_object_or_404(User, pk=user_id)
        if role_id:
            initial['role'] = get_object_or_404(Role, pk=role_id)
        return initial

    def get_success_url(self):
        messages.success(self.request, "Rôle assigné.")
        return reverse('jeiko_administration_users:role_list')


@method_decorator(never_cache, name='dispatch')
class RoleAssignmentDeleteView(LoginRequiredMixin, StaffOnlyMixin, DeleteView):
    model = RoleAssignment
    template_name = "users/admin/roles/role_assignment_confirm_delete.html"

    def get_success_url(self):
        messages.success(self.request, "Assignation supprimée.")
        return reverse('jeiko_administration_users:role_list')


@method_decorator(never_cache, name='dispatch')
class BulkAssignRoleView(LoginRequiredMixin, StaffOnlyMixin, FormView):
    form_class = BulkAssignRoleForm
    template_name = "users/admin/roles/role_bulk_assign.html"

    def form_valid(self, form):
        user_ids = form.cleaned_data['user_ids']
        role = form.cleaned_data['role']
        users = User.objects.filter(id__in=user_ids)
        created = 0
        for u in users:
            RoleAssignment.objects.get_or_create(user=u, role=role, defaults={'assigned_by': self.request.user})
            created += 1
        messages.success(self.request, f"{created} assignation(s) créées.")
        return redirect('jeiko_administration_users:role_list')


@method_decorator(never_cache, name='dispatch')
class BulkRevokeRoleView(LoginRequiredMixin, StaffOnlyMixin, FormView):
    form_class = BulkRevokeRoleForm
    template_name = "users/admin/roles/role_bulk_revoke.html"

    def form_valid(self, form):
        user_ids = form.cleaned_data['user_ids']
        role = form.cleaned_data['role']
        qs = RoleAssignment.objects.filter(user_id__in=user_ids, role=role)
        count = qs.count()
        qs.delete()
        messages.success(self.request, f"{count} assignation(s) supprimées.")
        return redirect('jeiko_administration_users:role_list')


# ----------------------------------------------------------
#  Providers (allauth)
# ----------------------------------------------------------

@method_decorator(never_cache, name='dispatch')
class ProviderListView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    model = ProviderConfig
    template_name = "users/admin/providers/provider_list.html"
    context_object_name = "providers"
    ordering = ("provider", "label")

    permission_required = 'users.authprov_view_providerconfig'
    raise_exception = True


@method_decorator(never_cache, name='dispatch')
class ProviderCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    model = ProviderConfig
    form_class = ProviderConfigForm
    template_name = "users/admin/providers/provider_form.html"

    permission_required = 'users.authprov_add_providerconfig'
    raise_exception = True


    def get_success_url(self):
        messages.success(self.request, "Provider enregistré.")
        return reverse('jeiko_administration_users:provider_list')


@method_decorator(never_cache, name='dispatch')
class ProviderUpdateView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    model = ProviderConfig
    form_class = ProviderConfigForm
    template_name = "users/admin/providers/provider_form.html"

    permission_required = 'users.authprov_change_providerconfig'
    raise_exception = True

    def get_success_url(self):
        messages.success(self.request, "Provider mis à jour.")
        return reverse('jeiko_administration_users:provider_list')


@method_decorator(never_cache, name='dispatch')
class ProviderDeleteView(LoginRequiredMixin, PermissionRequiredMixin, DeleteView):
    model = ProviderConfig
    template_name = "users/admin/providers/provider_confirm_delete.html"

    permission_required = 'users.authprov_delete_providerconfig'
    raise_exception = True


    def get_success_url(self):
        messages.success(self.request, "Provider supprimé.")
        return reverse('jeiko_administration_users:provider_list')


# ----------------------------------------------------------
#  Sécurité : 2FA, sessions, audit
# ----------------------------------------------------------
@method_decorator(never_cache, name='dispatch')
class TwoFactorDeviceListView(LoginRequiredMixin, StaffOnlyMixin, ListView):
    model = TwoFactorDevice
    template_name = "users/admin/security/twofa_list.html"
    context_object_name = "devices"
    ordering = ("-updated_at",)


@method_decorator(never_cache, name='dispatch')
class TwoFactorDeviceCreateView(LoginRequiredMixin, StaffOnlyMixin, CreateView):
    model = TwoFactorDevice
    form_class = TwoFactorDeviceForm
    template_name = "users/admin/security/twofa_form.html"

    def get_success_url(self):
        messages.success(self.request, "Dispositif 2FA créé.")
        return reverse('jeiko_administration_users:twofa_list')


@method_decorator(never_cache, name='dispatch')
class TwoFactorDeviceUpdateView(LoginRequiredMixin, StaffOnlyMixin, UpdateView):
    model = TwoFactorDevice
    form_class = TwoFactorDeviceForm
    template_name = "users/admin/security/twofa_form.html"

    def get_success_url(self):
        messages.success(self.request, "Dispositif 2FA mis à jour.")
        return reverse('jeiko_administration_users:twofa_list')


@method_decorator(never_cache, name='dispatch')
class TwoFactorDeviceDeleteView(LoginRequiredMixin, StaffOnlyMixin, DeleteView):
    model = TwoFactorDevice
    template_name = "users/admin/security/twofa_confirm_delete.html"

    def get_success_url(self):
        messages.success(self.request, "Dispositif 2FA supprimé.")
        return reverse('jeiko_administration_users:twofa_list')


@method_decorator(never_cache, name='dispatch')
class UserSessionRevokeView(LoginRequiredMixin, StaffOnlyMixin, FormView):
    form_class = UserSessionRevokeForm
    template_name = "users/admin/security/session_revoke.html"

    def form_valid(self, form):
        ids = form.cleaned_data['session_ids']
        count = UserSession.objects.filter(id__in=ids).update(is_active=False)
        messages.success(self.request, f"{count} session(s) révoquées.")
        return back(self.request, 'jeiko_administration_users:user_list')


@method_decorator(never_cache, name='dispatch')
class SecurityEventListView(LoginRequiredMixin, StaffOnlyMixin, ListView):
    model = SecurityEvent
    template_name = "users/admin/security/security_event_list.html"
    context_object_name = "events"
    paginate_by = 50
    ordering = ("-occured_at",)

    def get_queryset(self):
        qs = super().get_queryset().select_related('user')
        form = SecurityEventFilterForm(self.request.GET)
        if form.is_valid():
            cd = form.cleaned_data
            if cd.get('user'):
                qs = qs.filter(user=cd['user'])
            if cd.get('event_type'):
                qs = qs.filter(event_type=cd['event_type'])
            if cd.get('date_from'):
                qs = qs.filter(occured_at__gte=cd['date_from'])
            if cd.get('date_to'):
                qs = qs.filter(occured_at__lte=cd['date_to'])
        return qs

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx['form'] = SecurityEventFilterForm(self.request.GET)
        return ctx


# ----------------------------------------------------------
#  Consentements & préférences
# ----------------------------------------------------------

@method_decorator(never_cache, name='dispatch')
class ConsentCreateView(LoginRequiredMixin, StaffOnlyMixin, CreateView):
    model = Consent
    form_class = ConsentForm
    template_name = "users/admin/consent/consent_form.html"

    def get_success_url(self):
        messages.success(self.request, "Consentement enregistré.")
        return back(self.request, 'jeiko_administration_users:consent_create')


@method_decorator(never_cache, name='dispatch')
class MarketingPreferenceUpdateView(LoginRequiredMixin, StaffOnlyMixin, UpdateView):
    model = MarketingPreference
    form_class = MarketingPreferenceForm
    template_name = "users/admin/consent/marketing_pref_form.html"

    def get_success_url(self):
        messages.success(self.request, "Préférences marketing mises à jour.")
        return back(self.request, 'jeiko_administration_users:user_list')


# ----------------------------------------------------------
#  Notifications
# ----------------------------------------------------------

@method_decorator(never_cache, name='dispatch')
class NotificationChannelCreateView(LoginRequiredMixin, StaffOnlyMixin, CreateView):
    model = NotificationChannel
    form_class = NotificationChannelForm
    template_name = "users/admin/notifications/channel_form.html"

    def get_success_url(self):
        messages.success(self.request, "Canal de notification enregistré.")
        return back(self.request, 'jeiko_administration_users:user_list')


@method_decorator(never_cache, name='dispatch')
class NotificationComposeView(LoginRequiredMixin, StaffOnlyMixin, CreateView):
    model = Notification
    form_class = NotificationComposeForm
    template_name = "users/admin/notifications/notification_form.html"

    def get_success_url(self):
        messages.success(self.request, "Notification enregistrée.")
        return back(self.request, 'jeiko_administration_users:user_list')


@method_decorator(never_cache, name='dispatch')
class BulkNotificationView(LoginRequiredMixin, StaffOnlyMixin, FormView):
    form_class = BulkNotificationForm
    template_name = "users/admin/notifications/notification_bulk_form.html"

    def form_valid(self, form):
        ids = form.cleaned_data['user_ids']
        notif_type = form.cleaned_data['notif_type']
        payload = form.cleaned_data.get('payload') or ""
        users = User.objects.filter(id__in=ids)
        created = 0
        for u in users:
            Notification.objects.create(user=u, notif_type=notif_type, payload={"body": payload})
            created += 1
        messages.success(self.request, f"{created} notification(s) créées.")
        return back(self.request, 'jeiko_administration_users:user_list')


# ----------------------------------------------------------
#  Bridge User ↔ Prospect
# ----------------------------------------------------------

@method_decorator(never_cache, name='dispatch')
class ProspectLinkCreateView(LoginRequiredMixin, StaffOnlyMixin, CreateView):
    model = ProspectLink
    form_class = ProspectLinkForm
    template_name = "users/admin/prospects/prospect_link_form.html"

    def get_initial(self):
        initial = super().get_initial()
        user_id = self.request.GET.get('user')
        prospect_id = self.request.GET.get('prospect')
        if user_id:
            initial['user'] = get_object_or_404(User, pk=user_id)
        if prospect_id:
            initial['prospect'] = get_object_or_404(Prospect, pk=prospect_id)
        return initial

    def get_success_url(self):
        messages.success(self.request, "Lien User ↔ Prospect créé.")
        return back(self.request, 'jeiko_administration_users:user_list')


@method_decorator(never_cache, name='dispatch')
class ProspectLinkDeleteView(LoginRequiredMixin, StaffOnlyMixin, DeleteView):
    model = ProspectLink
    template_name = "users/admin/prospects/prospect_link_confirm_delete.html"

    def get_success_url(self):
        messages.success(self.request, "Lien User ↔ Prospect supprimé.")
        return back(self.request, 'jeiko_administration_users:user_list')
