from django.contrib.auth.backends import BaseBackend
from django.contrib.auth.models import Permission

class RolePermissionBackend(BaseBackend):
    """
    Donne des permissions via les rôles (Role ↔ RoleAssignment ↔ Permission).
    Ne gère PAS l'authentification (authenticate retourne None).
    """

    def authenticate(self, request, **credentials):
        return None

    def has_perm(self, user_obj, perm, obj=None):
        if not user_obj or not user_obj.is_active:
            return False
        if user_obj.is_superuser:
            return True
        if not perm or "." not in perm:
            return False
        app_label, codename = perm.split(".", 1)
        return user_obj.role_assignments.filter(
            role__is_active=True,
            role__permissions__content_type__app_label=app_label,
            role__permissions__codename=codename,
        ).exists()

    def has_module_perms(self, user_obj, app_label):
        if not user_obj or not user_obj.is_active:
            return False
        if user_obj.is_superuser:
            return True
        return user_obj.role_assignments.filter(
            role__is_active=True,
            role__permissions__content_type__app_label=app_label,
        ).exists()

    def get_all_permissions(self, user_obj, obj=None):
        if not user_obj or not user_obj.is_active:
            return set()
        if user_obj.is_superuser:
            # Renvoie toutes les perms "app.codename"
            qs = Permission.objects.all().values_list(
                "content_type__app_label", "codename"
            )
            return {f"{a}.{c}" for a, c in qs}
        qs = Permission.objects.filter(
            roles__assignments__user=user_obj,
            roles__is_active=True,
        ).values_list("content_type__app_label", "codename")
        return {f"{a}.{c}" for a, c in qs}
