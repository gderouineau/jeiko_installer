# JEIKO Installer v2

Installe et maintient un site JEIKO sur Debian ou Ubuntu : Django + Gunicorn + Nginx +
PostgreSQL + Memcached, avec TLS, sauvegardes et mise à jour depuis l'interface
d'administration.

---

## Ce qui a changé par rapport à la v1

La mise à jour depuis l'administration ne fonctionnait pas, pour quatre raisons
qui se cumulaient :

| Symptôme | Cause |
|---|---|
| Rien ne se passe, ou erreur sudo | Le fichier sudoers n'autorisait que `systemctl`, alors que la vue lançait `sudo <script>`. Sudo réclamait un mot de passe, sans terminal pour le saisir. |
| Le script se comporte de façon erratique | Il vivait dans `site-packages/jeiko/scripts/` et `pip install` le réécrivait pendant sa propre exécution. D'où les rustines « SELF-FIX » et un `chown` codé en dur sur un seul site. |
| La page ne revient jamais | Le script redémarrait Gunicorn, donc tuait le processus Django qui l'attendait. |
| Erreur 504 | La mise à jour dépassait le `proxy_read_timeout` de 60 s de Nginx. |

**Le correctif structurel** : l'updater sort de l'application.

```
avant   Django ──sudo──▶ script dans site-packages   (inscriptible par le site)
après   Django ──sudo──▶ systemctl start jeiko-update@<site>
                              └──▶ /usr/local/sbin/jeiko-client-update  (root:root)
```

L'application ne peut plus que **déclencher** sa propre mise à jour. Elle ne
peut plus décider de ce qui s'exécute sous privilèges.

### Deux scripts, deux responsabilités

| | Lancé par | Périmètre |
|---|---|---|
| `jeiko-server-update` | toi, en SSH | nginx, systemd, sudoers, permissions, sauvegardes. Installe aussi le script client. |
| `jeiko-client-update` | l'interface d'administration, ou toi | le package, `settings.py`, `urls.py`, migrations, statiques. |

Le client ne touche jamais à la configuration serveur : un clic dans
l'administration ne réécrit pas un vhost Nginx. Et comme c'est le script
serveur qui met à jour le script client, ce dernier n'a pas besoin de vivre
dans le package ni de se réécrire lui-même — ce qui supprime d'un coup
l'auto-écrasement par pip.

`settings.py` et `urls.py` voyagent **dans le package**
(`jeiko/project_template/`). C'est ce qui permet à une version qui ajoute une
application à `INSTALLED_APPS` d'arriver avec le `settings.py` qui la déclare :
le client réaligne le fichier, sans terminal.

---

## Prérequis

- Debian 12 ou 13, ou Ubuntu 22.04, 24.04 ou 26.04 LTS ; utilisateur avec
  `sudo`. Toute autre distribution est refusée juste après le choix de la
  langue, avant la moindre question ou modification ; une version plus
  récente que celles-ci est acceptée, avec un avertissement.
- Ports 22, 80, 443 ouverts
- Pour la visio, ouverts par l'installeur lui-même : 7881/tcp et 7882/udp (son
  et image), 3478/udp et 5349/tcp (relais pour les réseaux filtrés)
- Un domaine pointant vers le VPS (obligatoire si tu actives TLS)

---

## Installation d'un nouveau site

```bash
sudo apt-get update -y && sudo apt-get install -y curl unzip
sudo mkdir -p /var/www && cd /var/www
D=https://raw.githubusercontent.com/gderouineau/jeiko_installer/main
M="$(curl -fsSL "$D/version.json")"
A="$(printf '%s' "$M" | sed -n 's/.*"archive": *"\(jeiko-installer-v[0-9.]*\.zip\)".*/\1/p')"
S="$(printf '%s' "$M" | sed -n 's/.*"sha256": *"\([0-9a-f]\{64\}\)".*/\1/p')"
sudo curl -fL -o jeiko-installer.zip "$D/$A"
echo "$S  jeiko-installer.zip" | sha256sum -c - \
  && sudo unzip -o jeiko-installer.zip -d jeiko-installer \
  && cd jeiko-installer && sudo chmod +x install.sh && sudo ./install.sh
```

L'archive est celle que nomme `version.json`, et son empreinte est vérifiée
AVANT d'être extraite : une archive tronquée, ou différente de celle qui a été
publiée, s'arrête à « FAILED » sans rien installer.

L'installeur pose les questions, affiche un récapitulatif, puis enchaîne les
étapes `00` à `14`. Chaque étape est idempotente : en cas d'échec, corrige la
cause et relance `./install.sh`.

---

## Migrer un site existant

**À faire avant toute autre chose sur un serveur déjà en production.** Les sites
installés en v1 n'ont ni updater, ni fiche, ni sudoers correct.

```bash
sudo ./migrate_site.sh --list           # ce qui est détecté, et ce qui est déjà migré
sudo ./migrate_site.sh monsite --dry-run  # montre sans rien modifier
sudo ./migrate_site.sh monsite            # migration réelle, interactive
```

Le script reconstitue la fiche du site, retire l'ancien mécanisme de mise à
jour, puis passe la main à la convergence (`jeiko-server-update`), qui
sauvegarde la configuration qu'elle modifie dans
`/var/backups/jeiko/<site>/server-update_<horodatage>/`, teste `nginx -t`
avant de recharger et restaure le vhost si le test échoue.

La migration ne sauvegarde pas la base. Sur un serveur où l'outillage est
déjà en place, faire d'abord une sauvegarde complète :

```bash
sudo jeiko-backup monsite
```

---

## Publier une version

Double-clic sur **`Publier JEIKO`** sur le bureau, ou :

```bash
~/Documents/Projects/packages/jeiko/publier.sh
```

Il demande le type de version, puis fait tout le reste :

```
1) Correction  → 0.6.5   (corrections de bugs)
2) Mineure     → 0.7.0   (nouveautés, compatible)
3) Majeure     → 1.0.0   (changement de fond)
```

Déroulé : miroir de `Art/ENV/…/jeiko` et `Art/INSTALLER` vers le dossier de
publication → contrôle des doublons → gabarits recopiés dans le package →
version dans `pyproject.toml` → wheel → `version.json` avec l'empreinte →
archives → publication sur les deux dépôts.

| Dépôt | Contenu |
|---|---|
| `gderouineau/jeiko` | `version.json`, `dist/*.whl`, `jeiko-latest.zip`, `jeiko-v<version>.zip` |
| `gderouineau/jeiko_installer` | `jeiko-installer-latest.zip`, `jeiko-installer-v<version>.zip` |

Chaque archive existe en deux exemplaires : `latest`, que téléchargent les
serveurs déjà installés, et une copie versionnée qui garde l'historique.

`version.json` est ce que les serveurs lisent pour savoir s'il y a une mise à
jour, et le `sha256` est **le seul lien de confiance** entre ce que tu publies
et ce qui s'exécute en production.

Options : `--dry-run` montre tout sans rien modifier, `--local` prépare les
archives sans publier.

### Le miroir, plutôt que le copier-coller

La copie manuelle par le Finder ajoutait `fichier 2.py` à côté de l'original au
lieu de le remplacer. 89 doublons s'étaient accumulés dans le dossier de
publication, dont **101 sont partis dans l'archive publiée** — donc en
production, depuis février. `rsync --delete --delete-excluded` règle le
problème, et le script refuse de publier s'il détecte un doublon côté source.

---

## Mettre à jour un site

### Récupérer le dernier installeur sur le serveur

Les commandes `jeiko-*-update` s'exécutent depuis l'outillage **déjà déposé** sur
la machine : elles lisent leurs gabarits (nginx, unités systemd, scripts d'étape)
dans `/usr/local/share/jeiko`, pas depuis un dossier d'installeur. Après avoir
publié une nouvelle version de l'installeur, rafraîchis d'abord cet outillage,
sinon la convergence rejoue les anciens gabarits :

```bash
sudo apt-get install -y curl unzip
cd /var/www
D=https://raw.githubusercontent.com/gderouineau/jeiko_installer/main
M="$(curl -fsSL "$D/version.json")"
A="$(printf '%s' "$M" | sed -n 's/.*"archive": *"\(jeiko-installer-v[0-9.]*\.zip\)".*/\1/p')"
S="$(printf '%s' "$M" | sed -n 's/.*"sha256": *"\([0-9a-f]\{64\}\)".*/\1/p')"
sudo curl -fL -o jeiko-installer.zip "$D/$A"
echo "$S  jeiko-installer.zip" | sha256sum -c - \
  && sudo unzip -o jeiko-installer.zip -d jeiko-installer \
  && cd jeiko-installer \
  && sudo ./migrate_site.sh --tools-only    # dépose les nouveaux gabarits/scripts, sans toucher aux sites
```

Un site jamais amorcé sur ce schéma (installé avant l'installeur v2) :
`sudo ./migrate_site.sh <site>` à la place — voir « Migrer un site existant ».

### Mettre à jour le package (côté client)

Depuis l'interface : **Administration ▸ Mettre à jour JEIKO**. La page affiche
le journal en direct et survit au redémarrage du site.

Depuis le serveur :

```bash
sudo jeiko-client-update monsite --check     # compare les versions, n'installe rien
sudo jeiko-client-update monsite             # mise à jour du package
sudo jeiko-client-update monsite --force     # réinstalle la même version
sudo jeiko-client-update monsite --rollback  # revient à la version précédente
```

**Le serveur d'abord.** La mise à jour du package est refusée tant que le
site n'a pas été convergé avec l'installeur publié : un package récent peut
attendre une configuration serveur qui n'existe pas encore. Le message dit quoi
faire (Mises à jour ▸ Serveur, ou `sudo jeiko-maj --serveur monsite`).
`--ignorer-serveur` lève ce contrôle, en terminal seulement.

Déroulé : manifeste → vérification sha256 (paquet et dépendances) → Python
minimum → **préparation d'un nouvel environnement à côté** (`venv.next` : le
paquet et ses dépendances, site ouvert, l'environnement vivant intact) →
maintenance → dump PostgreSQL → **bascule** (deux renommages ; l'ancien
environnement est gardé en `venv.precedent`) → réalignement de `settings.py`
et `urls.py` → `django check` → migrations → collectstatic → permissions →
redémarrage → contrôle de santé → tâches planifiées.

Un échec pendant la préparation ne coûte rien : le nouvel environnement est
jeté, le site n'a rien vu. **Après la bascule, toute erreur déclenche un
retour arrière** : l'environnement d'avant reprend sa place d'un renommage —
mêmes dépendances, même paquet, sans réseau —, gabarits restaurés, base
restaurée si les migrations avaient tourné, statiques recollectés. Un retour
arrière qui n'aboutit pas entièrement le dit. (Un site dont le venv vit hors
de son dossier de projet s'installe sur place, avec le wheel de la version
installée pour filet.)

Le paquet se prépare site ouvert. Ensuite, du dump au redémarrage, le site
passe en maintenance : ses tâches planifiées sont suspendues et nginx affiche
sa page « indisponible » — rien ne s'écrit dans une base qu'un retour arrière
pourrait restaurer. Les webhooks refusés pendant ce temps (Stripe) sont
renvoyés par leur expéditeur. `jeiko-restore` procède de même.

### Mettre à jour la configuration serveur

Le package et le serveur évoluent séparément. Quand une version de l'installeur
apporte des corrections de configuration :

```bash
sudo jeiko-server-update monsite       # un site
sudo jeiko-server-update --all         # tous les sites de la machine
sudo jeiko-server-update monsite --with-client   # config serveur puis package
sudo jeiko-server-update --list        # sites enregistrés
```

Idempotent : le relancer sur un site déjà à jour ne change rien. Sauvegarde
avant, `nginx -t` avant rechargement, restauration si le test échoue.

**Ce que la convergence serveur couvre — et ne couvre pas.** Elle n'est *pas*
une réinstallation. Elle régénère toute la *configuration serveur du site* à
partir des **mêmes scripts d'étape** que l'installation (unité gunicorn `10`,
nginx `11`, TLS `12`, sauvegardes `13`), plus les unités systemd, le sudoers,
les permissions, les clés `.env` requises et les timers cron : un site déjà en
place converge donc vers **la même configuration qu'une install neuve
produirait**. Elle ne réinstalle **pas** la stack partagée (PostgreSQL,
memcached, venv), ne recrée ni la base ni le compte système, et ne rejoue pas
le durcissement (`01`) — ce sont des opérations d'installation, destructrices ou
inutiles sur un site vivant. Le package, `settings.py`/`urls.py` et les
migrations relèvent de la **maj client** (`--with-client` ou
`jeiko-client-update`). En clair : **maj serveur + maj client = tout à jour** ;
la maj serveur seule ne suffit que pour de la configuration serveur pure.

### Plusieurs sites sur une machine : les ressources de chacun

Sur une machine qui héberge plusieurs sites, chacun a ses ressources, écrites
dans sa fiche (`/etc/jeiko/sites/<site>.conf`, root seul) et appliquées par la
convergence :

```bash
sudo jeiko-server-update monsite --workers 2 --retention 14 --quota-medias 2
sudo jeiko-server-update monsite --workers auto    # revenir au calcul par défaut
```

| Réglage | Par défaut | Effet |
|---|---|---|
| `--workers N` (1 à 12) | premier site : 2 × cœurs + 1, plafonné par la RAM ; site suivant : **2** | workers gunicorn du site |
| `--retention JOURS` (1 à 365) | 30 | sauvegardes quotidiennes gardées sur la machine (chacune contient TOUS les médias) |
| `--quota-medias GO` (1 à 1000) | aucun | `jeiko-verifier` alerte au-delà ; rien n'est bloqué |

Sans réglage, un nouveau site installé sur une machine qui en porte déjà un
reçoit 2 workers : le calcul par cœurs donnerait à chaque site les workers
d'un serveur entier. Les sauvegardes locales ne protègent pas de la perte de
la machine : configurer une copie hors serveur (`JEIKO_OFFSITE_TARGET`, voir
« Sauvegardes »).

### La mise à jour automatique — `jeiko-maj`

Chaque site peut cocher **« Mise à jour automatique »** (Mises à jour ▸
Réglages, décochée par défaut). Chaque semaine, dans la nuit de dimanche à
lundi (00:15–00:30, `jeiko-maj.timer`), si au moins un site de la machine l'a
cochée :

1. **le serveur** — si un installeur plus récent est publié : archive
   vérifiée (sha256 du `version.json` du dépôt de l'installeur), outillage
   déposé par son `migrate_site.sh --tools-only`, puis chaque site convergé
   **un par un** : un échec propre à un site n'arrête pas la passe, un site
   que la convergence rend indisponible l'arrête net (un installeur fautif ne
   touche qu'un site) ;
2. **les sites** — ensuite seulement, et si l'étape 1 a réussi : le package de
   chaque site coché, s'il est en retard, avec ses timers. Un site en échec
   revient à son état d'avant et n'arrête pas les autres.

Rien ne commence après 03:45 (le redémarrage automatique du système tombe à
04:20) : ce qui n'est pas atteint passe la semaine suivante. Une passe
interrompue reprend là où elle s'est arrêtée — chaque site garde la version de
l'installeur avec laquelle il a été convergé.

Un site peut aussi demander l'étape serveur seule (Mises à jour ▸ Serveur ▸
« Mettre à jour le serveur ») : `jeiko-maj-serveur@<site>.service`. Elle ne fait
rien si le serveur est à jour, et concerne tous les sites de la machine.

```bash
sudo jeiko-maj --simulation          # dit ce que ferait la passe, ne touche à rien
sudo jeiko-maj --serveur monsite     # l'étape serveur, comme le bouton
sudo jeiko-maj --hebdo --sans-limite # la passe complète, hors de la fenêtre
```

État lu par les administrations : `/var/lib/jeiko/maj-serveur.state`. Journal
complet (il nomme tous les sites) : `/var/log/jeiko/maj-serveur.log`, root seul.

---

## La visio

Chaque installation et chaque convergence (`jeiko-server-update`, donc aussi
`jeiko-maj`) posent le serveur de visio LiveKit DU SITE — chaque site a le
sien, avec sa seule clé et ses propres ports —, la clé dans son `.env`, le
relais nginx `https://<domaine>/visio-rtc/` et les ports du pare-feu. Rien à
lancer à la main : la visio s'active depuis l'administration du site
(Réglages › Général › module « Conférence »). 50 personnes au plus par
séance ; pas d'enregistrement.

```bash
systemctl status livekit@monsite        # le service du site
journalctl -u livekit@monsite -n 50     # son journal
cat /var/lib/jeiko/visio-rangs/monsite  # son rang : ports 7880+10×rang…
```

---

## Sauvegardes

Quotidiennes, à une heure décalée par site pour ne pas saturer la machine.

```bash
sudo jeiko-backup monsite                                   # à la demande
sudo jeiko-restore monsite /var/backups/jeiko/monsite/daily/<horodatage>
```

Chaque sauvegarde contient un dump PostgreSQL (vérifié par `pg_restore --list`),
les médias, les fichiers de configuration, un `MANIFESTE` (la version du paquet
qui a produit la base) et leurs empreintes. Elle ne commence pas si la place
manque sur le disque. Rétention : 30 jours. La copie hors site (`JEIKO_OFFSITE_TARGET` dans la fiche) chiffre
avant l'envoi si une phrase secrète est configurée ; si elle ne peut pas
chiffrer, elle n'envoie rien et la sauvegarde locale reste.

`jeiko-restore` vérifie l'archive avant d'arrêter le site, arrête aussi ses
tâches planifiées, puis restaure **la base et les médias** et lance `migrate`.
Une base produite par un paquet plus récent que celui installé est refusée :
mettre d'abord le paquet à jour (ou `--force`). `--avec-config` remet aussi le
`.env` du site (l'ancien est gardé en `.env.avant-restauration`) ; la fiche et
le vhost restent dans `config.tar.gz`.

La désinstallation (`sudo ./uninstall.sh <site>`) garde les sauvegardes du
site — `--purge-backups` pour les effacer — et ne supprime son compte Unix que
s'il n'appartient qu'à lui.

---

## Changer le domaine d'un site

```bash
sudo jeiko-changer-domaine monsite nouveau-domaine.fr --dry-run   # vérifie sans rien changer
sudo jeiko-changer-domaine monsite nouveau-domaine.fr
```

Il vérifie d'abord que le domaine est bien formé, qu'aucun autre site du
serveur ne le sert, et — en HTTPS — qu'il résout déjà (www compris pour un
domaine nu). Puis il met à jour la fiche et le `.env` du site et reconverge :
vhost, certificat, visio. En cas d'échec, l'ancien domaine est remis. Restent
à faire dans l'administration du site : l'adresse dans Réglages › Identité, et
les clés d'accès (passkeys), liées à l'ancien domaine.

---

## Changer le mot de passe d'un compte

```bash
sudo jeiko-mot-de-passe monsite                  # liste les comptes d'administration, puis demande
sudo jeiko-mot-de-passe monsite gerant@exemple.fr
```

Pour quand « mot de passe oublié » ne peut pas servir (le site ne sait pas
encore envoyer d'e-mail, l'adresse n'est plus lue). Le mot de passe est
demandé deux fois, sans écho, et n'apparaît nulle part. Il suit les règles de
mot de passe du site ; l'adresse du compte est confirmée si la connexion
l'exige ; les sessions ouvertes sur ce compte sont fermées, le changement entre
au journal de sécurité et le titulaire en est prévenu par e-mail. Un compte
désactivé ou protégé par la double authentification le reste.

---

## Déménager un site vers un autre serveur

Le serveur d'arrivée a l'installeur et son outillage (`migrate_site.sh
--tools-only`, voir plus haut). Puis :

```bash
# 1. Sur le serveur de départ : une sauvegarde neuve, le certificat, la fiche
sudo jeiko-transferer exporter monsite
# 2. Depuis ton poste : l'archive d'un serveur à l'autre
scp -3 debian@depart:monsite-transfert-<date>.tar debian@arrivee:
# 3. Sur le serveur d'arrivée : vérifier, puis poser
sudo jeiko-transferer importer monsite-transfert-<date>.tar --dry-run
sudo jeiko-transferer importer monsite-transfert-<date>.tar
```

L'import vérifie tout avant de poser quoi que ce soit : l'archive (empreintes,
rien que des fichiers), qu'aucun site, dossier, base ou domaine du même nom
n'existe déjà ici, que le paquet publié n'est pas plus ancien que la base.
Puis il installe le site (étapes de l'installeur), remet son `.env`, converge,
et restaure la base et les médias. Le site garde ses comptes, ses contenus, ses
réglages et ses secrets.

Le domaine peut rester le même : le certificat HTTPS suit, le site répond sur
le nouveau serveur avant que le DNS y pointe, et la bascule se fait sans
coupure. Pour en changer en même temps : `--domaine nouveau-domaine.fr` (il
doit déjà pointer vers le serveur d'arrivée) — c'est `jeiko-changer-domaine`
qui s'en charge, à la fin.

Restent à la main : la bascule DNS ; le retrait du site de l'ancien serveur une
fois le nouveau vérifié (`sudo ./uninstall.sh monsite`) — ce qui y a été écrit
après l'export ne suit pas, d'où un export au dernier moment ; la copie hors
site et les alertes du nouveau serveur. L'archive contient la base et les
secrets du site : l'effacer des deux serveurs une fois le transfert fait.

---

## L'IPv6 du serveur

Chaque domaine doit viser ce serveur, IPv6 comprise : Let's Encrypt passe par
l'IPv6 quand la zone DNS a un enregistrement AAAA. Certains hébergeurs (OVH)
attribuent une IPv6 au VPS et publient un AAAA vers elle, sans que l'adresse
soit activée sur la machine. L'installeur le reconnaît et propose de
l'activer ; sur un serveur déjà en place :

```bash
sudo jeiko-ipv6              # dit l'état, ne change rien
sudo jeiko-ipv6 --activer    # active l'IPv6 attribuée par l'hébergeur
```

L'adresse est d'abord activée à chaud, gardée seulement si la passerelle
répond, puis écrite pour les démarrages suivants ; l'IPv4 n'est pas touchée.
Sans IPv6 attribuée, la zone DNS ne doit pas avoir de AAAA (domaine et www).

---

## Surveillance

```bash
sudo jeiko-alertes           # une fois : où envoyer les alertes (serveur SMTP), puis un e-mail d'essai
sudo jeiko-verifier          # à la demande
```

Tourne aussi chaque heure, journal dans `/var/log/jeiko/verification.log`.
Contrôle le disque, la mémoire disponible, l'expiration des certificats, l'état
des services, chaque site tel qu'un visiteur le voit (à travers nginx) et l'âge
des sauvegardes. Quand l'ensemble des problèmes change — un nouveau, un de
moins, le retour à la normale —, un e-mail part, envoyé par le serveur
lui-même : un site en panne ne peut pas prévenir. Un problème qui dure n'en
renvoie pas un par heure. `sudo jeiko-alertes --voir` montre la configuration,
`--essai` renvoie l'e-mail d'essai.

Aucun de ces problèmes ne se signale de lui-même avant que le site ne tombe : un
disque plein arrête les écritures PostgreSQL, un certificat expiré rend le
domaine inaccessible d'un coup, et une sauvegarde qui a cessé de tourner ne se
remarque que le jour où on en a besoin.

## Ajouter une clé SSH après l'installation

```bash
sudo jeiko-ssh-key 'ssh-ed25519 AAAA…'
```

Installe la clé, coupe l'authentification par mot de passe, vérifie la
configuration **avant** de recharger — si le test échoue, rien n'est appliqué —
puis contrôle avec `sshd -T` ce que sshd applique réellement. Garder une
session ouverte et essayer une nouvelle connexion avant de la fermer.

Si « garder le mot de passe » a été choisi à l'installation, ce choix reste
mémorisé dans `/etc/jeiko/keep-password-auth` : l'installation d'un site
suivant rétablira le mot de passe, et `jeiko-ssh-key` le rappelle. Supprimer ce
fichier pour que la coupure dure.

---

## Organisation

```
INSTALLER/
├── install.sh                    installation d'un nouveau site
├── migrate_site.sh               amorçage de l'outillage sur un serveur
├── lib/
│   └── jeiko-common.sh           → /usr/local/lib/jeiko/common.sh
│                                   modèle de permissions, registre des sites,
│                                   vérification d'intégrité. Un seul exemplaire.
├── updater/
│   ├── jeiko-server-update       → /usr/local/sbin/  (root:root) — terminal
│   ├── jeiko-client-update       → /usr/local/sbin/  (root:root) — interface
│   ├── jeiko-maj                 → /usr/local/sbin/  (root:root) — mise à jour automatique
│   ├── jeiko-update@.service     → /etc/systemd/system/
│   ├── jeiko-maj.service, .timer → /etc/systemd/system/  (chaque semaine)
│   └── jeiko-maj-serveur@.service → /etc/systemd/system/ (bouton d'un site)
├── tests/                        bancs d'essai (macOS) — non publiés
├── scripts/                      étapes 00 à 14
└── templates/
    ├── settings.template.py      SOURCE UNIQUE — recopiée dans le package
    └── urls.template.py            par publier.sh, à chaque publication
```

Le script de publication, lui, vit avec le dossier de publication :
`packages/jeiko/publier.sh`.

### Sur le serveur

| Chemin | Contenu | Droits |
|---|---|---|
| `/etc/jeiko/sites/<site>.conf` | fiche du site (domaine, DB, chemins) | `0600 root:root` |
| `/usr/local/lib/jeiko/common.sh` | bibliothèque partagée | `0644 root:root` |
| `/usr/local/sbin/jeiko-server-update` | convergence serveur | `0755 root:root` |
| `/usr/local/sbin/jeiko-client-update` | mise à jour du package | `0755 root:root` |
| `/usr/local/sbin/jeiko-maj` | mise à jour automatique (serveur puis sites) | `0755 root:root` |
| `/usr/local/share/jeiko/VERSION` | installeur dont l'outillage est déposé | `0644 root:root` |
| `/var/lib/jeiko/<site>/serveur.version` | installeur avec lequel le site a été convergé | `0640 root:<site>` |
| `/var/lib/jeiko/maj-serveur.state` | état de la dernière mise à jour serveur | `0644 root:root` |
| `/var/log/jeiko/maj-serveur.log` | journal de la mise à jour serveur | `0640 root:root` |
| `/usr/local/sbin/jeiko-verifier` | contrôle de santé quotidien | `0755 root:root` |
| `/usr/local/sbin/jeiko-ssh-key` | ajout d'une clé + coupure du mot de passe | `0755 root:root` |
| `/usr/local/sbin/jeiko-backup` / `-restore` | sauvegarde et restauration | `0700 root:root` |
| `/usr/local/share/jeiko/` | gabarits nginx, unités, scripts d'étape | `0755 root:root` |
| `/var/lib/jeiko/<site>/wheels/` | wheels conservés pour le rollback | `0750 root:root` |
| `/var/lib/jeiko/<site>/update.state` | état lu par l'administration | `0640 root:<site>` |
| `/var/log/jeiko/<site>/update.log` | journal de mise à jour | `0640 root:<site>` |
| `/etc/sudoers.d/jeiko-<site>` | 3 commandes autorisées, rien d'autre | `0440 root:root` |
| `/usr/local/bin/livekit-server` | serveur de visio LiveKit (version fixée, empreinte vérifiée) | `0755 root:root` |
| `/etc/livekit/livekit.yaml` | sa configuration, réécrite à chaque convergence | `0640 root:livekit` |
| `/etc/livekit/keys.yaml` | les clés de visio des sites de la machine | `0600 livekit:livekit` |

### Modèle de permissions

| Élément | Mode | Pourquoi |
|---|---|---|
| Dossiers du projet | `2750` | setgid : le groupe **du site** (`jeiko-<site>`) est hérité ; Nginx en est membre |
| Fichiers | `0640` | Nginx lit via le groupe ; les autres sites, comme tout autre compte local, ne voient rien |
| `.env` | `0600` | contient `DB_PASS`, jamais lisible par le groupe |
| `venv/bin/*` | `0750` | exécutable par le site uniquement |
| Socket Gunicorn | `0660` | **exception** : Nginx doit pouvoir y écrire pour s'y connecter (groupe du site) |
| Cache (memcached) | socket `0600` | une instance par site (`jeiko-memcached-<site>`), sous son compte : aucun autre site ne la joint |

Le socket étant nécessairement inscriptible par le groupe, `settings.py` force
`FILE_UPLOAD_PERMISSIONS = 0o640` : les fichiers uploadés ne dépendent pas du
umask du processus, et une compromission de Nginx ne permet pas de réécrire les
médias.

---

## Dépannage

**La mise à jour ne démarre pas depuis l'interface**

```bash
sudo -u jeiko-monsite sudo -n /usr/bin/systemctl start --no-block jeiko-update@monsite.service
cat /etc/sudoers.d/jeiko-monsite
```

La commande dans le sudoers doit correspondre **au caractère près** à celle
qu'émet la vue. `/bin/systemctl` et `/usr/bin/systemctl` désignent le même
fichier mais sont deux chaînes différentes pour sudo.

**La mise à jour échoue**

```bash
sudo journalctl -u jeiko-update@monsite -n 100
sudo cat /var/log/jeiko/monsite/update.log
```

Le rollback est automatique. Pour le forcer :
`sudo jeiko-client-update monsite --rollback`

**502 Bad Gateway**

```bash
sudo systemctl status gunicorn-monsite
sudo tail -50 /var/log/gunicorn/monsite/error.log
ls -l /run/gunicorn-monsite/gunicorn.sock   # doit être en 0660, groupe jeiko-monsite
id -nG www-data                             # nginx doit être membre de jeiko-monsite
```

**Le site boucle en redirection**

`JEIKO_SSL="True"` dans le `.env` alors qu'aucun certificat n'est en place.
Passe-le à `False` et redémarre, ou installe le certificat :

```bash
sudo /var/www/jeiko-installer/scripts/12_setup_tls_letsencrypt.sh
```

**413 Request Entity Too Large**

Le vhost n'a pas été régénéré : `sudo jeiko-server-update monsite`.
