# JEIKO Installer

Installe un serveur Debian (sécurisé) + Django + Gunicorn + Nginx + PostgreSQL + Memcached + package JEIKO.

## Prérequis

- Debian 12 (user `debian` avec `sudo`)
- Ports 22/80/443 ouverts côté fournisseur
- Un (sous-)domaine pointant vers le VPS (A/AAAA). Tu peux activer TLS plus tard.

---

## 1) Télécharger l’installeur (ZIP *raw*) et décompresser

```bash
sudo apt-get update -y
sudo apt-get install -y curl unzip

sudo mkdir /var/www
cd /var/www

sudo curl -fL -o jeiko-installer-latest.zip \
  https://raw.githubusercontent.com/gderouineau/jeiko_installer/main/jeiko-installer-latest.zip

# (optionnel) Vérifier que c'est bien un zip
file jeiko-installer-latest.zip

# Décompresser
sudo unzip -o jeiko-installer-latest.zip -d jeiko-installer

cd jeiko-installer 
sudo chmod +x install.sh
sudo chmod +x scripts/*.sh

sudo ./install.sh