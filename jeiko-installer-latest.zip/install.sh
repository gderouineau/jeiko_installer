#!/bin/bash
###############################################################################
# JEIKO INSTALLER v2.0
#
# Installe un site JEIKO complet sur Debian 12 : durcissement système,
# PostgreSQL, Memcached, venv Python, package JEIKO, Gunicorn, Nginx, TLS,
# sauvegardes, et le mécanisme de mise à jour depuis l'interface admin.
#
# ⚠️  Ce script est prévu pour une INSTALLATION NEUVE.
#     Pour amener un site déjà en production sur ce schéma, utiliser
#     ./migrate_site.sh <site> — qui sauvegarde et vérifie avant d'appliquer.
#
# Auteur : Guillaume Derouineau
###############################################################################

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"

# Version de l'installeur, distincte de celle du package JEIKO : les deux
# évoluent séparément. Le fichier VERSION est la source unique — publier-installer.sh
# l'incrémente, et rien d'autre ne la recopie.
VERSION="$(cat "$SCRIPT_DIR/VERSION" 2>/dev/null || echo "inconnue")"
# Racine des sites. Volontairement FIXE et hors de /home : le service gunicorn
# est durci avec ProtectHome=yes, qui masque /home au processus. Un projet
# installé sous /home devient alors invisible pour son propre service, et
# systemd échoue avec « No such file or directory » sur un binaire pourtant
# présent. Déduire cette racine du dossier de l'installeur — donc du répertoire
# où l'on a dézippé — plaçait les sites dans /home/<admin> et cassait tout.
DEFAULT_INSTALL_ROOT="/var/www"
BASE_DIR="${INSTALL_ROOT:-$DEFAULT_INSTALL_ROOT}"

if [[ "$BASE_DIR" == /home/* || "$BASE_DIR" == /root/* ]]; then
    echo "⚠️  Racine d'installation sous /home : $BASE_DIR"
    echo "    Le service gunicorn utilise ProtectHome=yes ; il sera adapté"
    echo "    automatiquement, mais /var/www reste l'emplacement recommandé."
fi

echo "📦 JEIKO INSTALLER v$VERSION"

if [[ ${EUID} -ne 0 ]]; then
    echo "❌ Ce script doit être exécuté avec sudo : sudo ./install.sh"
    exit 1
fi

###############################################################################
# 0) Déploiement de la bibliothèque partagée
#
# jeiko-common.sh doit être en place AVANT tout le reste : installeur et
# updater le partagent, c'est ce qui garantit qu'ils appliquent exactement le
# même modèle de permissions.
###############################################################################
install -d -m 0755 -o root -g root /usr/local/lib/jeiko
install -m 0644 -o root -g root "$SCRIPT_DIR/lib/jeiko-common.sh" /usr/local/lib/jeiko/common.sh

# shellcheck source=lib/jeiko-common.sh
source /usr/local/lib/jeiko/common.sh
jeiko_init_dirs

# I-08 (09/10/2026) : la langue d'abord — celle de l'installeur, du site
# (servie par défaut aux visiteurs, JEIKO_LANGUAGE dans le .env) et de son
# administration. Les messages techniques des étapes restent en français :
# ils servent au dépannage.
read -rp "▶️  Langue / Language / Idioma / Sprache / Lingua — fr, en, es, de, it [fr] : " SITE_LANGUE
SITE_LANGUE="${SITE_LANGUE:-fr}"; SITE_LANGUE="${SITE_LANGUE,,}"
[[ "$SITE_LANGUE" =~ ^(fr|en|es|de|it)$ ]] || { echo "❌ fr, en, es, de, it"; exit 1; }
export JEIKO_INSTALL_LANG="$SITE_LANGUE"

###############################################################################
# 1) Saisie
###############################################################################
read -rp "$(jeiko_t "▶️  Nom du site (ex: monsite) : ")" SITE_NAME
jeiko_valider_nouveau_site "$SITE_NAME" || exit 1

# Une REPRISE (fiche déjà là : installation interrompue, ou réinstallation)
# garde les identifiants de la base. En redemander un nouveau mot de passe le
# posait dans PostgreSQL (étape 05) mais pas dans le .env existant (étape 09,
# qui conserve le fichier) : le site perdait sa base.
REPRISE=0
if [[ -f "$(jeiko_site_conf_path "$SITE_NAME")" ]]; then
    echo "$(jeiko_t "⚠️  Un site nommé '%s' est déjà enregistré sur cette machine." "$SITE_NAME")"
    echo "$(jeiko_t "    Pour le mettre à jour : jeiko-client-update %s" "$SITE_NAME")"
    echo "$(jeiko_t "    Pour le migrer        : ./migrate_site.sh %s" "$SITE_NAME")"
    read -rp "$(jeiko_t "    Continuer quand même et écraser sa configuration ? (o/n) : ")" force_overwrite
    jeiko_oui "$force_overwrite" || { echo "$(jeiko_t "Installation annulée.")"; exit 0; }
    REPRISE=1
fi

read -rp "$(jeiko_t "▶️  Nom de domaine (ex: monsite.fr) : ")" DOMAIN_NAME
DOMAIN_NAME="${DOMAIN_NAME,,}"
jeiko_validate_domain "$DOMAIN_NAME" || exit 1

if [[ $REPRISE -eq 1 ]]; then
    read -r DB_NAME DB_USER < <(
        # shellcheck disable=SC1090
        source "$(jeiko_site_conf_path "$SITE_NAME")"; printf '%s %s\n' "${DB_NAME:-}" "${DB_USER:-}")
    DB_PASS="$(
        # shellcheck disable=SC1090
        source "$(jeiko_site_conf_path "$SITE_NAME")"; printf '%s' "${DB_PASS:-}")"
    [[ -n "$DB_NAME" && -n "$DB_USER" && -n "$DB_PASS" ]] \
        || { echo "❌ $(jeiko_site_conf_path "$SITE_NAME") : DB_NAME, DB_USER ou DB_PASS manquant."; exit 1; }
    echo "$(jeiko_t "🛢️  Base PostgreSQL   : %s (rôle %s)" "$DB_NAME" "$DB_USER")"
else
    read -rp "$(jeiko_t "▶️  Nom de la base PostgreSQL [%s_db] : " "${SITE_NAME}")" DB_NAME
    DB_NAME="${DB_NAME:-${SITE_NAME}_db}"
    read -rp "$(jeiko_t "▶️  Nom de l'utilisateur PostgreSQL [%s_user] : " "${SITE_NAME}")" DB_USER
    DB_USER="${DB_USER:-${SITE_NAME}_user}"

    # Un mot de passe généré évite à la fois les mots de passe faibles et les
    # caractères que le .env ou le SQL interpréteraient.
    read -rsp "$(jeiko_t "▶️  Mot de passe PostgreSQL (vide = généré automatiquement) : ")" DB_PASS; echo
    if [[ -z "$DB_PASS" ]]; then
        DB_PASS="$(jeiko_mot_de_passe_genere)"
        echo "$(jeiko_t "   🔑 Mot de passe généré (stocké dans la fiche du site, non affiché).")"
    else
        jeiko_valider_mot_de_passe_db "$DB_PASS" || exit 1
    fi
fi
jeiko_valider_noms_db "$SITE_NAME" "$DB_NAME" "$DB_USER" || exit 1
export JEIKO_REPRISE="$REPRISE"

read -rp "$(jeiko_t "▶️  Identifiant du compte d'administration : ")" DJANGO_SUPERUSER
[[ -n "$DJANGO_SUPERUSER" ]] || { echo "$(jeiko_t "❌ Nom requis.")"; exit 1; }
read -rp "$(jeiko_t "▶️  E-mail du compte d'administration : ")" DJANGO_SUPEREMAIL
# Obligatoire : la connexion exige une adresse confirmée, et c'est celle-ci que
# l'étape 14 enregistre comme telle (O-05). Le contrôle complet est fait par
# Django ; celui-ci évite seulement d'aller au bout pour échouer à la fin.
[[ "$DJANGO_SUPEREMAIL" =~ ^[^@[:space:]]+@[^@[:space:]]+\.[^@[:space:]]+$ ]] \
    || { echo "$(jeiko_t "❌ Adresse e-mail valide requise.")"; exit 1; }
read -rsp "$(jeiko_t "▶️  Mot de passe du compte d'administration : ")" DJANGO_SUPERPASS; echo
[[ ${#DJANGO_SUPERPASS} -ge 12 ]] || { echo "$(jeiko_t "❌ 12 caractères minimum.")"; exit 1; }

read -rp "$(jeiko_t "▶️  Activer HTTPS avec Let's Encrypt ? (o/n) : ")" ENABLE_SSL
# y, o, s, j… : le oui de chaque langue. Toute autre réponse vaut non, comme avant.
if jeiko_oui "$ENABLE_SSL"; then ENABLE_SSL=y; else ENABLE_SSL=n; fi

# L'utilisateur humain qui pourra lire le projet en SSH sans sudo.
ADMIN_SSH_USER="${SUDO_USER:-debian}"
read -rp "$(jeiko_t "▶️  Utilisateur SSH d'administration [%s] : " "$ADMIN_SSH_USER")" _admin
ADMIN_SSH_USER="${_admin:-$ADMIN_SSH_USER}"

###############################################################################
# Clé SSH publique
#
# Sans clé sur la machine, le durcissement laisse l'authentification par mot de
# passe active — c'est le seul moyen de ne pas t'enfermer dehors. L'installeur
# affichait alors un avertissement te demandant de la déposer toi-même, plus
# tard, à la main. On la demande maintenant : c'est le seul moment où l'on est
# sûr que quelqu'un est devant l'écran.
###############################################################################
SSH_PUBKEY=""
KEEP_PW_MARKER="$JEIKO_ETC_DIR/keep-password-auth"

# La machine peut déjà porter une clé : celle de l'administrateur, ou celle que
# l'hébergeur dépose dans /root à la création du VPS. La seconde ne donne aucun
# accès à qui installe.
EXISTING_KEY=0
grep -Eqs 'ssh-(ed25519|rsa)|ecdsa-sha2' \
    /root/.ssh/authorized_keys "/home/$ADMIN_SSH_USER/.ssh/authorized_keys" 2>/dev/null \
    && EXISTING_KEY=1

if [[ -f "$KEEP_PW_MARKER" ]]; then
    # Choix déjà arrêté sur cette machine : on ne repose pas la question du mot
    # de passe à chaque nouveau site, et on ne revient pas dessus en silence.
    # En revanche, ajouter une clé reste possible : c'est une autre décision, et
    # rien n'empêche d'avoir les deux moyens d'accès.
    JEIKO_KEEP_PASSWORD_AUTH=1
    echo "$(jeiko_t "🔑 Mot de passe SSH conservé (choix enregistré sur cette machine).")"
    if [[ $EXISTING_KEY -eq 0 ]]; then
        echo "$(jeiko_t "    Tu peux tout de même enregistrer une clé — le mot de passe")"
        echo "$(jeiko_t "    restera actif dans tous les cas.")"
        read -rp "$(jeiko_t "▶️  Clé publique (vide = aucune) : ")" SSH_PUBKEY
        SSH_PUBKEY="$(printf '%s' "$SSH_PUBKEY" | tr -d '\r')"
        case "${SSH_PUBKEY,,}" in
            n|no|non|none|aucune|aucun|nein|keiner|ninguna|nada|nessuna|nulla) SSH_PUBKEY="" ;;
        esac
        if [[ -n "$SSH_PUBKEY" ]]; then
            if ! jeiko_cle_ssh_valide "$SSH_PUBKEY"; then
                echo "$(jeiko_t "❌ Ce n'est pas une clé publique valide (attendu : « ssh-ed25519 AAAA… »).")"
                echo "$(jeiko_t "   Laisse le champ vide si tu ne veux pas installer de clé.")"
                exit 1
            fi
            echo "$(jeiko_t "   ✅ Clé retenue, elle sera installée pour %s." "$ADMIN_SSH_USER")"
        fi
    fi
elif [[ $EXISTING_KEY -eq 1 ]]; then
    echo ""
    echo "$(jeiko_t "🔐 Une clé SSH est déjà présente sur cette machine.")"
    echo ""
    echo "$(jeiko_t "    L'installeur peut désactiver l'authentification par mot de passe.")"
    echo "$(jeiko_t "    C'est plus sûr, MAIS tu ne pourras plus te connecter qu'avec cette")"
    echo "$(jeiko_t "    clé précise. Si elle appartient à ton hébergeur, ou si tu te")"
    echo "$(jeiko_t "    connectes depuis un poste qui ne l'a pas, tu seras enfermé dehors.")"
    echo ""
    read -rp "$(jeiko_t "▶️  Désactiver le mot de passe SSH ? (o/N) : ")" _harden
    if jeiko_oui "$_harden"; then
        JEIKO_KEEP_PASSWORD_AUTH=0
        echo "$(jeiko_t "   🔒 Mot de passe désactivé. Garde une session ouverte et vérifie")"
        echo "$(jeiko_t "      ta connexion par clé avant de la fermer.")"
    else
        JEIKO_KEEP_PASSWORD_AUTH=1
        echo "$(jeiko_t "   ✅ Mot de passe conservé (fail2ban actif). Choix mémorisé pour")"
        echo "$(jeiko_t "      les prochaines installations sur cette machine.")"
    fi
else
    echo ""
    echo "$(jeiko_t "⚠️  Aucune clé SSH publique trouvée sur cette machine.")"
    echo "$(jeiko_t "    Sans clé, l'accès par mot de passe doit rester ouvert, ce qui est")"
    echo "$(jeiko_t "    la faiblesse principale d'un serveur exposé.")"
    echo ""
    echo "$(jeiko_t "    Colle ta clé publique (le contenu de ~/.ssh/id_ed25519.pub sur ton")"
    echo "$(jeiko_t "    poste), ou laisse vide — tu pourras l'ajouter plus tard avec")"
    echo "$(jeiko_t "    ssh-copy-id, sans rien réinstaller.")"
    read -rp "$(jeiko_t "▶️  Clé publique (vide = aucune) : ")" SSH_PUBKEY
    SSH_PUBKEY="$(printf '%s' "$SSH_PUBKEY" | tr -d '\r')"

    # Une réponse négative n'est pas une clé illisible : c'est un refus. Sans
    # cette tolérance, taper « non » faisait échouer toute l'installation.
    case "${SSH_PUBKEY,,}" in
        n|no|non|none|aucune|aucun|nein|keiner|ninguna|nada|nessuna|nulla) SSH_PUBKEY="" ;;
    esac

    if [[ -n "$SSH_PUBKEY" ]]; then
        if ! jeiko_cle_ssh_valide "$SSH_PUBKEY"; then
            echo "$(jeiko_t "❌ Ce n'est pas une clé publique valide (attendu : « ssh-ed25519 AAAA… »).")"
            echo "$(jeiko_t "   Laisse le champ vide si tu ne veux pas installer de clé.")"
            exit 1
        fi
        echo "$(jeiko_t "   ✅ Clé retenue, elle sera installée pour %s." "$ADMIN_SSH_USER")"
        echo ""
        # Enregistrer une clé et couper le mot de passe sont DEUX décisions.
        # Les confondre coupait l'accès de secours à qui voulait seulement
        # ajouter un moyen de connexion supplémentaire.
        echo "$(jeiko_t "    Veux-tu aussi désactiver l'authentification par mot de passe ?")"
        echo "$(jeiko_t "    Tu ne pourras alors plus te connecter qu'avec cette clé, depuis")"
        echo "$(jeiko_t "    un poste qui la possède.")"
        read -rp "$(jeiko_t "▶️  Désactiver le mot de passe SSH ? (o/N) : ")" _harden
        if jeiko_oui "$_harden"; then
            JEIKO_KEEP_PASSWORD_AUTH=0
            echo "$(jeiko_t "   🔒 Mot de passe désactivé. Garde une session ouverte et vérifie")"
            echo "$(jeiko_t "      ta connexion par clé avant de la fermer.")"
        else
            JEIKO_KEEP_PASSWORD_AUTH=1
            echo "$(jeiko_t "   ✅ Clé ajoutée ET mot de passe conservé. Choix mémorisé.")"
        fi
    else
        JEIKO_KEEP_PASSWORD_AUTH=1
        echo "$(jeiko_t "   ⚠️  Aucune clé : mot de passe conservé, protégé par fail2ban.")"
    fi
fi

###############################################################################
# 2) Variables dérivées
###############################################################################
PROJECT_DIR="$BASE_DIR/$SITE_NAME"
SITE_USER="jeiko-$SITE_NAME"
VENV_DIR="$PROJECT_DIR/venv"
GUNICORN_SERVICE="gunicorn-$SITE_NAME"
JEIKO_CHANNEL_URL="${JEIKO_CHANNEL_URL:-$JEIKO_DEFAULT_CHANNEL_URL}"
INSTALLED_AT="$(date -Is)"

TIMESTAMP="$(date +"%Y%m%d_%H%M%S")"
LOG_DIR="$SCRIPT_DIR/logs"
install -d -m 0750 "$LOG_DIR"
LOG_FILE="$LOG_DIR/install_${SITE_NAME}_$TIMESTAMP.log"
: >"$LOG_FILE"; chmod 0640 "$LOG_FILE"

echo "$(jeiko_t "──────────── RÉCAPITULATIF ────────────")"
echo "$(jeiko_t "🧩 Site              : %s" "$SITE_NAME")"
echo "$(jeiko_t "🌍 Domaine           : %s" "$DOMAIN_NAME")"
echo "$(jeiko_t "🗣️  Langue            : %s" "$SITE_LANGUE")"
echo "$(jeiko_t "🛢️  Base PostgreSQL   : %s (rôle %s)" "$DB_NAME" "$DB_USER")"
echo "$(jeiko_t "👤 Administration    : %s <%s>" "$DJANGO_SUPERUSER" "$DJANGO_SUPEREMAIL")"
echo "$(jeiko_t "🔒 Let's Encrypt     : %s" "$ENABLE_SSL")"
echo "$(jeiko_t "📁 Dossier projet    : %s" "$PROJECT_DIR")"
echo "$(jeiko_t "🧑 Utilisateur système: %s" "$SITE_USER")"
echo "$(jeiko_t "🔑 Admin SSH (ACL)   : %s" "$ADMIN_SSH_USER")"
if [[ "${JEIKO_KEEP_PASSWORD_AUTH:-1}" == "1" ]]; then
    echo "$(jeiko_t "🔓 Mot de passe SSH  : CONSERVÉ (fail2ban actif)")"
else
    echo "$(jeiko_t "🔒 Mot de passe SSH  : DÉSACTIVÉ — connexion par clé uniquement")"
fi
echo "$(jeiko_t "📡 Canal de MAJ      : %s" "$JEIKO_CHANNEL_URL")"
echo "───────────────────────────────────────"
read -rp "$(jeiko_t "Confirmer l'installation ? (o/n) : ")" confirm
jeiko_oui "$confirm" || { echo "$(jeiko_t "Installation annulée.")"; exit 0; }

###############################################################################
# 3) Fiche du site
#
# Remplace le .env.<site> qui était écrit en 0644 dans le dossier de
# l'installeur — mot de passe PostgreSQL lisible par n'importe quel compte
# local. La fiche est en 0600 root:root et ne contient plus le mot de passe du
# superuser Django, qui ne sert qu'une fois (étape 14) et n'a aucune raison de
# survivre à l'installation.
###############################################################################
jeiko_write_site_conf "$SITE_NAME"
echo "$(jeiko_t "🗃️  Fiche du site : %s (0600 root:root)" "$(jeiko_site_conf_path "$SITE_NAME")")"

export SSH_PUBKEY JEIKO_KEEP_PASSWORD_AUTH
export SCRIPT_DIR BASE_DIR PROJECT_DIR SITE_NAME DOMAIN_NAME SITE_USER VENV_DIR
export GUNICORN_SERVICE DB_NAME DB_USER DB_PASS ENABLE_SSL ADMIN_SSH_USER
export DJANGO_SUPERUSER DJANGO_SUPEREMAIL DJANGO_SUPERPASS
export JEIKO_CHANNEL_URL LOG_FILE SITE_LANGUE

###############################################################################
# 4) Exécution des étapes
###############################################################################
chmod +x "$SCRIPT_DIR"/scripts/*.sh

STEPS=(
    00_preflight
    01_security_baseline
    02_users_dirs
    03_check_dependencies
    04_install_postgres
    05_setup_database
    06_install_memcached
    07_install_python_env
    08_install_jeiko_package
    09_configure_django
    10_configure_gunicorn
    11_configure_nginx
)
[[ "$ENABLE_SSL" == "y" ]] && STEPS+=(12_setup_tls_letsencrypt) || true
STEPS+=(13_backups 14_finalize)

echo "$(jeiko_t "🚀 Installation en cours… (journal : %s)" "$LOG_FILE")"

for step in "${STEPS[@]}"; do
    if ! "$SCRIPT_DIR/scripts/$step.sh" 2>&1 | tee -a "$LOG_FILE"; then
        echo ""
        echo "$(jeiko_t "❌ Échec à l'étape %s. Journal complet : %s" "$step" "$LOG_FILE")"
        echo "$(jeiko_t "   Les étapes sont idempotentes : corrige la cause et relance ./install.sh.")"
        exit 1
    fi
done

# fail2ban a chargé ses règles à l'étape 01, quand les journaux des sites
# n'existaient pas encore : il ne lit les motifs (« *_access.log ») qu'au
# chargement. On le recharge maintenant que nginx les a créés, et on montre
# les jails réellement actifs plutôt que ceux qu'on croit avoir posés.
if systemctl restart fail2ban 2>/dev/null; then
    sleep 2
    fail2ban-client status 2>/dev/null | sed -n 's/.*Jail list:[[:space:]]*/🚨 fail2ban : /p' || true
else
    echo "⚠️  fail2ban n'a pas redémarré : journalctl -u fail2ban -n 30"
fi

###############################################################################
# 5) Fin
###############################################################################
SCHEME="http"; [[ "$ENABLE_SSL" == "y" ]] && SCHEME="https" || true

echo
echo "═══════════════════════════════════════════════════════════"
echo "$(jeiko_t "✅ Installation terminée.")"
echo
echo "$(jeiko_t "🌐 Site           : %s" "$SCHEME://$DOMAIN_NAME")"
echo "$(jeiko_t "🔐 Administration : %s" "$SCHEME://$DOMAIN_NAME/administration/")"
echo "$(jeiko_t "📄 Journal        : %s" "$LOG_FILE")"
echo
echo "$(jeiko_t "Mise à jour du site :")"
echo "$(jeiko_t "  · depuis l'interface  → Administration ▸ Mettre à jour JEIKO")"
echo "$(jeiko_t "  · depuis le serveur   → sudo jeiko-client-update %s" "$SITE_NAME")"
echo "$(jeiko_t "  · vérifier sans agir  → sudo jeiko-client-update %s --check" "$SITE_NAME")"
echo "$(jeiko_t "  · revenir en arrière  → sudo jeiko-client-update %s --rollback" "$SITE_NAME")"
echo
echo "$(jeiko_t "Fiche du site : %s" "$(jeiko_site_conf_path "$SITE_NAME")")"
echo "$(jeiko_t "Sauvegardes   : %s" "$JEIKO_BACKUP_DIR/$SITE_NAME")"
echo "═══════════════════════════════════════════════════════════"

if [[ "$ENABLE_SSL" != "y" ]]; then
    echo "$(jeiko_t "⚠️  Le site tourne en HTTP. La redirection HTTPS et HSTS sont désactivées dans")"
    echo "$(jeiko_t "    le .env (JEIKO_SSL=\"False\") pour éviter la boucle de redirection.")"
    echo "$(jeiko_t "    Pour activer TLS plus tard :")"
    # Par la fiche et la convergence : c'est elle qui pose le certificat, passe
    # JEIKO_SSL à True et redémarre. Lancer l'étape 12 seule demandait toutes
    # les variables du site, que la commande affichée ne donnait pas.
    echo "      sudo sed -i \"s/^ENABLE_SSL=.*/ENABLE_SSL='y'/\" $(jeiko_site_conf_path "$SITE_NAME")"
    echo "      sudo jeiko-server-update $SITE_NAME"
    echo "$(jeiko_t "    (le certificat est demandé, JEIKO_SSL passe à True et le site redémarre)")"
fi
