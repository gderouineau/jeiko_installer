#!/bin/bash
set -euo pipefail

echo "👤 [02_users_dirs.sh] Comptes & arborescence par site…"

if [[ -z "${SITE_NAME:-}" || -z "${BASE_DIR:-}" ]]; then
    echo "❌ Variables SITE_NAME/BASE_DIR manquantes."; exit 1
fi

SITE_USER="jeiko-$SITE_NAME"
PROJECT_DIR="$BASE_DIR/$SITE_NAME"
RUN_DIR="/run"
LOG_DIR="/var/log/gunicorn/$SITE_NAME"

# 1) Dossier projet
mkdir -p "$PROJECT_DIR"
chmod 750 "$PROJECT_DIR" || true

# 2) Groupe & utilisateur système (home = dossier projet)
if ! id -u "$SITE_USER" >/dev/null 2>&1; then
    adduser --system --ingroup www-data --home "$PROJECT_DIR" --shell /usr/sbin/nologin "$SITE_USER"
    echo "✅ Utilisateur système créé: $SITE_USER"
else
    echo "ℹ️ Utilisateur $SITE_USER déjà présent."
fi

# 3) Dossiers applicatifs (staticdir/mediadir/run/log)
mkdir -p "$PROJECT_DIR/staticdir" "$PROJECT_DIR/mediadir" "$PROJECT_DIR/static" "$PROJECT_DIR/media"
mkdir -p "$LOG_DIR"
chown -R "$SITE_USER":www-data "$PROJECT_DIR" "$LOG_DIR"
chmod -R 750 "$PROJECT_DIR"
chmod -R 750 "$LOG_DIR"

# Nginx doit lire statiques & médias → groupe www-data OK, perms 750
chmod 750 "$PROJECT_DIR/staticdir" "$PROJECT_DIR/mediadir"

# 4) Socket path (sera créé par systemd), on s’assure que /run est OK pour www-data group
# Le fichier socket aura un group www-data via la unit .socket
test -d "$RUN_DIR" || mkdir -p "$RUN_DIR"

echo "📁 PROJECT_DIR=$PROJECT_DIR"
echo "📁 LOG_DIR=$LOG_DIR"
echo "✅ Arborescence & comptes prêts."
