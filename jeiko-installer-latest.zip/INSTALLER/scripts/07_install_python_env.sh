#!/bin/bash
set -euo pipefail

echo "🐍 [07_install_python_env.sh] Environnement Python (venv + paquets)…"

: "${BASE_DIR:?BASE_DIR manquant}"
: "${SITE_NAME:?SITE_NAME manquant}"

PROJECT_DIR="$BASE_DIR/$SITE_NAME"
VENV_DIR="$PROJECT_DIR/venv"
SITE_USER="jeiko-$SITE_NAME"

mkdir -p "$PROJECT_DIR"

# 1) venv
if [[ ! -d "$VENV_DIR" ]]; then
    python3 -m venv "$VENV_DIR"
    echo "✅ venv créé."
else
    echo "ℹ️ venv déjà présent."
fi

# 2) pip tooling
source "$VENV_DIR/bin/activate"
python -m pip install --upgrade pip wheel setuptools >/dev/null

# 3) Paquets de base
# ⚠️ settings.py utilise 'django.db.backends.postgresql_psycopg2' → garder psycopg2-binary
pip install --quiet \
    "django" \
    "gunicorn" \
    "psycopg2-binary" \
    "python-dotenv"

# 4) Permissions (l’app tournera sous jeiko-<site>)
chown -R "$SITE_USER":www-data "$VENV_DIR"
chmod -R 750 "$VENV_DIR"

echo "✅ Environnement Python prêt."
