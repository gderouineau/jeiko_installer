#!/bin/bash
set -euo pipefail

echo "🛡️ [01_security_baseline.sh] Durcissement de base (UFW, SSH, Fail2ban, sysctl, MAJ auto, temps)…"

export DEBIAN_FRONTEND=noninteractive

# 1) Paquets sécurité / base
apt-get update -y
apt-get install -y \
    ufw fail2ban \
    unattended-upgrades apt-listchanges \
    cron logrotate rsyslog \
    ca-certificates curl gnupg lsb-release jq \
    chrony

systemctl enable --now cron rsyslog chrony >/dev/null 2>&1 || true

# 2) Timezone & NTP
timedatectl set-timezone Europe/Paris
timedatectl set-ntp true || true
systemctl restart chrony || true
echo "⏱️  Timezone: $(timedatectl | grep 'Time zone' || true)"

# 3) Swapfile (si aucun swap)
if ! swapon --show | grep -qE 'partition|file'; then
    echo "💾 Création d’un swapfile de 2G…"
    fallocate -l 2G /swapfile || dd if=/dev/zero of=/swapfile bs=1M count=2048
    chmod 600 /swapfile
    mkswap /swapfile
    swapon /swapfile
    if ! grep -q '/swapfile' /etc/fstab; then
        echo '/swapfile none swap sw 0 0' >> /etc/fstab
    fi
    echo "vm.swappiness=10" > /etc/sysctl.d/60-swap.conf
    sysctl -p /etc/sysctl.d/60-swap.conf || true
else
    echo "ℹ️ Swap déjà présent."
fi

# 4) UFW (pare-feu)
ufw --force reset >/dev/null 2>&1 || true
ufw default deny incoming
ufw default allow outgoing
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
yes | ufw enable
ufw status verbose

# 5) SSH hardening (sans lock-out)
SSHD_CONF="/etc/ssh/sshd_config"
cp -n "$SSHD_CONF" "${SSHD_CONF}.bak" || true

# Root: on interdit le password (prohibit-password) par défaut
sed -ri 's/^#?PermitRootLogin .*/PermitRootLogin prohibit-password/' "$SSHD_CONF" || true

# PasswordAuthentication: on ne le coupe que s'il existe une clé installée pour root
if grep -Eqs 'ssh-(ed25519|rsa)' /root/.ssh/authorized_keys 2>/dev/null; then
    sed -ri 's/^#?PasswordAuthentication .*/PasswordAuthentication no/' "$SSHD_CONF" || true
    echo "🔐 SSH: PasswordAuthentication désactivé (clé détectée pour root)."
else
    sed -ri 's/^#?PasswordAuthentication .*/PasswordAuthentication yes/' "$SSHD_CONF" || true
    echo "⚠️ SSH: PasswordAuthentication laissé à YES (aucune clé détectée pour root)."
fi

# Autres réglages sobres
grep -q '^MaxAuthTries' "$SSHD_CONF" || echo 'MaxAuthTries 3' >> "$SSHD_CONF"
grep -q '^LoginGraceTime' "$SSHD_CONF" || echo 'LoginGraceTime 30' >> "$SSHD_CONF"
grep -q '^ClientAliveInterval' "$SSHD_CONF" || echo 'ClientAliveInterval 300' >> "$SSHD_CONF"
grep -q '^ClientAliveCountMax' "$SSHD_CONF" || echo 'ClientAliveCountMax 2' >> "$SSHD_CONF"

systemctl reload ssh || systemctl restart ssh

# 6) Fail2ban (jails basiques)
mkdir -p /etc/fail2ban/jail.d
cat >/etc/fail2ban/jail.d/jeiko-hardening.conf <<'JAIL'
[sshd]
enabled  = true
port     = ssh
findtime = 10m
maxretry = 3
bantime  = 1h

[nginx-http-auth]
enabled = true

[nginx-badbots]
enabled = true

[nginx-req-limit]
enabled = true
JAIL

systemctl enable --now fail2ban
fail2ban-client status || true

# 7) Unattended upgrades (MAJ de sécu)
cat >/etc/apt/apt.conf.d/20auto-upgrades <<'APT'
APT::Periodic::Update-Package-Lists "1";
APT::Periodic::Download-Upgradeable-Packages "1";
APT::Periodic::Unattended-Upgrade "1";
APT::Periodic::AutocleanInterval "7";
APT
# On laisse le reboot automatique désactivé par défaut

# 8) sysctl réseau (durcissement léger)
cat >/etc/sysctl.d/99-jeiko-hardening.conf <<'SYSCTL'
net.ipv4.conf.all.rp_filter = 1
net.ipv4.conf.default.rp_filter = 1
net.ipv4.tcp_syncookies = 1
net.ipv4.conf.all.accept_redirects = 0
net.ipv4.conf.default.accept_redirects = 0
net.ipv4.conf.all.send_redirects = 0
net.ipv4.conf.default.send_redirects = 0
net.ipv6.conf.all.accept_redirects = 0
net.ipv6.conf.default.accept_redirects = 0
net.ipv4.icmp_echo_ignore_broadcasts = 1
kernel.kptr_restrict = 2
SYSCTL
sysctl --system || true

echo "✅ Baseline sécurité appliquée."
