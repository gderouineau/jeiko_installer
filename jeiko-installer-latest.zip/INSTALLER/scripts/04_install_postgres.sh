#!/bin/bash
set -euo pipefail

echo "🛢️ [04_install_postgres.sh] Installation & sécurisation PostgreSQL…"

# 1) Présence de psql et service
if ! command -v psql >/dev/null 2>&1; then
    echo "❌ PostgreSQL non installé (psql introuvable). Lancer 03_check_dependencies avant."
    exit 1
fi

systemctl enable --now postgresql

# 2) Localisation des confs (Debian)
PG_VERSION=$(psql -V | awk '{print $3}' | cut -d. -f1,2)
PG_DATA_DIR=$(pg_lsclusters | awk 'NR==2{print "/etc/postgresql/"$2"/main"}')
[[ -z "$PG_DATA_DIR" || ! -d "$PG_DATA_DIR" ]] && PG_DATA_DIR="/etc/postgresql/$(ls /etc/postgresql | head -n1)/main"

PG_CONF="$PG_DATA_DIR/postgresql.conf"
HBA_CONF="$PG_DATA_DIR/pg_hba.conf"

# 3) Restreindre l’écoute au localhost et forcer scram-sha-256
if ! grep -q '^listen_addresses =.*127.0.0.1' "$PG_CONF"; then
    sed -ri "s/^#?listen_addresses.*/listen_addresses = '127.0.0.1'/g" "$PG_CONF"
    echo "🔒 listen_addresses=127.0.0.1 (pas d'exposition publique)."
fi

if ! grep -q '^password_encryption =.*scram-sha-256' "$PG_CONF"; then
    sed -ri "s/^#?password_encryption.*/password_encryption = scram-sha-256/g" "$PG_CONF"
    echo "🔐 password_encryption=scram-sha-256."
fi

# 4) pg_hba : connexions locales en scram
if ! grep -q "127.0.0.1/32.*scram-sha-256" "$HBA_CONF"; then
    echo "host    all             all             127.0.0.1/32            scram-sha-256" >> "$HBA_CONF"
fi
if ! grep -q "::1/128.*scram-sha-256" "$HBA_CONF"; then
    echo "host    all             all             ::1/128                 scram-sha-256" >> "$HBA_CONF"
fi

systemctl restart postgresql

# 5) Sanity
sudo -u postgres psql -c '\l' >/dev/null
echo "✅ PostgreSQL prêt (local only + scram)."
