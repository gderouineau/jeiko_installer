#!/bin/bash
###############################################################################
# uninstall.sh — supprime un site JEIKO et tout ce que l'installeur a créé pour lui.
#
# Lit la fiche /etc/jeiko/sites/<site>.conf pour retrouver les chemins RÉELS :
# la version précédente supposait /var/www/<site> et laissait donc tout en place
# dès que la racine d'installation différait — en plus d'ignorer le compte Unix,
# la base PostgreSQL, le sudoers et les sauvegardes.
#
# Ce qui est PARTAGÉ par tous les sites n'est jamais touché : PostgreSQL, nginx,
# memcached, /usr/local/lib/jeiko, /usr/local/sbin/jeiko-*, la configuration SSH.
#
# Usage :
#   sudo ./uninstall.sh <site>                  # demande confirmation
#   sudo ./uninstall.sh <site> --keep-db        # conserve la base et son rôle
#   sudo ./uninstall.sh <site> --purge-backups  # efface AUSSI ses sauvegardes
#   sudo ./uninstall.sh <site> --dry-run        # montre sans rien supprimer
#
# Les sauvegardes du site sont GARDÉES par défaut (IG-07, 16/10/2026) : elles
# partaient avec lui, et une suppression regrettée ne se rattrapait plus.
# Le compte Unix n'est supprimé que s'il n'appartient qu'à ce site.
###############################################################################

set -euo pipefail

if [[ -r /usr/local/lib/jeiko/common.sh ]]; then
    # shellcheck source=lib/jeiko-common.sh
    source /usr/local/lib/jeiko/common.sh
else
    # Désinstallation possible même si la bibliothèque a déjà disparu.
    JEIKO_ETC_DIR="/etc/jeiko"; JEIKO_LIB_DIR="/var/lib/jeiko"
    JEIKO_LOG_DIR="/var/log/jeiko"; JEIKO_BACKUP_DIR="/var/backups/jeiko"
    jeiko_log()  { printf '   %s\n' "$*"; }
    jeiko_ok()   { printf '✅ %s\n' "$*"; }
    jeiko_warn() { printf '⚠️  %s\n' "$*"; }
    jeiko_err()  { printf '❌ %s\n' "$*" >&2; }
    jeiko_die()  { jeiko_err "$*"; exit 1; }
fi

[[ ${EUID} -eq 0 ]] || jeiko_die "À lancer avec sudo."

SITE=""; KEEP_DB=0; DRY_RUN=0; PURGE_BACKUPS=0
while [[ $# -gt 0 ]]; do
    case "$1" in
        --keep-db) KEEP_DB=1; shift ;;
        --purge-backups) PURGE_BACKUPS=1; shift ;;
        --dry-run) DRY_RUN=1; shift ;;
        -h|--help) sed -n '2,23p' "$0"; exit 0 ;;
        -*)        jeiko_die "Option inconnue : $1" ;;
        *)         SITE="$1"; shift ;;
    esac
done
[[ -n "$SITE" ]] || jeiko_die "Usage : sudo ./uninstall.sh <site> [--keep-db] [--purge-backups] [--dry-run]"
[[ "$SITE" =~ ^[a-z0-9][a-z0-9_-]{0,30}$ ]] || jeiko_die "Nom de site invalide : $SITE"

run() { if [[ $DRY_RUN -eq 1 ]]; then printf '   [simulation] %s\n' "$*"; else "$@"; fi; }

# Le compte Unix de ce site sert-il À AUTRE CHOSE ? (IG-07, 16/10/2026)
# Rend 0 — et dit pourquoi — si on ne doit PAS le supprimer : un compte du
# système (uid < 1000), root, l'administrateur SSH, ou le compte inscrit dans
# la fiche d'un AUTRE site (un site migré peut garder un compte commun).
# Exception : « jeiko-<site> », que l'étape 02 crée avec `useradd --system`
# (donc un uid < 1000). La règle de l'uid le gardait à chaque fois : aucune
# suppression n'effaçait le compte du site (essai.kojei.fr, 20/10/2026).
# « pkill -u » puis « userdel -r » l'auraient arrêté et effacé, son home avec.
# Usage : compte_partage <compte> <site> <dossier des fiches>
compte_partage() {
    local compte="$1" site="$2" fiches="$3" uid fiche autre
    uid="$(id -u "$compte" 2>/dev/null)" || return 1
    if [[ "$compte" == root ]] || { [[ "$uid" -lt 1000 ]] && [[ "$compte" != "jeiko-$site" ]]; }; then
        echo "compte du système (uid $uid)"; return 0
    fi
    if [[ -n "${ADMIN_SSH_USER:-}" && "$compte" == "$ADMIN_SSH_USER" ]]; then
        echo "compte de l'administrateur SSH"; return 0
    fi
    for fiche in "$fiches"/*.conf; do
        [[ -f "$fiche" ]] || continue
        autre="$(basename "$fiche" .conf)"
        [[ "$autre" == "$site" ]] && continue
        if grep -qE "^SITE_USER=['\"]?${compte}['\"]?$" "$fiche"; then
            echo "compte aussi du site « $autre »"; return 0
        fi
    done
    return 1
}

###############################################################################
# Chemins : la fiche du site fait foi, avec repli sur les conventions.
###############################################################################
CONF="$JEIKO_ETC_DIR/sites/$SITE.conf"
if [[ -r "$CONF" ]]; then
    # shellcheck disable=SC1090
    source "$CONF"
    jeiko_log "Fiche trouvée : $CONF"
else
    jeiko_warn "Fiche $CONF absente — repli sur les emplacements par défaut."
fi

PROJECT_DIR="${PROJECT_DIR:-/var/www/$SITE}"

# Ce chemin part dans un « rm -rf » : une fiche abîmée (PROJECT_DIR=/var/www,
# ou une racine) effacerait bien plus que le site (audit du 04/10/2026, I-10).
# Tout projet JEIKO vit dans un dossier qui porte le nom du site ET contient
# son manage.py — la seconde condition écarte le cas d'un site nommé « www »
# dont la fiche dirait /var/www. Un dossier déjà disparu ne gêne pas.
if [[ "$PROJECT_DIR" != /*/"$SITE" ]]; then
    jeiko_die "PROJECT_DIR « $PROJECT_DIR » ne se termine pas par /…/$SITE : suppression refusée."
fi
if [[ -e "$PROJECT_DIR" && ! -f "$PROJECT_DIR/manage.py" ]]; then
    jeiko_die "$PROJECT_DIR ne contient pas de manage.py : ce n'est pas le projet du site, suppression refusée."
fi
SITE_USER="${SITE_USER:-jeiko-$SITE}"
GUNICORN_SERVICE="${GUNICORN_SERVICE:-gunicorn-$SITE}"
DB_NAME="${DB_NAME:-}"; DB_USER="${DB_USER:-}"; DOMAIN_NAME="${DOMAIN_NAME:-}"

cat <<RECAP

╔══════════════════════════════════════════════════════════════╗
   Suppression du site « $SITE »
╚══════════════════════════════════════════════════════════════╝
  Projet        : $PROJECT_DIR
  Compte Unix   : $SITE_USER
  Service       : $GUNICORN_SERVICE
  Base / rôle   : ${DB_NAME:-?} / ${DB_USER:-?}$( [[ $KEEP_DB -eq 1 ]] && echo "   [CONSERVÉS]" )
  Vhost nginx   : /etc/nginx/sites-{available,enabled}/$SITE.conf
  Timers cron   : jeiko-cron-*@$SITE
  Sauvegardes   : $JEIKO_BACKUP_DIR/$SITE$( [[ $PURGE_BACKUPS -eq 1 ]] && echo "   [EFFACÉES]" || echo "   [CONSERVÉES]" )
  Journaux      : /var/log/gunicorn/$SITE, /var/log/nginx/${SITE}_*.log, $JEIKO_LOG_DIR/$SITE
  Certificat    : ${DOMAIN_NAME:-?} (Let's Encrypt)

  NON touchés : PostgreSQL, nginx, memcached, outillage /usr/local, config SSH.
RECAP

if [[ $DRY_RUN -eq 0 ]]; then
    read -rp "Confirmer la suppression définitive ? (tape le nom du site) : " c
    [[ "$c" == "$SITE" ]] || { echo "Annulé."; exit 0; }
fi

###############################################################################
# 1) Arrêt des services — avant toute suppression de fichiers
###############################################################################
jeiko_log "🛑 Arrêt des services…"
run systemctl stop "$GUNICORN_SERVICE.service" 2>/dev/null || true
run systemctl disable "$GUNICORN_SERVICE.service" 2>/dev/null || true

# Timers cron : instances du site, puis gabarits devenus orphelins.
for timer in /etc/systemd/system/jeiko-cron-*@.timer; do
    [[ -e "$timer" ]] || continue
    cad="$(basename "$timer")"; cad="${cad#jeiko-cron-}"; cad="${cad%@.timer}"
    run systemctl disable --now "jeiko-cron-$cad@$SITE.timer" 2>/dev/null || true
    run rm -rf "/etc/systemd/system/jeiko-cron-$cad@$SITE.service.d" \
               "/etc/systemd/system/jeiko-cron-$cad@$SITE.timer.d"
    if ! compgen -G "/etc/systemd/system/jeiko-cron-$cad@*.service.d" >/dev/null; then
        run rm -f "/etc/systemd/system/jeiko-cron-$cad@.timer" \
                  "/etc/systemd/system/jeiko-cron-$cad@.service"
    fi
done

run systemctl disable --now "jeiko-memcached-$SITE.service" 2>/dev/null || true
run rm -f "/etc/systemd/system/$GUNICORN_SERVICE.service" \
          "/etc/systemd/system/$GUNICORN_SERVICE.socket" \
          "/etc/systemd/system/jeiko-memcached-$SITE.service"
run systemctl daemon-reload
run systemctl reset-failed 2>/dev/null || true

###############################################################################
# 2) Base de données
###############################################################################
if [[ $KEEP_DB -eq 1 ]]; then
    jeiko_warn "Base et rôle conservés (--keep-db)."
elif [[ -n "$DB_NAME" ]] && command -v psql >/dev/null 2>&1; then
    jeiko_log "🛢️  Suppression de la base $DB_NAME et du rôle $DB_USER…"
    # Noms passés en ARGUMENTS et en variable psql, jamais dans une chaîne
    # interprétée : « su - postgres -c "… '$DB_NAME' …" » les faisait exécuter
    # par le superutilisateur PostgreSQL, en shell ET en SQL. Pour un site
    # migré, ces noms venaient de son .env, sans contrôle (audit du
    # 04/10/2026, I-10). Même méthode que 05_setup_database.sh.
    #
    # Les connexions résiduelles empêchent le DROP DATABASE.
    run runuser -u postgres -- psql -v ON_ERROR_STOP=1 -v dbname="$DB_NAME" -qtA >/dev/null 2>&1 <<'SQL' || true
SELECT pg_terminate_backend(pid) FROM pg_stat_activity
 WHERE datname = :'dbname' AND pid <> pg_backend_pid();
SQL
    run runuser -u postgres -- dropdb --if-exists -- "$DB_NAME" || jeiko_warn "Échec du dropdb $DB_NAME"
    if [[ -n "$DB_USER" ]]; then
        run runuser -u postgres -- dropuser --if-exists -- "$DB_USER" || true
    fi
else
    jeiko_warn "Base inconnue (fiche absente) — à supprimer à la main si nécessaire."
fi

###############################################################################
# 3) Fichiers
###############################################################################
jeiko_log "🗑️  Suppression des fichiers…"
run rm -rf "$PROJECT_DIR"
run rm -f  "/etc/nginx/sites-available/$SITE.conf" "/etc/nginx/sites-enabled/$SITE.conf"
# Ce que l'installeur pose aussi pour le site, et qui restait derrière lui
# (essai.kojei.fr, 20/10/2026) : son extrait nginx, les copies de son vhost,
# ses règles logrotate, l'ancienne version de son sudoers.
run rm -f  "/etc/nginx/snippets/jeiko-$SITE.conf" "/etc/nginx/sites-available/$SITE.conf".bak_*
run rm -f  "/etc/logrotate.d/gunicorn-$SITE" "/etc/logrotate.d/jeiko-$SITE"
run rm -f  "/etc/sudoers.d/jeiko-$SITE" "/etc/sudoers.d/jeiko-$SITE.old"
# La visio du site (VISIO-04) : SON LiveKit s'arrête, sa configuration et sa
# clé disparaissent, ses ports se referment et son rang se libère. Les
# LiveKit des autres sites ne sont pas touchés.
if [[ -d "/etc/livekit/sites/$SITE" || -f "$JEIKO_VISIO_RANGS/$SITE" ]]; then
    if [[ $DRY_RUN -eq 0 && -f "$JEIKO_VISIO_RANGS/$SITE" ]] && command -v ufw >/dev/null 2>&1; then
        read -r _ v_tcp v_udp v_turn_udp v_turn_tls < <(jeiko_visio_ports "$SITE") || true
        for regle in "${v_tcp:-}/tcp" "${v_udp:-}/udp" "${v_turn_udp:-}/udp" "${v_turn_tls:-}/tcp"; do
            [[ "$regle" == /* ]] || ufw delete allow "$regle" >/dev/null 2>&1 || true
        done
    elif [[ $DRY_RUN -eq 1 && -f "$JEIKO_VISIO_RANGS/$SITE" ]]; then
        # La simulation montre aussi les ports qui se refermeront.
        read -r _ v_tcp v_udp v_turn_udp v_turn_tls < <(jeiko_visio_ports "$SITE") || true
        printf '   [simulation] ufw delete allow %s\n' "${v_tcp:-?}/tcp" "${v_udp:-?}/udp" "${v_turn_udp:-?}/udp" "${v_turn_tls:-?}/tcp"
    fi
    run systemctl disable --now "livekit@$SITE.service" || true
    run rm -rf "/etc/livekit/sites/$SITE"
    run rm -f "$JEIKO_VISIO_RANGS/$SITE"
fi
run rm -f  "/etc/cron.d/jeiko-backup-$SITE"
# Les journaux nginx du site sont des FICHIERS <site>_access.log et
# <site>_error.log (et leurs rotations) : effacer un dossier /var/log/nginx/<site>
# qui n'existe pas laissait derrière soi les adresses IP de ses visiteurs.
run rm -rf "/var/log/gunicorn/$SITE" "/var/log/nginx/$SITE" "$JEIKO_LOG_DIR/$SITE"
run rm -f  "/var/log/nginx/${SITE}_access.log"* "/var/log/nginx/${SITE}_error.log"*
# Son certificat : sinon certbot tente chaque jour de le renouveler pour un
# site qui n'existe plus, échoue, et le dit. Un nom porté par un AUTRE site
# (fiche qui le déclare) n'est pas touché.
cert_partage=0
for fiche in "$JEIKO_ETC_DIR"/sites/*.conf; do
    [[ -f "$fiche" && "$fiche" != "$CONF" ]] || continue
    grep -qE "^DOMAIN_NAME=['\"]?${DOMAIN_NAME//./\\.}['\"]?$" "$fiche" && cert_partage=1
done
if [[ -n "${DOMAIN_NAME:-}" && -f "/etc/letsencrypt/renewal/$DOMAIN_NAME.conf" && $cert_partage -eq 0 ]]; then
    run certbot delete --cert-name "$DOMAIN_NAME" --non-interactive \
        || jeiko_warn "Certificat $DOMAIN_NAME non supprimé — certbot delete --cert-name $DOMAIN_NAME"
fi
run rm -rf "/run/$GUNICORN_SERVICE"
# Les horodatages des minuteurs « Persistent= » : sans effet, mais un reste du site.
run rm -f  /var/lib/systemd/timers/stamp-jeiko-cron-*@"$SITE".timer
run rm -rf "$JEIKO_LIB_DIR/$SITE"
if [[ $PURGE_BACKUPS -eq 1 ]]; then
    run rm -rf "$JEIKO_BACKUP_DIR/$SITE"
elif [[ -d "$JEIKO_BACKUP_DIR/$SITE" ]]; then
    jeiko_log "💾 Sauvegardes conservées : $JEIKO_BACKUP_DIR/$SITE (--purge-backups pour les effacer)."
fi
run rm -f  "$CONF"

###############################################################################
# 4) Compte Unix
###############################################################################
if raison="$(compte_partage "$SITE_USER" "$SITE" "$JEIKO_ETC_DIR/sites")"; then
    jeiko_warn "Compte $SITE_USER conservé : $raison."
elif id "$SITE_USER" >/dev/null 2>&1; then
    jeiko_log "👤 Suppression du compte $SITE_USER…"
    run pkill -u "$SITE_USER" 2>/dev/null || true
    # nginx sort du groupe du site, sans quoi userdel le laisse en place.
    run gpasswd -d www-data "$SITE_USER" 2>/dev/null || true
    # Sans -r : le compte est créé sans home (useradd --no-create-home), et
    # « userdel -r » échoue faute de home à effacer.
    run userdel "$SITE_USER" 2>/dev/null \
        || jeiko_warn "userdel a échoué — supprime le compte à la main."
fi

###############################################################################
# 5) nginx
###############################################################################
if command -v nginx >/dev/null 2>&1; then
    if [[ $DRY_RUN -eq 1 ]]; then
        printf '   [simulation] nginx -t && systemctl reload nginx\n'
    elif nginx -t >/dev/null 2>&1; then
        systemctl reload nginx && jeiko_ok "nginx rechargé."
    else
        jeiko_warn "nginx -t échoue : un AUTRE site a un problème de configuration."
        nginx -t || true
    fi
fi

jeiko_ok "Site « $SITE » supprimé."
[[ $KEEP_DB -eq 1 ]] && jeiko_log "Rappel : la base $DB_NAME existe toujours." || true
