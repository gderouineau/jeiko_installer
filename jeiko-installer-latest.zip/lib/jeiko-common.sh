# shellcheck shell=bash
###############################################################################
# jeiko-common.sh — fonctions partagées JEIKO
#
# Déployé en /usr/local/lib/jeiko/common.sh (root:root 0644).
# Sourcé par l'installeur ET par /usr/local/sbin/jeiko-update.
#
# ⚠️  Il ne doit exister qu'UN SEUL exemplaire de ce fichier sur la machine.
#     La divergence de permissions entre installation et mise à jour venait
#     précisément d'avoir deux implémentations du même modèle de droits.
#
# Ce fichier ne fait pas `set -euo pipefail` : c'est au script appelant de le
# décider.
###############################################################################

JEIKO_COMMON_VERSION="2.0"

# --------------------------------------------------------------------------- #
# Emplacements canoniques
# --------------------------------------------------------------------------- #
JEIKO_ETC_DIR="/etc/jeiko"
JEIKO_SITES_DIR="$JEIKO_ETC_DIR/sites"     # registre des sites (root:root 0700)
JEIKO_LIB_DIR="/var/lib/jeiko"             # état + cache des wheels
JEIKO_LOG_DIR="/var/log/jeiko"             # logs de mise à jour, par site
JEIKO_BACKUP_DIR="/var/backups/jeiko"      # dumps DB + media
# Les verrous vivent dans un dossier root SEUL (0700), pas dans /run/lock qui
# est inscriptible par tous (1777) : sur /run/lock, n'importe quel compte local
# — donc le compte web d'un site, tenu pour compromis — pouvait créer le
# fichier de verrou d'avance, ou le tenir via un simple descripteur en lecture
# (flock ne regarde pas le mode d'ouverture), et arrêter EN SILENCE toute mise à
# jour du serveur (rapport du 05/10, P1-b). /run est un tmpfs : le dossier est
# recréé à chaque prise de verrou (jeiko_dossier_verrous).
JEIKO_LOCK_DIR="/run/jeiko"

# Canal de distribution par défaut (surchargeable par site dans sa fiche).
JEIKO_DEFAULT_CHANNEL_URL="https://raw.githubusercontent.com/gderouineau/jeiko/main"

# Canal de l'INSTALLEUR (outillage serveur), et dépôt de cet outillage. Tous
# deux surchargeables par l'environnement, comme l'était déjà JEIKO_ASSET_DIR
# dans jeiko-server-update.
JEIKO_INSTALLER_CHANNEL_URL="${JEIKO_INSTALLER_CHANNEL_URL:-https://raw.githubusercontent.com/gderouineau/jeiko_installer/main}"
JEIKO_ASSET_DIR="${JEIKO_ASSET_DIR:-/usr/local/share/jeiko}"

# Le serveur de licences (LIC-01) : jeiko-client-update lui demande, avant
# chaque mise à jour, si la clé du site l'autorise. Surchargeable par la fiche
# d'un site ou l'environnement.
JEIKO_LICENCE_URL="${JEIKO_LICENCE_URL:-https://jeiko.fr/api/licences/verifier/}"

# --------------------------------------------------------------------------- #
# Modèle de permissions canonique
#
#  Répertoires  2750  setgid → le groupe DU SITE est hérité par tout nouveau
#                     fichier, donc nginx (membre de ce groupe) peut lire sans
#                     intervention manuelle
#  Fichiers     0640  propriétaire lit/écrit, nginx lit via le groupe,
#                     les autres comptes — les autres sites compris — ne
#                     voient rien
#  .env         0600  jamais lisible par le groupe (contient DB_PASS)
#  Exécutables  0750
#
# Le socket gunicorn fait exception : nginx doit pouvoir y ÉCRIRE pour s'y
# connecter, il est donc en 0660, groupe du site (géré par UMask dans l'unité
# systemd). C'est la raison pour laquelle les uploads Django sont, eux, forcés
# explicitement via FILE_UPLOAD_PERMISSIONS dans settings.py plutôt que laissés
# au umask du processus.
# --------------------------------------------------------------------------- #
JEIKO_DIR_MODE="2750"
JEIKO_FILE_MODE="0640"
JEIKO_EXEC_MODE="0750"
JEIKO_SECRET_MODE="0600"

# --------------------------------------------------------------------------- #
# Journalisation
# --------------------------------------------------------------------------- #
jeiko_log()  { printf '%s\n' "$*"; }
jeiko_step() { printf '\n▶ %s\n' "$(jeiko_traduire "$*")"; }
jeiko_ok()   { printf '✅ %s\n' "$(jeiko_traduire "$*")"; }
jeiko_warn() { printf '⚠️  %s\n' "$*" >&2; }
jeiko_err()  { printf '❌ %s\n' "$*" >&2; }
jeiko_die()  { jeiko_err "$*"; exit 1; }

jeiko_require_root() {
    [[ ${EUID:-$(id -u)} -eq 0 ]] || jeiko_die "Cette opération doit être exécutée en root."
}

# --------------------------------------------------------------------------- #
# Validation
#
# Le nom de site sert à construire des noms d'unités systemd, des chemins et
# des entrées sudoers : il doit être strictement contraint. Cette fonction est
# la seule barrière entre une valeur fournie par l'utilisateur et un ExecStart.
# --------------------------------------------------------------------------- #
jeiko_validate_site_name() {
    local name="${1:-}"
    [[ -n "$name" ]] || { jeiko_err "Nom de site vide."; return 1; }
    [[ "$name" =~ ^[a-z0-9][a-z0-9_-]{0,30}$ ]] || {
        jeiko_err "Nom de site invalide : '$name' (minuscules, chiffres, - et _, 31 max, commence par un alphanumérique)."
        return 1
    }
    # Un nom de site devient aussi un nom de paquet Python de projet Django.
    [[ "$name" != *-* ]] || {
        jeiko_err "Nom de site invalide : '$name' contient un tiret, or il sert de nom de module Python (utilise _)."
        return 1
    }
    return 0
}

jeiko_validate_domain() {
    local domain="${1:-}" etiquette
    [[ "$domain" =~ ^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$ ]] || {
        jeiko_err "Domaine invalide : '$domain'"
        return 1
    }
    [[ ${#domain} -le 253 ]] || { jeiko_err "Domaine trop long."; return 1; }
    for etiquette in ${domain//./ }; do
        [[ ${#etiquette} -le 63 ]] || { jeiko_err "Domaine invalide : « $etiquette » dépasse 63 caractères."; return 1; }
    done
    return 0
}

# Ce qu'un NOUVEAU site doit respecter en plus de jeiko_validate_site_name —
# appelé à la saisie, avant toute création. Les sites déjà installés n'y sont
# pas soumis : leur nom est fixé.
#   · Django refuse un nom de projet qui n'est pas un identifiant Python, ou
#     qui masque un module importable (site, json, django…) : l'échec arrivait
#     à l'étape 09, après la base, le compte et les dossiers ;
#   · le compte système « jeiko-<nom> » doit tenir dans les 32 caractères
#     de useradd.
# Usage : jeiko_valider_nouveau_site <nom> [python3]
jeiko_valider_nouveau_site() {
    local name="${1:-}" py="${2:-$(command -v python3 || true)}"
    jeiko_validate_site_name "$name" || return 1
    [[ ${#name} -le 26 ]] || { jeiko_err "Nom de site trop long : 26 caractères au plus (le compte système s'appelle jeiko-$name)."; return 1; }
    [[ "$name" =~ ^[a-z_] ]] || { jeiko_err "Nom de site invalide : '$name' doit commencer par une lettre (c'est un nom de module Python)."; return 1; }
    case "$name" in
        django|jeiko|gunicorn|psycopg|psycopg2|stripe|allauth|weasyprint|pymemcache|dotenv|requests|test|tests)
            jeiko_err "Nom de site réservé : '$name' masquerait un module Python du site."; return 1 ;;
    esac
    if [[ -x "$py" ]]; then
        "$py" -c 'import importlib.util, keyword, sys
n = sys.argv[1]
sys.exit(1 if keyword.iskeyword(n) or importlib.util.find_spec(n) else 0)' "$name" 2>/dev/null \
            || { jeiko_err "Nom de site réservé : '$name' est un mot-clé ou un module Python existant."; return 1; }
    fi
    return 0
}

# Un mot de passe de base SAISI doit passer tel quel par trois lecteurs : la
# fiche (shell), le .env (python-dotenv, entre guillemets doubles) et
# PostgreSQL. dotenv interprète « \ » et « ${…} », et un « " » coupe la
# valeur : la base aurait accepté le mot de passe, Django pas. On refuse donc
# ces caractères, les apostrophes et les espaces ; le mot de passe généré n'en
# contient jamais.
jeiko_valider_mot_de_passe_db() {
    local mdp="${1-}" permis='^[A-Za-z0-9._,:;!?@#%+=*/~^-]+$'
    [[ ${#mdp} -ge 12 ]] || { jeiko_err "Mot de passe PostgreSQL : 12 caractères minimum."; return 1; }
    [[ "$mdp" =~ $permis ]] || {
        jeiko_err "Mot de passe PostgreSQL : lettres, chiffres et . _ , : ; ! ? @ # % + = * / ~ ^ - seulement (ni guillemet, ni \\, ni \$, ni espace)."
        return 1
    }
}

# Mot de passe généré : 30 octets aléatoires, encodés. `head -c` lit un nombre
# FINI d'octets : rien n'est coupé en cours d'écriture. L'ancienne forme
# (`tr </dev/urandom | head -c40`) recevait SIGPIPE et, sous pipefail,
# arrêtait l'installeur exactement dans le cas « vide = généré ».
jeiko_mot_de_passe_genere() {
    head -c 30 /dev/urandom | base64 | tr -d '+/=\n'
}

# Les noms PostgreSQL d'un site ne doivent ni viser un rôle du système ni
# reprendre ceux d'un autre site : l'étape 05 changerait le mot de passe de ce
# rôle, et l'autre site perdrait sa base.
# Usage : jeiko_valider_noms_db <site> <base> <rôle>
jeiko_valider_noms_db() {
    local site="$1" base="$2" role="$3" autre a_base a_role
    local n
    for n in "$base" "$role"; do
        [[ "$n" =~ ^[a-zA-Z_][a-zA-Z0-9_]{0,62}$ ]] || { jeiko_err "Nom PostgreSQL invalide : « $n »."; return 1; }
        case "${n,,}" in
            postgres|template0|template1|pg_*)
                jeiko_err "Nom PostgreSQL réservé : « $n »."; return 1 ;;
        esac
    done
    for autre in $(jeiko_list_sites); do
        [[ "$autre" == "$site" ]] && continue
        read -r a_base a_role < <(
            # shellcheck disable=SC1090
            source "$(jeiko_site_conf_path "$autre")" 2>/dev/null; printf '%s %s\n' "${DB_NAME:-}" "${DB_USER:-}")
        if [[ "$base" == "$a_base" || "$role" == "$a_role" ]]; then
            jeiko_err "Base ou rôle PostgreSQL déjà utilisé par le site « $autre »."; return 1
        fi
    done
    return 0
}

# Une clé publique que sshd saura lire — jugée par ssh-keygen, pas par une
# expression régulière (qui acceptait « ssh-ed25519 AAAA » tronquée).
jeiko_cle_ssh_valide() {
    [[ "${1-}" != *$'\n'* ]] || return 1
    ssh-keygen -l -f /dev/stdin <<<"$1" >/dev/null 2>&1
}

# --------------------------------------------------------------------------- #
# Langue de l'installeur (I-08, 09/10/2026)
#
# JEIKO_INSTALL_LANG (fr, en, es, de, it) est choisie à la première question
# d'install.sh. `jeiko_t "texte français %s" args` rend la phrase dans cette
# langue — ou en français si elle manque à la table : une phrase oubliée
# s'affiche, elle ne casse rien. Les titres d'étape (jeiko_step) et les
# messages fixes de jeiko_ok / jeiko_log passent par la même table ; les
# messages techniques des étapes restent en français (dépannage).
# --------------------------------------------------------------------------- #
jeiko_traduire() {
    local fr="$1" tr=""
    # Tables seulement sous bash ≥ 4 (tableaux associatifs) : ailleurs, le
    # français — jamais une erreur dans une bibliothèque que tout source.
    (( BASH_VERSINFO[0] >= 4 )) || { printf '%s' "$fr"; return 0; }
    case "${JEIKO_INSTALL_LANG:-fr}" in
        en) tr="${JEIKO_T_EN[$fr]-}" ;;
        es) tr="${JEIKO_T_ES[$fr]-}" ;;
        de) tr="${JEIKO_T_DE[$fr]-}" ;;
        it) tr="${JEIKO_T_IT[$fr]-}" ;;
    esac
    printf '%s' "${tr:-$fr}"
}

jeiko_t() {
    local gabarit
    gabarit="$(jeiko_traduire "$1")"; shift
    if (( $# )); then
        # shellcheck disable=SC2059  # le gabarit EST le format, par construction
        printf -- "$gabarit" "$@"
    else
        printf '%s' "$gabarit"
    fi
}

# Le oui de chaque langue : y, yes, o, oui, s, si, sí, j, ja. Tout le reste
# vaut non — la réponse par défaut des questions qui engagent.
jeiko_oui() {
    case "${1,,}" in
        y|yes|o|oui|s|si|sí|j|ja) return 0 ;;
        *) return 1 ;;
    esac
}

if (( BASH_VERSINFO[0] >= 4 )); then
declare -gA JEIKO_T_EN=(
    ['▶️  Nom du site (ex: monsite) : ']='▶️  Site name (e.g. mysite): '
    ['⚠️  Un site nommé '\''%s'\'' est déjà enregistré sur cette machine.']='⚠️  A site named '\''%s'\'' is already registered on this machine.'
    ['    Pour le mettre à jour : jeiko-client-update %s']='    To update it: jeiko-client-update %s'
    ['    Pour le migrer        : ./migrate_site.sh %s']='    To migrate it: ./migrate_site.sh %s'
    ['    Continuer quand même et écraser sa configuration ? (o/n) : ']='    Continue anyway and overwrite its configuration? (y/n): '
    ['Installation annulée.']='Installation cancelled.'
    ['▶️  Nom de domaine (ex: monsite.fr) : ']='▶️  Domain name (e.g. mysite.com): '
    ['▶️  Nom de la base PostgreSQL [%s_db] : ']='▶️  PostgreSQL database name [%s_db]: '
    ['❌ Nom de base invalide.']='❌ Invalid database name.'
    ['▶️  Nom de l'\''utilisateur PostgreSQL [%s_user] : ']='▶️  PostgreSQL user name [%s_user]: '
    ['❌ Nom d'\''utilisateur invalide.']='❌ Invalid user name.'
    ['▶️  Mot de passe PostgreSQL (vide = généré automatiquement) : ']='▶️  PostgreSQL password (empty = generated automatically): '
    ['   🔑 Mot de passe généré (stocké dans la fiche du site, non affiché).']='   🔑 Password generated (stored in the site record, not displayed).'
    ['▶️  Identifiant du compte d'\''administration : ']='▶️  Admin account username: '
    ['❌ Nom requis.']='❌ Name required.'
    ['▶️  E-mail du compte d'\''administration : ']='▶️  Admin account e-mail: '
    ['❌ Adresse e-mail valide requise.']='❌ A valid e-mail address is required.'
    ['▶️  Mot de passe du compte d'\''administration : ']='▶️  Admin account password: '
    ['❌ 12 caractères minimum.']='❌ 12 characters minimum.'
    ['▶️  Activer HTTPS avec Let'\''s Encrypt ? (o/n) : ']='▶️  Enable HTTPS with Let'\''s Encrypt? (y/n): '
    ['▶️  Utilisateur SSH d'\''administration [%s] : ']='▶️  SSH admin user [%s]: '
    ['🔑 Mot de passe SSH conservé (choix enregistré sur cette machine).']='🔑 SSH password kept (choice saved on this machine).'
    ['    Tu peux tout de même enregistrer une clé — le mot de passe']='    You can still register a key — the password'
    ['    restera actif dans tous les cas.']='    will stay active in any case.'
    ['▶️  Clé publique (vide = aucune) : ']='▶️  Public key (empty = none): '
    ['❌ Ce n'\''est pas une clé publique valide (attendu : « ssh-ed25519 AAAA… »).']='❌ This is not a valid public key (expected: “ssh-ed25519 AAAA…”).'
    ['   Laisse le champ vide si tu ne veux pas installer de clé.']='   Leave it empty if you don'\''t want to install a key.'
    ['   ✅ Clé retenue, elle sera installée pour %s.']='   ✅ Key accepted, it will be installed for %s.'
    ['🔐 Une clé SSH est déjà présente sur cette machine.']='🔐 An SSH key is already present on this machine.'
    ['    L'\''installeur peut désactiver l'\''authentification par mot de passe.']='    The installer can disable password authentication.'
    ['    C'\''est plus sûr, MAIS tu ne pourras plus te connecter qu'\''avec cette']='    It is safer, BUT you will only be able to log in with this'
    ['    clé précise. Si elle appartient à ton hébergeur, ou si tu te']='    exact key. If it belongs to your hosting provider, or if you'
    ['    connectes depuis un poste qui ne l'\''a pas, tu seras enfermé dehors.']='    connect from a computer that doesn'\''t have it, you will be locked out.'
    ['▶️  Désactiver le mot de passe SSH ? (o/N) : ']='▶️  Disable the SSH password? (y/N): '
    ['   🔒 Mot de passe désactivé. Garde une session ouverte et vérifie']='   🔒 Password disabled. Keep a session open and check'
    ['      ta connexion par clé avant de la fermer.']='      your key login before closing it.'
    ['   ✅ Mot de passe conservé (fail2ban actif). Choix mémorisé pour']='   ✅ Password kept (fail2ban active). Choice remembered for'
    ['      les prochaines installations sur cette machine.']='      future installations on this machine.'
    ['⚠️  Aucune clé SSH publique trouvée sur cette machine.']='⚠️  No public SSH key found on this machine.'
    ['    Sans clé, l'\''accès par mot de passe doit rester ouvert, ce qui est']='    Without a key, password access must stay open, which is'
    ['    la faiblesse principale d'\''un serveur exposé.']='    the main weakness of an exposed server.'
    ['    Colle ta clé publique (le contenu de ~/.ssh/id_ed25519.pub sur ton']='    Paste your public key (the content of ~/.ssh/id_ed25519.pub on your'
    ['    poste), ou laisse vide — tu pourras l'\''ajouter plus tard avec']='    computer), or leave it empty — you can add it later with'
    ['    ssh-copy-id, sans rien réinstaller.']='    ssh-copy-id, without reinstalling anything.'
    ['    Veux-tu aussi désactiver l'\''authentification par mot de passe ?']='    Do you also want to disable password authentication?'
    ['    Tu ne pourras alors plus te connecter qu'\''avec cette clé, depuis']='    You will then only be able to log in with this key, from'
    ['    un poste qui la possède.']='    a computer that has it.'
    ['   ✅ Clé ajoutée ET mot de passe conservé. Choix mémorisé.']='   ✅ Key added AND password kept. Choice remembered.'
    ['   ⚠️  Aucune clé : mot de passe conservé, protégé par fail2ban.']='   ⚠️  No key: password kept, protected by fail2ban.'
    ['──────────── RÉCAPITULATIF ────────────']='──────────── SUMMARY ────────────'
    ['🧩 Site              : %s']='🧩 Site              : %s'
    ['🌍 Domaine           : %s']='🌍 Domain            : %s'
    ['🗣️  Langue            : %s']='🗣️  Language          : %s'
    ['🛢️  Base PostgreSQL   : %s (rôle %s)']='🛢️  PostgreSQL DB     : %s (role %s)'
    ['👤 Administration    : %s <%s>']='👤 Admin account     : %s <%s>'
    ['🔒 Let'\''s Encrypt     : %s']='🔒 Let'\''s Encrypt     : %s'
    ['📁 Dossier projet    : %s']='📁 Project folder    : %s'
    ['🧑 Utilisateur système: %s']='🧑 System user       : %s'
    ['🔑 Admin SSH (ACL)   : %s']='🔑 SSH admin (ACL)   : %s'
    ['🔓 Mot de passe SSH  : CONSERVÉ (fail2ban actif)']='🔓 SSH password      : KEPT (fail2ban active)'
    ['🔒 Mot de passe SSH  : DÉSACTIVÉ — connexion par clé uniquement']='🔒 SSH password      : DISABLED — key login only'
    ['📡 Canal de MAJ      : %s']='📡 Update channel    : %s'
    ['Confirmer l'\''installation ? (o/n) : ']='Confirm the installation? (y/n): '
    ['🗃️  Fiche du site : %s (0600 root:root)']='🗃️  Site record: %s (0600 root:root)'
    ['🚀 Installation en cours… (journal : %s)']='🚀 Installing… (log: %s)'
    ['❌ Échec à l'\''étape %s. Journal complet : %s']='❌ Step %s failed. Full log: %s'
    ['   Les étapes sont idempotentes : corrige la cause et relance ./install.sh.']='   Steps are idempotent: fix the cause and run ./install.sh again.'
    ['✅ Installation terminée.']='✅ Installation complete.'
    ['🌐 Site           : %s']='🌐 Site           : %s'
    ['🔐 Administration : %s']='🔐 Admin          : %s'
    ['📄 Journal        : %s']='📄 Log            : %s'
    ['Mise à jour du site :']='Updating the site:'
    ['  · depuis l'\''interface  → Administration ▸ Mettre à jour JEIKO']='  · from the interface → Admin ▸ Update JEIKO'
    ['  · depuis le serveur   → sudo jeiko-client-update %s']='  · from the server    → sudo jeiko-client-update %s'
    ['  · vérifier sans agir  → sudo jeiko-client-update %s --check']='  · check only         → sudo jeiko-client-update %s --check'
    ['  · revenir en arrière  → sudo jeiko-client-update %s --rollback']='  · roll back          → sudo jeiko-client-update %s --rollback'
    ['Fiche du site : %s']='Site record  : %s'
    ['Sauvegardes   : %s']='Backups      : %s'
    ['⚠️  Le site tourne en HTTP. La redirection HTTPS et HSTS sont désactivées dans']='⚠️  The site runs on HTTP. HTTPS redirection and HSTS are disabled in'
    ['    le .env (JEIKO_SSL="False") pour éviter la boucle de redirection.']='    the .env (JEIKO_SSL="False") to avoid a redirect loop.'
    ['    Pour activer TLS plus tard :']='    To enable TLS later:'
    ['    (le certificat est demandé, JEIKO_SSL passe à True et le site redémarre)']='    (the certificate is requested, JEIKO_SSL is set to True and the site restarts)'
    ['[00] Pré-vol & vérifications']='[00] Pre-flight & checks'
    ['[01] Durcissement de base (UFW, SSH, Fail2ban, sysctl, MAJ auto, temps)']='[01] Base hardening (UFW, SSH, Fail2ban, sysctl, auto updates, time)'
    ['[02] Compte système, dossiers et permissions']='[02] System account, folders and permissions'
    ['[03] Dépendances système']='[03] System dependencies'
    ['[04] PostgreSQL — service et durcissement']='[04] PostgreSQL — service and hardening'
    ['[05] Base de données et rôle applicatif']='[05] Database and application role'
    ['[06] Memcached']='[06] Memcached'
    ['[07] Environnement Python (venv)']='[07] Python environment (venv)'
    ['[08] Package JEIKO et mécanisme de mise à jour']='[08] JEIKO package and update mechanism'
    ['[09] Configuration Django (.env, settings, urls)']='[09] Django configuration (.env, settings, urls)'
    ['[10] Service Gunicorn']='[10] Gunicorn service'
    ['[11] Nginx (vhost HTTP, prêt pour Certbot)']='[11] Nginx (HTTP vhost, ready for Certbot)'
    ['[12] TLS Let'\''s Encrypt et vhost HTTPS']='[12] Let'\''s Encrypt TLS and HTTPS vhost'
    ['[13] Sauvegardes (base, médias, configuration)']='[13] Backups (database, media, configuration)'
    ['[14] Migrations, statiques, droits de mise à jour, contrôles']='[14] Migrations, static files, update rights, checks'
    ['Finalisation terminée.']='Finalisation complete.'
    ['🏠 Site de départ…']='🏠 Starter site…'
)

declare -gA JEIKO_T_ES=(
    ['▶️  Nom du site (ex: monsite) : ']='▶️  Nombre del sitio (p. ej. misitio): '
    ['⚠️  Un site nommé '\''%s'\'' est déjà enregistré sur cette machine.']='⚠️  Ya hay un sitio llamado '\''%s'\'' registrado en esta máquina.'
    ['    Pour le mettre à jour : jeiko-client-update %s']='    Para actualizarlo: jeiko-client-update %s'
    ['    Pour le migrer        : ./migrate_site.sh %s']='    Para migrarlo: ./migrate_site.sh %s'
    ['    Continuer quand même et écraser sa configuration ? (o/n) : ']='    ¿Continuar de todos modos y sobrescribir su configuración? (s/n): '
    ['Installation annulée.']='Instalación cancelada.'
    ['▶️  Nom de domaine (ex: monsite.fr) : ']='▶️  Nombre de dominio (p. ej. misitio.es): '
    ['▶️  Nom de la base PostgreSQL [%s_db] : ']='▶️  Nombre de la base PostgreSQL [%s_db]: '
    ['❌ Nom de base invalide.']='❌ Nombre de base no válido.'
    ['▶️  Nom de l'\''utilisateur PostgreSQL [%s_user] : ']='▶️  Nombre del usuario PostgreSQL [%s_user]: '
    ['❌ Nom d'\''utilisateur invalide.']='❌ Nombre de usuario no válido.'
    ['▶️  Mot de passe PostgreSQL (vide = généré automatiquement) : ']='▶️  Contraseña PostgreSQL (vacía = generada automáticamente): '
    ['   🔑 Mot de passe généré (stocké dans la fiche du site, non affiché).']='   🔑 Contraseña generada (guardada en la ficha del sitio, no se muestra).'
    ['▶️  Identifiant du compte d'\''administration : ']='▶️  Usuario de la cuenta de administración: '
    ['❌ Nom requis.']='❌ Nombre obligatorio.'
    ['▶️  E-mail du compte d'\''administration : ']='▶️  Correo de la cuenta de administración: '
    ['❌ Adresse e-mail valide requise.']='❌ Se necesita una dirección de correo válida.'
    ['▶️  Mot de passe du compte d'\''administration : ']='▶️  Contraseña de la cuenta de administración: '
    ['❌ 12 caractères minimum.']='❌ Mínimo 12 caracteres.'
    ['▶️  Activer HTTPS avec Let'\''s Encrypt ? (o/n) : ']='▶️  ¿Activar HTTPS con Let'\''s Encrypt? (s/n): '
    ['▶️  Utilisateur SSH d'\''administration [%s] : ']='▶️  Usuario SSH de administración [%s]: '
    ['🔑 Mot de passe SSH conservé (choix enregistré sur cette machine).']='🔑 Contraseña SSH conservada (elección guardada en esta máquina).'
    ['    Tu peux tout de même enregistrer une clé — le mot de passe']='    Aun así puedes registrar una clave — la contraseña'
    ['    restera actif dans tous les cas.']='    seguirá activa en cualquier caso.'
    ['▶️  Clé publique (vide = aucune) : ']='▶️  Clave pública (vacía = ninguna): '
    ['❌ Ce n'\''est pas une clé publique valide (attendu : « ssh-ed25519 AAAA… »).']='❌ No es una clave pública válida (se espera: «ssh-ed25519 AAAA…»).'
    ['   Laisse le champ vide si tu ne veux pas installer de clé.']='   Déjalo vacío si no quieres instalar una clave.'
    ['   ✅ Clé retenue, elle sera installée pour %s.']='   ✅ Clave aceptada, se instalará para %s.'
    ['🔐 Une clé SSH est déjà présente sur cette machine.']='🔐 Ya hay una clave SSH en esta máquina.'
    ['    L'\''installeur peut désactiver l'\''authentification par mot de passe.']='    El instalador puede desactivar la autenticación por contraseña.'
    ['    C'\''est plus sûr, MAIS tu ne pourras plus te connecter qu'\''avec cette']='    Es más seguro, PERO solo podrás conectarte con esta'
    ['    clé précise. Si elle appartient à ton hébergeur, ou si tu te']='    clave concreta. Si pertenece a tu proveedor de alojamiento, o si te'
    ['    connectes depuis un poste qui ne l'\''a pas, tu seras enfermé dehors.']='    conectas desde un equipo que no la tiene, te quedarás fuera.'
    ['▶️  Désactiver le mot de passe SSH ? (o/N) : ']='▶️  ¿Desactivar la contraseña SSH? (s/N): '
    ['   🔒 Mot de passe désactivé. Garde une session ouverte et vérifie']='   🔒 Contraseña desactivada. Mantén una sesión abierta y comprueba'
    ['      ta connexion par clé avant de la fermer.']='      tu conexión con clave antes de cerrarla.'
    ['   ✅ Mot de passe conservé (fail2ban actif). Choix mémorisé pour']='   ✅ Contraseña conservada (fail2ban activo). Elección guardada para'
    ['      les prochaines installations sur cette machine.']='      las próximas instalaciones en esta máquina.'
    ['⚠️  Aucune clé SSH publique trouvée sur cette machine.']='⚠️  No se encontró ninguna clave SSH pública en esta máquina.'
    ['    Sans clé, l'\''accès par mot de passe doit rester ouvert, ce qui est']='    Sin clave, el acceso por contraseña debe seguir abierto, lo que es'
    ['    la faiblesse principale d'\''un serveur exposé.']='    la principal debilidad de un servidor expuesto.'
    ['    Colle ta clé publique (le contenu de ~/.ssh/id_ed25519.pub sur ton']='    Pega tu clave pública (el contenido de ~/.ssh/id_ed25519.pub en tu'
    ['    poste), ou laisse vide — tu pourras l'\''ajouter plus tard avec']='    equipo), o déjalo vacío — podrás añadirla más tarde con'
    ['    ssh-copy-id, sans rien réinstaller.']='    ssh-copy-id, sin reinstalar nada.'
    ['    Veux-tu aussi désactiver l'\''authentification par mot de passe ?']='    ¿Quieres desactivar también la autenticación por contraseña?'
    ['    Tu ne pourras alors plus te connecter qu'\''avec cette clé, depuis']='    Entonces solo podrás conectarte con esta clave, desde'
    ['    un poste qui la possède.']='    un equipo que la tenga.'
    ['   ✅ Clé ajoutée ET mot de passe conservé. Choix mémorisé.']='   ✅ Clave añadida Y contraseña conservada. Elección guardada.'
    ['   ⚠️  Aucune clé : mot de passe conservé, protégé par fail2ban.']='   ⚠️  Sin clave: contraseña conservada, protegida por fail2ban.'
    ['──────────── RÉCAPITULATIF ────────────']='──────────── RESUMEN ────────────'
    ['🧩 Site              : %s']='🧩 Sitio             : %s'
    ['🌍 Domaine           : %s']='🌍 Dominio           : %s'
    ['🗣️  Langue            : %s']='🗣️  Idioma            : %s'
    ['🛢️  Base PostgreSQL   : %s (rôle %s)']='🛢️  Base PostgreSQL   : %s (rol %s)'
    ['👤 Administration    : %s <%s>']='👤 Administración    : %s <%s>'
    ['🔒 Let'\''s Encrypt     : %s']='🔒 Let'\''s Encrypt     : %s'
    ['📁 Dossier projet    : %s']='📁 Carpeta del proyecto: %s'
    ['🧑 Utilisateur système: %s']='🧑 Usuario del sistema: %s'
    ['🔑 Admin SSH (ACL)   : %s']='🔑 Admin SSH (ACL)   : %s'
    ['🔓 Mot de passe SSH  : CONSERVÉ (fail2ban actif)']='🔓 Contraseña SSH    : CONSERVADA (fail2ban activo)'
    ['🔒 Mot de passe SSH  : DÉSACTIVÉ — connexion par clé uniquement']='🔒 Contraseña SSH    : DESACTIVADA — solo conexión con clave'
    ['📡 Canal de MAJ      : %s']='📡 Canal de actualización: %s'
    ['Confirmer l'\''installation ? (o/n) : ']='¿Confirmar la instalación? (s/n): '
    ['🗃️  Fiche du site : %s (0600 root:root)']='🗃️  Ficha del sitio: %s (0600 root:root)'
    ['🚀 Installation en cours… (journal : %s)']='🚀 Instalando… (registro: %s)'
    ['❌ Échec à l'\''étape %s. Journal complet : %s']='❌ Fallo en el paso %s. Registro completo: %s'
    ['   Les étapes sont idempotentes : corrige la cause et relance ./install.sh.']='   Los pasos son idempotentes: corrige la causa y vuelve a lanzar ./install.sh.'
    ['✅ Installation terminée.']='✅ Instalación terminada.'
    ['🌐 Site           : %s']='🌐 Sitio          : %s'
    ['🔐 Administration : %s']='🔐 Administración : %s'
    ['📄 Journal        : %s']='📄 Registro       : %s'
    ['Mise à jour du site :']='Actualizar el sitio:'
    ['  · depuis l'\''interface  → Administration ▸ Mettre à jour JEIKO']='  · desde la interfaz  → Administración ▸ Actualizar JEIKO'
    ['  · depuis le serveur   → sudo jeiko-client-update %s']='  · desde el servidor  → sudo jeiko-client-update %s'
    ['  · vérifier sans agir  → sudo jeiko-client-update %s --check']='  · comprobar sin actuar → sudo jeiko-client-update %s --check'
    ['  · revenir en arrière  → sudo jeiko-client-update %s --rollback']='  · volver atrás       → sudo jeiko-client-update %s --rollback'
    ['Fiche du site : %s']='Ficha del sitio: %s'
    ['Sauvegardes   : %s']='Copias de seguridad: %s'
    ['⚠️  Le site tourne en HTTP. La redirection HTTPS et HSTS sont désactivées dans']='⚠️  El sitio funciona en HTTP. La redirección HTTPS y HSTS están desactivadas en'
    ['    le .env (JEIKO_SSL="False") pour éviter la boucle de redirection.']='    el .env (JEIKO_SSL="False") para evitar el bucle de redirección.'
    ['    Pour activer TLS plus tard :']='    Para activar TLS más tarde:'
    ['    (le certificat est demandé, JEIKO_SSL passe à True et le site redémarre)']='    (se solicita el certificado, JEIKO_SSL pasa a True y el sitio se reinicia)'
    ['[00] Pré-vol & vérifications']='[00] Comprobaciones previas'
    ['[01] Durcissement de base (UFW, SSH, Fail2ban, sysctl, MAJ auto, temps)']='[01] Endurecimiento básico (UFW, SSH, Fail2ban, sysctl, actualizaciones, hora)'
    ['[02] Compte système, dossiers et permissions']='[02] Cuenta del sistema, carpetas y permisos'
    ['[03] Dépendances système']='[03] Dependencias del sistema'
    ['[04] PostgreSQL — service et durcissement']='[04] PostgreSQL — servicio y endurecimiento'
    ['[05] Base de données et rôle applicatif']='[05] Base de datos y rol de la aplicación'
    ['[06] Memcached']='[06] Memcached'
    ['[07] Environnement Python (venv)']='[07] Entorno Python (venv)'
    ['[08] Package JEIKO et mécanisme de mise à jour']='[08] Paquete JEIKO y mecanismo de actualización'
    ['[09] Configuration Django (.env, settings, urls)']='[09] Configuración de Django (.env, settings, urls)'
    ['[10] Service Gunicorn']='[10] Servicio Gunicorn'
    ['[11] Nginx (vhost HTTP, prêt pour Certbot)']='[11] Nginx (vhost HTTP, listo para Certbot)'
    ['[12] TLS Let'\''s Encrypt et vhost HTTPS']='[12] TLS Let'\''s Encrypt y vhost HTTPS'
    ['[13] Sauvegardes (base, médias, configuration)']='[13] Copias de seguridad (base, medios, configuración)'
    ['[14] Migrations, statiques, droits de mise à jour, contrôles']='[14] Migraciones, estáticos, permisos de actualización, controles'
    ['Finalisation terminée.']='Finalización terminada.'
    ['🏠 Site de départ…']='🏠 Sitio de inicio…'
)

declare -gA JEIKO_T_DE=(
    ['▶️  Nom du site (ex: monsite) : ']='▶️  Name der Website (z. B. meineseite): '
    ['⚠️  Un site nommé '\''%s'\'' est déjà enregistré sur cette machine.']='⚠️  Auf diesem Rechner ist bereits eine Website namens '\''%s'\'' registriert.'
    ['    Pour le mettre à jour : jeiko-client-update %s']='    Zum Aktualisieren: jeiko-client-update %s'
    ['    Pour le migrer        : ./migrate_site.sh %s']='    Zum Migrieren: ./migrate_site.sh %s'
    ['    Continuer quand même et écraser sa configuration ? (o/n) : ']='    Trotzdem fortfahren und seine Konfiguration überschreiben? (j/n): '
    ['Installation annulée.']='Installation abgebrochen.'
    ['▶️  Nom de domaine (ex: monsite.fr) : ']='▶️  Domainname (z. B. meineseite.de): '
    ['▶️  Nom de la base PostgreSQL [%s_db] : ']='▶️  Name der PostgreSQL-Datenbank [%s_db]: '
    ['❌ Nom de base invalide.']='❌ Ungültiger Datenbankname.'
    ['▶️  Nom de l'\''utilisateur PostgreSQL [%s_user] : ']='▶️  Name des PostgreSQL-Benutzers [%s_user]: '
    ['❌ Nom d'\''utilisateur invalide.']='❌ Ungültiger Benutzername.'
    ['▶️  Mot de passe PostgreSQL (vide = généré automatiquement) : ']='▶️  PostgreSQL-Passwort (leer = automatisch erzeugt): '
    ['   🔑 Mot de passe généré (stocké dans la fiche du site, non affiché).']='   🔑 Passwort erzeugt (in der Website-Akte gespeichert, nicht angezeigt).'
    ['▶️  Identifiant du compte d'\''administration : ']='▶️  Benutzername des Verwaltungskontos: '
    ['❌ Nom requis.']='❌ Name erforderlich.'
    ['▶️  E-mail du compte d'\''administration : ']='▶️  E-Mail des Verwaltungskontos: '
    ['❌ Adresse e-mail valide requise.']='❌ Eine gültige E-Mail-Adresse ist erforderlich.'
    ['▶️  Mot de passe du compte d'\''administration : ']='▶️  Passwort des Verwaltungskontos: '
    ['❌ 12 caractères minimum.']='❌ Mindestens 12 Zeichen.'
    ['▶️  Activer HTTPS avec Let'\''s Encrypt ? (o/n) : ']='▶️  HTTPS mit Let'\''s Encrypt aktivieren? (j/n): '
    ['▶️  Utilisateur SSH d'\''administration [%s] : ']='▶️  SSH-Verwaltungsbenutzer [%s]: '
    ['🔑 Mot de passe SSH conservé (choix enregistré sur cette machine).']='🔑 SSH-Passwort beibehalten (Wahl auf diesem Rechner gespeichert).'
    ['    Tu peux tout de même enregistrer une clé — le mot de passe']='    Du kannst trotzdem einen Schlüssel hinterlegen — das Passwort'
    ['    restera actif dans tous les cas.']='    bleibt in jedem Fall aktiv.'
    ['▶️  Clé publique (vide = aucune) : ']='▶️  Öffentlicher Schlüssel (leer = keiner): '
    ['❌ Ce n'\''est pas une clé publique valide (attendu : « ssh-ed25519 AAAA… »).']='❌ Das ist kein gültiger öffentlicher Schlüssel (erwartet: „ssh-ed25519 AAAA…“).'
    ['   Laisse le champ vide si tu ne veux pas installer de clé.']='   Lass das Feld leer, wenn du keinen Schlüssel installieren willst.'
    ['   ✅ Clé retenue, elle sera installée pour %s.']='   ✅ Schlüssel übernommen, er wird für %s installiert.'
    ['🔐 Une clé SSH est déjà présente sur cette machine.']='🔐 Auf diesem Rechner ist bereits ein SSH-Schlüssel vorhanden.'
    ['    L'\''installeur peut désactiver l'\''authentification par mot de passe.']='    Das Installationsprogramm kann die Passwort-Anmeldung deaktivieren.'
    ['    C'\''est plus sûr, MAIS tu ne pourras plus te connecter qu'\''avec cette']='    Das ist sicherer, ABER du kannst dich dann nur noch mit diesem'
    ['    clé précise. Si elle appartient à ton hébergeur, ou si tu te']='    bestimmten Schlüssel anmelden. Gehört er deinem Hoster, oder meldest du'
    ['    connectes depuis un poste qui ne l'\''a pas, tu seras enfermé dehors.']='    dich von einem Rechner ohne ihn an, sperrst du dich aus.'
    ['▶️  Désactiver le mot de passe SSH ? (o/N) : ']='▶️  SSH-Passwort deaktivieren? (j/N): '
    ['   🔒 Mot de passe désactivé. Garde une session ouverte et vérifie']='   🔒 Passwort deaktiviert. Lass eine Sitzung offen und prüfe'
    ['      ta connexion par clé avant de la fermer.']='      deine Anmeldung per Schlüssel, bevor du sie schließt.'
    ['   ✅ Mot de passe conservé (fail2ban actif). Choix mémorisé pour']='   ✅ Passwort beibehalten (fail2ban aktiv). Wahl gespeichert für'
    ['      les prochaines installations sur cette machine.']='      künftige Installationen auf diesem Rechner.'
    ['⚠️  Aucune clé SSH publique trouvée sur cette machine.']='⚠️  Auf diesem Rechner wurde kein öffentlicher SSH-Schlüssel gefunden.'
    ['    Sans clé, l'\''accès par mot de passe doit rester ouvert, ce qui est']='    Ohne Schlüssel muss der Passwortzugang offen bleiben – das ist'
    ['    la faiblesse principale d'\''un serveur exposé.']='    die größte Schwachstelle eines öffentlich erreichbaren Servers.'
    ['    Colle ta clé publique (le contenu de ~/.ssh/id_ed25519.pub sur ton']='    Füge deinen öffentlichen Schlüssel ein (den Inhalt von ~/.ssh/id_ed25519.pub auf deinem'
    ['    poste), ou laisse vide — tu pourras l'\''ajouter plus tard avec']='    Rechner), oder lass es leer — du kannst ihn später mit'
    ['    ssh-copy-id, sans rien réinstaller.']='    ssh-copy-id hinzufügen, ohne etwas neu zu installieren.'
    ['    Veux-tu aussi désactiver l'\''authentification par mot de passe ?']='    Willst du auch die Passwort-Anmeldung deaktivieren?'
    ['    Tu ne pourras alors plus te connecter qu'\''avec cette clé, depuis']='    Du kannst dich dann nur noch mit diesem Schlüssel anmelden, von'
    ['    un poste qui la possède.']='    einem Rechner, der ihn besitzt.'
    ['   ✅ Clé ajoutée ET mot de passe conservé. Choix mémorisé.']='   ✅ Schlüssel hinzugefügt UND Passwort beibehalten. Wahl gespeichert.'
    ['   ⚠️  Aucune clé : mot de passe conservé, protégé par fail2ban.']='   ⚠️  Kein Schlüssel: Passwort beibehalten, durch fail2ban geschützt.'
    ['──────────── RÉCAPITULATIF ────────────']='──────────── ÜBERSICHT ────────────'
    ['🧩 Site              : %s']='🧩 Website           : %s'
    ['🌍 Domaine           : %s']='🌍 Domain            : %s'
    ['🗣️  Langue            : %s']='🗣️  Sprache           : %s'
    ['🛢️  Base PostgreSQL   : %s (rôle %s)']='🛢️  PostgreSQL-DB     : %s (Rolle %s)'
    ['👤 Administration    : %s <%s>']='👤 Verwaltung        : %s <%s>'
    ['🔒 Let'\''s Encrypt     : %s']='🔒 Let'\''s Encrypt     : %s'
    ['📁 Dossier projet    : %s']='📁 Projektordner     : %s'
    ['🧑 Utilisateur système: %s']='🧑 Systembenutzer    : %s'
    ['🔑 Admin SSH (ACL)   : %s']='🔑 SSH-Admin (ACL)   : %s'
    ['🔓 Mot de passe SSH  : CONSERVÉ (fail2ban actif)']='🔓 SSH-Passwort      : BEIBEHALTEN (fail2ban aktiv)'
    ['🔒 Mot de passe SSH  : DÉSACTIVÉ — connexion par clé uniquement']='🔒 SSH-Passwort      : DEAKTIVIERT — nur Anmeldung per Schlüssel'
    ['📡 Canal de MAJ      : %s']='📡 Update-Kanal      : %s'
    ['Confirmer l'\''installation ? (o/n) : ']='Installation bestätigen? (j/n): '
    ['🗃️  Fiche du site : %s (0600 root:root)']='🗃️  Website-Akte: %s (0600 root:root)'
    ['🚀 Installation en cours… (journal : %s)']='🚀 Installation läuft… (Protokoll: %s)'
    ['❌ Échec à l'\''étape %s. Journal complet : %s']='❌ Schritt %s fehlgeschlagen. Vollständiges Protokoll: %s'
    ['   Les étapes sont idempotentes : corrige la cause et relance ./install.sh.']='   Die Schritte sind idempotent: Behebe die Ursache und starte ./install.sh erneut.'
    ['✅ Installation terminée.']='✅ Installation abgeschlossen.'
    ['🌐 Site           : %s']='🌐 Website        : %s'
    ['🔐 Administration : %s']='🔐 Verwaltung     : %s'
    ['📄 Journal        : %s']='📄 Protokoll      : %s'
    ['Mise à jour du site :']='Website aktualisieren:'
    ['  · depuis l'\''interface  → Administration ▸ Mettre à jour JEIKO']='  · über die Oberfläche → Verwaltung ▸ JEIKO aktualisieren'
    ['  · depuis le serveur   → sudo jeiko-client-update %s']='  · vom Server aus     → sudo jeiko-client-update %s'
    ['  · vérifier sans agir  → sudo jeiko-client-update %s --check']='  · nur prüfen         → sudo jeiko-client-update %s --check'
    ['  · revenir en arrière  → sudo jeiko-client-update %s --rollback']='  · zurücksetzen       → sudo jeiko-client-update %s --rollback'
    ['Fiche du site : %s']='Website-Akte : %s'
    ['Sauvegardes   : %s']='Sicherungen  : %s'
    ['⚠️  Le site tourne en HTTP. La redirection HTTPS et HSTS sont désactivées dans']='⚠️  Die Website läuft über HTTP. HTTPS-Weiterleitung und HSTS sind deaktiviert in'
    ['    le .env (JEIKO_SSL="False") pour éviter la boucle de redirection.']='    der .env (JEIKO_SSL="False"), um eine Weiterleitungsschleife zu vermeiden.'
    ['    Pour activer TLS plus tard :']='    Um TLS später zu aktivieren:'
    ['    (le certificat est demandé, JEIKO_SSL passe à True et le site redémarre)']='    (das Zertifikat wird angefordert, JEIKO_SSL wird auf True gesetzt und die Website neu gestartet)'
    ['[00] Pré-vol & vérifications']='[00] Vorabprüfungen'
    ['[01] Durcissement de base (UFW, SSH, Fail2ban, sysctl, MAJ auto, temps)']='[01] Grundhärtung (UFW, SSH, Fail2ban, sysctl, Auto-Updates, Zeit)'
    ['[02] Compte système, dossiers et permissions']='[02] Systemkonto, Ordner und Berechtigungen'
    ['[03] Dépendances système']='[03] Systemabhängigkeiten'
    ['[04] PostgreSQL — service et durcissement']='[04] PostgreSQL — Dienst und Härtung'
    ['[05] Base de données et rôle applicatif']='[05] Datenbank und Anwendungsrolle'
    ['[06] Memcached']='[06] Memcached'
    ['[07] Environnement Python (venv)']='[07] Python-Umgebung (venv)'
    ['[08] Package JEIKO et mécanisme de mise à jour']='[08] JEIKO-Paket und Update-Mechanismus'
    ['[09] Configuration Django (.env, settings, urls)']='[09] Django-Konfiguration (.env, settings, urls)'
    ['[10] Service Gunicorn']='[10] Gunicorn-Dienst'
    ['[11] Nginx (vhost HTTP, prêt pour Certbot)']='[11] Nginx (HTTP-vhost, bereit für Certbot)'
    ['[12] TLS Let'\''s Encrypt et vhost HTTPS']='[12] Let'\''s-Encrypt-TLS und HTTPS-vhost'
    ['[13] Sauvegardes (base, médias, configuration)']='[13] Sicherungen (Datenbank, Medien, Konfiguration)'
    ['[14] Migrations, statiques, droits de mise à jour, contrôles']='[14] Migrationen, statische Dateien, Update-Rechte, Prüfungen'
    ['Finalisation terminée.']='Abschluss beendet.'
    ['🏠 Site de départ…']='🏠 Startseite…'
)

declare -gA JEIKO_T_IT=(
    ['▶️  Nom du site (ex: monsite) : ']='▶️  Nome del sito (es. miosito): '
    ['⚠️  Un site nommé '\''%s'\'' est déjà enregistré sur cette machine.']='⚠️  Su questa macchina è già registrato un sito chiamato '\''%s'\''.'
    ['    Pour le mettre à jour : jeiko-client-update %s']='    Per aggiornarlo: jeiko-client-update %s'
    ['    Pour le migrer        : ./migrate_site.sh %s']='    Per migrarlo: ./migrate_site.sh %s'
    ['    Continuer quand même et écraser sa configuration ? (o/n) : ']='    Continuare comunque e sovrascrivere la sua configurazione? (s/n): '
    ['Installation annulée.']='Installazione annullata.'
    ['▶️  Nom de domaine (ex: monsite.fr) : ']='▶️  Nome di dominio (es. miosito.it): '
    ['▶️  Nom de la base PostgreSQL [%s_db] : ']='▶️  Nome del database PostgreSQL [%s_db]: '
    ['❌ Nom de base invalide.']='❌ Nome del database non valido.'
    ['▶️  Nom de l'\''utilisateur PostgreSQL [%s_user] : ']='▶️  Nome dell'\''utente PostgreSQL [%s_user]: '
    ['❌ Nom d'\''utilisateur invalide.']='❌ Nome utente non valido.'
    ['▶️  Mot de passe PostgreSQL (vide = généré automatiquement) : ']='▶️  Password PostgreSQL (vuota = generata automaticamente): '
    ['   🔑 Mot de passe généré (stocké dans la fiche du site, non affiché).']='   🔑 Password generata (salvata nella scheda del sito, non mostrata).'
    ['▶️  Identifiant du compte d'\''administration : ']='▶️  Nome utente dell'\''account di amministrazione: '
    ['❌ Nom requis.']='❌ Nome obbligatorio.'
    ['▶️  E-mail du compte d'\''administration : ']='▶️  E-mail dell'\''account di amministrazione: '
    ['❌ Adresse e-mail valide requise.']='❌ È necessario un indirizzo e-mail valido.'
    ['▶️  Mot de passe du compte d'\''administration : ']='▶️  Password dell'\''account di amministrazione: '
    ['❌ 12 caractères minimum.']='❌ Minimo 12 caratteri.'
    ['▶️  Activer HTTPS avec Let'\''s Encrypt ? (o/n) : ']='▶️  Attivare HTTPS con Let'\''s Encrypt? (s/n): '
    ['▶️  Utilisateur SSH d'\''administration [%s] : ']='▶️  Utente SSH di amministrazione [%s]: '
    ['🔑 Mot de passe SSH conservé (choix enregistré sur cette machine).']='🔑 Password SSH mantenuta (scelta salvata su questa macchina).'
    ['    Tu peux tout de même enregistrer une clé — le mot de passe']='    Puoi comunque registrare una chiave — la password'
    ['    restera actif dans tous les cas.']='    resterà attiva in ogni caso.'
    ['▶️  Clé publique (vide = aucune) : ']='▶️  Chiave pubblica (vuota = nessuna): '
    ['❌ Ce n'\''est pas une clé publique valide (attendu : « ssh-ed25519 AAAA… »).']='❌ Non è una chiave pubblica valida (atteso: «ssh-ed25519 AAAA…»).'
    ['   Laisse le champ vide si tu ne veux pas installer de clé.']='   Lascia il campo vuoto se non vuoi installare una chiave.'
    ['   ✅ Clé retenue, elle sera installée pour %s.']='   ✅ Chiave accettata, verrà installata per %s.'
    ['🔐 Une clé SSH est déjà présente sur cette machine.']='🔐 Su questa macchina è già presente una chiave SSH.'
    ['    L'\''installeur peut désactiver l'\''authentification par mot de passe.']='    Il programma di installazione può disattivare l'\''autenticazione con password.'
    ['    C'\''est plus sûr, MAIS tu ne pourras plus te connecter qu'\''avec cette']='    È più sicuro, MA potrai connetterti solo con questa'
    ['    clé précise. Si elle appartient à ton hébergeur, ou si tu te']='    chiave precisa. Se appartiene al tuo hosting, o se ti'
    ['    connectes depuis un poste qui ne l'\''a pas, tu seras enfermé dehors.']='    connetti da un computer che non la possiede, resterai chiuso fuori.'
    ['▶️  Désactiver le mot de passe SSH ? (o/N) : ']='▶️  Disattivare la password SSH? (s/N): '
    ['   🔒 Mot de passe désactivé. Garde une session ouverte et vérifie']='   🔒 Password disattivata. Tieni aperta una sessione e verifica'
    ['      ta connexion par clé avant de la fermer.']='      la connessione con chiave prima di chiuderla.'
    ['   ✅ Mot de passe conservé (fail2ban actif). Choix mémorisé pour']='   ✅ Password mantenuta (fail2ban attivo). Scelta memorizzata per'
    ['      les prochaines installations sur cette machine.']='      le prossime installazioni su questa macchina.'
    ['⚠️  Aucune clé SSH publique trouvée sur cette machine.']='⚠️  Nessuna chiave SSH pubblica trovata su questa macchina.'
    ['    Sans clé, l'\''accès par mot de passe doit rester ouvert, ce qui est']='    Senza chiave, l'\''accesso con password deve restare aperto, il che è'
    ['    la faiblesse principale d'\''un serveur exposé.']='    il principale punto debole di un server esposto.'
    ['    Colle ta clé publique (le contenu de ~/.ssh/id_ed25519.pub sur ton']='    Incolla la tua chiave pubblica (il contenuto di ~/.ssh/id_ed25519.pub sul tuo'
    ['    poste), ou laisse vide — tu pourras l'\''ajouter plus tard avec']='    computer), o lascia vuoto — potrai aggiungerla più tardi con'
    ['    ssh-copy-id, sans rien réinstaller.']='    ssh-copy-id, senza reinstallare nulla.'
    ['    Veux-tu aussi désactiver l'\''authentification par mot de passe ?']='    Vuoi disattivare anche l'\''autenticazione con password?'
    ['    Tu ne pourras alors plus te connecter qu'\''avec cette clé, depuis']='    Potrai quindi connetterti solo con questa chiave, da'
    ['    un poste qui la possède.']='    un computer che la possiede.'
    ['   ✅ Clé ajoutée ET mot de passe conservé. Choix mémorisé.']='   ✅ Chiave aggiunta E password mantenuta. Scelta memorizzata.'
    ['   ⚠️  Aucune clé : mot de passe conservé, protégé par fail2ban.']='   ⚠️  Nessuna chiave: password mantenuta, protetta da fail2ban.'
    ['──────────── RÉCAPITULATIF ────────────']='──────────── RIEPILOGO ────────────'
    ['🧩 Site              : %s']='🧩 Sito              : %s'
    ['🌍 Domaine           : %s']='🌍 Dominio           : %s'
    ['🗣️  Langue            : %s']='🗣️  Lingua            : %s'
    ['🛢️  Base PostgreSQL   : %s (rôle %s)']='🛢️  Database PostgreSQL: %s (ruolo %s)'
    ['👤 Administration    : %s <%s>']='👤 Amministrazione   : %s <%s>'
    ['🔒 Let'\''s Encrypt     : %s']='🔒 Let'\''s Encrypt     : %s'
    ['📁 Dossier projet    : %s']='📁 Cartella progetto : %s'
    ['🧑 Utilisateur système: %s']='🧑 Utente di sistema : %s'
    ['🔑 Admin SSH (ACL)   : %s']='🔑 Admin SSH (ACL)   : %s'
    ['🔓 Mot de passe SSH  : CONSERVÉ (fail2ban actif)']='🔓 Password SSH      : MANTENUTA (fail2ban attivo)'
    ['🔒 Mot de passe SSH  : DÉSACTIVÉ — connexion par clé uniquement']='🔒 Password SSH      : DISATTIVATA — solo accesso con chiave'
    ['📡 Canal de MAJ      : %s']='📡 Canale aggiornamenti: %s'
    ['Confirmer l'\''installation ? (o/n) : ']='Confermare l'\''installazione? (s/n): '
    ['🗃️  Fiche du site : %s (0600 root:root)']='🗃️  Scheda del sito: %s (0600 root:root)'
    ['🚀 Installation en cours… (journal : %s)']='🚀 Installazione in corso… (registro: %s)'
    ['❌ Échec à l'\''étape %s. Journal complet : %s']='❌ Errore al passo %s. Registro completo: %s'
    ['   Les étapes sont idempotentes : corrige la cause et relance ./install.sh.']='   I passi sono idempotenti: correggi la causa e rilancia ./install.sh.'
    ['✅ Installation terminée.']='✅ Installazione completata.'
    ['🌐 Site           : %s']='🌐 Sito           : %s'
    ['🔐 Administration : %s']='🔐 Amministrazione: %s'
    ['📄 Journal        : %s']='📄 Registro       : %s'
    ['Mise à jour du site :']='Aggiornare il sito:'
    ['  · depuis l'\''interface  → Administration ▸ Mettre à jour JEIKO']='  · dall'\''interfaccia   → Amministrazione ▸ Aggiorna JEIKO'
    ['  · depuis le serveur   → sudo jeiko-client-update %s']='  · dal server         → sudo jeiko-client-update %s'
    ['  · vérifier sans agir  → sudo jeiko-client-update %s --check']='  · verificare senza agire → sudo jeiko-client-update %s --check'
    ['  · revenir en arrière  → sudo jeiko-client-update %s --rollback']='  · tornare indietro   → sudo jeiko-client-update %s --rollback'
    ['Fiche du site : %s']='Scheda del sito: %s'
    ['Sauvegardes   : %s']='Backup       : %s'
    ['⚠️  Le site tourne en HTTP. La redirection HTTPS et HSTS sont désactivées dans']='⚠️  Il sito funziona in HTTP. Il reindirizzamento HTTPS e HSTS sono disattivati nel'
    ['    le .env (JEIKO_SSL="False") pour éviter la boucle de redirection.']='    .env (JEIKO_SSL="False") per evitare il ciclo di reindirizzamento.'
    ['    Pour activer TLS plus tard :']='    Per attivare TLS più tardi:'
    ['    (le certificat est demandé, JEIKO_SSL passe à True et le site redémarre)']='    (viene richiesto il certificato, JEIKO_SSL passa a True e il sito si riavvia)'
    ['[00] Pré-vol & vérifications']='[00] Controlli preliminari'
    ['[01] Durcissement de base (UFW, SSH, Fail2ban, sysctl, MAJ auto, temps)']='[01] Hardening di base (UFW, SSH, Fail2ban, sysctl, aggiornamenti, ora)'
    ['[02] Compte système, dossiers et permissions']='[02] Account di sistema, cartelle e permessi'
    ['[03] Dépendances système']='[03] Dipendenze di sistema'
    ['[04] PostgreSQL — service et durcissement']='[04] PostgreSQL — servizio e hardening'
    ['[05] Base de données et rôle applicatif']='[05] Database e ruolo dell'\''applicazione'
    ['[06] Memcached']='[06] Memcached'
    ['[07] Environnement Python (venv)']='[07] Ambiente Python (venv)'
    ['[08] Package JEIKO et mécanisme de mise à jour']='[08] Pacchetto JEIKO e meccanismo di aggiornamento'
    ['[09] Configuration Django (.env, settings, urls)']='[09] Configurazione Django (.env, settings, urls)'
    ['[10] Service Gunicorn']='[10] Servizio Gunicorn'
    ['[11] Nginx (vhost HTTP, prêt pour Certbot)']='[11] Nginx (vhost HTTP, pronto per Certbot)'
    ['[12] TLS Let'\''s Encrypt et vhost HTTPS']='[12] TLS Let'\''s Encrypt e vhost HTTPS'
    ['[13] Sauvegardes (base, médias, configuration)']='[13] Backup (database, media, configurazione)'
    ['[14] Migrations, statiques, droits de mise à jour, contrôles']='[14] Migrazioni, file statici, diritti di aggiornamento, controlli'
    ['Finalisation terminée.']='Finalizzazione completata.'
    ['🏠 Site de départ…']='🏠 Sito di partenza…'
)
fi

# Le LANGUAGE_CODE de Django pour une langue proposée à l'installation (I-08).
# Le français garde « fr-fr », la valeur historique des sites existants.
jeiko_code_de_langue() {
    case "${1:-fr}" in
        fr) printf 'fr-fr' ;;
        en|es|de|it) printf '%s' "$1" ;;
        *) printf 'fr-fr' ;;
    esac
}

# Un domaine « apex » (exemple.fr) mérite un vhost www ; un sous-domaine non.
jeiko_is_apex() {
    [[ "${1:-}" =~ ^[^.]+\.[^.]+$ ]]
}

# Les vhosts ACTIFS qui déclarent déjà le nom « $1 » (un nom exact : un autre
# sous-domaine du même domaine n'en est pas un), sauf le fichier « $2 », celui
# du site lui-même. Un par ligne. nginx ne distingue pas la casse : la
# comparaison non plus. Lit sites-enabled ET conf.d, où un vhost peut aussi
# vivre (NGX-3, 09/10/2026).
jeiko_vhosts_du_nom() {
    local nom="${1,,}" exclu="${2:-}" base="${JEIKO_NGINX_DIR:-/etc/nginx}" f motif
    motif="${nom//./\\.}"
    for f in "$base"/sites-enabled/* "$base"/conf.d/*.conf; do
        [[ -e "$f" ]] || continue
        [[ -n "$exclu" && "$(readlink -f "$f")" == "$(readlink -f "$exclu" 2>/dev/null)" ]] && continue
        if grep -qiE "^[[:space:]]*server_name[[:space:]]([^;#]*[[:space:]])?${motif}([[:space:]]|;)" "$f" 2>/dev/null; then
            printf '%s\n' "$f"
        fi
    done
}

# --------------------------------------------------------------------------- #
# Registre des sites
#
# /etc/jeiko/sites/<site>.conf (root:root 0600) est la source de vérité unique
# pour l'updater, les backups et les scripts de maintenance. Il remplace le
# .env.<site> qui traînait dans le dossier de l'installeur en 0644.
# --------------------------------------------------------------------------- #
jeiko_site_conf_path() { printf '%s/%s.conf' "$JEIKO_SITES_DIR" "$1"; }

# Le dossier des verrous, root seul. Sur /run (tmpfs, effacé au redémarrage) :
# à (re)créer avant toute prise de verrou. Appelé par jeiko_init_dirs ET,
# directement, par les scripts qui verrouillent sans passer par jeiko_init_dirs
# (jeiko-server-update, jeiko-client-update).
jeiko_dossier_verrous() {
    install -d -m 0700 -o root -g root "$JEIKO_LOCK_DIR"
}

jeiko_init_dirs() {
    jeiko_require_root
    jeiko_dossier_verrous
    install -d -m 0755 -o root -g root "$JEIKO_ETC_DIR"
    install -d -m 0700 -o root -g root "$JEIKO_SITES_DIR"

    # 0755 et non 0750 : chaque site doit pouvoir TRAVERSER cette racine pour
    # lire son propre /var/lib/jeiko/<site>/update.state — c'est ce qui alimente
    # la page de mise à jour de son administration. Le cloisonnement est porté
    # par les sous-dossiers, en 0750 root:<compte du site> ; la racine ne
    # contient rien d'autre que des noms de sites.
    # 0750 root:root ici rendait l'état illisible pour TOUS les sites, et
    # « install -d -m » réapplique le mode même à un dossier existant : chaque
    # migrate_site.sh recassait donc les sites déjà en place.
    install -d -m 0755 -o root -g root "$JEIKO_LIB_DIR"
    install -d -m 0755 -o root -g root "$JEIKO_LOG_DIR"
    install -d -m 0700 -o root -g root "$JEIKO_BACKUP_DIR"
}

# Écrit (ou réécrit) la fiche d'un site. Toutes les valeurs sont échappées.
jeiko_write_site_conf() {
    jeiko_require_root
    local site="$1"
    jeiko_validate_site_name "$site" || return 1

    local conf; conf="$(jeiko_site_conf_path "$site")"
    local tmp;  tmp="$(mktemp "${conf}.XXXXXX")"
    chmod 0600 "$tmp"

    {
        echo "# Fiche du site '$site' — générée par l'installeur JEIKO."
        echo "# Source de vérité pour jeiko-update et les sauvegardes. Ne pas éditer à la main"
        echo "# sans relancer 'nginx -t' et 'systemctl restart gunicorn-$site'."
        echo "SITE_NAME=$(jeiko_shell_quote "$site")"
        echo "DOMAIN_NAME=$(jeiko_shell_quote "${DOMAIN_NAME:-}")"
        echo "BASE_DIR=$(jeiko_shell_quote "${BASE_DIR:-}")"
        echo "PROJECT_DIR=$(jeiko_shell_quote "${PROJECT_DIR:-${BASE_DIR:-}/$site}")"
        echo "SITE_USER=$(jeiko_shell_quote "${SITE_USER:-jeiko-$site}")"
        echo "VENV_DIR=$(jeiko_shell_quote "${VENV_DIR:-${BASE_DIR:-}/$site/venv}")"
        echo "GUNICORN_SERVICE=$(jeiko_shell_quote "${GUNICORN_SERVICE:-gunicorn-$site}")"
        echo "DB_NAME=$(jeiko_shell_quote "${DB_NAME:-}")"
        echo "DB_USER=$(jeiko_shell_quote "${DB_USER:-}")"
        echo "DB_PASS=$(jeiko_shell_quote "${DB_PASS:-}")"
        echo "ENABLE_SSL=$(jeiko_shell_quote "${ENABLE_SSL:-n}")"
        echo "ADMIN_SSH_USER=$(jeiko_shell_quote "${ADMIN_SSH_USER:-}")"
        # Canal de distribution : d'où proviennent les mises à jour.
        echo "JEIKO_CHANNEL_URL=$(jeiko_shell_quote "${JEIKO_CHANNEL_URL:-$JEIKO_DEFAULT_CHANNEL_URL}")"
        echo "INSTALLED_AT=$(jeiko_shell_quote "${INSTALLED_AT:-$(date -Is)}")"
        echo ""
        echo "# Copie hors-site des sauvegardes. Vide = désactivée : les"
        echo "# sauvegardes restent alors sur la même machine que le site, et"
        echo "# disparaissent avec lui."
        echo "#   rclone:mon-remote:/jeiko    ou    rsync:user@hote:/sauvegardes"
        echo "JEIKO_OFFSITE_TARGET=$(jeiko_shell_quote "${JEIKO_OFFSITE_TARGET:-}")"
        echo "# Fichier contenant la phrase secrète GPG (root:root 0600). Sans"
        echo "# elle, la base part en clair hors de la machine."
        echo "JEIKO_OFFSITE_PASSPHRASE_FILE=$(jeiko_shell_quote "${JEIKO_OFFSITE_PASSPHRASE_FILE:-}")"
    } >"$tmp"

    mv -f "$tmp" "$conf"
    chown root:root "$conf"
    chmod 0600 "$conf"
}

# Charge une fiche de site dans l'environnement courant.
jeiko_load_site() {
    local site="$1"
    jeiko_validate_site_name "$site" || return 1
    local conf; conf="$(jeiko_site_conf_path "$site")"
    [[ -r "$conf" ]] || {
        jeiko_err "Fiche de site introuvable : $conf"
        jeiko_err "Site jamais installé, ou pas encore migré (voir migrate_site.sh)."
        return 1
    }
    # shellcheck disable=SC1090
    source "$conf"
    : "${PROJECT_DIR:?PROJECT_DIR absent de $conf}"
    : "${SITE_USER:?SITE_USER absent de $conf}"
    : "${VENV_DIR:?VENV_DIR absent de $conf}"
    return 0
}

jeiko_list_sites() {
    [[ -d "$JEIKO_SITES_DIR" ]] || return 0
    find "$JEIKO_SITES_DIR" -maxdepth 1 -name '*.conf' -printf '%f\n' 2>/dev/null \
        | sed 's/\.conf$//' | sort
}

# Quoting sûr pour réinjection dans un fichier sourcé par bash.
#
# Le motif de remplacement passe par des variables plutôt que par une cascade
# d'échappements littéraux : écrite en une seule expression, la substitution
# produisait une chaîne mal formée dès que la valeur contenait une apostrophe —
# un mot de passe PostgreSQL avec une apostrophe rendait la fiche du site
# illisible, donc le site immettable à jour.
jeiko_shell_quote() {
    local s="${1-}"
    local quote="'"
    local escaped="'\\''"
    printf "'%s'" "${s//$quote/$escaped}"
}

# --------------------------------------------------------------------------- #
# Exécution sous l'identité du site
#
# On passe par `runuser -u <user> -- cmd args…` : la commande est exécutée par
# execvp, sans shell intermédiaire. L'ancienne implémentation construisait une
# chaîne injectée dans `bash -s <<EOF`, ce qui exposait chaque variable
# (chemins, URL, nom de site) à une interprétation shell.
# --------------------------------------------------------------------------- #
jeiko_as_site() {
    local user="$1"; shift
    [[ $# -gt 0 ]] || { jeiko_err "jeiko_as_site: aucune commande fournie."; return 2; }
    # Depuis `/`, jamais depuis le dossier courant de l'exploitant (28/09/2026).
    # `python -` et `python -c` placent le dossier courant en TÊTE de sys.path :
    # lancé depuis /var/www/jeiko-installer, où traînait un dossier `jeiko/`
    # d'une ancienne archive, `import jeiko` trouvait ce dossier au lieu du
    # package installé. Le réalignement de settings.py était sauté, `check`
    # échouait et la mise à jour 3.5.0 repartait en arrière sur tous les sites.
    # Tous les chemins transmis ici sont absolus : le dossier courant ne sert
    # à rien, il ne peut que nuire.
    #
    # Deux protections, posées DANS le sous-shell pour ne rien changer chez
    # l'appelant (rapport du 05/10) :
    #  · on ferme les descripteurs de verrou (6,7,8,9) avant de redescendre vers
    #    le compte du site — tenu pour compromis. runuser les lui laisserait
    #    hériter : une prise en écriture sur les verrous de /run et sur un
    #    verrou root ouvert (P1-b). Fermer un descripteur non ouvert est sans
    #    effet, donc inoffensif dans les contextes qui n'ont pas tous ces fd.
    #  · setsid détache du terminal de contrôle de l'exploitant quand l'outil
    #    est lancé en SSH : sans ça, le code du site pourrait y réinjecter des
    #    frappes (ioctl TIOCSTI, CVE-2016-2779 ; P1-f). `-w` attend la fin et
    #    rend le code de sortie de la commande ; l'entrée standard (un éventuel
    #    tube, pour jeiko_site_ecrire) est conservée.
    local detache=()
    command -v setsid >/dev/null 2>&1 && detache=(setsid -w)
    if command -v runuser >/dev/null 2>&1; then
        ( exec 6>&- 7>&- 8>&- 9>&-; cd / && "${detache[@]}" runuser -u "$user" -- "$@" )
    else
        ( exec 6>&- 7>&- 8>&- 9>&-; cd / && "${detache[@]}" sudo -n -u "$user" -- "$@" )
    fi
}

# --------------------------------------------------------------------------- #
# Fichiers de l'arborescence d'un site : jamais touchés par root
#
# Le compte du site possède son dossier de projet : il peut y remplacer à tout
# moment un fichier par un lien symbolique. Root qui lit, écrit, `chown` ou
# `chmod` un chemin de cette arborescence suit le lien — vers /etc/shadow, par
# exemple (audit du 04/10/2026, I-01 et I-04). La règle est donc : ce qui se
# trouve chez le site se lit et s'écrit SOUS SON COMPTE. Un lien piégé ne mène
# alors qu'à ce que le site pouvait déjà atteindre.
#
# Le seul geste root qui reste est `chown -h`, qui agit sur le lien lui-même et
# jamais sur sa cible (il sert à réparer un fichier qui aurait changé de
# propriétaire).
# --------------------------------------------------------------------------- #

# --------------------------------------------------------------------------- #
# Groupe du site (IG-01, 11/10/2026)
#
# Chaque site a SON groupe — celui de son compte, créé avec lui par useradd
# (jeiko-<site>). Ses fichiers, son socket gunicorn et ses journaux sont à ce
# groupe ; nginx (www-data) en est membre, et lui seul. Avant, tous les sites
# partageaient www-data : un compte de site lisait les médias privés et les
# journaux des voisins, et joignait directement leur gunicorn.
#
# Un site migré dont le compte n'a pas de groupe à son nom (ou EST www-data)
# garde www-data : il n'est pas cloisonné, et on le dit.
# --------------------------------------------------------------------------- #
jeiko_groupe_du_site() {
    local user="$1"
    if [[ "$user" != www-data ]] && getent group "$user" >/dev/null 2>&1; then
        printf '%s' "$user"
    else
        printf 'www-data'
    fi
}

# Vrai si un worker nginx en service n'a pas encore <groupe> : ses groupes se
# lisent dans /proc, au démarrage du worker — pas dans /etc/group. Une
# appartenance déjà déclarée ne prouve donc rien (vérification du 11/10,
# C-01 : nginx -t en échec après usermod, et la passe suivante ne
# rechargeait plus).
# Usage : jeiko_nginx_sans_le_groupe <groupe>
jeiko_nginx_sans_le_groupe() {
    local gid pid
    gid="$(getent group "$1" | cut -d: -f3)" || true   # groupe absent : sous set -e, sortie muette
    [[ -n "$gid" ]] || return 1
    for pid in $(pgrep -u www-data -x nginx 2>/dev/null); do
        if ! awk '$1 == "Groups:" { for (i = 2; i <= NF; i++) if ($i == g) trouve = 1 } END { exit !trouve }' \
                 g="$gid" "/proc/$pid/status" 2>/dev/null; then
            return 0
        fi
    done
    return 1
}

# nginx entre dans le groupe du site, le site sort de www-data. nginx est
# rechargé tant qu'un de ses workers n'a pas le groupe : il doit lire les
# fichiers du site AVANT qu'ils changent de groupe — d'où l'appel, en
# convergence, avant la réapplication des droits, et au début de
# jeiko_fix_perms (restauration, retour arrière : tout chemin qui pose le
# groupe du site sur des fichiers).
# Usage : jeiko_isoler_le_site <compte>
jeiko_isoler_le_site() {
    local user="$1" groupe
    groupe="$(jeiko_groupe_du_site "$user")"
    if [[ "$groupe" == www-data ]]; then
        jeiko_warn "Le compte $user n'a pas de groupe à son nom : site NON cloisonné (groupe www-data)."
        return 0
    fi
    if ! id -nG www-data | tr ' ' '\n' | grep -qx "$groupe"; then
        usermod -aG "$groupe" www-data || { jeiko_err "nginx (www-data) n'a pas pu entrer dans le groupe $groupe."; return 1; }
        jeiko_log "🔒 nginx membre du groupe $groupe."
    fi
    if systemctl is-active --quiet nginx && jeiko_nginx_sans_le_groupe "$groupe"; then
        nginx -t >/dev/null 2>&1 && systemctl reload nginx \
            || { jeiko_err "nginx non rechargé : il ne lirait pas les fichiers du groupe $groupe."; return 1; }
    fi
    if id -nG "$user" | tr ' ' '\n' | grep -qx www-data; then
        gpasswd -d "$user" www-data >/dev/null || { jeiko_err "$user n'a pas pu sortir du groupe www-data."; return 1; }
        jeiko_log "🔒 $user retiré du groupe www-data partagé."
    fi
}

# Un memcached PAR SITE, sous son compte, sur un socket Unix en 0600 (IG-01).
# Le memcached commun (127.0.0.1:11211) n'a pas d'authentification : tout
# processus local y lisait, écrivait ou vidait le cache — compteurs anti-abus
# compris — de n'importe quel site. Avec « -s », memcached n'écoute plus le
# réseau. Le commun reste en service pour les sites dont le paquet ne lit pas
# encore JEIKO_MEMCACHED.
# Usage : jeiko_memcached_du_site <site> <compte>
jeiko_memcached_socket() { printf '/run/jeiko-memcached-%s/memcached.sock' "$1"; }

jeiko_memcached_du_site() {
    local site="$1" user="$2" unite="${JEIKO_SYSTEMD_DIR:-/etc/systemd/system}/jeiko-memcached-$1.service" groupe
    groupe="$(jeiko_groupe_du_site "$user")"
    command -v memcached >/dev/null 2>&1 || { jeiko_err "memcached absent (apt install memcached)."; return 1; }
    cat >"$unite.tmp" <<EOF
# Généré par l'outillage JEIKO (jeiko_memcached_du_site) — ne pas éditer.
# Cache du site « $site », sous son compte, joignable par lui seul.
[Unit]
Description=Memcached du site $site

[Service]
User=$user
Group=$groupe
RuntimeDirectory=jeiko-memcached-$site
RuntimeDirectoryMode=0700
ExecStart=$(command -v memcached) -s $(jeiko_memcached_socket "$site") -a 0600 -m 64 -c 1024
Restart=always
RestartSec=2s
NoNewPrivileges=yes
PrivateTmp=yes
ProtectSystem=strict
ProtectHome=yes

[Install]
WantedBy=multi-user.target
EOF
    chmod 0644 "$unite.tmp"
    if ! cmp -s "$unite.tmp" "$unite" 2>/dev/null; then
        mv -f "$unite.tmp" "$unite"
        systemctl daemon-reload
        systemctl enable "jeiko-memcached-$site.service" >/dev/null 2>&1 || true
        systemctl restart "jeiko-memcached-$site.service" \
            || { jeiko_err "jeiko-memcached-$site ne démarre pas."; return 1; }
    else
        rm -f "$unite.tmp"
        systemctl enable --now "jeiko-memcached-$site.service" >/dev/null 2>&1 \
            || { jeiko_err "jeiko-memcached-$site ne démarre pas."; return 1; }
    fi
}

# Rend au site la propriété de son dossier de configuration (<projet>/<site>,
# .env compris) — le seul `chown` que root fait encore sur un chemin du site.
#
# `chown -h <projet>/<site>/.env` ne protégeait que le DERNIER élément du
# chemin : un dossier <site> remplacé par un lien était suivi, et le .env
# atteint au bout changeait de propriétaire. On part donc de <projet>, que le
# site ne peut pas remplacer (son parent appartient à root), et `chown -R`
# sans -L ni -H ne traverse aucun lien rencontré : il agit sur le lien
# lui-même, jamais sur sa cible.
# Usage : jeiko_reparer_proprietaire <compte> <projet> <site>
jeiko_reparer_proprietaire() {
    local user="$1" projet="$2" site="$3"
    if [[ -L "$projet/$site" ]]; then
        jeiko_err "$projet/$site est un lien symbolique : refusé. Un site JEIKO n'en pose jamais."
        return 1
    fi
    [[ -d "$projet/$site" ]] || return 0
    chown -Rh "$user":"$(jeiko_groupe_du_site "$user")" -- "$projet/$site"
}

# Remplace le contenu de <chemin> par l'entrée standard, sous le compte du site.
# Écriture dans un fichier voisin puis renommage : jamais de fichier à moitié
# écrit, et un fichier existant appartenant à quelqu'un d'autre est remplacé
# (le dossier appartient au site) au lieu de faire échouer l'écriture.
# Le fichier provisoire naît en 0600 (umask 077) et ne prend son mode qu'une
# fois écrit : un .env ne passe jamais, même un instant, par un mode lisible
# par d'autres.
# Usage : <contenu> | jeiko_site_ecrire <compte> <chemin> <mode>
jeiko_site_ecrire() {
    local user="$1" chemin="$2" mode="$3"
    jeiko_as_site "$user" sh -c '
        umask 077
        t="$1.jeiko-tmp.$$"
        if cat >"$t" && chmod "$2" "$t" && mv -f "$t" "$1"; then exit 0; fi
        rm -f "$t"; exit 1
    ' sh "$chemin" "$mode"
}

# Ajoute une ligne à <chemin>, sous le compte du site. S'il n'existait pas, il
# naît en 0600, comme ci-dessus.
# Usage : jeiko_site_ajouter <compte> <chemin> <ligne>
jeiko_site_ajouter() {
    printf '%s\n' "$3" | jeiko_as_site "$1" sh -c 'umask 077; cat >>"$1"' sh "$2"
}

# Vrai si <chemin> contient une affectation « NOM= », lu sous le compte du site.
# Usage : jeiko_site_a_la_cle <compte> <chemin> <NOM>
jeiko_site_a_la_cle() {
    jeiko_as_site "$1" grep -qE "^[[:space:]]*$3[[:space:]]*=" -- "$2" 2>/dev/null
}

# --------------------------------------------------------------------------- #
# Droits sudo d'un site — un seul exemplaire
#
# Ce fichier était écrit à DEUX endroits (14_finalize.sh à l'installation,
# jeiko-server-update à chaque convergence) : une règle ajoutée à l'un et pas à
# l'autre disparaissait à la convergence suivante, ou manquait aux installations
# neuves. Il est désormais écrit ici seulement.
#
# L'application ne peut que DÉCLENCHER des unités systemd dont l'ExecStart est
# un binaire root:root hors de son arborescence, et redémarrer son propre
# service. Rien d'autre, à l'argument près : sudo compare la ligne entière.
#   · jeiko-update@<site>         — mise à jour du paquet de CE site ;
#   · jeiko-maj-serveur@<site>    — mise à jour du serveur demandée par ce site
#                                   (n'agit que si un installeur plus récent
#                                   est publié : voir jeiko-maj) ;
#   · restart de son gunicorn.
#
# Ni « !syslog » (il effaçait la trace sudo du compte le plus exposé du
# système), ni « reload nginx » (nginx est partagé par tous les sites).
# Usage : jeiko_ecrire_sudoers <site> <compte> <service gunicorn>
# --------------------------------------------------------------------------- #
jeiko_ecrire_sudoers() {
    jeiko_require_root
    local site="$1" user="$2" service="$3"
    jeiko_validate_site_name "$site" || return 1
    jeiko_require_systemctl_path || return 1

    local cible="/etc/sudoers.d/jeiko-$site" tmp
    tmp="$(mktemp)"
    cat >"$tmp" <<EOF
# Droits accordés à l'application JEIKO du site « $site ».
# Généré par l'outillage JEIKO (jeiko_ecrire_sudoers) — ne pas éditer à la main.
#
# L'application ne peut que déclencher des unités dont l'ExecStart est un
# binaire root:root hors de son arborescence, et redémarrer son propre service.

Defaults:$user !requiretty

$user ALL=(root) NOPASSWD: $JEIKO_SYSTEMCTL start --no-block jeiko-update@$site.service
$user ALL=(root) NOPASSWD: $JEIKO_SYSTEMCTL start --no-block jeiko-maj-serveur@$site.service
$user ALL=(root) NOPASSWD: $JEIKO_SYSTEMCTL restart $service.service
EOF
    # visudo AVANT la mise en place : un sudoers invalide rend sudo inutilisable
    # sur toute la machine, y compris pour le réparer.
    if ! visudo -cqf "$tmp"; then
        rm -f "$tmp"
        jeiko_err "sudoers généré invalide pour « $site », non installé."
        return 1
    fi
    install -m 0440 -o root -g root "$tmp" "$cible"
    rm -f "$tmp"
    return 0
}

# La mise à jour est-elle déclenchable depuis l'application ?
#
# `sudo -l <commande>` répond si la règle sudoers autorise CETTE commande, à
# l'argument près, sans rien exécuter. Le contrôle précédent démarrait une vraie
# mise à jour puis l'arrêtait au bout de 2 s : si une version plus récente du
# paquet était publiée, l'arrêt pouvait tomber en plein `pip install` et laisser
# le venv à moitié installé (audit du 04/10/2026, I-05).
# Usage : jeiko_verifier_declenchement <site> <compte> [préfixe d'unité]
#         (préfixe : jeiko-update par défaut, ou jeiko-maj-serveur)
jeiko_verifier_declenchement() {
    jeiko_as_site "$2" sudo -n -l "$JEIKO_SYSTEMCTL" start --no-block "${3:-jeiko-update}@$1.service" \
        >/dev/null 2>&1
}

# Lance manage.py sous l'identité du site, avec le python du venv.
# Usage : jeiko_manage <project_dir> <venv_dir> <site_user> migrate --noinput
jeiko_manage() {
    local project_dir="$1" venv_dir="$2" site_user="$3"; shift 3
    local py="$venv_dir/bin/python"
    [[ -x "$py" ]] || { jeiko_err "Python du venv introuvable : $py"; return 1; }
    # PYTHONNOUSERSITE empêche un ~/.local/lib parasite de masquer le venv.
    jeiko_as_site "$site_user" env \
        PYTHONNOUSERSITE=1 \
        PYTHONUNBUFFERED=1 \
        HOME="$project_dir" \
        "$py" "$project_dir/manage.py" "$@"
}

# --------------------------------------------------------------------------- #
# Permissions — implémentation unique
# --------------------------------------------------------------------------- #

# Applique le modèle canonique à l'arborescence d'un site.
# Le venv est traité à part : ses binaires doivent rester exécutables.
jeiko_fix_perms() {
    jeiko_require_root
    local project_dir="$1" site_user="$2" site_name="$3"
    local venv_dir="${4:-$project_dir/venv}"

    [[ -d "$project_dir" ]] || { jeiko_err "Dossier projet introuvable : $project_dir"; return 1; }

    jeiko_log "🔐 Application des permissions sur $project_dir…"

    # Le groupe du site va être posé : nginx doit en être membre — et ses
    # workers l'avoir — AVANT. Sans cela, une restauration ou un retour
    # arrière lancés entre le dépôt d'un outillage et la convergence
    # passaient les fichiers à un groupe que nginx ne lisait pas (C-02).
    jeiko_isoler_le_site "$site_user" || return 1

    local env_path="$project_dir/$site_name/.env"

    # ─────────────────────────────────────────────────────────────────────────
    # L'arborescence appartient au site, qui peut y poser un lien symbolique à
    # tout instant. Deux gestes seulement restent en root, et aucun ne suit un
    # lien : `chown -Rh` (agit sur le lien, jamais sur sa cible). TOUT le reste
    # — création des dossiers, chmod — se fait SOUS LE COMPTE DU SITE.
    #
    # C'était la dernière course de l'audit du 04/10 laissée ouverte (I-06,
    # « limite connue ») : les `find … | xargs chmod` tournaient en root, et un
    # lien substitué entre le parcours et le chmod faisait poser un mode sur un
    # fichier root. On la tenait pour bénigne (« panne, pas élévation ») — à
    # tort : le site peut rejouer cette passe à volonté (jeiko-update@ sans
    # limite de fréquence), et un 0640 posé sur le .env d'un VOISIN le rend
    # lisible par www-data, groupe que tous les gunicorn portent — fuite de
    # secrets entre sites (rapport du 05/10, P1-c). Sous son compte, le site ne
    # pose que des modes qu'il a déjà le droit de poser, sur ce qu'il possède :
    # un lien substitué ne mène qu'à ce qu'il atteignait déjà.
    #
    # Le bit setgid des dossiers (2750) : le site l'applique car c'est son
    # propre groupe (IG-01). D'abord le propriétaire et le groupe (root, sûr),
    # ENSUITE les modes (site), pour que le groupe soit bien le sien au moment
    # où le setgid est posé.
    # ─────────────────────────────────────────────────────────────────────────
    # Chaque geste obligatoire rend 1 en cas d'échec. Cette fonction est
    # appelée sous « || » ou « if » : set -e y est suspendu, et un `return 0`
    # final annonçait des droits posés qui ne l'étaient pas.
    local d
    for d in staticdir mediadir logs; do
        if [[ -L "$project_dir/$d" ]]; then
            jeiko_warn "$project_dir/$d est un lien symbolique : remplacé par un vrai répertoire."
        fi
        # Remplacement d'un éventuel lien ET création, d'un seul geste, sous le
        # compte du site : pas de fenêtre entre un rm root et un install root.
        jeiko_as_site "$site_user" sh -c '
            if [ -L "$1" ]; then rm -f "$1" || exit 1; fi
            mkdir -p "$1"' sh "$project_dir/$d" \
            || { jeiko_err "Dossier $project_dir/$d impossible à créer."; return 1; }
    done

    chown -Rh "$site_user":"$(jeiko_groupe_du_site "$site_user")" "$project_dir" \
        || { jeiko_err "Propriétaire non appliqué sur $project_dir."; return 1; }

    # Les modes, sous le compte du site (voir ci-dessus). Les variables de mode
    # passent par l'environnement ; les chemins, en arguments positionnels.
    # shellcheck disable=SC2016  # $DIR_MODE/$1 s'expandent dans le shell enfant, pas ici
    jeiko_as_site "$site_user" env \
        DIR_MODE="$JEIKO_DIR_MODE" FILE_MODE="$JEIKO_FILE_MODE" EXEC_MODE="$JEIKO_EXEC_MODE" \
        sh -c '
            pd="$1"; venv="$2"; env="$3"; rc=0
            # Hors venv : dossiers 2750, fichiers 0640. Un lien (ni -type d ni
            # -type f) est ignore. Le .env est exclu : il passerait sinon par
            # 0640 (lisible par www-data) entre ce chmod et son 0600 final.
            find "$pd" -path "$venv" -prune -o -type d -print0 | xargs -0r chmod "$DIR_MODE" || rc=1
            find "$pd" -path "$venv" -prune -o -type f ! -path "$env" -print0 | xargs -0r chmod "$FILE_MODE" || rc=1
            # Venv : lecture et execution pour le proprietaire et le groupe.
            if [ -d "$venv" ]; then
                find "$venv" -type d -print0 | xargs -0r chmod u=rwx,g=rx,o= || rc=1
                find "$venv" -type f -print0 | xargs -0r chmod u=rw,g=r,o= || rc=1
                if [ -d "$venv/bin" ]; then
                    chmod "$EXEC_MODE" "$venv/bin" || rc=1
                    find "$venv/bin" -maxdepth 1 -type f -print0 | xargs -0r chmod "$EXEC_MODE" || rc=1
                fi
            fi
            exit "$rc"
        ' sh "$project_dir" "$venv_dir" "$env_path" \
        || { jeiko_err "Modes non appliqués sur $project_dir."; return 1; }

    # Exceptions explicites — déjà sous le compte du site : `[[ -f ]]` est vrai
    # pour un lien vers un fichier, et chmod suit le lien. Un manage.py remplacé
    # par un lien vers /usr/bin/sudo lui aurait fait perdre son bit setuid
    # (I-06). Le lien est écarté, et la course qui resterait ne mène qu'à des
    # fichiers que le site possède déjà.
    if [[ -f "$project_dir/manage.py" && ! -L "$project_dir/manage.py" ]]; then
        jeiko_as_site "$site_user" chmod -- "$JEIKO_EXEC_MODE" "$project_dir/manage.py" \
            || { jeiko_err "manage.py : mode non appliqué."; return 1; }
    fi
    if [[ -f "$env_path" && ! -L "$env_path" ]]; then
        jeiko_as_site "$site_user" chmod -- "$JEIKO_SECRET_MODE" "$env_path" \
            || { jeiko_err ".env : mode 0600 non appliqué."; return 1; }
    fi

    # /var/www doit rester traversable par nginx.
    local base_dir; base_dir="$(dirname "$project_dir")"
    chmod o+x "$base_dir" 2>/dev/null || true

    return 0
}

# Confort SSH : l'administrateur humain peut lire le projet sans sudo.
#
# Aucune ACL « par défaut » (d:u:) n'est posée. La version précédente en
# mettait une sur toute l'arborescence : tout fichier créé ensuite héritait du
# droit de lecture pour l'administrateur, y compris un .env recréé plus tard —
# le mot de passe de la base redevenait lisible sans sudo, en contradiction
# avec le 0600 affiché. Le confort de lecture ne justifiait pas cet écart.
jeiko_apply_admin_acl() {
    local project_dir="$1" admin_user="${2:-}"
    [[ -n "$admin_user" ]] || return 0
    id -u "$admin_user" >/dev/null 2>&1 || return 0
    command -v setfacl >/dev/null 2>&1 || { jeiko_warn "setfacl absent, ACL non appliquées."; return 0; }

    local base_dir; base_dir="$(dirname "$project_dir")"
    local site_name; site_name="$(basename "$project_dir")"

    setfacl -m "u:$admin_user:rx" "$base_dir" 2>/dev/null || true
    setfacl -R -m "u:$admin_user:rX" "$project_dir" 2>/dev/null || true

    # Les secrets restent des secrets, ACL ou pas. L'échec est signalé plutôt
    # que silencieusement avalé : si le retrait ne prend pas, l'administrateur
    # conserve un accès en lecture au mot de passe de la base.
    local env_path="$project_dir/$site_name/.env"
    if [[ -f "$env_path" ]]; then
        if ! setfacl -x "u:$admin_user" "$env_path" 2>/dev/null; then
            jeiko_warn "ACL non retirée de $env_path — vérifier : getfacl $env_path"
        fi
    fi
}

# --------------------------------------------------------------------------- #
# Réseau / intégrité
# --------------------------------------------------------------------------- #

# Télécharge dans un fichier, sans pipe vers un interpréteur.
jeiko_download() {
    local url="$1" dest="$2"
    curl -fsSL --proto '=https' --tlsv1.2 \
         --retry 4 --retry-connrefused --retry-delay 2 \
         --max-time 300 --speed-time 30 --speed-limit 1024 \
         -o "$dest" "$url"
}

# Vérifie un sha256 attendu. C'est le seul garde-fou entre le dépôt distant et
# l'exécution de code sur la machine : ne jamais rendre cet appel optionnel.
jeiko_verify_sha256() {
    local file="$1" expected="$2"
    [[ -s "$file" ]] || { jeiko_err "Fichier vide ou absent : $file"; return 1; }
    [[ "$expected" =~ ^[a-f0-9]{64}$ ]] || { jeiko_err "Empreinte sha256 malformée : '$expected'"; return 1; }

    local actual
    actual="$(sha256sum "$file" | awk '{print $1}')"
    if [[ "$actual" != "$expected" ]]; then
        jeiko_err "Empreinte sha256 incorrecte pour $(basename "$file")."
        jeiko_err "  attendue : $expected"
        jeiko_err "  obtenue  : $actual"
        return 1
    fi
    jeiko_ok "Empreinte sha256 vérifiée ($(basename "$file"))."
    return 0
}

# --------------------------------------------------------------------------- #
# Récupération vérifiée du package JEIKO
#
# Deux fonctions, utilisées par l'installation initiale (script 08) comme par
# jeiko-update. Une seule implémentation, donc pas de chemin « rapide » où le
# sha256 serait contourné — c'est le point où un package altéré entrerait dans
# le système.
# --------------------------------------------------------------------------- #

# Lit version.json et renseigne JEIKO_PKG_VERSION / _WHEEL_NAME / _WHEEL_SHA.
# Ne télécharge pas le package : permet à `--check` de comparer les versions
# sans rapatrier plusieurs mégaoctets.
jeiko_read_manifest() {
    local channel="$1" tmp="$2"

    # Le python SYSTÈME, jamais celui du venv : ce dernier appartient à
    # l'utilisateur du site, et l'exécuter en root lui rendrait précisément les
    # privilèges qu'on cherche à lui retirer.
    local system_py; system_py="$(command -v python3 || true)"
    [[ -x "$system_py" ]] || { jeiko_err "python3 système introuvable."; return 1; }

    local manifest="$tmp/version.json"
    jeiko_download "$channel/version.json" "$manifest" || {
        jeiko_err "version.json introuvable sur $channel"
        jeiko_err "Il se publie avec packages/jeiko/publier-jeiko.sh."
        return 1
    }

    local version wheel sha
    read -r version wheel sha < <("$system_py" - "$manifest" <<'PY'
import json, sys
try:
    d = json.load(open(sys.argv[1], encoding="utf-8"))
except (OSError, ValueError):
    d = {}
print(d.get("version", ""), d.get("wheel", ""), d.get("sha256", ""))
PY
)

    [[ -n "$version" && -n "$wheel" && -n "$sha" ]] || {
        jeiko_err "Manifeste incomplet ou illisible : version, wheel et sha256 sont requis."
        return 1
    }
    # Le nom du wheel provient du réseau et sert à construire un chemin local :
    # sans ce bornage, un manifeste hostile écrirait où il veut sur le disque.
    [[ "$wheel" =~ ^[A-Za-z0-9._+-]+\.whl$ ]] || {
        jeiko_err "Nom de wheel refusé : '$wheel'"
        return 1
    }

    JEIKO_PKG_VERSION="$version"
    JEIKO_PKG_WHEEL_NAME="$wheel"
    JEIKO_PKG_WHEEL_SHA="$sha"
    return 0
}

# Télécharge le wheel décrit par le manifeste et vérifie son empreinte.
# Renseigne JEIKO_PKG_WHEEL (chemin local). À appeler après jeiko_read_manifest.
jeiko_fetch_wheel() {
    local channel="$1" tmp="$2"
    : "${JEIKO_PKG_WHEEL_NAME:?jeiko_read_manifest doit être appelé avant}"

    local dest="$tmp/$JEIKO_PKG_WHEEL_NAME"
    jeiko_download "$channel/dist/$JEIKO_PKG_WHEEL_NAME" "$dest" \
        || { jeiko_err "Téléchargement du wheel impossible."; return 1; }
    jeiko_verify_sha256 "$dest" "$JEIKO_PKG_WHEEL_SHA" || return 1

    JEIKO_PKG_WHEEL="$dest"
    return 0
}

# Enchaînement des deux, pour l'installation initiale.
jeiko_fetch_package() {
    jeiko_read_manifest "$1" "$2" && jeiko_fetch_wheel "$1" "$2"
}

# --------------------------------------------------------------------------- #
# Versions de l'outillage serveur — « le serveur avant les sites »
#
# Deux repères, et pas un :
#   · $JEIKO_ASSET_DIR/VERSION — l'installeur dont l'outillage est DÉPOSÉ
#     (écrit par migrate_site.sh --tools-only et par l'installation) ;
#   · $JEIKO_LIB_DIR/<site>/serveur.version — l'installeur avec lequel CE site
#     a été CONVERGÉ avec succès (écrit par jeiko-server-update et par
#     l'installation).
# Un seul repère, posé au dépôt, aurait fait croire « à jour » un serveur dont
# la convergence avait échoué à mi-parcours : elle n'aurait jamais été
# reprise. Et c'est site par site que se vérifie l'ordre exigé par
# jeiko-client-update : le paquet d'un site ne passe qu'après la convergence de
# CE site avec l'installeur publié.
# --------------------------------------------------------------------------- #

# Vrai si la version <a> est STRICTEMENT plus récente que <b> (vide = 0).
jeiko_version_superieure() {
    local a="${1:-0}" b="${2:-0}"
    [[ "$a" != "$b" ]] && [[ "$(printf '%s\n%s\n' "$a" "$b" | sort -V | tail -n1)" == "$a" ]]
}

# Lit une version dans un fichier root ; « 0 » si absent ou mal formé.
jeiko_lire_version() {
    local v=""
    [[ -f "$1" && ! -L "$1" ]] && v="$(head -c 32 "$1" | tr -d ' \n\r')"
    [[ "$v" =~ ^[0-9]+(\.[0-9]+){0,3}$ ]] || v="0"
    printf '%s' "$v"
}

jeiko_version_outillage() { jeiko_lire_version "$JEIKO_ASSET_DIR/VERSION"; }

jeiko_version_convergee() { jeiko_lire_version "$JEIKO_LIB_DIR/$1/serveur.version"; }

# Note qu'un site vient d'être convergé avec <version>. Le fichier est lisible
# par le site (son administration l'affiche), modifiable par root seul.
# Usage : jeiko_noter_convergence <site> <compte> <version>
jeiko_noter_convergence() {
    local dossier="$JEIKO_LIB_DIR/$1"
    install -d -m 0750 -o root -g "$2" "$dossier"
    printf '%s\n' "$3" >"$dossier/serveur.version.tmp"
    chown root:"$2" "$dossier/serveur.version.tmp"
    chmod 0640 "$dossier/serveur.version.tmp"
    mv -f "$dossier/serveur.version.tmp" "$dossier/serveur.version"
}

# Verdict du contrôle de santé d'une convergence, d'après le code HTTP du site
# AVANT qu'on y touche et APRÈS (jeiko-server-update, étape 8) :
#   ok    — il répond (1xx/2xx/3xx) ;
#   avert — il répond mais route mal (4xx) : debout, on n'échoue pas ;
#   deja  — il ne répond pas, mais ne répondait déjà pas avant : ce n'est pas
#           la convergence qui l'a cassé. L'en accuser bloquerait son paquet
#           (jeiko-client-update exige un site convergé) — donc la mise à jour
#           même qui peut le réparer ;
#   casse — il répondait avant, plus maintenant : la convergence l'a cassé, et
#           casserait de même les sites suivants.
# Usage : jeiko_verdict_de_sante <code avant> <code après>
jeiko_verdict_de_sante() {
    if [[ "$2" =~ ^[123] ]]; then echo ok
    elif [[ "$2" =~ ^4 ]]; then echo avert
    elif [[ "$1" =~ ^[1234] ]]; then echo casse
    else echo deja
    fi
}

# Lit le manifeste de l'installeur publié et renseigne JEIKO_INST_VERSION,
# JEIKO_INST_ARCHIVE et JEIKO_INST_SHA256. Le python du SYSTÈME, comme pour le
# paquet. Chaque champ est borné : le nom d'archive sert à construire une URL
# et un chemin local.
# Usage : jeiko_lire_manifeste_installeur <dossier temporaire root>
jeiko_lire_manifeste_installeur() {
    local tmp="$1" system_py lu
    system_py="$(command -v python3 || true)"
    [[ -x "$system_py" ]] || { jeiko_err "python3 système introuvable."; return 1; }
    jeiko_download "$JEIKO_INSTALLER_CHANNEL_URL/version.json" "$tmp/installeur.json" || {
        jeiko_err "Manifeste de l'installeur injoignable ($JEIKO_INSTALLER_CHANNEL_URL/version.json)."
        return 1
    }
    lu="$("$system_py" - "$tmp/installeur.json" <<'PY'
import json, re, sys
try:
    d = json.load(open(sys.argv[1], encoding="utf-8"))
except (OSError, ValueError):
    sys.exit(1)
version, archive, sha = (str(d.get(k, "")) for k in ("version", "archive", "sha256"))
if not (re.fullmatch(r"[0-9]+\.[0-9]+\.[0-9]+", version)
        and archive == "jeiko-installer-v%s.zip" % version
        and re.fullmatch(r"[a-f0-9]{64}", sha)):
    sys.exit(1)
print(version, archive, sha)
PY
)" || { jeiko_err "Manifeste de l'installeur illisible ou incomplet."; return 1; }
    # shellcheck disable=SC2034  # lues par les appelants (jeiko-maj, jeiko-client-update)
    read -r JEIKO_INST_VERSION JEIKO_INST_ARCHIVE JEIKO_INST_SHA256 <<<"$lu"
    return 0
}

# --------------------------------------------------------------------------- #
# Chemin de systemctl
#
# La règle sudoers et la commande émise par la vue Django doivent correspondre
# AU CARACTÈRE PRÈS : sudo compare la ligne de commande complète, pas seulement
# le binaire. /bin/systemctl et /usr/bin/systemctl désignent le même fichier sur
# Debian (usrmerge) mais sont deux chaînes différentes pour sudo.
# On fige donc /usr/bin/systemctl des deux côtés.
# --------------------------------------------------------------------------- #
JEIKO_SYSTEMCTL="/usr/bin/systemctl"

jeiko_require_systemctl_path() {
    if [[ ! -x "$JEIKO_SYSTEMCTL" ]]; then
        local found; found="$(command -v systemctl || true)"
        jeiko_err "systemctl attendu en $JEIKO_SYSTEMCTL, trouvé : ${found:-nulle part}."
        jeiko_err "La règle sudoers et la vue Django doivent viser le même chemin."
        return 1
    fi
    return 0
}

# --------------------------------------------------------------------------- #
# systemd
# --------------------------------------------------------------------------- #
jeiko_unit_exists() {
    systemctl list-unit-files "$1" >/dev/null 2>&1 && \
    systemctl list-unit-files --no-legend "$1" | grep -q .
}

# --------------------------------------------------------------------------- #
# Maintenance d'un site (IG-02, 11/10/2026)
#
# Pendant qu'on remplace sa base — mise à jour qui migre, retour arrière,
# restauration —, plus rien ne doit y écrire : une commande, un paiement ou
# une inscription enregistrés entre le dump et sa restauration seraient
# perdus. On arrête donc les tâches planifiées du site (en laissant finir une
# tâche déjà lancée, 5 min au plus), puis gunicorn : nginx sert la page
# « indisponible » du site (location @jeiko_indisponible). Les webhooks
# refusés pendant ce temps, Stripe les renvoie de lui-même.
#
# Ce que ça ne couvre pas : une requête déjà en cours au moment de l'arrêt
# finit son travail (systemd laisse gunicorn terminer ses requêtes).
#
# Les timers arrêtés sont retenus dans JEIKO_TIMERS_SUSPENDUS — une variable
# et non la sortie, pour qu'un échec de l'arrêt de gunicorn ne les fasse pas
# oublier : jeiko_reprendre_le_site doit être appelé dans tous les cas.
# Usage : jeiko_suspendre_le_site <site> <service gunicorn>
#         jeiko_reprendre_le_site <service gunicorn>
# --------------------------------------------------------------------------- #
JEIKO_TIMERS_SUSPENDUS=()

jeiko_suspendre_le_site() {
    local site="$1" service="$2" t i
    JEIKO_TIMERS_SUSPENDUS=()
    while read -r t; do
        [[ -n "$t" ]] && JEIKO_TIMERS_SUSPENDUS+=("$t")
    done < <(systemctl list-units --type=timer --state=active --no-legend --plain \
                 "jeiko-cron-*@$site.timer" 2>/dev/null | awk '{print $1}')
    for t in "${JEIKO_TIMERS_SUSPENDUS[@]}"; do
        systemctl stop "$t" || jeiko_warn "Timer non arrêté : $t"
    done
    for i in $(seq 1 60); do
        [[ -z "$(systemctl list-units --type=service --state=active,activating --no-legend --plain \
                     "jeiko-cron-*@$site.service" 2>/dev/null)" ]] && break
        (( i == 1 )) && jeiko_log "⏳ Une tâche planifiée de « $site » se termine…"
        sleep 5
    done
    systemctl stop "$service" || { jeiko_err "$service ne s'arrête pas."; return 1; }
    jeiko_log "🚧 « $site » en maintenance (${#JEIKO_TIMERS_SUSPENDUS[@]} tâche(s) planifiée(s) suspendue(s))."
}

jeiko_reprendre_le_site() {
    local service="$1" t rc=0
    for t in "${JEIKO_TIMERS_SUSPENDUS[@]}"; do
        systemctl start "$t" || { jeiko_warn "Timer non relancé : $t"; rc=1; }
    done
    JEIKO_TIMERS_SUSPENDUS=()
    systemctl is-active --quiet "$service" || systemctl start "$service" \
        || { jeiko_err "$service ne redémarre pas."; rc=1; }
    return "$rc"
}

jeiko_restart_if_exists() {
    local unit="$1"
    if jeiko_unit_exists "$unit"; then
        jeiko_log "🔁 Redémarrage de $unit…"
        systemctl restart "$unit"
    else
        jeiko_warn "Unité absente, ignorée : $unit"
    fi
}

# --------------------------------------------------------------------------- #
# Tâches planifiées
#
# Le serveur ne connaît aucune cadence à l'avance : il demande la liste au
# package (`manage.py jeiko_cron_units --json`) et s'y conforme. Ajouter un
# fichier `cron_<cadence>.py` dans jeiko fait donc apparaître le timer à la
# prochaine mise à jour serveur ; le retirer fait disparaître le timer.
#
# Une unité modèle par cadence, instanciée par site :
#   jeiko-cron-5m@monsite.timer  ->  jeiko-cron-5m@monsite.service
# --------------------------------------------------------------------------- #

# Liste les cadences actuellement installées POUR UN SITE.
#
# On s'appuie sur les drop-ins plutôt que sur les gabarits : ces derniers sont
# partagés entre tous les sites de la machine, alors que le drop-in est la
# marque qu'une cadence a bien été déployée pour ce site-là.
# Usage : jeiko_installed_cron_cadences <site>
jeiko_installed_cron_cadences() {
    local site="$1" dir base
    for dir in "/etc/systemd/system/jeiko-cron-"*"@$site.service.d"; do
        [[ -d "$dir" ]] || continue
        base="$(basename "$dir")"           # jeiko-cron-5m@monsite.service.d
        base="${base#jeiko-cron-}"
        printf '%s\n' "${base%%@*}"
    done
}

# Écrit (ou met à jour) le couple service+timer d'une cadence.
#
# Les gabarits sont PARTAGÉS par tous les sites de la machine : ils ne doivent
# donc contenir que ce qui est commun à tous. Rien de propre à un site — ni les
# chemins, ni l'horaire — ne peut y figurer, sinon deux sites installés sur des
# versions différentes de JEIKO se voleraient mutuellement leur configuration,
# le dernier convergé imposant la sienne aux autres.
#
# D'où l'absence délibérée de ExecStart/User côté service et de OnCalendar côté
# timer : tout cela vient des drop-ins par site. Une unité incomplète est un
# choix — si son drop-in manquait, systemd refuserait de la démarrer, ce qui
# est un échec visible plutôt qu'un cron tournant sur la mauvaise cadence.
#
# Usage : jeiko_write_cron_unit <cadence>
jeiko_write_cron_unit() {
    local cadence="$1"
    local service="/etc/systemd/system/jeiko-cron-$cadence@.service"
    local timer="/etc/systemd/system/jeiko-cron-$cadence@.timer"

    cat >"$service" <<EOF
# Généré par jeiko-server-update — ne pas éditer à la main.
# Gabarit PARTAGÉ : cadence « $cadence », toutes instances de site confondues.
# Le contenu des jobs vit dans le package (commande manage.py cron_$cadence).
# ExecStart, User et WorkingDirectory sont fournis par
# /etc/systemd/system/jeiko-cron-$cadence@<site>.service.d/site.conf
[Unit]
Description=Tâches planifiées $cadence — site %i
After=network-online.target postgresql.service
Wants=network-online.target

[Service]
Type=oneshot
Environment=PYTHONNOUSERSITE=1
Environment=PYTHONUNBUFFERED=1

# Un job qui traîne ne doit pas chevaucher le déclenchement suivant.
TimeoutStartSec=900

StandardOutput=journal
StandardError=journal
# %i dans l'identifiant : les journaux de deux sites ne doivent pas se mélanger.
SyslogIdentifier=jeiko-cron-$cadence-%i

# ProtectHome n'est volontairement pas activé : le projet et son venv vivent
# sous /home/<compte du site>, et certains jobs y écrivent (médias, journaux).
NoNewPrivileges=yes
PrivateTmp=yes
ProtectSystem=full
ProtectKernelTunables=yes
ProtectKernelModules=yes
ProtectControlGroups=yes
RestrictRealtime=yes
LockPersonality=yes
EOF

    cat >"$timer" <<EOF
# Généré par jeiko-server-update — ne pas éditer à la main.
# Gabarit PARTAGÉ. L'horaire est propre à chaque site : il est défini dans
# /etc/systemd/system/jeiko-cron-$cadence@<site>.timer.d/site.conf
[Unit]
Description=Déclenchement $cadence des tâches planifiées — site %i

[Timer]
Unit=jeiko-cron-$cadence@%i.service

[Install]
WantedBy=timers.target
EOF

    chmod 0644 "$service" "$timer"
}

# Fixe tout ce qui est propre à un site pour une cadence donnée : ses chemins
# et son horaire. C'est ce qui permet à deux sites de la même machine de tourner
# sur des versions différentes de JEIKO sans se marcher dessus.
#
# Usage : jeiko_write_cron_dropin <cadence> <site> <project_dir> <venv_dir> \
#                                 <site_user> <on_calendar> <persistent> <delay> \
#                                 [description]
jeiko_write_cron_dropin() {
    local cadence="$1" site="$2" project_dir="$3" venv_dir="$4" site_user="$5"
    local on_calendar="$6" persistent="$7" delay="$8"
    local description="${9:-Tâches planifiées $cadence}"
    local svc_dir="/etc/systemd/system/jeiko-cron-$cadence@$site.service.d"
    local tmr_dir="/etc/systemd/system/jeiko-cron-$cadence@$site.timer.d"

    install -d -m 0755 -o root -g root "$svc_dir" "$tmr_dir"

    # La description vient du package installé SUR CE SITE : `systemctl status`
    # affiche donc ce que fait réellement la cadence dans sa version à lui.
    cat >"$svc_dir/site.conf" <<EOF
# Généré par jeiko-server-update — ne pas éditer à la main.
# Chemins du site « $site », relus à chaque convergence depuis sa fiche.
[Unit]
Description=$description — site $site

[Service]
User=$site_user
WorkingDirectory=$project_dir
ExecStart=$venv_dir/bin/python $project_dir/manage.py cron_$cadence
EOF

    # OnCalendar s'ACCUMULE d'un fragment à l'autre : la ligne vide remet le
    # compteur à zéro avant de poser la valeur du site. Sans elle, une cadence
    # modifiée dans le package s'ajouterait à l'ancienne au lieu de la remplacer.
    cat >"$tmr_dir/site.conf" <<EOF
# Généré par jeiko-server-update — ne pas éditer à la main.
# Horaire du site « $site », tel que déclaré par SA version du package.
[Timer]
OnCalendar=
OnCalendar=$on_calendar
# Étalement : plusieurs sites cohabitent, leurs timers ne doivent pas partir
# à la même seconde et se disputer la base.
RandomizedDelaySec=$delay
Persistent=$persistent
EOF

    chmod 0644 "$svc_dir/site.conf" "$tmr_dir/site.conf"
}

# --------------------------------------------------------------------------- #
# Licence (LIC-01, 11/10/2026)
#
# Avant toute mise à jour du paquet d'un site, le serveur de licences dit si
# sa clé l'autorise. Trois issues, écrites sur la sortie :
#   « oui<TAB>message »  — autorisée (clé valide, ou mode observation) ;
#   « non<TAB>message »  — refusée : la mise à jour n'a pas lieu ;
#   « muet<TAB>raison »  — serveur injoignable ou réponse illisible : la mise
#                          à jour PASSE (décision de Guillaume : une panne de
#                          jeiko.fr ne bloque jamais un client, ni ses
#                          correctifs de sécurité).
# Ce qui vient du site (la clé) est borné avant d'être envoyé ; ce qui vient du
# serveur (le message) est borné avant d'être affiché. La demande ne part qu'en
# HTTPS, et la clé n'est jamais écrite dans un journal.
# Usage : jeiko_demander_la_licence <cle> <domaine> <version actuelle> <version visée> <dossier root>
# --------------------------------------------------------------------------- #
jeiko_demander_la_licence() {
    local cle="$1" domaine="$2" actuelle="$3" visee="$4" tmp="$5" py
    py="$(command -v python3 || true)"
    [[ -x "$py" ]] || { printf 'muet\tpython3 système introuvable\n'; return 0; }
    [[ "$cle" =~ ^[A-Za-z0-9-]{12,64}$ ]] || cle=""
    "$py" -c 'import json, sys; json.dump(dict(zip(("cle", "domaine", "version_actuelle", "version_visee"), sys.argv[1:])), sys.stdout)' \
        "$cle" "$domaine" "$actuelle" "$visee" >"$tmp/licence-demande.json" 2>/dev/null \
        || { printf 'muet\tdemande impossible à préparer\n'; return 0; }
    chmod 0600 "$tmp/licence-demande.json"
    if ! curl -fsS --proto '=https' --tlsv1.2 --max-time 15 \
            -H 'Content-Type: application/json' --data-binary @"$tmp/licence-demande.json" \
            -o "$tmp/licence-reponse.json" "$JEIKO_LICENCE_URL" 2>/dev/null; then
        rm -f "$tmp/licence-demande.json"
        printf 'muet\tserveur de licences injoignable\n'; return 0
    fi
    rm -f "$tmp/licence-demande.json"
    "$py" - "$tmp/licence-reponse.json" <<'PY' || printf 'muet\tréponse illisible\n'
import json, sys
try:
    with open(sys.argv[1], encoding="utf-8") as f:
        d = json.load(f)
    autorisee = d["autorisee"]
    if not isinstance(autorisee, bool):
        raise ValueError
except (OSError, ValueError, KeyError, TypeError):
    sys.exit(1)
message = "".join(c for c in str(d.get("message", "")) if c.isprintable() and c != "\t")[:300]
print(("oui" if autorisee else "non") + "\t" + message)
PY
}

# --------------------------------------------------------------------------- #
# Alertes hors du site (IG-05, 11/10/2026)
#
# Quand un site, PostgreSQL ou une sauvegarde tombe, le site ne peut pas
# prévenir lui-même : c'est justement lui qui est en panne. Le serveur envoie
# donc ses alertes seul, par un serveur d'envoi (SMTP) configuré une fois par
# `sudo jeiko-alertes`, dans un fichier réservé à root. Aucun MTA à installer :
# le python du système suffit (smtplib, TLS obligatoire).
#
# Format du fichier : une clé par ligne, « CLE=valeur », la valeur prise telle
# quelle (aucune interprétation par un shell). Clés : A, DE, SMTP_HOTE,
# SMTP_PORT, SMTP_UTILISATEUR, SMTP_MOT_DE_PASSE.
# --------------------------------------------------------------------------- #
JEIKO_ALERTES_CONF="${JEIKO_ALERTES_CONF:-$JEIKO_ETC_DIR/alertes.conf}"

# Envoie le corps lu sur l'entrée standard, avec <sujet>, à l'adresse
# configurée. Rend 0 si l'e-mail est parti, 2 si rien n'est configuré, 1 en
# cas d'échec (dit sur la sortie d'erreur). JEIKO_ALERTE_SEC=1 : n'envoie
# rien, écrit le message composé sur la sortie (essai, banc).
# Usage : <corps> | jeiko_envoyer_alerte <sujet>
jeiko_envoyer_alerte() {
    local py
    py="$(command -v python3 || true)"
    [[ -x "$py" ]] || { jeiko_err "python3 système introuvable : alerte non envoyée."; return 1; }
    [[ -f "$JEIKO_ALERTES_CONF" && ! -L "$JEIKO_ALERTES_CONF" ]] || return 2
    "$py" - "$JEIKO_ALERTES_CONF" "$1" "$(hostname -f 2>/dev/null || hostname)" <<'PY'
import os, smtplib, ssl, sys
from email.message import EmailMessage
from email.utils import formatdate, make_msgid

conf = {}
with open(sys.argv[1], encoding="utf-8") as f:
    for ligne in f:
        ligne = ligne.rstrip("\n")
        if ligne and not ligne.startswith("#") and "=" in ligne:
            cle, valeur = ligne.split("=", 1)
            conf[cle.strip()] = valeur
a, hote = conf.get("A", ""), conf.get("SMTP_HOTE", "")
if not a or not hote:
    sys.exit(2)
# Un retour à la ligne dans le sujet ouvrirait un en-tête de plus.
sujet = " ".join(sys.argv[2].split())[:200]
message = EmailMessage()
message["Subject"] = f"[JEIKO {sys.argv[3]}] {sujet}"
message["From"] = conf.get("DE") or conf.get("SMTP_UTILISATEUR") or a
message["To"] = a
message["Date"] = formatdate(localtime=True)
message["Message-ID"] = make_msgid()
message.set_content(sys.stdin.read())
if os.environ.get("JEIKO_ALERTE_SEC") == "1":
    print(message.as_string())
    sys.exit(0)
try:
    port = int(conf.get("SMTP_PORT") or 587)
    contexte = ssl.create_default_context()
    if port == 465:
        smtp = smtplib.SMTP_SSL(hote, port, context=contexte, timeout=30)
    else:
        smtp = smtplib.SMTP(hote, port, timeout=30)
        smtp.starttls(context=contexte)
    with smtp:
        if conf.get("SMTP_UTILISATEUR"):
            smtp.login(conf["SMTP_UTILISATEUR"], conf.get("SMTP_MOT_DE_PASSE", ""))
        smtp.send_message(message)
except Exception as souci:
    print(f"Alerte non envoyée : {souci}", file=sys.stderr)
    sys.exit(1)
PY
}

# Faut-il prévenir ? Oui si l'ensemble des problèmes a CHANGÉ depuis le
# dernier passage — un nouveau, ou un de moins, ou le retour à la normale.
# Les clés (« disque:/var », « service:nginx »…) et non les messages : un
# disque qui passe de 91 à 92 % n'est pas un problème nouveau. Met l'état à
# jour. Rend 0 s'il faut prévenir.
# Usage : printf '%s\n' <clés…> | jeiko_etat_a_change <fichier d'état>
jeiko_etat_a_change() {
    local etat="$1" nouveau
    nouveau="$(grep -v '^$' | sort -u)" || true   # aucun problème : grep rend 1
    if [[ -f "$etat" && "$(cat "$etat")" == "$nouveau" ]] || [[ ! -f "$etat" && -z "$nouveau" ]]; then
        [[ -f "$etat" ]] || : >"$etat"
        return 1
    fi
    printf '%s' "$nouveau" >"$etat.tmp" && chmod 0600 "$etat.tmp" && mv -f "$etat.tmp" "$etat"
    return 0
}

# Lit sur l'entrée standard le JSON de `manage.py jeiko_cron_units --json` et
# rend une ligne par cadence ACCEPTÉE : cadence, OnCalendar, persistant,
# délai, description — séparés par des tabulations.
#
# Les bornes sont celles de ce qu'une unité systemd peut recevoir sans risque :
#   · cadence     : 1 à 4 chiffres et m/h/d (sert de nom de fichier) ;
#   · OnCalendar  : lettres, chiffres, espace et « *:/,.~- » — de quoi écrire
#                   « *:0/5 » ou « Mon *-*-* 03:30:00 », rien qui ouvre une
#                   ligne ou une section ;
#   · délai       : entier de 0 à 86 400 ;
#   · description : caractères imprimables, sans « \ » (continuation de ligne)
#                   ni « % » (spécificateurs systemd), 120 au plus.
# Un enregistrement hors bornes est écarté, et dit sur la sortie d'erreur ; les
# autres restent planifiés.
# Usage : <json> | jeiko_lire_les_cadences <python3 système>
jeiko_lire_les_cadences() {
    "$1" -c '
import json, re, sys

CADENCE = re.compile(r"[0-9]{1,4}[mhd]")
CALENDRIER = re.compile(r"[A-Za-z0-9 *:/,.~-]{1,80}")

def propre(texte):
    texte = "".join(c for c in str(texte) if c.isprintable() and c not in "\\%")
    return " ".join(texte.split())[:120]

try:
    specs = json.load(sys.stdin)
except ValueError:
    sys.exit(1)
if not isinstance(specs, list):
    sys.exit(1)

for spec in specs:
    if not isinstance(spec, dict):
        continue
    cadence = str(spec.get("cadence", ""))
    calendrier = str(spec.get("on_calendar", ""))
    try:
        delai = int(spec.get("randomized_delay_sec") or 0)
    except (TypeError, ValueError):
        delai = -1
    if not (CADENCE.fullmatch(cadence) and CALENDRIER.fullmatch(calendrier)
            and 0 <= delai <= 86400):
        print("cadence écartée (valeurs hors bornes) : %r" % cadence[:40], file=sys.stderr)
        continue
    print("\t".join([
        cadence,
        calendrier,
        "true" if spec.get("persistent") else "false",
        str(delai),
        propre(spec.get("description") or ""),
    ]))
'
}

# Converge les timers d'un site sur ce que déclare le package.
# Usage : jeiko_sync_cron_timers <site> <project_dir> <venv_dir> <site_user> [dry_run]
jeiko_sync_cron_timers() {
    jeiko_require_root
    local site="$1" project_dir="$2" venv_dir="$3" site_user="$4" dry_run="${5:-0}"

    local specs
    if ! specs="$(jeiko_manage "$project_dir" "$venv_dir" "$site_user" \
                    jeiko_cron_units --json 2>/dev/null)"; then
        jeiko_warn "Impossible d'interroger les cadences (jeiko_cron_units absent ?) — timers inchangés."
        return 0
    fi
    [[ -n "$specs" ]] || { jeiko_warn "Aucune cadence retournée par le package."; return 0; }

    # Ce JSON vient du code du site : il est lu par le python du SYSTÈME, et
    # chaque champ est borné avant d'entrer dans une unité systemd écrite par
    # root (audit du 04/10/2026, I-02 et I-03). Avant, c'était le python du
    # venv — que le site possède : un sitecustomize.py s'y exécutait en root —
    # et les valeurs passaient telles quelles : un retour à la ligne dans la
    # description ajoutait « ExecStartPre=+… » (exécuté en root malgré User=),
    # un « ../ » dans la cadence faisait écrire hors de /etc/systemd/system.
    local system_py; system_py="$(command -v python3 || true)"
    [[ -x "$system_py" ]] || { jeiko_warn "python3 système introuvable — timers inchangés."; return 0; }

    local parsed
    if ! parsed="$(printf '%s' "$specs" | jeiko_lire_les_cadences "$system_py")"; then
        jeiko_warn "Réponse de jeiko_cron_units illisible — timers inchangés."
        return 0
    fi

    local wanted=() cadence on_calendar persistent delay description
    while IFS=$'\t' read -r cadence on_calendar persistent delay description; do
        [[ -n "$cadence" ]] || continue
        wanted+=("$cadence")

        if [[ $dry_run -eq 1 ]]; then
            jeiko_log "   [simulation] cadence $cadence → $on_calendar (délai ${delay}s)"
            continue
        fi

        jeiko_write_cron_unit "$cadence"
        jeiko_write_cron_dropin "$cadence" "$site" "$project_dir" "$venv_dir" \
                                "$site_user" "$on_calendar" "$persistent" "$delay" \
                                "$description"
        jeiko_log "   cadence $cadence → $on_calendar (délai ${delay}s)"
    done <<<"$parsed"

    [[ ${#wanted[@]} -gt 0 ]] || { jeiko_warn "Aucune cadence exploitable."; return 0; }

    if [[ $dry_run -eq 1 ]]; then
        return 0
    fi

    systemctl daemon-reload

    # Activation de ce qui est déclaré.
    for cadence in "${wanted[@]}"; do
        systemctl enable --now "jeiko-cron-$cadence@$site.timer" >/dev/null 2>&1 \
            || jeiko_warn "Activation impossible : jeiko-cron-$cadence@$site.timer"
    done

    # Retrait de ce qui ne l'est plus. On ne supprime que l'instance du site ;
    # le gabarit reste tant qu'un autre site l'utilise.
    local installed keep
    for installed in $(jeiko_installed_cron_cadences "$site"); do
        keep=0
        for cadence in "${wanted[@]}"; do
            [[ "$installed" == "$cadence" ]] && { keep=1; break; }
        done
        if [[ $keep -eq 0 ]]; then
            jeiko_log "   cadence $installed retirée du package → désactivation"
            systemctl disable --now "jeiko-cron-$installed@$site.timer" >/dev/null 2>&1 || true
            rm -rf "/etc/systemd/system/jeiko-cron-$installed@$site.service.d" \
                   "/etc/systemd/system/jeiko-cron-$installed@$site.timer.d"

            # Le gabarit est partagé : on ne le supprime que si plus aucun site
            # ne l'utilise, sinon on casserait les autres sites de la machine.
            if ! compgen -G "/etc/systemd/system/jeiko-cron-$installed@*.service.d" >/dev/null; then
                rm -f "/etc/systemd/system/jeiko-cron-$installed@.timer" \
                      "/etc/systemd/system/jeiko-cron-$installed@.service"
            fi
        fi
    done

    systemctl daemon-reload
    jeiko_ok "Tâches planifiées synchronisées (${#wanted[@]} cadence(s))."
}
