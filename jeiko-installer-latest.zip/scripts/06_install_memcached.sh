#!/bin/bash
set -euo pipefail

echo "🧠 [06_install_memcached.sh] Installation & confinement Memcached…"

# 1) Conf fichier Debian
CONF="/etc/memcached.conf"
cp -n "$CONF" "${CONF}.bak" || true

# 2) Bind loopback, mémoire et connexions
sed -ri 's/^(-l\s+).*/\1127.0.0.1/' "$CONF" || echo "-l 127.0.0.1" >> "$CONF"
sed -ri 's/^(-m\s+).*/\1128/' "$CONF" || echo "-m 128" >> "$CONF"   # 128MB par défaut
sed -ri 's/^(-c\s+).*/\11024/' "$CONF" || echo "-c 1024" >> "$CONF"

systemctl enable --now memcached
sleep 1
ss -lntu | grep -q '127.0.0.1:11211' && echo "✅ Memcached écoute en local uniquement." || { echo "❌ Memcached non détecté sur 127.0.0.1:11211"; exit 1; }
