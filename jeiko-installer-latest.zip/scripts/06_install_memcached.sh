#!/bin/bash
set -euo pipefail
# shellcheck source=../lib/jeiko-common.sh
source /usr/local/lib/jeiko/common.sh

jeiko_step "[06] Memcached"
jeiko_require_root

export DEBIAN_FRONTEND=noninteractive
dpkg -s memcached &>/dev/null || jeiko_apt install -y memcached

# --------------------------------------------------------------------------- #
# Memcached n'a aucune authentification : la seule protection est de ne pas
# l'exposer.
#
# Note sur l'ancienne version : `sed -ri 's/^(-l\s+).*/\1127.0.0.1/' || echo …`
# ne pouvait jamais tomber dans la branche `echo`, sed renvoyant 0 même quand
# il ne substitue rien. Si la directive était absente du fichier, elle n'était
# donc jamais ajoutée. On teste explicitement la présence de chaque directive.
# --------------------------------------------------------------------------- #
CONF="/etc/memcached.conf"
if [[ -f "$CONF" ]]; then
    cp -n "$CONF" "$CONF.jeiko.bak" 2>/dev/null || true

    set_directive() {
        local flag="$1" value="$2"
        if grep -qE "^\s*${flag}\s" "$CONF"; then
            sed -ri "s|^\s*${flag}\s+.*|${flag} ${value}|" "$CONF"
        else
            echo "${flag} ${value}" >>"$CONF"
        fi
    }

    set_directive '-l' '127.0.0.1'   # écoute locale uniquement
    set_directive '-m' '128'         # 128 Mo de cache
    set_directive '-c' '1024'        # connexions simultanées
    set_directive '-U' '0'           # UDP coupé : vecteur d'amplification DDoS
fi

# Le site qu'on installe aura le sien (jeiko_memcached_du_site). Le commun ne
# reste allumé que si un autre projet du serveur peut encore en dépendre.
if ! jeiko_memcached_commun_utile "${SITE_NAME:-}"; then
    systemctl disable --now memcached >/dev/null 2>&1 || true
    jeiko_ok "Memcached commun éteint : chaque site a le sien (aucun autre projet n'en dépend)."
    exit 0
fi

systemctl enable --now memcached
systemctl restart memcached

sleep 1
if ss -lnt | grep -q '127\.0\.0\.1:11211'; then
    jeiko_ok "Memcached commun actif sur 127.0.0.1:11211 (non exposé) : un autre projet du serveur s'en sert encore."
else
    jeiko_die "Memcached ne répond pas sur 127.0.0.1:11211."
fi

# Cette instance commune ne sert plus qu'aux sites dont le paquet ne lit pas
# encore JEIKO_MEMCACHED : chaque site a désormais la sienne, sous son compte
# (jeiko_memcached_du_site, étape 10 — IG-01).
