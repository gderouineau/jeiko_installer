#!/bin/bash
set -euo pipefail

echo "💾 [13_backups.sh] Backups (DB + media + conf) + cron…"

if [[ -z "${SITE_NAME:-}" || -z "${BASE_DIR:-}" || -z "${DB_NAME:-}" || -z "${DB_USER:-}" || -z "${DB_PASS:-}" ]]; then
  echo "❌ Variables requises manquantes (SITE_NAME, BASE_DIR, DB_*)."; exit 1
fi

BACKUP_DIR="/var/backups/jeiko/$SITE_NAME"
SCRIPT_PATH="/usr/local/bin/jeiko_backup_${SITE_NAME}.sh"
PROJECT_DIR="$BASE_DIR/$SITE_NAME"
MEDIA_DIR="$PROJECT_DIR/mediadir"
ENV_FILE="$PROJECT_DIR/$SITE_NAME/.env"
NGX_AVAIL_DIR="/etc/nginx/sites-available"

mkdir -p "$BACKUP_DIR"
chmod 750 "$BACKUP_DIR"
chown root:root "$BACKUP_DIR"

cat > "$SCRIPT_PATH" <<EOF
#!/bin/bash
set -euo pipefail

TS=\$(date +"%Y%m%d_%H%M%S")
DEST="$BACKUP_DIR/\$TS"
mkdir -p "\$DEST"

export PGPASSWORD="$DB_PASS"
pg_dump -h localhost -U "$DB_USER" -d "$DB_NAME" -F c -f "\$DEST/${DB_NAME}_dump.dump"

tar -czf "\$DEST/media.tar.gz" -C "$MEDIA_DIR" .
tar -czf "\$DEST/env_and_conf.tar.gz" "$ENV_FILE" "$NGX_AVAIL_DIR/${SITE_NAME}.conf" 2>/dev/null || true

# rotation simple: garder 30 archives
cd "$BACKUP_DIR"
ls -1dt */ 2>/dev/null | tail -n +31 | xargs -r rm -rf
EOF

chmod 700 "$SCRIPT_PATH"

# Cron quotidien à 03:17
CRON_FILE="/etc/cron.d/jeiko-backup-${SITE_NAME}"
cat > "$CRON_FILE" <<EOF
# Backups JEIKO pour $SITE_NAME
17 3 * * * root $SCRIPT_PATH >/var/log/jeiko_backup_${SITE_NAME}.log 2>&1
EOF
chmod 644 "$CRON_FILE"

echo "✅ Backups configurés. Script: $SCRIPT_PATH | Dossier: $BACKUP_DIR"
