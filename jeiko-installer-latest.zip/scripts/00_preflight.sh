#!/bin/bash
set -euo pipefail

echo "🔎 [00_preflight.sh] Pré-vol & vérifications…"

# 1) Root + apt + systemd
if [[ $EUID -ne 0 ]]; then
    echo "❌ Ce script doit être exécuté en root (sudo)."; exit 1
fi
if ! command -v apt-get >/dev/null 2>&1; then
    echo "❌ Système non Debian/Ubuntu (apt-get introuvable)."; exit 1
fi
if ! pidof systemd >/dev/null 2>&1; then
    echo "❌ systemd requis."; exit 1
fi

# 2) Infos système
DEBIAN_CODENAME=$(grep -oP '(?<=VERSION_CODENAME=).*' /etc/os-release || true)
ARCH=$(uname -m)
CPU=$(nproc)
RAM_MB=$(awk '/MemTotal/ {print int($2/1024)}' /proc/meminfo)
DISK_ROOT=$(df -h / | awk 'NR==2{print $4}')

echo "ℹ️ Debian: ${DEBIAN_CODENAME:-inconnue} | Arch: $ARCH | CPU: $CPU | RAM: ${RAM_MB}MB | Disk free /: $DISK_ROOT"

# 3) DNS domaine (avertissement seulement)
if [[ -n "${DOMAIN_NAME:-}" ]]; then
    if getent hosts "$DOMAIN_NAME" >/dev/null 2>&1; then
        echo "✅ Résolution DNS OK pour $DOMAIN_NAME"
    else
        echo "⚠️ Avertissement: $DOMAIN_NAME ne résout pas encore (OK si DNS pas propagé)."
    fi
fi

# 4) Ports web libres ? (avertissement)
for p in 80 443; do
    if ss -lnt "( sport = :$p )" | grep -q ":$p"; then
        echo "⚠️ Port $p déjà occupé (c'est peut-être Nginx si présent)."
    fi
done

# 5) Variables dérivées communes (à re-calculer dans chaque script)
echo "ℹ️ SITE_NAME=$SITE_NAME | DOMAIN_NAME=$DOMAIN_NAME | BASE_DIR=$BASE_DIR"
echo "ℹ️ Preflight OK."
