#!/bin/bash
set -euo pipefail

echo "🔐 [12_setup_tls_letsencrypt.sh] Obtention certificats + vhost HTTPS complet…"

: "${BASE_DIR:?BASE_DIR manquant}"
: "${SITE_NAME:?SITE_NAME manquant}"
: "${DOMAIN_NAME:?DOMAIN_NAME manquant}"

NGX_AVAIL_DIR="/etc/nginx/sites-available"
NGX_ENABLE_DIR="/etc/nginx/sites-enabled"
FINAL_CONF="$NGX_AVAIL_DIR/${SITE_NAME}.conf"

PROJECT_DIR="$BASE_DIR/$SITE_NAME"
STATIC_ROOT="$PROJECT_DIR/staticdir"
MEDIA_ROOT="$PROJECT_DIR/mediadir"

# Doit correspondre à 10_configure_gunicorn.sh
SOCKET_PATH="/run/gunicorn-$SITE_NAME/gunicorn.sock"

# Apex (ex: exemple.com) => gérer redirection www -> apex
WWW_REDIRECT=0
if [[ "$DOMAIN_NAME" =~ ^[^.]+\.[^.]+$ ]]; then
  WWW_REDIRECT=1
fi

apt-get update -y
apt-get install -y certbot python3-certbot-nginx

DOM_ARGS="-d $DOMAIN_NAME"
if [[ $WWW_REDIRECT -eq 1 ]]; then
  DOM_ARGS="$DOM_ARGS -d www.$DOMAIN_NAME"
fi

# Obtenir/renouveler le certificat sans modifier la conf Nginx
certbot certonly --nginx --non-interactive --agree-tos -m "admin@$DOMAIN_NAME" $DOM_ARGS

CRT="/etc/letsencrypt/live/$DOMAIN_NAME/fullchain.pem"
KEY="/etc/letsencrypt/live/$DOMAIN_NAME/privkey.pem"
if [[ ! -f "$CRT" || ! -f "$KEY" ]]; then
  echo "❌ Certificats non trouvés. ($CRT / $KEY)"; exit 1
fi

# Écrire la conf HTTPS finale (échapper les variables Nginx)
cat > "$FINAL_CONF" <<EOF
# ${SITE_NAME} — configuration finale HTTPS

# Redirections HTTP (80) → HTTPS
EOF

if [[ $WWW_REDIRECT -eq 1 ]]; then
cat >> "$FINAL_CONF" <<EOF
server {
    listen 80;
    listen [::]:80;
    server_name www.$DOMAIN_NAME;
    return 301 https://$DOMAIN_NAME\$request_uri;
}
server {
    listen 80;
    listen [::]:80;
    server_name $DOMAIN_NAME;
    return 301 https://$DOMAIN_NAME\$request_uri;
}
EOF
else
cat >> "$FINAL_CONF" <<EOF
server {
    listen 80;
    listen [::]:80;
    server_name $DOMAIN_NAME;
    return 301 https://\$host\$request_uri;
}
EOF
fi

# Redirection HTTPS (443) pour www -> apex si apex
if [[ $WWW_REDIRECT -eq 1 ]]; then
cat >> "$FINAL_CONF" <<EOF
server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name www.$DOMAIN_NAME;

    ssl_certificate     $CRT;
    ssl_certificate_key $KEY;

    return 301 https://$DOMAIN_NAME\$request_uri;
}
EOF
fi

# Serveur principal 443
cat >> "$FINAL_CONF" <<EOF
server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name $DOMAIN_NAME;

    ssl_certificate     $CRT;
    ssl_certificate_key $KEY;

    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains; preload" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;
    add_header Permissions-Policy "accelerometer=(), geolocation=(), camera=(), microphone=()" always;

    location /static/ {
        alias $STATIC_ROOT/;
        try_files \$uri =404;
        add_header Cache-Control "public, max-age=31536000, immutable";
        expires 1y;
    }

    location /media/ {
        alias $MEDIA_ROOT/;
        try_files \$uri =404;
        add_header Cache-Control "public, max-age=31536000, immutable";
        expires 1y;
    }

    location / {
        include proxy_params;
        proxy_set_header Host \$host;
        proxy_set_header X-Forwarded-Host \$host;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_read_timeout 60s;
        proxy_connect_timeout 60s;
        proxy_pass http://unix:$SOCKET_PATH;
        add_header Cache-Control "no-cache, no-store, must-revalidate";
    }

    gzip on;
    gzip_types text/plain text/css application/javascript application/json image/svg+xml font/woff2;
}
EOF

ln -sfn "$FINAL_CONF" "$NGX_ENABLE_DIR/$SITE_NAME.conf"

# Test & (re)start/reload
if ! nginx -t; then
  echo "❌ nginx -t a échoué. Infos rapides :"
  ls -l /etc/nginx/sites-enabled/ || true
  echo "--- Contenu $FINAL_CONF"
  sed -n '1,200p' "$FINAL_CONF" || true
  exit 1
fi

if systemctl is-active --quiet nginx; then
  systemctl reload nginx
else
  systemctl start nginx
fi

# s'assurer du renouvellement auto
systemctl enable --now certbot.timer || true

echo "✅ TLS actif pour $DOMAIN_NAME (socket: $SOCKET_PATH)"
