#!/bin/bash
set -euo pipefail

echo "🛠️ [11_configure_nginx.sh] Configuration Nginx (HTTP prêt pour Certbot)…"

: "${BASE_DIR:?BASE_DIR manquant}"
: "${SITE_NAME:?SITE_NAME manquant}"
: "${DOMAIN_NAME:?DOMAIN_NAME manquant}"

NGX_AVAIL="/etc/nginx/sites-available/$SITE_NAME.conf"
NGX_ENABLED="/etc/nginx/sites-enabled/$SITE_NAME.conf"

PROJECT_DIR="$BASE_DIR/$SITE_NAME"
STATIC_ROOT="$PROJECT_DIR/staticdir"
MEDIA_ROOT="$PROJECT_DIR/mediadir"

# Doit correspondre à 10_configure_gunicorn.sh
SOCKET_PATH="/run/gunicorn-$SITE_NAME/gunicorn.sock"

# Apex (ex: domaine.tld) => inclure www ; sinon (sous-domaine) juste FQDN
if [[ "$DOMAIN_NAME" =~ ^[^.]+\.[^.]+$ ]]; then
  SERVER_NAMES="$DOMAIN_NAME www.$DOMAIN_NAME"
else
  SERVER_NAMES="$DOMAIN_NAME"
fi

# Répertoire pour défis ACME, si absent
mkdir -p /var/www/html

cat > "$NGX_AVAIL" <<EOF
server {
    listen 80;
    listen [::]:80;
    server_name $SERVER_NAMES;

    # Défis ACME (Let's Encrypt)
    location ^~ /.well-known/acme-challenge/ {
        default_type "text/plain";
        root /var/www/html;
    }

    location /static/ {
        alias $STATIC_ROOT/;
        try_files \$uri =404;
        add_header Cache-Control "public, max-age=31536000, immutable";
        expires 1y;
    }

    location /media/ {
        alias $MEDIA_ROOT/;
        try_files \$uri =404;
        add_header Cache-Control "public, max-age=31536000, immutable";
        expires 1y;
    }

    location / {
        include proxy_params;
        proxy_set_header Host \$host;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_read_timeout 60s;
        proxy_connect_timeout 60s;
        proxy_pass http://unix:$SOCKET_PATH;
        proxy_set_header X-Forwarded-Host \$host;
        add_header Cache-Control "no-cache, no-store, must-revalidate";
    }

    gzip on;
    gzip_types text/plain text/css application/javascript application/json image/svg+xml font/woff2;
}
EOF

# Désactiver site par défaut
rm -f /etc/nginx/sites-enabled/default || true

# Activer ce vhost (lien propre)
rm -f "$NGX_ENABLED" || true
ln -s "$NGX_AVAIL" "$NGX_ENABLED"

# Test conf
if ! nginx -t; then
  echo "❌ nginx -t a échoué. Infos rapides :"
  ls -l /etc/nginx/sites-enabled/ || true
  echo "--- Contenu $NGX_ENABLED"
  sed -n '1,200p' "$NGX_ENABLED" || true
  exit 1
fi

# Démarrer si inactif, sinon recharger
if systemctl is-active --quiet nginx; then
  systemctl reload nginx
else
  systemctl start nginx
fi

echo "✅ Nginx HTTP configuré pour $SERVER_NAMES (socket: $SOCKET_PATH)"
