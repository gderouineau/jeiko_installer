#!/bin/bash
set -euo pipefail

echo "🌐 [11_configure_nginx.sh] Vhosts Nginx (HTTP initial + prêt pour HTTPS)…"

if [[ -z "${BASE_DIR:-}" || -z "${SITE_NAME:-}" || -z "${DOMAIN_NAME:-}" ]]; then
  echo "❌ Variables requises manquantes (BASE_DIR, SITE_NAME, DOMAIN_NAME)."; exit 1
fi

NGX_AVAIL_DIR="/etc/nginx/sites-available"
NGX_ENABLE_DIR="/etc/nginx/sites-enabled"
PROJECT_DIR="$BASE_DIR/$SITE_NAME"
STATIC_ROOT="$PROJECT_DIR/staticdir"
MEDIA_ROOT="$PROJECT_DIR/mediadir"
SOCKET_PATH="/run/gunicorn-$SITE_NAME.sock"

# Détecter sous-domaine
IS_SUBDOMAIN=0
if [[ "$DOMAIN_NAME" =~ ^([a-z0-9-]+)\.([a-z0-9-]+)\.([a-z]+)$ ]]; then
  # ex: blog.exemple.com → sous-domaine
  IS_SUBDOMAIN=1
fi

HTTP_CONF="$NGX_AVAIL_DIR/${SITE_NAME}_pressl.conf"
FINAL_CONF="$NGX_AVAIL_DIR/${SITE_NAME}.conf"

# 1) HTTP direct (pré-SSL) — on sert l'appli en HTTP dans un premier temps
cat > "$HTTP_CONF" <<EOF
# ${SITE_NAME} - HTTP temporaire (avant TLS)
server {
    listen 80;
    listen [::]:80;
    server_name ${IS_SUBDOMAIN==1 && echo "$DOMAIN_NAME" || echo "$DOMAIN_NAME www.$DOMAIN_NAME"};

    # Static
    location /static/ {
        alias $STATIC_ROOT/;
        try_files \$uri =404;
        add_header Cache-Control "public, max-age=31536000, immutable";
        expires 1y;
    }

    # Media
    location /media/ {
        alias $MEDIA_ROOT/;
        try_files \$uri =404;
        add_header Cache-Control "public, max-age=31536000, immutable";
        expires 1y;
    }

    # App
    location / {
        include proxy_params;
        proxy_set_header Host \$host;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_read_timeout 60s;
        proxy_connect_timeout 60s;
        proxy_pass http://unix:$SOCKET_PATH;
        add_header Cache-Control "no-cache, no-store, must-revalidate";
    }

    # gzip
    gzip on;
    gzip_types text/plain text/css application/javascript application/json image/svg+xml font/woff2;
}
EOF

ln -sfn "$HTTP_CONF" "$NGX_ENABLE_DIR/$SITE_NAME.conf"
nginx -t && systemctl reload nginx

# 2) Final HTTPS conf (écrit maintenant mais activé par 12_setup_tls_letsencrypt.sh)
cat > "$FINAL_CONF" <<'EOF'
# REPLACED_AT_RUNTIME
EOF

# On le remplira en 12_setup_tls_letsencrypt.sh (pour injecter les chemins certs + redirs).
echo "✅ Nginx HTTP prêt. HTTPS sera activé à l'étape 12."
