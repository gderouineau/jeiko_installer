#!/bin/bash
set -euo pipefail

echo "📦 [08_install_jeiko_package.sh] Installation du package JEIKO (+ deps)…"

: "${BASE_DIR:?BASE_DIR manquant}"
: "${SITE_NAME:?SITE_NAME manquant}"

PROJECT_DIR="$BASE_DIR/$SITE_NAME"
VENV_DIR="$PROJECT_DIR/venv"
SITE_USER="jeiko-$SITE_NAME"

ZIP_URL="https://github.com/gderouineau/jeiko/raw/refs/heads/main/jeiko-latest.zip"
TMP_ZIP="/tmp/jeiko_latest.zip"
TMP_EXTRACT="/tmp/jeiko_extracted"

# 0) Sanity
if [[ ! -d "$VENV_DIR" ]]; then
  echo "❌ venv introuvable ($VENV_DIR). Exécute d'abord 07_install_python_env.sh."; exit 1
fi

# 1) Activer le venv
source "$VENV_DIR/bin/activate"

# 2) Télécharger l’archive du package (RAW)
echo "🔽 Téléchargement du package JEIKO…"
curl -fsSL "$ZIP_URL" -o "$TMP_ZIP"

# 3) Extraire
echo "📂 Extraction…"
rm -rf "$TMP_EXTRACT"
mkdir -p "$TMP_EXTRACT"
unzip -oq "$TMP_ZIP" -d "$TMP_EXTRACT"

# 4) Trouver le dossier contenant pyproject.toml (racine du package)
PACKAGE_DIR=$(find "$TMP_EXTRACT" -name "pyproject.toml" -exec dirname {} \; | head -n 1)
if [[ -z "$PACKAGE_DIR" ]]; then
    echo "❌ Impossible de localiser le dossier du package (pyproject.toml manquant)"; exit 1
fi
echo "📍 PACKAGE_DIR=$PACKAGE_DIR"

# 5) Installer des dépendances optionnelles si un requirements.txt est fourni
REQ_FILE=$(find "$PACKAGE_DIR" -maxdepth 2 -name "requirements.txt" | head -n 1 || true)
if [[ -n "${REQ_FILE:-}" && -f "$REQ_FILE" ]]; then
    echo "📥 Installation deps JEIKO (requirements.txt)…"
    pip install --no-cache-dir -r "$REQ_FILE"
else
    echo "ℹ️ Aucun requirements.txt spécifique au package."
fi

# 6) Installer le package JEIKO directement (pip gère le build PEP517 si besoin)
echo "🛠️ Installation du package JEIKO (pip install $PACKAGE_DIR)…"
pip install --no-cache-dir --force-reinstall "$PACKAGE_DIR"

# 7) Placer le script d’update dans le dossier projet (priorité à celui fourni par le package)
UPDATE_DST="$PROJECT_DIR/update_jeiko.sh"

# Essayer de localiser le script dans le package installé
PKG_UPDATE_PATH=$(python - <<'PY'
import os, sys, importlib.util
try:
    import jeiko
    base = os.path.dirname(jeiko.__file__)
    cand = os.path.join(base, "scripts", "update_jeiko.sh")
    print(cand if os.path.isfile(cand) else "")
except Exception:
    print("")
PY
)

if [[ -n "$PKG_UPDATE_PATH" && -f "$PKG_UPDATE_PATH" ]]; then
    cp "$PKG_UPDATE_PATH" "$UPDATE_DST"
else
    # Sinon, s'il existe une copie locale dans le dossier scripts de l’installer
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    LOCAL_UPDATE="$SCRIPT_DIR/update_jeiko.sh"
    if [[ -f "$LOCAL_UPDATE" ]]; then
        cp "$LOCAL_UPDATE" "$UPDATE_DST"
    fi
fi

if [[ -f "$UPDATE_DST" ]]; then
    chown "$SITE_USER":www-data "$UPDATE_DST"
    chmod 750 "$UPDATE_DST"
    echo "✅ Script update_jeiko.sh installé dans le projet."
else
    echo "ℹ️ Aucun update_jeiko.sh trouvé dans le package ni en local."
fi

# 8) Nettoyage
echo "🧹 Nettoyage des temporaires…"
rm -rf "$TMP_ZIP" "$TMP_EXTRACT"

echo "✅ JEIKO installé avec succès."
