#!/bin/bash
set -euo pipefail

echo "📦 [08_install_jeiko_package.sh] Installation du package JEIKO (+ deps)…"

: "${BASE_DIR:?BASE_DIR manquant}"
: "${SITE_NAME:?SITE_NAME manquant}"

PROJECT_DIR="$BASE_DIR/$SITE_NAME"
VENV_DIR="$PROJECT_DIR/venv"
SITE_USER="jeiko-$SITE_NAME"

ZIP_URL="https://github.com/gderouineau/jeiko/raw/refs/heads/main/jeiko-latest.zip"
TMP_ZIP="/tmp/jeiko_latest.zip"
TMP_EXTRACT="/tmp/jeiko_extracted"

source "$VENV_DIR/bin/activate"

# 1) Télécharger
curl -fsSL "$ZIP_URL" -o "$TMP_ZIP"

# 2) Extraire
rm -rf "$TMP_EXTRACT"
mkdir -p "$TMP_EXTRACT"
unzip -oq "$TMP_ZIP" -d "$TMP_EXTRACT"

# 3) Trouver pyproject.toml
PACKAGE_DIR=$(find "$TMP_EXTRACT" -name "pyproject.toml" -exec dirname {} \; | head -n 1)
[[ -z "$PACKAGE_DIR" ]] && { echo "❌ pyproject.toml introuvable"; exit 1; }

# 4) Installer deps optionnels si un requirements.txt existe dans le package
REQ_FILE=$(find "$PACKAGE_DIR" -maxdepth 2 -name "requirements.txt" | head -n 1)
if [[ -n "$REQ_FILE" ]]; then
    echo "📥 Installation deps JEIKO (requirements.txt)…"
    pip install -r "$REQ_FILE"
fi

# 5) Build du wheel
python -m pip install --quiet build
python -m build -q -C--global-option=--quiet "$PACKAGE_DIR" >/dev/null

DIST_DIR="$PACKAGE_DIR/dist"
WHEEL_FILE=$(ls "$DIST_DIR"/*.whl 2>/dev/null | head -n 1)
TAR_FILE=$(ls "$DIST_DIR"/*.tar.gz 2>/dev/null | head -n 1)
[[ -z "$WHEEL_FILE" && -z "$TAR_FILE" ]] && { echo "❌ Aucun artefact de build trouvé"; exit 1; }

# 6) Install JEIKO
if [[ -n "$WHEEL_FILE" ]]; then
    pip install --force-reinstall --no-cache-dir "$WHEEL_FILE"
else
    pip install --force-reinstall --no-cache-dir "$TAR_FILE"
fi

# 7) Copier le script update côté projet (pour exécution depuis l’admin)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
UPDATE_SRC="$SCRIPT_DIR/update_jeiko.sh"  # si tu gardes une copie ici
UPDATE_DST="$PROJECT_DIR/update_jeiko.sh"

# Priorité: si le package fournit un update script, on le préfère
PKG_UPDATE=$(python -c "import importlib.util, pkgutil, sys; import jeiko, os; p=getattr(jeiko,'__file__',None); print(os.path.join(os.path.dirname(p),'scripts','update_jeiko.sh') if p else '')" || true)
if [[ -n "$PKG_UPDATE" && -f "$PKG_UPDATE" ]]; then
    cp "$PKG_UPDATE" "$UPDATE_DST"
elif [[ -f "$UPDATE_SRC" ]]; then
    cp "$UPDATE_SRC" "$UPDATE_DST"
fi

if [[ -f "$UPDATE_DST" ]]; then
    chown "$SITE_USER":www-data "$UPDATE_DST"
    chmod 750 "$UPDATE_DST"
    echo "✅ update_jeiko.sh installé dans le projet."
else
    echo "ℹ️ Aucun update_jeiko.sh trouvé (package/scripts)."
fi

# 8) Nettoyage
rm -rf "$TMP_ZIP" "$TMP_EXTRACT"

echo "✅ JEIKO installé."
