#!/bin/bash

set -e

echo "🛠️ [configure_nginx.sh] Configuration de Nginx et HTTPS..."

NGINX_AVAILABLE="/etc/nginx/sites-available/$SITE_NAME"
NGINX_ENABLED="/etc/nginx/sites-enabled/$SITE_NAME"
GUNICORN_SOCKET="unix:/run/gunicorn-$SITE_NAME.sock"
STATIC_ROOT="$BASE_DIR/$SITE_NAME/staticdir"
MEDIA_ROOT="$BASE_DIR/$SITE_NAME/mediadir"

# Créer le fichier de configuration Nginx
cat > "$NGINX_AVAILABLE" <<EOF
server {
    listen 80;
    server_name $DOMAIN_NAME www.$DOMAIN_NAME;

    location /static/ {
        alias $STATIC_ROOT/;
    }

    location /media/ {
        alias $MEDIA_ROOT/;
    }

    location / {
        include proxy_params;
        proxy_pass http://unix:/run/gunicorn-$SITE_NAME.sock;
    }
}
EOF

ln -sf "$NGINX_AVAILABLE" "$NGINX_ENABLED"

# Test de config Nginx
nginx -t

# Relancer Nginx
systemctl reload nginx

echo "🔐 Installation du certificat HTTPS avec Let's Encrypt..."
certbot --nginx --expand --non-interactive --agree-tos -m admin@$DOMAIN_NAME -d "$DOMAIN_NAME" -d "www.$DOMAIN_NAME"

# Créer un timer pour renouveler automatiquement le certificat
cat > /etc/systemd/system/certbot-renew.timer <<EOF
[Unit]
Description=Renew Let's Encrypt certificates daily

[Timer]
OnCalendar=daily
Persistent=true

[Install]
WantedBy=timers.target
EOF

cat > /etc/systemd/system/certbot-renew.service <<EOF
[Unit]
Description=Renew Let's Encrypt certificates

[Service]
Type=oneshot
ExecStart=/usr/bin/certbot renew --quiet
EOF

systemctl daemon-reexec
systemctl daemon-reload
systemctl enable certbot-renew.timer
systemctl start certbot-renew.timer

# Reload Nginx again to ensure HTTPS is active
systemctl reload nginx

echo "✅ Nginx et HTTPS configurés pour $DOMAIN_NAME"
