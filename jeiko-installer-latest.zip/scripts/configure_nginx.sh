#!/bin/bash

set -e

echo "🛠️ [configure_nginx.sh] Configuration de Nginx et HTTPS..."

NGINX_AVAILABLE="/etc/nginx/sites-available/$SITE_NAME"
NGINX_ENABLED="/etc/nginx/sites-enabled/$SITE_NAME"
GUNICORN_SOCKET="unix:/run/gunicorn-$SITE_NAME.sock"
STATIC_ROOT="$BASE_DIR/$SITE_NAME/staticdir"
MEDIA_ROOT="$BASE_DIR/$SITE_NAME/mediadir"

# ───────────────────────────────────────────────
# Déterminer si le domaine est un sous-domaine
# ───────────────────────────────────────────────
if [[ "$DOMAIN_NAME" =~ ^([a-z0-9-]+)\.([a-z0-9-]+)\.([a-z]+)$ ]]; then
    echo "🌐 Domaine détecté comme sous-domaine : $DOMAIN_NAME"
    NGINX_SERVER_NAME="$DOMAIN_NAME"
    CERTBOT_DOMAINS="-d $DOMAIN_NAME"
else
    echo "🌐 Domaine principal : $DOMAIN_NAME (avec www)"
    NGINX_SERVER_NAME="$DOMAIN_NAME www.$DOMAIN_NAME"
    CERTBOT_DOMAINS="-d $DOMAIN_NAME -d www.$DOMAIN_NAME"
fi

# ───────────────────────────────────────────────
# Génération du fichier de conf Nginx
# ───────────────────────────────────────────────
cat > "$NGINX_AVAILABLE" <<EOF
server {
    listen 80;
    server_name $NGINX_SERVER_NAME;

    location /static/ {
        alias $STATIC_ROOT/;
    }

    location /media/ {
        alias $MEDIA_ROOT/;
    }

    location / {
        include proxy_params;
        proxy_pass http://$GUNICORN_SOCKET;
    }
}
EOF

ln -sf "$NGINX_AVAILABLE" "$NGINX_ENABLED"

# Test de la configuration
nginx -t

# Redémarrage de Nginx
systemctl reload nginx

# ───────────────────────────────────────────────
# Installation Let's Encrypt
# ───────────────────────────────────────────────
echo "🔐 Installation du certificat HTTPS avec Let's Encrypt..."
certbot --nginx --expand --non-interactive --agree-tos -m admin@$DOMAIN_NAME $CERTBOT_DOMAINS

# ───────────────────────────────────────────────
# Timer pour le renouvellement auto
# ───────────────────────────────────────────────
cat > /etc/systemd/system/certbot-renew.timer <<EOF
[Unit]
Description=Renew Let's Encrypt certificates daily

[Timer]
OnCalendar=daily
Persistent=true

[Install]
WantedBy=timers.target
EOF

cat > /etc/systemd/system/certbot-renew.service <<EOF
[Unit]
Description=Renew Let's Encrypt certificates

[Service]
Type=oneshot
ExecStart=/usr/bin/certbot renew --quiet
EOF

systemctl daemon-reexec
systemctl daemon-reload
systemctl enable certbot-renew.timer
systemctl start certbot-renew.timer

# Reload Nginx to apply HTTPS
systemctl reload nginx

echo "✅ Nginx et HTTPS configurés pour $NGINX_SERVER_NAME"
