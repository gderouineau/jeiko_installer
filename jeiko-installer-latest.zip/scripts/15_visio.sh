#!/bin/bash
###############################################################################
# 15 — La visio (VISIO-01) : LiveKit sur la machine, la clé du site.
#
# Le besoin (Guillaume, 12/10/2026) : « je ne dois pas avoir à modifier quoi
# que ce soit » et « l'activer depuis le site, sans aller sur le serveur ».
# Cette étape tourne donc à l'installation ET à chaque convergence
# (jeiko-server-update, la mise à jour hebdomadaire jeiko-maj, la mise à jour
# du serveur demandée depuis un site) : quand l'exploitant coche « Conférence »
# dans Réglages, tout est déjà là.
#
# Ce qu'elle fait, idempotent :
#   1. le binaire livekit-server, version FIXÉE et empreinte vérifiée ;
#   2. un compte système « livekit », sans shell ni maison ;
#   3. la clé du site (JEIKO_VISIO_CLE / JEIKO_VISIO_SECRET), créée dans son
#      .env si elle manque ;
#   4. UN LIVEKIT PAR SITE (VISIO-04, audit V-09) : livekit@<site>.service,
#      sa configuration et SON seul fichier de clés sous /etc/livekit/sites/<site>/.
#      Un LiveKit commun à plusieurs sites laissait la clé de l'un
#      administrer les salles des autres. Ses ports viennent du rang du site
#      (jeiko_visio_ports) ; le .env reçoit JEIKO_VISIO_API vers SON port.
#      L'ancien LiveKit commun (livekit.service) est arrêté et retiré ;
#   5. le relais TURN du site sur SON domaine, s'il a un certificat (aucun DNS
#      ni sous-domaine) — certificat recopié pour LiveKit, et à chaque
#      renouvellement par un crochet certbot ;
#   6. le pare-feu : les ports RTC et relais du site. La signalisation
#      n'écoute QUE 127.0.0.1 : nginx la relaie sous
#      https://<domaine>/visio-rtc/ (11_configure_nginx.sh).
#
# Ce qu'elle ne fait pas : toucher au SSH (règle de Guillaume) ; activer la
# visio d'un site — c'est la case « Conférence », dans son administration.
# Un échec ici n'arrête ni l'installation ni la convergence du site : la visio
# manque, le site tourne (l'écran « Serveur de visio » le dit).
#
# Limite connue : un réseau d'entreprise qui n'ouvre QUE le 443 en sortie ne
# joint ni le 5349 ni l'UDP — il faudrait alors un relais dédié sur le 443.
###############################################################################
set -euo pipefail
# shellcheck source=/usr/local/lib/jeiko/common.sh
source /usr/local/lib/jeiko/common.sh

jeiko_step "[15] Visio (LiveKit)"
jeiko_require_root

: "${SITE_NAME:?SITE_NAME manquant}"
: "${PROJECT_DIR:?PROJECT_DIR manquant}"
: "${SITE_USER:?SITE_USER manquant}"
: "${DOMAIN_NAME:?DOMAIN_NAME manquant}"

LIVEKIT_VERSION="1.13.8"
# checksums.txt de la publication v1.13.8 (github.com/livekit/livekit),
# relevé le 12/10/2026. Changer de version, c'est changer les deux lignes.
declare -A LIVEKIT_SHA256=(
    [amd64]="059f6de65da11a57400e4646027da705d592ce42acb48c08570a397df446f869"
    [arm64]="39883cb07f370057692139fcf500a763cfedae1e9934bd8a1815a144e2127bd2"
)

BIN="${JEIKO_LIVEKIT_BIN:-/usr/local/bin/livekit-server}"
ETC="${JEIKO_LIVEKIT_ETC:-/etc/livekit}"
UNIT="/etc/systemd/system/livekit@.service"
ANCIENNE_UNIT="/etc/systemd/system/livekit.service"
HOOK="/etc/letsencrypt/renewal-hooks/deploy/jeiko-livekit"
ENV_PATH="$PROJECT_DIR/$SITE_NAME/.env"
change=0

# --------------------------------------------------------------------------- #
# 1) Le binaire
# --------------------------------------------------------------------------- #
installee="$("$BIN" --version 2>/dev/null | awk '{print $NF}' || true)"
if [[ "$installee" != "$LIVEKIT_VERSION" ]]; then
    arch="$(dpkg --print-architecture 2>/dev/null || uname -m)"
    [[ "$arch" == "x86_64" ]] && arch="amd64"
    [[ "$arch" == "aarch64" ]] && arch="arm64"
    empreinte="${LIVEKIT_SHA256[$arch]:-}"
    [[ -n "$empreinte" ]] || jeiko_die "Architecture « $arch » non prise en charge par la visio."
    tmp="$(mktemp -d /tmp/jeiko-livekit.XXXXXX)"
    trap 'rm -rf "$tmp"' EXIT
    jeiko_download \
        "https://github.com/livekit/livekit/releases/download/v${LIVEKIT_VERSION}/livekit_${LIVEKIT_VERSION}_linux_${arch}.tar.gz" \
        "$tmp/livekit.tar.gz" || jeiko_die "Téléchargement de LiveKit impossible."
    jeiko_verify_sha256 "$tmp/livekit.tar.gz" "$empreinte" || jeiko_die "LiveKit refusé : empreinte incorrecte."
    tar -xzf "$tmp/livekit.tar.gz" -C "$tmp" livekit-server
    # Un vrai fichier : « install » suivrait un lien et copierait sa cible.
    [[ -f "$tmp/livekit-server" && ! -L "$tmp/livekit-server" ]] \
        || jeiko_die "LiveKit refusé : livekit-server n'est pas un fichier ordinaire dans l'archive."
    install -m 0755 -o root -g root "$tmp/livekit-server" "$BIN"
    jeiko_ok "LiveKit $LIVEKIT_VERSION installé (${installee:-absent} auparavant)"
    change=1
fi

# --------------------------------------------------------------------------- #
# 2) Le compte, les dossiers, et la fin du LiveKit commun
# --------------------------------------------------------------------------- #
if ! id livekit >/dev/null 2>&1; then
    useradd --system --no-create-home --home-dir /nonexistent --shell /usr/sbin/nologin livekit
fi
install -d -m 0750 -o root -g livekit "$ETC" "$ETC/sites"
SITE_ETC="$ETC/sites/$SITE_NAME"
install -d -m 0750 -o root -g livekit "$SITE_ETC" "$SITE_ETC/tls"

# Avant VISIO-04 : un seul LiveKit, toutes les clés dans un fichier. Il est
# arrêté (il tient le port 7880, celui du rang 0) et retiré ; chaque site
# retrouve sa visio à sa propre convergence — `jeiko-server-update --all` les
# enchaîne.
if [[ -f "$ANCIENNE_UNIT" ]]; then
    systemctl disable --now livekit.service >/dev/null 2>&1 || true
    rm -f "$ANCIENNE_UNIT" "$ETC/livekit.yaml" "$ETC/keys.yaml" "$ETC/turn-domaine"
    rm -rf "$ETC/keys.d" "$ETC/tls"
    systemctl daemon-reload
    jeiko_ok "Ancien LiveKit commun retiré : un LiveKit par site désormais"
fi

read -r P_SIGNAL P_TCP P_UDP P_TURN_UDP P_TURN_TLS < <(jeiko_visio_ports "$SITE_NAME") \
    || jeiko_die "Plus de rang libre pour la visio sur cette machine (100 sites)."

# --------------------------------------------------------------------------- #
# 3) La clé du site — et l'adresse de SON LiveKit
# --------------------------------------------------------------------------- #
[[ -L "$ENV_PATH" ]] && jeiko_die ".env est un lien symbolique ($ENV_PATH) : refusé."
[[ -f "$ENV_PATH" ]] || jeiko_die ".env introuvable : $ENV_PATH"

lire_env() {
    jeiko_as_site "$SITE_USER" sed -nE "s/^[[:space:]]*$1[[:space:]]*=[[:space:]]*\"?([^\"]*)\"?[[:space:]]*$/\1/p" \
        -- "$ENV_PATH" | tail -n 1
}

cle="$(lire_env JEIKO_VISIO_CLE)"
secret="$(lire_env JEIKO_VISIO_SECRET)"
if [[ -z "$cle" || -z "$secret" ]]; then
    cle="jeiko-$SITE_NAME"
    secret="$(openssl rand -hex 32)"
    jeiko_site_a_la_cle "$SITE_USER" "$ENV_PATH" JEIKO_VISIO_CLE \
        || jeiko_site_ajouter "$SITE_USER" "$ENV_PATH" "JEIKO_VISIO_CLE=\"$cle\""
    jeiko_site_a_la_cle "$SITE_USER" "$ENV_PATH" JEIKO_VISIO_SECRET \
        || jeiko_site_ajouter "$SITE_USER" "$ENV_PATH" "JEIKO_VISIO_SECRET=\"$secret\""
    # Une seule des deux présente : on relit ce qui fait foi dans le .env.
    cle="$(lire_env JEIKO_VISIO_CLE)"
    secret="$(lire_env JEIKO_VISIO_SECRET)"
    jeiko_ok "Clé de visio du site créée dans son .env"
fi
[[ "$cle" =~ ^[A-Za-z0-9_-]{3,64}$ && "$secret" =~ ^[A-Za-z0-9_-]{32,128}$ ]] \
    || jeiko_die "JEIKO_VISIO_CLE / JEIKO_VISIO_SECRET du .env illisibles."

ecrire_si_change() {  # <fichier> <mode> <groupe> — le contenu sur l'entrée standard
    local fichier="$1" mode="$2" groupe="$3" tmp
    tmp="$(mktemp "$fichier.XXXXXX")"
    cat >"$tmp"
    if [[ -f "$fichier" ]] && cmp -s "$tmp" "$fichier"; then
        rm -f "$tmp"
        return 1
    fi
    chmod "$mode" "$tmp"
    chown "root:$groupe" "$tmp"
    mv -f "$tmp" "$fichier"
    return 0
}

# Le seul fichier de clés de CE LiveKit : la clé de ce site, aucune autre.
printf '%s: %s\n' "$cle" "$secret" | ecrire_si_change "$SITE_ETC/keys.yaml" 0600 root && change=1 || true
chown livekit:livekit "$SITE_ETC/keys.yaml"

api="http://127.0.0.1:$P_SIGNAL"
if [[ "$(lire_env JEIKO_VISIO_API)" != "$api" ]]; then
    jeiko_site_poser "$SITE_USER" "$ENV_PATH" JEIKO_VISIO_API "$api" \
        || jeiko_die "JEIKO_VISIO_API non écrit dans $ENV_PATH."
    jeiko_ok "Le site vise son LiveKit : $api (relu au redémarrage du site)"
fi

# --------------------------------------------------------------------------- #
# 4) Le relais TURN, sur le domaine du site s'il a son certificat
# --------------------------------------------------------------------------- #
domaine_turn=""
[[ -f "/etc/letsencrypt/live/$DOMAIN_NAME/fullchain.pem" ]] && domaine_turn="$DOMAIN_NAME"
printf '%s\n' "$domaine_turn" >"$SITE_ETC/turn-domaine"

# Le crochet de renouvellement : certbot ne relance pas LiveKit tout seul, et
# LiveKit (compte « livekit ») ne lit pas /etc/letsencrypt (root seul).
if [[ -d /etc/letsencrypt ]]; then
    install -d -m 0755 "$(dirname "$HOOK")"
    ecrire_si_change "$HOOK" 0755 root <<'CROCHET' || true
#!/bin/sh
# Installé par JEIKO (15_visio.sh) : recopie pour le LiveKit de chaque site le
# certificat de son domaine de relais, et le relance. Rien pour les autres domaines.
set -e
for dossier in /etc/livekit/sites/*/; do
    site="$(basename "$dossier")"
    domaine="$(cat "$dossier/turn-domaine" 2>/dev/null || true)"
    [ -n "$domaine" ] || continue
    case " $RENEWED_DOMAINS " in *" $domaine "*) ;; *) [ -n "$RENEWED_DOMAINS" ] && continue ;; esac
    install -m 0640 -o root -g livekit "/etc/letsencrypt/live/$domaine/fullchain.pem" "$dossier/tls/fullchain.pem"
    install -m 0640 -o root -g livekit "/etc/letsencrypt/live/$domaine/privkey.pem" "$dossier/tls/privkey.pem"
    systemctl try-restart "livekit@$site.service"
done
CROCHET
fi
if [[ -n "$domaine_turn" ]]; then
    for f in fullchain.pem privkey.pem; do
        if ! cmp -s "/etc/letsencrypt/live/$domaine_turn/$f" "$SITE_ETC/tls/$f"; then
            install -m 0640 -o root -g livekit "/etc/letsencrypt/live/$domaine_turn/$f" "$SITE_ETC/tls/$f"
            change=1
        fi
    done
fi

# --------------------------------------------------------------------------- #
# 5) La configuration et le service du site
# --------------------------------------------------------------------------- #
# Par le domaine du site, comme un visiteur : en HTTPS dès qu'il a son
# certificat (le vhost HTTP redirige alors, et une redirection ne rejoue pas un
# POST). Le site vérifie la signature ; l'adresse seule ne donne rien.
schema_evenements="http"
[[ -f "/etc/letsencrypt/live/$DOMAIN_NAME/fullchain.pem" ]] && schema_evenements="https"
adresse_evenements="$schema_evenements://$DOMAIN_NAME/visio/livekit/evenements/"
{
    cat <<CONF
# Écrit par JEIKO (15_visio.sh) — réécrit à chaque convergence. Le LiveKit du
# site « $SITE_NAME » : il ne connaît que SA clé (keys.yaml), ses ports
# viennent de son rang sur la machine (VISIO-04).
port: $P_SIGNAL
bind_addresses: ["127.0.0.1"]
rtc:
  tcp_port: $P_TCP
  udp_port: $P_UDP
  use_external_ip: true
room:
  max_participants: 50
  empty_timeout: 600
key_file: $SITE_ETC/keys.yaml
logging:
  level: info
# Les événements de la salle (arrivées, départs) vont au site, signés de sa
# clé (VISIO-03) : il retire aussitôt qui n'a plus de lien valable, et compte
# la présence réelle plutôt que la délivrance du jeton.
webhook:
  api_key: $cle
  urls:
    - $adresse_evenements
CONF
    if [[ -n "$domaine_turn" ]]; then
        cat <<CONF
turn:
  enabled: true
  domain: $domaine_turn
  tls_port: $P_TURN_TLS
  udp_port: $P_TURN_UDP
  cert_file: $SITE_ETC/tls/fullchain.pem
  key_file: $SITE_ETC/tls/privkey.pem
CONF
    fi
} | ecrire_si_change "$SITE_ETC/livekit.yaml" 0640 livekit && change=1 || true

ecrire_si_change "$UNIT" 0644 root <<UNITE && { change=1; systemctl daemon-reload; } || true
[Unit]
Description=LiveKit — la visio du site JEIKO %i
After=network-online.target
Wants=network-online.target

[Service]
User=livekit
Group=livekit
ExecStart=$BIN --config $ETC/sites/%i/livekit.yaml
Restart=on-failure
RestartSec=5
LimitNOFILE=65536
NoNewPrivileges=yes
ProtectSystem=strict
ProtectHome=yes
PrivateTmp=yes
ProtectKernelTunables=yes
ProtectKernelModules=yes
ProtectControlGroups=yes
RestrictSUIDSGID=yes
LockPersonality=yes
ReadOnlyPaths=$ETC/sites/%i

[Install]
WantedBy=multi-user.target
UNITE

SERVICE="livekit@$SITE_NAME.service"
systemctl enable "$SERVICE" >/dev/null 2>&1 || true
if [[ $change -eq 1 ]]; then
    systemctl restart "$SERVICE"
elif ! systemctl is-active --quiet "$SERVICE"; then
    systemctl start "$SERVICE"
fi

# --------------------------------------------------------------------------- #
# 6) Le pare-feu
# --------------------------------------------------------------------------- #
if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q "Status: active"; then
    ufw allow "$P_TCP/tcp" comment "Visio $SITE_NAME (LiveKit, TCP)" >/dev/null
    ufw allow "$P_UDP/udp" comment "Visio $SITE_NAME (LiveKit, UDP)" >/dev/null
    if [[ -n "$domaine_turn" ]]; then
        ufw allow "$P_TURN_UDP/udp" comment "Visio $SITE_NAME (relais TURN, UDP)" >/dev/null
        ufw allow "$P_TURN_TLS/tcp" comment "Visio $SITE_NAME (relais TURN, TLS)" >/dev/null
    fi
fi

# --------------------------------------------------------------------------- #
# Contrôle : le LiveKit du site répond-il ?
# --------------------------------------------------------------------------- #
for _ in 1 2 3 4 5 6 7 8 9 10; do
    if curl -fsS --max-time 2 "http://127.0.0.1:$P_SIGNAL/" >/dev/null 2>&1; then
        jeiko_ok "Visio prête (LiveKit $LIVEKIT_VERSION du site, port $P_SIGNAL${domaine_turn:+, relais sur $domaine_turn})"
        exit 0
    fi
    sleep 1
done
jeiko_die "Le LiveKit du site ne répond pas sur 127.0.0.1:$P_SIGNAL — voir « journalctl -u $SERVICE »."
