#!/bin/bash
###############################################################################
# 15 — La visio (VISIO-01) : LiveKit sur la machine, la clé du site.
#
# Le besoin (Guillaume, 12/10/2026) : « je ne dois pas avoir à modifier quoi
# que ce soit » et « l'activer depuis le site, sans aller sur le serveur ».
# Cette étape tourne donc à l'installation ET à chaque convergence
# (jeiko-server-update, la mise à jour hebdomadaire jeiko-maj, la mise à jour
# du serveur demandée depuis un site) : quand l'exploitant coche « Conférence »
# dans Réglages, tout est déjà là.
#
# Ce qu'elle fait, idempotent :
#   1. le binaire livekit-server, version FIXÉE et empreinte vérifiée ;
#   2. un compte système « livekit », sans shell ni maison ;
#   3. la clé du site (JEIKO_VISIO_CLE / JEIKO_VISIO_SECRET), créée dans son
#      .env si elle manque, recopiée dans /etc/livekit/keys.d/<site> ; le
#      fichier de clés de LiveKit est la réunion de celles des sites ;
#   4. le relais TURN sur le domaine d'un site qui a un certificat (aucun DNS
#      ni sous-domaine) — certificat recopié pour LiveKit, et à chaque
#      renouvellement par un crochet certbot ;
#   5. le service systemd, durci, redémarré seulement si quelque chose a changé ;
#   6. le pare-feu : 7881/tcp et 7882/udp (son et image), 3478/udp et 5349/tcp
#      (relais). La signalisation (7880) n'écoute QUE 127.0.0.1 : nginx la
#      relaie sous https://<domaine>/visio-rtc/ (11_configure_nginx.sh).
#
# Ce qu'elle ne fait pas : toucher au SSH (règle de Guillaume) ; activer la
# visio d'un site — c'est la case « Conférence », dans son administration.
# Un échec ici n'arrête ni l'installation ni la convergence du site : la visio
# manque, le site tourne (l'écran « Serveur de visio » le dit).
#
# Limite connue : un réseau d'entreprise qui n'ouvre QUE le 443 en sortie ne
# joint ni le 5349 ni l'UDP — il faudrait alors un relais dédié sur le 443.
###############################################################################
set -euo pipefail
# shellcheck source=/usr/local/lib/jeiko/common.sh
source /usr/local/lib/jeiko/common.sh

jeiko_step "[15] Visio (LiveKit)"
jeiko_require_root

: "${SITE_NAME:?SITE_NAME manquant}"
: "${PROJECT_DIR:?PROJECT_DIR manquant}"
: "${SITE_USER:?SITE_USER manquant}"
: "${DOMAIN_NAME:?DOMAIN_NAME manquant}"

LIVEKIT_VERSION="1.13.8"
# checksums.txt de la publication v1.13.8 (github.com/livekit/livekit),
# relevé le 12/10/2026. Changer de version, c'est changer les deux lignes.
declare -A LIVEKIT_SHA256=(
    [amd64]="059f6de65da11a57400e4646027da705d592ce42acb48c08570a397df446f869"
    [arm64]="39883cb07f370057692139fcf500a763cfedae1e9934bd8a1815a144e2127bd2"
)

BIN="${JEIKO_LIVEKIT_BIN:-/usr/local/bin/livekit-server}"
ETC="${JEIKO_LIVEKIT_ETC:-/etc/livekit}"
UNIT="/etc/systemd/system/livekit.service"
HOOK="/etc/letsencrypt/renewal-hooks/deploy/jeiko-livekit"
ENV_PATH="$PROJECT_DIR/$SITE_NAME/.env"
change=0

# --------------------------------------------------------------------------- #
# 1) Le binaire
# --------------------------------------------------------------------------- #
installee="$("$BIN" --version 2>/dev/null | awk '{print $NF}' || true)"
if [[ "$installee" != "$LIVEKIT_VERSION" ]]; then
    arch="$(dpkg --print-architecture 2>/dev/null || uname -m)"
    [[ "$arch" == "x86_64" ]] && arch="amd64"
    [[ "$arch" == "aarch64" ]] && arch="arm64"
    empreinte="${LIVEKIT_SHA256[$arch]:-}"
    [[ -n "$empreinte" ]] || jeiko_die "Architecture « $arch » non prise en charge par la visio."
    tmp="$(mktemp -d /tmp/jeiko-livekit.XXXXXX)"
    trap 'rm -rf "$tmp"' EXIT
    jeiko_download \
        "https://github.com/livekit/livekit/releases/download/v${LIVEKIT_VERSION}/livekit_${LIVEKIT_VERSION}_linux_${arch}.tar.gz" \
        "$tmp/livekit.tar.gz" || jeiko_die "Téléchargement de LiveKit impossible."
    jeiko_verify_sha256 "$tmp/livekit.tar.gz" "$empreinte" || jeiko_die "LiveKit refusé : empreinte incorrecte."
    tar -xzf "$tmp/livekit.tar.gz" -C "$tmp" livekit-server
    install -m 0755 -o root -g root "$tmp/livekit-server" "$BIN"
    jeiko_ok "LiveKit $LIVEKIT_VERSION installé (${installee:-absent} auparavant)"
    change=1
fi

# --------------------------------------------------------------------------- #
# 2) Le compte et les dossiers
# --------------------------------------------------------------------------- #
if ! id livekit >/dev/null 2>&1; then
    useradd --system --no-create-home --home-dir /nonexistent --shell /usr/sbin/nologin livekit
fi
install -d -m 0750 -o root -g livekit "$ETC" "$ETC/tls"
install -d -m 0700 -o root -g root "$ETC/keys.d"

# --------------------------------------------------------------------------- #
# 3) La clé du site
# --------------------------------------------------------------------------- #
[[ -L "$ENV_PATH" ]] && jeiko_die ".env est un lien symbolique ($ENV_PATH) : refusé."
[[ -f "$ENV_PATH" ]] || jeiko_die ".env introuvable : $ENV_PATH"

lire_env() {
    jeiko_as_site "$SITE_USER" sed -nE "s/^[[:space:]]*$1[[:space:]]*=[[:space:]]*\"?([^\"]*)\"?[[:space:]]*$/\1/p" \
        -- "$ENV_PATH" | tail -n 1
}

cle="$(lire_env JEIKO_VISIO_CLE)"
secret="$(lire_env JEIKO_VISIO_SECRET)"
if [[ -z "$cle" || -z "$secret" ]]; then
    cle="jeiko-$SITE_NAME"
    secret="$(openssl rand -hex 32)"
    jeiko_site_a_la_cle "$SITE_USER" "$ENV_PATH" JEIKO_VISIO_CLE \
        || jeiko_site_ajouter "$SITE_USER" "$ENV_PATH" "JEIKO_VISIO_CLE=\"$cle\""
    jeiko_site_a_la_cle "$SITE_USER" "$ENV_PATH" JEIKO_VISIO_SECRET \
        || jeiko_site_ajouter "$SITE_USER" "$ENV_PATH" "JEIKO_VISIO_SECRET=\"$secret\""
    # Une seule des deux présente : on relit ce qui fait foi dans le .env.
    cle="$(lire_env JEIKO_VISIO_CLE)"
    secret="$(lire_env JEIKO_VISIO_SECRET)"
    jeiko_ok "Clé de visio du site créée dans son .env"
fi
[[ "$cle" =~ ^[A-Za-z0-9_-]{3,64}$ && "$secret" =~ ^[A-Za-z0-9_-]{32,128}$ ]] \
    || jeiko_die "JEIKO_VISIO_CLE / JEIKO_VISIO_SECRET du .env illisibles."

ecrire_si_change() {  # <fichier> <mode> <groupe> — le contenu sur l'entrée standard
    local fichier="$1" mode="$2" groupe="$3" tmp
    tmp="$(mktemp "$fichier.XXXXXX")"
    cat >"$tmp"
    if [[ -f "$fichier" ]] && cmp -s "$tmp" "$fichier"; then
        rm -f "$tmp"
        return 1
    fi
    chmod "$mode" "$tmp"
    chown "root:$groupe" "$tmp"
    mv -f "$tmp" "$fichier"
    return 0
}

printf '%s: %s\n' "$cle" "$secret" | ecrire_si_change "$ETC/keys.d/$SITE_NAME" 0600 root && change=1 || true

# Les clés de TOUS les sites de la machine, et seulement des sites qui
# existent encore. LiveKit exige un fichier de clés non lisible par les autres.
{
    for f in "$ETC"/keys.d/*; do
        [[ -f "$f" ]] || continue
        site="$(basename "$f")"
        if [[ -f "$(jeiko_site_conf_path "$site")" ]]; then
            cat "$f"
        fi
    done
} | ecrire_si_change "$ETC/keys.yaml" 0600 root && change=1 || true
chown livekit:livekit "$ETC/keys.yaml"

# --------------------------------------------------------------------------- #
# 4) Le relais TURN, sur le domaine d'un site qui a son certificat
# --------------------------------------------------------------------------- #
# Un seul domaine de relais par machine : le premier retenu le reste, tant
# que son certificat existe (sinon celui de ce site, s'il en a un).
domaine_turn="$(cat "$ETC/turn-domaine" 2>/dev/null || true)"
if [[ -z "$domaine_turn" || ! -f "/etc/letsencrypt/live/$domaine_turn/fullchain.pem" ]]; then
    domaine_turn=""
    [[ -f "/etc/letsencrypt/live/$DOMAIN_NAME/fullchain.pem" ]] && domaine_turn="$DOMAIN_NAME"
    printf '%s\n' "$domaine_turn" >"$ETC/turn-domaine"
fi

# Le crochet de renouvellement : certbot ne relance pas LiveKit tout seul, et
# LiveKit (compte « livekit ») ne lit pas /etc/letsencrypt (root seul).
if [[ -d /etc/letsencrypt ]]; then
    install -d -m 0755 "$(dirname "$HOOK")"
    ecrire_si_change "$HOOK" 0755 root <<'CROCHET' || true
#!/bin/sh
# Installé par JEIKO (15_visio.sh) : recopie le certificat du domaine de relais
# de la visio pour LiveKit, et le relance. Rien à faire pour les autres domaines.
set -e
domaine="$(cat /etc/livekit/turn-domaine 2>/dev/null || true)"
[ -n "$domaine" ] || exit 0
case " $RENEWED_DOMAINS " in *" $domaine "*) ;; *) [ -n "$RENEWED_DOMAINS" ] && exit 0 ;; esac
install -m 0640 -o root -g livekit "/etc/letsencrypt/live/$domaine/fullchain.pem" /etc/livekit/tls/fullchain.pem
install -m 0640 -o root -g livekit "/etc/letsencrypt/live/$domaine/privkey.pem" /etc/livekit/tls/privkey.pem
systemctl try-restart livekit.service
CROCHET
fi
if [[ -n "$domaine_turn" ]]; then
    for f in fullchain.pem privkey.pem; do
        if ! cmp -s "/etc/letsencrypt/live/$domaine_turn/$f" "$ETC/tls/$f"; then
            install -m 0640 -o root -g livekit "/etc/letsencrypt/live/$domaine_turn/$f" "$ETC/tls/$f"
            change=1
        fi
    done
fi

# --------------------------------------------------------------------------- #
# 5) La configuration et le service
# --------------------------------------------------------------------------- #
{
    cat <<CONF
# Écrit par JEIKO (15_visio.sh) — réécrit à chaque convergence.
port: 7880
bind_addresses: ["127.0.0.1"]
rtc:
  tcp_port: 7881
  udp_port: 7882
  use_external_ip: true
room:
  max_participants: 50
  empty_timeout: 600
key_file: $ETC/keys.yaml
logging:
  level: info
CONF
    if [[ -n "$domaine_turn" ]]; then
        cat <<CONF
turn:
  enabled: true
  domain: $domaine_turn
  tls_port: 5349
  udp_port: 3478
  cert_file: $ETC/tls/fullchain.pem
  key_file: $ETC/tls/privkey.pem
CONF
    fi
} | ecrire_si_change "$ETC/livekit.yaml" 0640 livekit && change=1 || true

ecrire_si_change "$UNIT" 0644 root <<UNITE && { change=1; systemctl daemon-reload; } || true
[Unit]
Description=LiveKit — la visio des sites JEIKO
After=network-online.target
Wants=network-online.target

[Service]
User=livekit
Group=livekit
ExecStart=$BIN --config $ETC/livekit.yaml
Restart=on-failure
RestartSec=5
LimitNOFILE=65536
NoNewPrivileges=yes
ProtectSystem=strict
ProtectHome=yes
PrivateTmp=yes
ProtectKernelTunables=yes
ProtectKernelModules=yes
ProtectControlGroups=yes
RestrictSUIDSGID=yes
LockPersonality=yes
ReadOnlyPaths=$ETC

[Install]
WantedBy=multi-user.target
UNITE

systemctl enable livekit.service >/dev/null 2>&1 || true
if [[ $change -eq 1 ]]; then
    systemctl restart livekit.service
elif ! systemctl is-active --quiet livekit.service; then
    systemctl start livekit.service
fi

# --------------------------------------------------------------------------- #
# 6) Le pare-feu
# --------------------------------------------------------------------------- #
if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q "Status: active"; then
    ufw allow 7881/tcp comment 'Visio (LiveKit, TCP)' >/dev/null
    ufw allow 7882/udp comment 'Visio (LiveKit, UDP)' >/dev/null
    if [[ -n "$domaine_turn" ]]; then
        ufw allow 3478/udp comment 'Visio (relais TURN, UDP)' >/dev/null
        ufw allow 5349/tcp comment 'Visio (relais TURN, TLS)' >/dev/null
    fi
fi

# --------------------------------------------------------------------------- #
# Contrôle : LiveKit répond-il ?
# --------------------------------------------------------------------------- #
for _ in 1 2 3 4 5 6 7 8 9 10; do
    if curl -fsS --max-time 2 http://127.0.0.1:7880/ >/dev/null 2>&1; then
        jeiko_ok "Visio prête (LiveKit $LIVEKIT_VERSION${domaine_turn:+, relais sur $domaine_turn})"
        exit 0
    fi
    sleep 1
done
jeiko_die "LiveKit ne répond pas sur 127.0.0.1:7880 — voir « journalctl -u livekit »."
