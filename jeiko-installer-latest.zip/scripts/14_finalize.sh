#!/bin/bash
set -euo pipefail

echo "🎯 [14_finalize.sh] Migrations, collectstatic, sudoers (update), checks…"

if [[ -z "${BASE_DIR:-}" || -z "${SITE_NAME:-}" || -z "${DJANGO_SUPERUSER:-}" ]]; then
  echo "❌ Variables requises manquantes."; exit 1
fi

PROJECT_DIR="$BASE_DIR/$SITE_NAME"
VENV_DIR="$PROJECT_DIR/venv"
MANAGE="$PROJECT_DIR/manage.py"
SERVICE_NAME="gunicorn-$SITE_NAME"
SITE_USER="jeiko-$SITE_NAME"

source "$VENV_DIR/bin/activate"

echo "🔄 Migrations…"
python "$MANAGE" migrate --noinput

echo "📦 Collectstatic…"
python "$MANAGE" collectstatic --noinput

echo "👤 Superuser…"
python "$MANAGE" shell <<EOF
from django.contrib.auth import get_user_model
U=get_user_model()
u=U.objects.filter(username="$DJANGO_SUPERUSER").first()
if not u:
    U.objects.create_superuser("$DJANGO_SUPERUSER","$DJANGO_SUPEREMAIL","$DJANGO_SUPERPASS")
    print("✅ Superuser créé")
else:
    print("ℹ️ Superuser déjà présent")
EOF


# --- Synchroniser django.contrib.sites avec le domaine fourni ---
echo "🌐 Mise à jour django.contrib.sites…"
python "$MANAGE" shell <<'EOF'
import os
from django.conf import settings
from django.contrib.sites.models import Site

domain = os.getenv("DOMAIN_NAME")
name = os.getenv("SITE_NAME") or domain

if domain:
    site, created = Site.objects.get_or_create(id=1, defaults={"domain": domain, "name": name})
    # Toujours réaligner (idempotent)
    site.domain = domain
    site.name = name
    site.save()
    print(f"✅ Site(id=1) = {site.domain} ({site.name})")
else:
    print("⚠️ DOMAIN_NAME absent de l'environnement, sites non modifié.")
EOF


# (Option) Check déploiement
python "$MANAGE" check --deploy || true

echo "🔁 Redémarrage services…"
systemctl restart "$SERVICE_NAME"
systemctl reload nginx || systemctl restart nginx

# Sudoers minimal pour update via interface admin
# Autoriser l'user applicatif à redémarrer son gunicorn et recharger Nginx (uniquement ces commandes)
SUDOERS="/etc/sudoers.d/jeiko-$SITE_NAME"
if [[ ! -f "$SUDOERS" ]]; then
  echo "🔐 Sudoers limité pour $SITE_USER"
  cat > "$SUDOERS" <<EOF
$SITE_USER ALL=NOPASSWD: /bin/systemctl restart $SERVICE_NAME, /bin/systemctl reload nginx
EOF
  chmod 440 "$SUDOERS"
  visudo -cf "$SUDOERS" >/dev/null
fi

echo "✅ Finalisation OK. Site: https://$DOMAIN_NAME"
