#!/bin/bash
set -euo pipefail

echo "🐍 [07_install_python_env.sh] Environnement Python (venv + paquets)…"

: "${BASE_DIR:?BASE_DIR manquant}"
: "${SITE_NAME:?SITE_NAME manquant}"

PROJECT_DIR="$BASE_DIR/$SITE_NAME"
VENV_DIR="$PROJECT_DIR/venv"
SITE_USER="jeiko-$SITE_NAME"

# 0) Dossier projet
mkdir -p "$PROJECT_DIR"
chown -R "$SITE_USER":www-data "$PROJECT_DIR"

# 1) Python
PYTHON_BIN="$(command -v python3 || true)"
if [[ -z "${PYTHON_BIN}" ]]; then
  echo "❌ python3 introuvable (vérifier 03_check_dependencies.sh)"; exit 1
fi

# 2) venv
if [[ ! -d "$VENV_DIR/bin" ]]; then
  echo "📦 Création de l’environnement virtuel…"
  "$PYTHON_BIN" -m venv "$VENV_DIR"
else
  echo "ℹ️ venv déjà présent."
fi

PY="$VENV_DIR/bin/python"
PIP="$VENV_DIR/bin/pip"

# 3) S’assurer que pip existe dans le venv
if [[ ! -x "$PIP" ]]; then
  echo "🧰 pip absent dans le venv → ensurepip…"
  "$PY" -m ensurepip --upgrade || true
fi

# 3.1 Réparer les permissions du venv si besoin (exécutables dans bin)
chown -R "$SITE_USER":www-data "$VENV_DIR"
# lecture/exécution pour owner+group, rien pour others
chmod -R u=rwX,g=rX,o= "$VENV_DIR"
# bin et son contenu doivent être exécutables
chmod 0755 "$VENV_DIR/bin" || true
chmod 0755 "$VENV_DIR/bin/"* 2>/dev/null || true

# 4) Upgrade outils (dans le venv)
echo "⬆️ Mise à jour pip/setuptools/wheel (venv)…"
"$PY" -m pip install --no-input --disable-pip-version-check --upgrade pip setuptools wheel

# 5) Dépendances Python de base (le reste via le package JEIKO étape 08)
echo "📥 Installation des dépendances Python de base (venv)…"
"$PIP" install --no-input --disable-pip-version-check \
  django gunicorn psycopg2-binary python-dotenv

echo "✅ Environnement Python prêt : $("$PY" -V)"
echo "   pip = $(readlink -f "$PIP")"
