#!/bin/bash
set -euo pipefail
# shellcheck source=../lib/jeiko-common.sh
source /usr/local/lib/jeiko/common.sh

jeiko_step "[05] Base de données et rôle applicatif"
jeiko_require_root

: "${DB_NAME:?DB_NAME manquant}"
: "${DB_USER:?DB_USER manquant}"
: "${DB_PASS:?DB_PASS manquant}"

# --------------------------------------------------------------------------- #
# Rôle
#
# L'ancienne version interpolait le mot de passe directement dans la chaîne SQL
# (`PASSWORD '$DB_PASS'`) : une apostrophe suffisait à casser l'installation,
# et un mot de passe choisi malicieusement à injecter du SQL exécuté en tant
# que superutilisateur postgres.
#
# Ici, psql reçoit la valeur comme variable (:'dbpass'), format() applique le
# quoting littéral (%L) et \gexec exécute la commande ainsi construite.
# --------------------------------------------------------------------------- #
ROLE_EXISTS="$(sudo -u postgres psql -tAc \
    "SELECT 1 FROM pg_roles WHERE rolname = '$(sed "s/'/''/g" <<<"$DB_USER")'")"

if [[ "$ROLE_EXISTS" == "1" ]]; then
    # Un rôle qui existe hors d'une reprise de CE site appartient à quelqu'un
    # d'autre (une autre application, un site hors registre) : lui imposer un
    # nouveau mot de passe le couperait de sa base.
    [[ "${JEIKO_REPRISE:-0}" == "1" ]] \
        || jeiko_die "Le rôle PostgreSQL '$DB_USER' existe déjà et n'appartient pas à ce site. Choisis un autre nom."
    jeiko_log "ℹ️  Rôle '$DB_USER' déjà présent (reprise) → mot de passe de la fiche réappliqué."
    SQL_ROLE="SELECT format('ALTER ROLE %I WITH LOGIN PASSWORD %L', :'dbuser', :'dbpass')"
else
    SQL_ROLE="SELECT format('CREATE ROLE %I WITH LOGIN PASSWORD %L', :'dbuser', :'dbpass')"
fi

# Le mot de passe passe par l'ENVIRONNEMENT (\getenv, psql ≥ 15 : Debian 12
# et suivantes), pas par la ligne de commande : /proc/<pid>/cmdline est lisible
# par tous les comptes locaux, l'environnement par le seul propriétaire.
# runuser garde l'environnement, là où sudo le réinitialise. Un psql plus
# ancien (14, Ubuntu 22.04 — DIST-01) le reçoit par l'entrée, entre
# apostrophes : jeiko_valider_mot_de_passe_db y exclut l'apostrophe et la
# barre oblique inverse, seules à pouvoir en sortir.
if (( $(psql -V | grep -oE '[0-9]+' | head -1) >= 15 )); then
    JEIKO_DBPASS="$DB_PASS" runuser -u postgres -- psql -v ON_ERROR_STOP=1 \
        -v dbuser="$DB_USER" \
        -q <<SQL
\\getenv dbpass JEIKO_DBPASS
$SQL_ROLE \gexec
SQL
else
    # Une fiche plus ancienne que la règle (site transféré) peut porter un mot
    # de passe hors de l'alphabet : refuser plutôt que d'exécuter sa fin.
    jeiko_valider_mot_de_passe_db "$DB_PASS" \
        || jeiko_die "Mot de passe de la fiche inutilisable avec psql $(psql -V | grep -oE '[0-9]+' | head -1) : le changer dans la fiche du site, puis relancer."
    runuser -u postgres -- psql -v ON_ERROR_STOP=1 \
        -v dbuser="$DB_USER" \
        -q <<SQL
\\set dbpass '$DB_PASS'
$SQL_ROLE \gexec
SQL
fi

[[ "$ROLE_EXISTS" == "1" ]] || jeiko_ok "Rôle '$DB_USER' créé."

# Le rôle applicatif n'a aucun besoin de créer des bases ou d'autres rôles.
sudo -u postgres psql -v ON_ERROR_STOP=1 -v dbuser="$DB_USER" -q <<'SQL'
SELECT format('ALTER ROLE %I NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION', :'dbuser') \gexec
SQL

# --------------------------------------------------------------------------- #
# Base — createdb prend ses arguments en argv, aucune interpolation SQL.
# --------------------------------------------------------------------------- #
DB_EXISTS="$(sudo -u postgres psql -tAc \
    "SELECT 1 FROM pg_database WHERE datname = '$(sed "s/'/''/g" <<<"$DB_NAME")'")"

if [[ "$DB_EXISTS" != "1" ]]; then
    sudo -u postgres createdb -E UTF8 -T template0 -O "$DB_USER" "$DB_NAME"
    jeiko_ok "Base '$DB_NAME' créée (propriétaire : $DB_USER)."
else
    jeiko_log "ℹ️  Base '$DB_NAME' déjà présente."
fi

# --------------------------------------------------------------------------- #
# Droits
#
# Depuis PostgreSQL 15, le schéma public n'est plus inscriptible par défaut :
# sans ce GRANT explicite, `migrate` échoue avec « permission denied for
# schema public ».
# --------------------------------------------------------------------------- #
# PostgreSQL donne CONNECT à PUBLIC sur toute base : le compte d'un site
# pouvait ouvrir la base d'un VOISIN — sans lire ses tables, mais en voyant
# leurs noms, ses rôles et ses réglages (audit du serveur de test de kojei.fr,
# 20/10/2026). Le site garde CONNECT par le GRANT ALL ci-dessous.
sudo -u postgres psql -v ON_ERROR_STOP=1 -v dbname="$DB_NAME" -v dbuser="$DB_USER" -q <<'SQL'
SELECT format('GRANT ALL PRIVILEGES ON DATABASE %I TO %I', :'dbname', :'dbuser') \gexec
SELECT format('REVOKE CONNECT ON DATABASE %I FROM PUBLIC', :'dbname') \gexec
SQL

sudo -u postgres psql -v ON_ERROR_STOP=1 -d "$DB_NAME" -v dbuser="$DB_USER" -q <<'SQL'
SELECT format('GRANT ALL ON SCHEMA public TO %I', :'dbuser') \gexec
SELECT format('ALTER SCHEMA public OWNER TO %I', :'dbuser') \gexec
SELECT format('ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO %I', :'dbuser') \gexec
SELECT format('ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO %I', :'dbuser') \gexec
SQL

# --------------------------------------------------------------------------- #
# Vérification de bout en bout : c'est exactement la connexion que Django fera.
# --------------------------------------------------------------------------- #
if PGPASSWORD="$DB_PASS" psql -h 127.0.0.1 -U "$DB_USER" -d "$DB_NAME" -tAc 'SELECT 1' >/dev/null 2>&1; then
    jeiko_ok "Connexion applicative vérifiée ($DB_USER@127.0.0.1/$DB_NAME)."
else
    jeiko_die "Connexion impossible avec les identifiants applicatifs — vérifie pg_hba.conf."
fi
