#!/bin/bash
set -euo pipefail

echo "🧱 [05_setup_database.sh] Création DB & rôle applicatif…"

: "${DB_NAME:?DB_NAME manquant}"
: "${DB_USER:?DB_USER manquant}"
: "${DB_PASS:?DB_PASS manquant}"

# DB
DB_EXISTS=$(sudo -u postgres psql -tAc "SELECT 1 FROM pg_database WHERE datname='$DB_NAME'")
if [[ "$DB_EXISTS" != "1" ]]; then
    sudo -u postgres createdb -E UTF8 -T template0 "$DB_NAME"
    echo "✅ Base '$DB_NAME' créée."
else
    echo "ℹ️ Base '$DB_NAME' déjà présente."
fi

# USER (scram)
USER_EXISTS=$(sudo -u postgres psql -tAc "SELECT 1 FROM pg_roles WHERE rolname='$DB_USER'")
if [[ "$USER_EXISTS" != "1" ]]; then
    sudo -u postgres psql -c "CREATE ROLE $DB_USER WITH LOGIN PASSWORD '$DB_PASS';"
    echo "✅ Rôle '$DB_USER' créé."
else
    echo "ℹ️ Rôle '$DB_USER' déjà présent → mise à jour du mot de passe."
    sudo -u postgres psql -c "ALTER ROLE $DB_USER WITH PASSWORD '$DB_PASS';"
fi

# GRANTS
sudo -u postgres psql <<EOF
GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;
\c $DB_NAME;
GRANT ALL PRIVILEGES ON SCHEMA public TO $DB_USER;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO $DB_USER;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO $DB_USER;
EOF

echo "✅ Droits appliqués sur '$DB_NAME' pour '$DB_USER'."
