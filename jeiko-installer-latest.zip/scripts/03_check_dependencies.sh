#!/bin/bash
set -euo pipefail

echo "🔍 [03_check_dependencies.sh] Dépendances système (élargies)…"

if ! command -v apt-get >/dev/null 2>&1; then
    echo "❌ apt-get introuvable (Debian/Ubuntu requis)"; exit 1
fi

export DEBIAN_FRONTEND=noninteractive

REQUIRED_PACKAGES=(
    # Base outils
    curl unzip git jq htop
    ca-certificates lsb-release
    acl

    # Web & TLS
    nginx certbot python3-certbot-nginx

    # Toolchain Python / build
    python3 python3-venv python3-pip python3-dev build-essential pkg-config

    # PostgreSQL client & headers
    postgresql postgresql-contrib libpq-dev

    # Memcached + headers (pour pylibmc) & sasl/zlib
    memcached libmemcached-dev libsasl2-dev zlib1g-dev

    # Libs image utiles (Pillow)
    libjpeg-dev libfreetype6-dev libwebp-dev
)

NEED_UPDATE=false
for pkg in "${REQUIRED_PACKAGES[@]}"; do
    if ! dpkg -s "$pkg" &>/dev/null; then
        echo "📦 $pkg manquant : sera installé"
        NEED_UPDATE=true
    else
        echo "✅ $pkg OK"
    fi
done

if $NEED_UPDATE; then
    echo "🔄 apt-get update"
    apt-get update -y
    echo "⬇️ Installation paquets manquants…"
    apt-get install -y "${REQUIRED_PACKAGES[@]}"
else
    echo "ℹ️ Toutes les dépendances nécessaires sont déjà présentes."
fi

# Python version minimale (>=3.10 recommandé sur Debian 12)
PY_VERSION=$(python3 -V 2>&1 | awk '{print $2}')
MIN_VERSION="3.10"
if [[ "$(printf '%s\n' "$MIN_VERSION" "$PY_VERSION" | sort -V | head -n1)" != "$MIN_VERSION" ]]; then
    echo "❌ Python $MIN_VERSION ou supérieur requis (actuel : $PY_VERSION)"; exit 1
fi

echo "✅ Dépendances OK."
