#!/bin/bash

set -e

echo "🔄 Mise à jour du package JEIKO..."

# 1. Définir les chemins
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PROJECT_DIR="$SCRIPT_DIR"
VENV_DIR="$PROJECT_DIR/venv"
TMP_ZIP="/tmp/jeiko_latest.zip"
TMP_EXTRACT="/tmp/jeiko_extracted"
ZIP_URL="https://github.com/gderouineau/jeiko/raw/refs/heads/main/jeiko-latest.zip"

# 2. Activer l'environnement virtuel
source "$VENV_DIR/bin/activate"

# 3. Télécharger le zip
echo "📥 Téléchargement de la dernière version..."
curl -L "$ZIP_URL" -o "$TMP_ZIP"

# 4. Extraction
echo "📂 Extraction dans $TMP_EXTRACT..."
rm -rf "$TMP_EXTRACT"
mkdir -p "$TMP_EXTRACT"
unzip -o "$TMP_ZIP" -d "$TMP_EXTRACT"

# 5. Trouver le dossier contenant pyproject.toml
PACKAGE_DIR=$(find "$TMP_EXTRACT" -name "pyproject.toml" -exec dirname {} \; | head -n 1)
if [[ -z "$PACKAGE_DIR" ]]; then
    echo "❌ Fichier pyproject.toml introuvable."
    exit 1
fi
DIST_DIR="$PACKAGE_DIR/dist"

# 6. Installer les dépendances du requirements.txt si présent
REQUIREMENTS_FILE=$(find "$TMP_EXTRACT" -name "requirements.txt" | head -n 1)
if [[ -n "$REQUIREMENTS_FILE" ]]; then
    echo "📦 Installation des dépendances..."
    pip install -r "$REQUIREMENTS_FILE"
fi

# 7. S'assurer que build et setuptools sont installés
if ! python -m build --version &>/dev/null; then
    echo "📚 Installation de 'build'..."
    pip install build
fi
if ! python -c "import setuptools" &>/dev/null; then
    echo "📚 Installation de 'setuptools'..."
    pip install setuptools
fi

# 8. Nettoyage du dossier dist
echo "🧹 Nettoyage de $DIST_DIR..."
rm -rf "$DIST_DIR"

# 9. Build du package
echo "🔧 Build du package..."
cd "$PACKAGE_DIR"
python -m build > /dev/null

# 10. Installation du package
cd "$DIST_DIR"
WHEEL_FILE=$(ls *.whl 2>/dev/null | head -n 1)
TAR_FILE=$(ls *.tar.gz 2>/dev/null | head -n 1)

if [[ -n "$WHEEL_FILE" ]]; then
    echo "📦 Installation (wheel)..."
    pip install "$DIST_DIR/$WHEEL_FILE"
elif [[ -n "$TAR_FILE" ]]; then
    echo "📦 Installation (archive)..."
    pip install "$DIST_DIR/$TAR_FILE"
else
    echo "❌ Aucun fichier .whl ou .tar.gz trouvé."
    exit 1
fi

# 11. Exécuter collectstatic et migrate
echo "🗂️ Collecte des fichiers statiques..."
python manage.py collectstatic --noinput

echo "🛠️ Application des migrations..."
python manage.py migrate

# 12. Redémarrer Gunicorn
SERVICE_NAME="gunicorn-$(basename "$PROJECT_DIR")"
echo "🔁 Redémarrage de Gunicorn ($SERVICE_NAME)..."
systemctl restart "$SERVICE_NAME"

# 13. Redémarrer Nginx
echo "🔁 Redémarrage de Nginx..."
systemctl restart nginx

# 14. Nettoyage final
echo "🧹 Suppression des fichiers temporaires..."
rm -rf "$TMP_ZIP" "$TMP_EXTRACT"

echo "✅ Mise à jour de JEIKO terminée avec succès."
