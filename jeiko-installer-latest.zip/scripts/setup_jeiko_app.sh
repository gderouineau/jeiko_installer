#!/bin/bash

echo "⚙️ [setup_jeiko_app.sh] Création de l’application Django avec JEIKO..."

PROJECT_DIR="$BASE_DIR/$SITE_NAME"
DJANGO_PROJECT_DIR="$PROJECT_DIR/$SITE_NAME"
MANAGE_PATH="$PROJECT_DIR/manage.py"
VENV_BIN="$PROJECT_DIR/venv/bin"
PYTHON="$VENV_BIN/python"
PIP="$VENV_BIN/pip"

# 1. Créer le projet Django s’il n'existe pas
if [[ ! -f "$MANAGE_PATH" ]]; then
    echo "📁 Création du projet Django : $SITE_NAME"
    "$VENV_BIN/django-admin" startproject "$SITE_NAME" "$PROJECT_DIR"
else
    echo "ℹ️ Projet Django déjà existant. Aucun changement."
fi

# 2. Installer les dépendances via le requirements.txt du package JEIKO
REQUIREMENTS_PATH=$(find "$PROJECT_DIR/venv/lib" -type f -path "*/site-packages/jeiko/requirements.txt" | head -n 1)

if [[ -f "$REQUIREMENTS_PATH" ]]; then
    echo "📦 Installation des dépendances de jeiko..."
    "$PIP" install -r "$REQUIREMENTS_PATH"
else
    echo "⚠️ Aucun requirements.txt trouvé dans le package JEIKO."
fi

# 3. Ajouter le include('jeiko.urls') à urls.py
URLS_PATH="$DJANGO_PROJECT_DIR/urls.py"

cat > "$URLS_PATH" <<EOF
from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('jeiko.urls')),
]

urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
EOF

echo "✅ urls.py mis à jour"

# 4. Exécuter les migrations
echo "🛠️ Migration des bases de données..."
"$PYTHON" "$MANAGE_PATH" migrate

# 5. Créer le superuser
echo "👤 Création du superuser Django..."

"$PYTHON" "$MANAGE_PATH" shell <<EOF
from django.contrib.auth import get_user_model
User = get_user_model()
if not User.objects.filter(username="$DJANGO_SUPERUSER").exists():
    User.objects.create_superuser(
        username="$DJANGO_SUPERUSER",
        email="$DJANGO_SUPEREMAIL",
        password="$DJANGO_SUPERPASS"
    )
EOF

# 6. Collecte des fichiers statiques
echo "📦 Collecte des fichiers statiques..."
"$PYTHON" "$MANAGE_PATH" collectstatic --noinput

echo "✅ Application Django JEIKO prête à l’emploi."
