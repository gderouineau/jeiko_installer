#!/bin/bash

set -e

echo "📦 [install_jeiko_package.sh] Installation du package JEIKO..."

# Variables
PROJECT_DIR="$BASE_DIR/$SITE_NAME"
PACKAGE_DIR="$PROJECT_DIR/jeiko"
DIST_DIR="$PACKAGE_DIR/dist"
VENV_DIR="$PROJECT_DIR/venv"

# 1. Activer l'environnement virtuel
echo "🐍 Activation du virtualenv..."
source "$VENV_DIR/bin/activate"

# 2. Vérifier et installer 'build' si absent
if ! python -m build --version &>/dev/null; then
    echo "📚 Installation du module 'build'..."
    pip install --quiet build
else
    echo "📚 Module 'build' déjà disponible."
fi

# 3. Nettoyer l'ancien dossier dist (si présent)
echo "🧹 Nettoyage de l'ancien dossier 'dist/'..."
rm -rf "$DIST_DIR"

# 4. Construire le package
echo "🔧 Construction du package JEIKO..."
cd "$PACKAGE_DIR"
python -m build > /dev/null

# 5. Aller dans le dossier dist et installer le package
cd "$DIST_DIR"
WHEEL_FILE=$(ls *.whl 2>/dev/null | head -n 1)
TAR_FILE=$(ls *.tar.gz 2>/dev/null | head -n 1)

if [[ -n "$WHEEL_FILE" ]]; then
    echo "📦 Installation via wheel : $WHEEL_FILE"
    pip install "$DIST_DIR/$WHEEL_FILE"
elif [[ -n "$TAR_FILE" ]]; then
    echo "📦 Installation via archive source : $TAR_FILE"
    pip install "$DIST_DIR/$TAR_FILE"
else
    echo "❌ Aucun package .whl ou .tar.gz trouvé dans $DIST_DIR"
    exit 1
fi

echo "✅ Package JEIKO installé avec succès dans l’environnement virtuel."
