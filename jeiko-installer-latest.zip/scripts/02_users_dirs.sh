#!/bin/bash
set -euo pipefail

echo "👤 [02_users_dirs.sh] Comptes, dossiers, permissions & ACL…"

: "${BASE_DIR:?BASE_DIR manquant}"
: "${SITE_NAME:?SITE_NAME manquant}"

PROJECT_DIR="$BASE_DIR/$SITE_NAME"
SITE_USER="jeiko-$SITE_NAME"
SITE_GROUP="www-data"      # groupe pour Nginx
ACL_USER="debian"          # confort SSH (lecture/traversée)

# 1) Créer l'utilisateur système pour le site (si absent)
if ! id -u "$SITE_USER" >/dev/null 2>&1; then
  useradd --system --no-create-home --shell /usr/sbin/nologin "$SITE_USER"
  echo "✅ Utilisateur système créé: $SITE_USER"
else
  echo "ℹ️ Utilisateur système déjà présent: $SITE_USER"
fi

# 2) Dossier projet
mkdir -p "$PROJECT_DIR"
chown -R "$SITE_USER":"$SITE_GROUP" "$PROJECT_DIR"

# 3) Permissions sécurisées (⚠️ sans impacter le venv)
#    - setgid sur dossiers → conserve le groupe
#    - 2750 sur dossiers (owner RWX / group RX / autres -)
#    - 0640 sur fichiers (owner RW / group R / autres -)
if [ -d "$PROJECT_DIR" ]; then
  # Dossiers hors venv
  find "$PROJECT_DIR" -type d -not -path "$PROJECT_DIR/venv*" -exec chmod 2750 {} +
  # Fichiers hors venv
  find "$PROJECT_DIR" -type f -not -path "$PROJECT_DIR/venv/*" -exec chmod 0640 {} + || true
fi

# 4) ACL pour l’admin SSH (user 'debian') → lecture/traversée
if command -v setfacl >/dev/null 2>&1; then
  setfacl -m u:$ACL_USER:rx "$BASE_DIR" || true
  setfacl -R -m u:$ACL_USER:rX "$PROJECT_DIR" || true
  setfacl -R -m d:u:$ACL_USER:rX "$PROJECT_DIR" || true
  echo "✅ ACL appliquées pour $ACL_USER (rX)"
else
  echo "⚠️ setfacl introuvable (installé à l’étape 03), ACL non appliquées."
fi

# 5) Dossiers standards
mkdir -p "$PROJECT_DIR/staticdir" "$PROJECT_DIR/mediadir" "$PROJECT_DIR/logs"
chown -R "$SITE_USER":"$SITE_GROUP" "$PROJECT_DIR/staticdir" "$PROJECT_DIR/mediadir" "$PROJECT_DIR/logs"
chmod 2750 "$PROJECT_DIR/staticdir" "$PROJECT_DIR/mediadir" "$PROJECT_DIR/logs"

echo "✅ Comptes, dossiers et permissions prêts pour $SITE_NAME"
