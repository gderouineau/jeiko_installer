#!/bin/bash
set -euo pipefail

echo "🔥 [10_configure_gunicorn.sh] Service systemd Gunicorn…"

if [[ -z "${BASE_DIR:-}" || -z "${SITE_NAME:-}" ]]; then
  echo "❌ Variables requises manquantes (BASE_DIR, SITE_NAME)."; exit 1
fi

SERVICE_NAME="gunicorn-$SITE_NAME"
PROJECT_DIR="$BASE_DIR/$SITE_NAME"
VENV_DIR="$PROJECT_DIR/venv"
WSGI_MODULE="$SITE_NAME.wsgi"
ENV_FILE="$PROJECT_DIR/$SITE_NAME/.env"
LOG_DIR="/var/log/gunicorn/$SITE_NAME"
SITE_USER="jeiko-$SITE_NAME"
SOCKET_PATH="/run/$SERVICE_NAME.sock"

mkdir -p "$LOG_DIR"
chown -R "$SITE_USER":www-data "$LOG_DIR"
chmod -R 750 "$LOG_DIR"

# calcul workers (2*CPU)+1 minimal 3
CPU=$(nproc)
WORKERS=$(( 2*CPU + 1 ))
if (( WORKERS < 3 )); then WORKERS=3; fi

SERVICE_FILE="/etc/systemd/system/$SERVICE_NAME.service"

cat > "$SERVICE_FILE" <<EOF
[Unit]
Description=Gunicorn for $SITE_NAME (Django)
After=network.target

[Service]
User=$SITE_USER
Group=www-data
WorkingDirectory=$PROJECT_DIR
EnvironmentFile=$ENV_FILE
RuntimeDirectory=gunicorn-$SITE_NAME
ExecStart=$VENV_DIR/bin/gunicorn \\
  --workers $WORKERS \\
  --threads 2 \\
  --timeout 30 \\
  --umask 007 \\
  --chdir $PROJECT_DIR \\
  --access-logfile $LOG_DIR/access.log \\
  --error-logfile  $LOG_DIR/error.log \\
  --bind unix:$SOCKET_PATH \\
  $WSGI_MODULE:application
Restart=on-failure
RestartSec=2
LimitNOFILE=4096

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable "$SERVICE_NAME"
systemctl restart "$SERVICE_NAME"

# Vérif
if systemctl is-active --quiet "$SERVICE_NAME"; then
  echo "✅ Gunicorn actif. Socket: $SOCKET_PATH"
else
  echo "❌ Gunicorn ne démarre pas."
  journalctl -u "$SERVICE_NAME" --no-pager | tail -n 50
  exit 1
fi
