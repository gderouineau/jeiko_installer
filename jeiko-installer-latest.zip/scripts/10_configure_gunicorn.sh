#!/bin/bash
set -euo pipefail

echo "🔥 [10_configure_gunicorn.sh] Configuration du service Gunicorn…"

: "${BASE_DIR:?BASE_DIR manquant}"
: "${SITE_NAME:?SITE_NAME manquant}"

SERVICE_NAME="gunicorn-$SITE_NAME"
PROJECT_DIR="$BASE_DIR/$SITE_NAME"
VENV_DIR="$PROJECT_DIR/venv"
WSGI_MODULE="$SITE_NAME.wsgi"

SOCKET_DIR="/run/$SERVICE_NAME"
SOCKET_PATH="$SOCKET_DIR/gunicorn.sock"

SERVICE_FILE="/etc/systemd/system/$SERVICE_NAME.service"
LOG_DIR="/var/log/gunicorn/$SITE_NAME"
SITE_USER="jeiko-$SITE_NAME"

# workers = min(max(2*CPU+1, 3), 12)
CPU=$(nproc --all || echo 2)
W="$(( 2*CPU + 1 ))"
if [ "$W" -lt 3 ]; then W=3; fi
if [ "$W" -gt 12 ]; then W=12; fi

mkdir -p "$LOG_DIR"
chown "$SITE_USER":www-data "$LOG_DIR"

cat > "$SERVICE_FILE" <<EOF
[Unit]
Description=Gunicorn for $SITE_NAME (Django)
After=network.target

[Service]
Type=simple
User=$SITE_USER
Group=www-data
WorkingDirectory=$PROJECT_DIR
Environment=PYTHONUNBUFFERED=1

# Crée /run/gunicorn-<site> avec le bon propriétaire
RuntimeDirectory=$SERVICE_NAME
RuntimeDirectoryMode=0755

# UMask pour que www-data lise le socket (660)
UMask=0007

ExecStart=$VENV_DIR/bin/gunicorn \\
  --workers $W \\
  --threads 2 \\
  --timeout 30 \\
  --access-logfile $LOG_DIR/access.log \\
  --error-logfile $LOG_DIR/error.log \\
  --bind unix:$SOCKET_PATH \\
  $WSGI_MODULE:application

Restart=on-failure
RestartSec=3s

[Install]
WantedBy=multi-user.target
EOF

# Supprimer une éventuelle ancienne socket-activation
if systemctl list-unit-files | grep -q "^$SERVICE_NAME\\.socket"; then
  systemctl stop "$SERVICE_NAME.socket" || true
  systemctl disable "$SERVICE_NAME.socket" || true
  rm -f "/etc/systemd/system/$SERVICE_NAME.socket" || true
fi

systemctl daemon-reload
systemctl enable "$SERVICE_NAME"
systemctl restart "$SERVICE_NAME"

# Attendre l'apparition du socket (max ~5s)
for i in {1..10}; do
  if [ -S "$SOCKET_PATH" ] && systemctl is-active --quiet "$SERVICE_NAME"; then
    echo "✅ Gunicorn OK (socket : $SOCKET_PATH)"
    exit 0
  fi
  sleep 0.5
done

echo "❌ Gunicorn ne fournit pas le socket attendu : $SOCKET_PATH"
journalctl -u "$SERVICE_NAME" -n 100 --no-pager || true
exit 1
