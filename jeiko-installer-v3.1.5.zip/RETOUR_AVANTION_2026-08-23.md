# Retour sur l'installeur — vu depuis l'installation d'un site tiers

**23 août 2026.** Constats relevés en préparant la mise en ligne d'Avantion
(`avantion.fr`) sur **51.91.57.254**, la machine qui sert déjà deux sites JEIKO
dont `ateliersderouineau.com`.

**Ce n'est pas un audit.** Je n'ai lu que le chemin nginx / gunicorn / TLS —
`02_users_dirs.sh`, `10_configure_gunicorn.sh`, `11_configure_nginx.sh`,
`12_setup_tls_letsencrypt.sh`, `lib/jeiko-common.sh` — parce que c'est là que
l'arrivée d'un troisième site pouvait casser quelque chose. Les 16 failles de
`AUDIT_SECURITE.md` sont un sujet distinct, non abordé ici.

**Et l'installeur est bon.** `set -euo pipefail` partout, `nginx -t` avant tout
reload avec restauration en cas d'échec, sauvegarde horodatée du vhost,
détection des `server_name` concurrents, `trap` de nettoyage. Les quatre
constats ci-dessous sont à lire sur ce fond-là.

---

## 1. `rm -f /etc/nginx/sites-enabled/default` sans remplaçant — le seul grave

`11_configure_nginx.sh:369`.

nginx sert un bloc `server` **par défaut** à toute requête dont le nom d'hôte
ne correspond à aucun `server_name` : requêtes vers l'IP nue, scans, robots,
domaine tiers pointé à tort vers la machine, sondes à en-tête `Host` forgé.
C'est le bloc portant `default_server` — et **à défaut, le premier chargé,
c'est-à-dire le premier dans l'ordre alphabétique de `sites-enabled`**.

En supprimant le vhost Debian par défaut sans en poser un autre, l'installeur
laisse ce rôle **implicite et positionnel**. Trois conséquences :

**a. Personne ne sait qui le tient.** Ce n'est écrit nulle part, ne figure dans
aucune configuration, et change au gré des noms de fichiers.

**b. N'importe quel vhost ajouté plus tard le prend, en silence.** C'est le cas
concret qui m'a fait écrire cette note : nommer le vhost d'Avantion
`avantion.conf` — le nom évident — le plaçait avant `ateliersderouineau…` en
ordre ASCII. Avantion aurait capté le trafic non apparié d'un site JEIKO en
production. Aucun avertissement, `nginx -t` « successful », les contrôles de
convergence au vert. Contourné côté Avantion par un `zz-avantion.conf` qui trie
en dernier — une rustine, pas une correction.

**c. Le trafic non apparié est servi par un site JEIKO tiré au sort.** Il
répond sous son certificat, applique sa politique HSTS, et pollue son journal
d'accès. Pour un scan c'est bénin ; pour un domaine tiers pointé sur l'IP,
c'est le contenu d'un client servi sous un nom qui n'est pas le sien.

Ça détonne aussi avec le soin du reste du script : `rm -f` sur un fichier que
l'installeur n'a pas créé, sans sauvegarde, alors que la ligne 342 juste
au-dessus prend la peine de faire
`cp -a "$NGX_AVAIL" "$NGX_AVAIL.bak_$(date …)"`.

### La correction

Poser un attrape-tout explicite, chargé en premier, qui refuse :

```nginx
# /etc/nginx/sites-available/000-jeiko-catchall.conf
server {
    listen 80 default_server;
    listen [::]:80 default_server;
    server_name _;
    return 444;                 # ferme sans répondre
}

server {
    listen 443 ssl default_server;
    listen [::]:443 ssl default_server;
    ssl_reject_handshake on;    # nginx >= 1.19.4 ; Debian 12 livre 1.22
}
```

`ssl_reject_handshake on` évite d'avoir à fabriquer un certificat auto-signé
pour le bloc 443 — c'était la partie pénible de cette correction avant nginx
1.19.4.

**Le garde-fou indispensable avant de le poser :** deux blocs `default_server`
sur la même paire écoute/adresse font **refuser le démarrage** de nginx —
« duplicate default server ». Sur une machine qui héberge déjà des sites, il
faut donc chercher un `default_server` existant avant d'en écrire un, et ne
rien faire s'il y en a un. Le script sait déjà faire ce genre de balayage : la
boucle des `CONCURRENTS` (l. 385-393) est le patron exact.

Et rendre l'attrape-tout **idempotent** : le poser une fois, ne pas le
réécrire à chaque installation de site, ne jamais le supprimer en désinstallant
un site — il n'appartient à aucun.

---

## 2. La détection de vhost concurrent avertit là où elle devrait arrêter

`11_configure_nginx.sh:395-405`.

Le commentaire de la l. 375 décrit précisément un incident de production du
15/08/2026 : un fichier `ah_new` primait sur `ah_new.conf`, le site répondait
502, et « la convergence et son contrôle final affichent des voyants verts,
puisqu'ils interrogent le backend et non le trafic public ».

Le code qui détecte exactement ça se contente d'un `jeiko_warn`, puis continue.
Dans une installation qui produit des centaines de lignes, un avertissement au
milieu du parcours est un avertissement qui ne sera pas lu — d'autant que le
script se termine, lui, sur un succès.

**Suggestion :** en faire un échec, avec un `--force` explicite pour le cas où
l'opérateur sait ce qu'il fait. La règle générale : quand un contrôle détecte
la cause connue d'une panne silencieuse, il doit arrêter, pas commenter.

---

## 3. `A && cp … || true` avale un échec de sauvegarde

`11_configure_nginx.sh:342` :

```bash
[[ -f "$NGX_AVAIL" ]] && cp -a "$NGX_AVAIL" "$NGX_AVAIL.bak_$(date +%Y%m%d_%H%M%S)" || true
```

Le `|| true` est là pour `set -e` — nécessaire, puisque le `[[ ]]` faux ferait
sortir le script. Mais il masque aussi l'échec du `cp` lui-même : disque plein,
permissions, système de fichiers en lecture seule. Le `cat >"$NGX_AVAIL"` de la
ligne suivante écrase alors la configuration **sans qu'aucune copie n'existe**,
et c'est précisément dans ces circonstances-là qu'on en aurait besoin.

```bash
if [[ -f "$NGX_AVAIL" ]]; then
    cp -a "$NGX_AVAIL" "$NGX_AVAIL.bak_$(date +%Y%m%d_%H%M%S)" \
        || jeiko_err "sauvegarde du vhost impossible — arrêt avant écrasement"
fi
```

Le motif `cond && action || true` mérite un coup d'œil ailleurs dans
l'installeur pour la même raison.

---

## 4. Les vhosts n'ont pas de préfixe d'ordre

Conséquence de 1, et à ne traiter qu'avec lui : tant que le rôle de site par
défaut est positionnel, les noms de fichiers portent une sémantique qu'ils ne
déclarent pas. Une fois l'attrape-tout `000-` en place, l'ordre n'a plus
d'importance et la question tombe — c'est d'ailleurs le meilleur argument pour
le point 1.

Si l'ordre devait rester significatif, préfixer (`10-<site>.conf`) rendrait
l'intention lisible. Mais c'est la deuxième meilleure solution.

---

## Ce que j'ai repris de l'installeur, et qui a servi tel quel

À dire, parce que ce sont des commentaires qui ont manifestement coûté une
panne chacun, et qu'ils m'ont évité de la repayer :

| Ce qui a servi | Où |
|---|---|
| `SupplementaryGroups=` — un `Group=` explicite fait perdre à systemd les groupes secondaires, contrairement à `sudo -u` | `10_configure_gunicorn.sh` |
| `Environment=HOME=` — sans quoi gunicorn 26 journalise une erreur de socket de contrôle à chaque démarrage | idem |
| `UMask=0007` — pour que la socket naisse en 0660 et que www-data puisse y **écrire** | idem |
| La propriété des journaux (`chown … www-data`, `chmod 0640`) — sinon gunicorn sort sur `PermissionError` et le site ne monte jamais | idem, incident du 15/08/2026 |
| `add_header` ne s'hérite pas dans une location enfant qui déclare le sien | `11_configure_nginx.sh` |
| `certonly --webroot` et jamais `--nginx`, qui réécrirait les blocs `server` existants | `12_setup_tls_letsencrypt.sh` |
| `nginx -t` avant tout reload, jamais de `restart` | `11_configure_nginx.sh` |

Avantion se donne par ailleurs `OOMScoreAdjust=400` là où JEIKO se donne 200 :
sous pression mémoire, le noyau sacrifie un worker d'Avantion avant le
PostgreSQL ou les gunicorn de JEIKO. Volontaire — le dernier arrivé cède.
