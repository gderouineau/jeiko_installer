# JEIKO — TODO / évolutions

Fonctionnalités à venir. Convention de statut : `[ ]` à faire · `[~]` en cours · `[x]` fait.

---

# ⚠️ PRIORITÉ — chemin nginx, quatre points relevés le 23/08/2026

Relevés en installant un **troisième site** (Avantion, non-JEIKO) sur
`51.91.57.254`, la machine qui sert déjà deux JEIKO dont `ateliersderouineau.com`.
Note d'origine : `RETOUR_AVANTION_2026-08-23.md`, à la racine de l'installeur.

Les références de lignes et les mécanismes nginx de cette note ont été
revérifiés contre le code : ils sont exacts. Ce qui suit ajoute ce que la
relecture a trouvé en plus, et corrige deux points de son ordre de priorité.

**Ordre recommandé : NGX-1, puis NGX-2, puis NGX-3.** NGX-1 passe devant parce
qu'il est le seul à pouvoir *détruire* la configuration d'un autre site.

---

### [ ] NGX-1 — Une sauvegarde ratée en silence transforme la restauration en suppression

`scripts/11_configure_nginx.sh:54` et `:56` — **le point le plus grave, et
celui que la note d'origine classait en mineur.**

`jeiko_nginx_snapshot()` sauvegarde l'état **partagé** — le `conf.d` global et
les snippets de *tous* les sites — avec le motif :

```bash
[[ -f "$f" ]] && cp -a "$f" "$NGX_STATE_BAK/snippets/" || true
```

Le `|| true` est nécessaire pour `set -e` (un `[[ ]]` faux terminerait le
script), mais il avale aussi l'échec du `cp` : disque plein, permissions,
`/tmp` saturé.

Or `jeiko_nginx_restore()` (l. 60-77) interprète l'absence de sauvegarde comme
« ce fichier a été créé par cette exécution » et fait `rm -f` :

```bash
if [[ -f "$NGX_STATE_BAK/snippets/$base" ]]; then
    cp -a ...            # restaurer
else
    rm -f "$f"           # créé par cette exécution  ← faux si le cp a échoué
fi
```

**Conséquence : la restauration supprime la configuration d'un autre site**, et
la ligne 417 annonce ensuite « État nginx d'origine restauré — les autres sites
sont intacts. » Un mensonge, au pire moment.

L'objection « un `cp` échoue rarement » ne tient pas ici : ce chemin ne
s'exécute **que** lorsque quelque chose a déjà mal tourné, et le disque plein
est une cause commune des deux.

**Correctif** — passer en `if` avec échec explicite, aux cinq endroits qui
partagent le motif sur une sauvegarde ou un déplacement :

| Fichier | Ligne | Ce qui est avalé |
|---|---|---|
| `scripts/11_configure_nginx.sh` | 54 | sauvegarde du `conf.d` global (**restauration**) |
| `scripts/11_configure_nginx.sh` | 56 | sauvegarde des snippets des autres sites (**restauration**) |
| `scripts/11_configure_nginx.sh` | 342 | sauvegarde du vhost avant écrasement |
| `scripts/09_configure_django.sh` | 148 | sauvegarde de `urls.py` avant écrasement |
| `scripts/12_setup_tls_letsencrypt.sh` | 101 | idem, avec `2>/dev/null` qui masque en plus la raison |

```bash
if [[ -f "$NGX_AVAIL" ]]; then
    cp -a "$NGX_AVAIL" "$NGX_AVAIL.bak_$(date +%Y%m%d_%H%M%S)" \
        || jeiko_err "sauvegarde du vhost impossible — arrêt avant écrasement"
fi
```

Et, indépendamment : `jeiko_nginx_restore` ne devrait pas déduire « créé par
cette exécution » d'une absence. Lui faire tenir la liste de ce qu'il a
réellement créé lève l'ambiguïté à la source.

---

### [ ] NGX-2 — `rm -f sites-enabled/default` sans remplaçant : le site par défaut devient positionnel

`scripts/11_configure_nginx.sh:369`.

nginx sert un bloc `server` **par défaut** à toute requête dont l'hôte ne
correspond à aucun `server_name` — IP nue, scans, domaine tiers pointé à tort.
C'est le bloc portant `default_server`, et à défaut **le premier chargé**,
c'est-à-dire le premier en ordre alphabétique de `sites-enabled`.
`grep -rn default_server` sur tout l'installeur ne rend rien : le rôle est donc
implicite sur toutes les machines installées.

Trois conséquences : personne ne sait qui le tient ; **tout vhost ajouté
ensuite peut le prendre en silence** ; le trafic non apparié part chez un JEIKO
tiré au sort, sous son certificat et dans son journal.

Le cas réel : nommer le vhost d'Avantion `avantion.conf` — le nom évident — le
plaçait avant `ateliersderouineau…` en ordre ASCII et lui donnait le rôle.
Aucun avertissement, `nginx -t` « successful ». Contourné par un
`zz-avantion.conf` qui trie en dernier — rustine, pas correction.

*Gravité, pour être juste* : il n'y a pas de fuite entre sites. En HTTPS sans
SNI apparié, le client reçoit le certificat du site par défaut, donc une
**erreur de nom visible**. C'est une confusion de nom d'hôte, pas une
divulgation.

**Correctif** — un attrape-tout explicite, `sites-available/000-jeiko-catchall.conf` :

```nginx
server {
    listen 80 default_server;
    listen [::]:80 default_server;
    server_name _;
    return 444;                 # ferme sans répondre
}
server {
    listen 443 ssl default_server;
    listen [::]:443 ssl default_server;
    ssl_reject_handshake on;    # nginx >= 1.19.4 ; Debian 12 livre 1.22
}
```

`ssl_reject_handshake` évite d'avoir à fabriquer un certificat auto-signé pour
le bloc 443.

**⚠️ Garde-fou obligatoire — c'est ce qui peut casser la machine.** Deux
`default_server` sur la même paire écoute/adresse font **refuser le démarrage**
de nginx (« duplicate default server ») — donc *tous* les sites tombent, pas
seulement celui qu'on installe. Avant d'écrire quoi que ce soit :

```bash
sudo nginx -T | grep -n default_server
```

S'il en existe déjà un — **et Avantion a pu en poser un** en contournant ce
défaut — ne rien écrire et le signaler. La boucle `CONCURRENTS` (l. 385-393)
est le patron exact du balayage.

Deux points que la note d'origine n'a pas vus :

- **Rien à faire côté désinstallation.** Elle demandait de ne jamais supprimer
  l'attrape-tout ; c'est acquis par construction, `uninstall.sh:136` ne retire
  que `$SITE.conf`.
- **Cela change le comportement des installations existantes** : aller à l'IP
  nue pour vérifier qu'un site répond cessera de fonctionner. Voulu, mais à
  annoncer — sinon ce sera signalé comme une régression.

L'attrape-tout doit être **idempotent** : posé une fois, non réécrit à chaque
installation de site.

*(Corollaire, sans action propre : tant que le rôle est positionnel, les noms
de vhosts portent une sémantique d'ordre qu'ils ne déclarent pas. Une fois le
`000-` posé, la question tombe — c'est le meilleur argument pour NGX-2.)*

---

### [ ] NGX-3 — La détection de vhost concurrent avertit là où elle devrait arrêter

`scripts/11_configure_nginx.sh:393-400`.

C'est le contrôle de BUG-4, la panne du 15/08/2026 — celle dont le commentaire
de la l. 375 dit lui-même que « tous les voyants seront au vert ». Il se
contente d'un `jeiko_warn` puis continue. Au milieu de centaines de lignes, et
suivi d'un succès, cet avertissement ne sera pas lu.

**Mais le correctif demande d'être conçu, pas seulement durci** — deux raisons
de ne pas se contenter d'un `jeiko_die` :

1. **À la l. 393, le vhost et le lien symbolique sont déjà écrits** (l. 370).
   Un arrêt nu laisse la machine à moitié configurée. Il faut le même déroulé
   de restauration que le chemin `nginx -t` (l. 413-423).
2. **Un vhost concurrent est légitime pendant un remplacement** — c'est ce que
   fait `migrate_site.sh`. Arrêter sans porte de sortie casse le chemin de
   migration normal.

Et `--force` n'est pas l'idiome de la maison : `install.sh:70` demande une
confirmation interactive « oui/non » pour exactement ce cas de figure. Reprendre
cette convention plutôt que d'en introduire une seconde.

Règle générale à retenir : *quand un contrôle détecte la cause connue d'une
panne silencieuse, il doit arrêter — mais un arrêt qui laisse l'état à
mi-chemin est pire que l'avertissement qu'il remplace.*

---

### À savoir avant de toucher à ces trois points

**`Projects/INSTALLER_jeiko/` est une copie de ce dossier**, remise au projet
Avantion pour qu'il s'installe sur `51.91.57.254` sans casser les deux JEIKO
qui y tournent. Vérifiée identique au 23/08/2026, au fichier de retour près.
C'est ce qui a produit les constats ci-dessus, donc l'échange a servi.

Deux conséquences quand NGX-1 à NGX-3 seront traités :

- **La copie va diverger.** Elle est un instantané, pas un lien. Si Avantion
  s'en sert encore comme référence, la rafraîchir après correction — sinon il
  travaillera sur un installeur qui n'existe plus.
- **Avantion tourne sur la machine visée.** Son vhost s'appelle
  `zz-avantion.conf`, nommé ainsi pour trier en dernier et *ne pas* prendre le
  rôle de site par défaut. C'est un contournement de NGX-2. Poser
  l'attrape-tout rend ce nom inutile mais ne le casse pas — en revanche, si
  Avantion a depuis déclaré un `default_server` de son côté, poser le nôtre
  fait **refuser le démarrage de nginx et tombe les trois sites**. D'où le
  `nginx -T | grep default_server` obligatoire avant d'écrire.

---

## [ ] MAJ-1 — Notification quotidienne de mise à jour disponible

**But** : détecter chaque jour si une version de `jeiko` **supérieure** à celle
installée a été publiée, et l'annoncer dans le *quick admin menu* par un lien
« Mise à jour en attente » (ex. « Mise à jour 1 ») qui renvoie vers la page de
mise à jour de l'administration. Le message disparaît une fois la mise à jour
réussie.

### Pourquoi passer par un cron (et pas un check à chaque requête)
Le canal de publication est distant (`version.json` sur
`raw.githubusercontent.com/gderouineau/jeiko`). Interroger le réseau à chaque
chargement de page serait lent et exposé au rate-limiting. On respecte aussi la
frontière de privilèges existante : **l'application ne fait pas d'appel réseau
sortant**. Un job root écrit le résultat dans un fichier d'état (comme
`update.state`), l'app le lit en local, sans coût ni droit particulier.

### Points d'ancrage existants (à réutiliser, ne pas réécrire)
- Version installée : `_jeiko_installed_version()` — `administration/views.py`
  (`importlib.metadata.version("jeiko")`).
- État de mise à jour : `_jeiko_update_state(site)` — lit
  `/var/lib/jeiko/<site>/update.state` (écrit par `jeiko-client-update`, root,
  non falsifiable par le site). Statuts déjà gérés : `idle` / `unknown` / …
- Version publiée : `jeiko_read_manifest` (`lib/jeiko-common.sh`) lit
  `version.json` sur `JEIKO_CHANNEL_URL`
  (défaut `JEIKO_DEFAULT_CHANNEL_URL`) → `JEIKO_PKG_VERSION`.
- Emplacement du badge : `templates/includes/quick_admin_menu.html`.
- Page cible du lien : la vue de mise à jour de l'administration
  (`administration/views.py`, autour de `JEIKO_CLIENT_UPDATER` /
  `_jeiko_update_state`) — reprendre son nom d'URL réel.

### Sous-tâches

- [ ] **Cron/timer côté serveur** (installeur). Ajouter un script d'étape +
  une unité systemd `timer` quotidienne (modèle : `scripts/13_backups.sh` et les
  unités `jeiko-update@`). Le job, en root :
  1. lit la version installée du site,
  2. `jeiko_read_manifest` sur le canal pour la version publiée,
  3. écrit `/var/lib/jeiko/<site>/update.available` (root, groupe du site, `0640`)
     avec `{ "latest": "<x.y.z>", "checked_at": "<iso>" }`.
  Déployé/convergé par `jeiko-server-update` (ajouter une étape), et déposé par
  `migrate_site.sh --tools-only`. Idempotent, échec réseau silencieux (dégrade,
  ne casse pas).

- [ ] **Lecture côté package.** Fonction `_jeiko_update_available(site)` qui lit
  `update.available` façon `_jeiko_update_state` (tolérante aux
  `FileNotFoundError` / `PermissionError`). Exposer au template via context
  processor ou tag, en réutilisant `_jeiko_site_name()`.

- [ ] **Badge dans le quick admin menu.** Dans `quick_admin_menu.html`, si
  `latest` > version installée (comparaison **sémantique**, pas lexicale : « 3.0.10 »
  > « 3.0.9 »), afficher un `<li>` « Mise à jour en attente » (compteur possible)
  pointant vers la page de mise à jour. N'afficher qu'aux comptes ayant le droit
  de lancer la mise à jour.

- [ ] **Disparition automatique.** Le badge est **dérivé** de
  `latest > installée` : après un `jeiko-client-update` réussi, la version
  installée rejoint `latest` → le badge s'efface sans action explicite. Gérer en
  plus l'état transitoire : si `_jeiko_update_state` est « en cours », afficher
  « Mise à jour en cours… » plutôt que le lien.

### Critères d'acceptation
1. Une version publiée supérieure fait apparaître le lien dans les 24 h (ou
   immédiatement après un passage manuel du cron).
2. Le lien mène à la page de mise à jour de l'administration.
3. Après une mise à jour réussie, le message disparaît de lui-même.
4. Aucun appel réseau depuis le processus web ; panne réseau du cron = pas de
   message, jamais d'erreur 500.
5. Le site ne peut pas se déclarer « à jour » en falsifiant un fichier
   (fichier d'état root, lecture seule pour le site).

---

# Défauts relevés en production — migration de `ah_new` (15/08/2026)

Première migration d'un site en production vers le schéma v3. Elle a provoqué
**deux interruptions de service** et une mise à jour en échec. Tout est
consigné ici : `ah_pro` rencontrera les mêmes pièges à l'identique.

Statut : `[x]` corrigé dans `Art/INSTALLER` · `[ ]` à faire.

## Ceux qui ont causé ou aggravé une panne

### [x] BUG-1 — Les logs préexistants ne sont pas réattribués → gunicorn refuse de démarrer
`scripts/10_configure_gunicorn.sh`

`install -d -m 0750 -o "$SITE_USER" -g www-data "$LOG_DIR"` corrige le
**dossier** mais pas les fichiers qu'il contient. Sur `ah_new`, `access.log` et
`error.log` appartenaient à `www-data` en `0644` alors que le nouveau service
tourne sous `debian` : `PermissionError` sur `error.log`, gunicorn sort
immédiatement. **Le site est tombé.**

Correctif : `chown -R "$SITE_USER":www-data "$LOG_DIR"` et `chmod 0640` sur les
fichiers, après le `install -d`. Concerne tout site migré dont les logs
préexistent — donc tous.

### [x] BUG-2 — Le rollback ne restaure pas le `.socket` qu'il vient de supprimer
`scripts/10_configure_gunicorn.sh` + `updater/jeiko-server-update` [1/8]

L'étape 10 supprime `gunicorn-<site>.socket` (nettoyage d'une socket-activation
héritée), mais la sauvegarde `[1/8]` ne couvre que le `.service`, le sudoers, le
vhost et le `.env`. Quand l'étape échoue, le rollback restaure un `.service` qui
réclame une socket désormais inexistante : `Failed to schedule restart job`.
**C'est ce qui a transformé un échec de convergence en panne réelle.**

Correctif : sauvegarder `*.socket` dans `[1/8]`, et le restaurer avec le
`.service`. Règle générale : un rollback doit restaurer tout ce qu'il détruit.

### [x] BUG-3 — `SITE_USER` non transmis aux scripts 11 et 12
`updater/jeiko-server-update` — **corrigé**

`12_setup_tls_letsencrypt.sh:211` fait
`chown "${SITE_USER:-jeiko-$SITE_NAME}"`. La convergence appelait les scripts 11
et 12 sans passer `SITE_USER` : le repli `jeiko-<site>` s'appliquait, ce compte
n'existe pas sur un site migré, `chown` échouait, `set -e` sortait, et **tout le
bloc nginx était annulé** alors que le vhost venait d'être écrit correctement.
Gunicorn se retrouvait sur la nouvelle socket et nginx sur l'ancienne → **502**.

### [x] BUG-4 — Vhost en doublon non détecté
`scripts/11_configure_nginx.sh`

Le script écrit `sites-available/<site>.conf` et l'active en
`sites-enabled/<site>.conf`, sans vérifier qu'un vhost servant le **même
`server_name`** existe déjà. Sur `ah_new`, un fichier `sites-enabled/ah_new`
(sans extension, non symbolique) subsistait, pointait sur l'ancienne socket, et
primait en ordre ASCII sur `ah_new.conf`. Résultat : **502 pour les visiteurs**,
alors que `nginx -t` ne produisait qu'un avertissement `conflicting server name`
et que le contrôle `[8/8]` affichait « ✅ Le site répond (HTTP 200) », puisqu'il
teste le backend et non le trafic public.

Correctif : détecter les `server_name` en conflit (`nginx -T`), refuser ou
signaler bruyamment, et faire porter le contrôle final sur l'URL publique.

### [x] BUG-5 — Le wheel de secours n'est pas vérifié avant la mise à jour
`updater/jeiko-client-update`

Le rollback réinstalle `/var/lib/jeiko/<site>/wheels/<précédent>.whl`. Sur un
site migré, ce fichier n'existe pas (l'ancien mécanisme ne l'y déposait pas) :

    ERROR: Could not install packages due to an OSError: [Errno 13]
    Permission denied: '.../jeiko-3.0.5-py3-none-any.whl'

La base a été restaurée mais **le paquet est resté en version neuve** : code
récent sur schéma ancien, l'état le plus incohérent possible. Le script promet
un filet de sécurité qu'il n'a pas, et ne s'en aperçoit qu'au pire moment.

Correctif : vérifier présence **et** lisibilité du wheel de secours **avant**
d'installer quoi que ce soit ; refuser de démarrer sinon, `--force` pour
outrepasser en connaissance de cause.

### [x] BUG-6 — Le cache n'est pas purgé après changement de version
`updater/jeiko-client-update`

La 3.0.5 mettait en cache une **instance** `Menu` ; la 3.1.0 n'y met que son
`pk`, sous la même clé. Après mise à jour, le nouveau code relit l'ancienne
valeur et lève
`TypeError: Field 'id' expected a number but got <Menu: Principal>` :
**site entier en 500**, alors que code, base et configuration étaient corrects.

Correctif : purger le cache après installation du paquet et **avant** le
contrôle de santé. Plus fin et sans purge partagée : intégrer la version du
paquet dans `KEY_PREFIX`, ce qui invalide naturellement à chaque montée.
C'est probablement le correctif le plus rentable de cette liste — il aurait à
lui seul évité l'échec de la mise à jour.

### [x] BUG-7 — Le rollback de base laisse les tables créées par les migrations
`updater/jeiko-client-update`

La restauration utilise `pg_restore --clean --if-exists`, qui ne supprime que
les objets **présents dans le dump**. Les tables créées par les migrations de la
version neuve (`administration_socialprovider`, `administration_favicon`,
`users_adminpermission`) survivent, tandis que `django_migrations` revient en
arrière. `migrate` échoue alors sur `DuplicateTable` et **la base ne peut plus
avancer** sans intervention manuelle.

Correctif : restaurer dans un schéma vide (`DROP SCHEMA public CASCADE` puis
restauration), ou redescendre les migrations (`migrate <app> <précédente>`)
avant de restaurer les données.

## Configuration manquante

### [x] CONF-1 — `ALLAUTH_TRUSTED_PROXY_COUNT` absent → connexion impossible
`templates/settings.template.py` — **corrigé**

django-allauth ≥ 65.4 limite le débit des vues d'authentification et exige l'IP
du client. Gunicorn écoutant sur une socket Unix, `REMOTE_ADDR` est vide :
allauth lève `PermissionDenied` sur **chaque POST** de connexion. La page
s'affiche (le GET n'est pas limité) mais **plus personne ne peut se connecter**,
quel que soit le compte.

Invisible en développement (runserver reçoit en TCP, `REMOTE_ADDR=127.0.0.1`).
Apparu au passage d'allauth 65.3 → 65.19 pendant la mise à jour.

⚠️ `ALLAUTH_TRUSTED_CLIENT_IP_HEADER = "X-Real-IP"` a été essayé sans succès en
production ; c'est `ALLAUTH_TRUSTED_PROXY_COUNT = 1` (lecture de
`X-Forwarded-For`) qui fonctionne.

## Contrôles trop permissifs

### [x] CTRL-1 — Le contrôle `[8/8]` ne teste qu'un `GET`
`updater/jeiko-server-update`

Il a affiché « ✅ Le site répond (HTTP 200) » et « ✅ L'interface
d'administration peut déclencher la mise à jour » alors que, simultanément, les
visiteurs recevaient des 502 (BUG-4) et que personne ne pouvait se connecter
(CONF-1). Le test sudo est lancé depuis le shell **root** de la convergence, pas
depuis le cgroup de gunicorn : il ne valide donc jamais le vrai chemin (BUG-8).

Correctif : contrôler l'**URL publique**, et vérifier qu'un `POST` sur la page
de connexion aboutit. Ces deux ajouts auraient détecté les deux pannes
immédiatement, et déclenché le rollback.

### [x] BUG-8 — `NoNewPrivileges` réactivé par implication
`scripts/10_configure_gunicorn.sh` — **corrigé**

L'unité posait `NoNewPrivileges=no` avec un commentaire expliquant que c'était
délibéré (sudo est setuid), puis `ProtectKernelTunables=`,
`ProtectKernelModules=`, `RestrictSUIDSGID=` et `LockPersonality=` — quatre
options qui, d'après systemd.exec(5), **impliquent** `NoNewPrivileges=yes`.
L'implication l'emportait, et la mise à jour depuis l'administration échouait
avec « the "no new privileges" flag is set ».

Piste de fond : ne plus dépendre de `sudo` depuis le processus web. L'appli
déposerait un jeton dans un dossier surveillé par une unité `systemd.path`, et
le service resterait pleinement durci.

## Points mineurs

### [x] MIN-1 — `HOME` non défini dans l'unité gunicorn
`[ERROR] Control server error: [Errno 13] Permission denied: '/home/debian'` à
chaque démarrage (gunicorn 26 + `ProtectHome=yes`). Sans conséquence, mais
pollue les logs. Ajouter `Environment=HOME=$PROJECT_DIR`.

### [ ] MIN-2 — `HEAD` sur les pages de connexion renvoie 403
`GET /accounts/login/` → 200, `HEAD` → 403. Sans effet pour les navigateurs,
mais la plupart des sondes de disponibilité interrogent en `HEAD` et
signaleraient la page comme cassée.

### [x] MIN-3 — `migrate_site.sh --dry-run` inutilisable sur un site non enregistré
En simulation la fiche n'est pas écrite, mais le script enchaîne quand même sur
`jeiko-server-update`, qui exige cette fiche : l'essai se termine toujours par
`❌ Fiche de site introuvable`. Le `--dry-run` ne peut donc jamais aboutir dans
le cas précis où il serait le plus utile.

### [ ] MIN-4 — Dépendances non déclarées
`setfacl` absent → « ACL non appliquées » (paquet `acl`). Ajouter au contrôle
des dépendances de l'étape 03.

## Remarque transverse

Le compte de service de `ah_new` est `debian`, c'est-à-dire l'utilisateur SSH
d'administration, détecté par `migrate_site.sh` à partir du propriétaire du
dossier projet. Le modèle d'isolation v2 (« l'application ne peut que déclencher
sa propre mise à jour ») perd alors sa portée : ce compte dispose déjà de `sudo`
complet. Préexistant, sans lien avec la migration, mais à traiter si on veut que
le durcissement ait un sens sur ce site.

---

# Deuxième série — mise à jour d'`ateliersderouineau` (16/08/2026)

Autre serveur (`vps-6bbf8214`), autre site, compte de service dédié
(`jeiko-ateliersderouineau`). La mise à jour a échoué, et le retour arrière
avec elle — révélant que **toute la mécanique de rollback était inopérante
depuis l'origine**, sur tous les sites.

### [x] BUG-9 — Le cache de wheels est inaccessible au compte du site
`updater/jeiko-client-update`

    install -d -m 0750 -o root -g root "$WHEEL_CACHE"

`root:root` en `0750`, alors que `pip` est lancé sous l'identité du site
(`jeiko_as_site`). La réinstallation du wheel précédent échouait donc
systématiquement :

    ERROR: Could not install packages due to an OSError: [Errno 13]
    Permission denied: '.../jeiko-3.1.1-py3-none-any.whl'

Le retour arrière du paquet n'a **jamais** fonctionné, sur aucun site, jusqu'à
cette date. Correctif : dossier et wheels en `root:<compte du site>`, `0750` /
`0640` — le site lit, lui seul et root, et ne peut rien modifier.

### [x] BUG-5 bis — La vérification du wheel testait la lisibilité en root
`updater/jeiko-client-update`

Le contrôle ajouté la veille (BUG-5) utilisait `find -readable`, exécuté en
root : root lit tout, y compris un cache que pip ne pourra pas ouvrir. Il
validait donc un filet de sécurité inexistant. Correctif : `test -r` **sous le
compte du site**, avec correction automatique des droits si nécessaire.

Leçon générale : tout contrôle d'accès doit être fait sous l'identité qui
effectuera réellement l'opération.

### [x] BUG-10 — La détection des gabarits masque la cause de son échec
`updater/jeiko-client-update`, `sync_project_templates`

La sonde Python tournait avec `2>/dev/null`, et son échec produisait :

    ⚠️ Le package n'embarque pas de gabarits (jeiko/project_template).

**Message faux** : le wheel 3.1.2 contenait bien les trois fichiers (vérifié par
`unzip -l`). Conséquence lourde : `settings.py` n'était pas réaligné, donc
`ALLAUTH_TRUSTED_PROXY_COUNT` n'arrivait pas, donc **plus aucune connexion
n'aboutissait** — et l'avertissement envoyait chercher le problème du mauvais
côté (republier le paquet).

Correctif : `HOME` imposé (le home du compte de service peut être inaccessible
et faire échouer l'interpréteur), erreurs affichées au lieu d'être avalées, et
message indiquant la conséquence réelle plutôt qu'une cause supposée.

### [x] BUG-7 bis — `DROP SCHEMA public` échoue faute d'être propriétaire
`updater/jeiko-client-update`

Le correctif de la veille supposait que le rôle applicatif possédait le schéma
`public`. Ce n'est généralement pas le cas :

    ⚠️ Purge du schéma impossible — la restauration peut laisser des tables orphelines.
    ❌ Restauration DB échouée — intervention manuelle requise

Correctif : suppression table par table de celles dont le rôle est
propriétaire (`tableowner = current_user`) — exactement celles que les
migrations ont pu créer — puis `pg_restore --clean --if-exists` en filet.

### Constat d'ensemble

Ni le paquet ni la base ne pouvaient être restaurés. Le script annonçait
pourtant « Le site a été remis dans son état antérieur ». Deux migrations ont
ainsi exigé une réparation manuelle alors qu'un rollback fonctionnel les aurait
absorbées. **Un mécanisme de retour arrière doit être testé en conditions
réelles**, sans quoi il n'offre qu'une confiance trompeuse.

---

# État du serveur après la migration de `ah_new`

Site fonctionnel au 15/08/2026 : public en 200, médias de formation protégés
(404 en accès direct), paquet 3.1.0, base à jour, connexion et mise à jour
depuis l'administration opérationnelles.

## Interventions manuelles en place — à ne pas perdre

| Intervention | Emplacement | Survit à une maj ? |
|---|---|---|
| `ALLAUTH_TRUSTED_PROXY_COUNT = 1` | `/var/www/ah_new/ah_new/settings.py` | ❌ **écrasé** par le réalignement du gabarit |
| `ALLAUTH_TRUSTED_CLIENT_IP_HEADER` (commenté, sans effet) | idem | ❌ idem |
| Override systemd (`NoNewPrivileges`) | `/etc/systemd/system/gunicorn-ah_new.service.d/override.conf` | ✅ les drop-ins survivent |
| Permissions des logs corrigées | `/var/log/gunicorn/ah_new/` | ⚠️ à refaire si les logs sont recréés |
| Ancien vhost écarté | déplacé en `/root/vhost-ah_new-ancien-2026-08-15.conf` | ✅ |

⚠️ **Republier l'installeur est impératif** : tant que le gabarit corrigé n'est
pas publié, le prochain `jeiko-client-update` réécrira `settings.py` sans
`ALLAUTH_TRUSTED_PROXY_COUNT` et **recassera la connexion sur tout le site**.

    cd ~/Documents/Projects/packages/jeiko && ./publier-installer.sh

## Reste à faire sur `ah_new`

- [ ] Renseigner les **hash Vimeo** dans l'admin (champ « Hash / clé privée de
      la vidéo »). Les vidéos non listées renvoient 403 sans leur hash ;
      laisser vide pour les vidéos publiques. Commande de listing en section G
      de `AUDIT_COURSES.md`.
- [ ] Remonter **`dev.accompagnementhumain.com`** : le bloc `server` est dans
      `/root/vhost-ah_new-ancien-2026-08-15.conf` et proxifie vers l'ancienne
      socket ; le repointer sur `/run/gunicorn-ah_new/gunicorn.sock`.
- [ ] Adresse e-mail d'expiration du certificat (aucune alerte aujourd'hui).
- [ ] `JEIKO_OFFSITE_TARGET` : les sauvegardes (973 Mo) restent uniquement sur
      la machine.

---

# Avant de migrer `ah_pro`

Il cumule les mêmes conditions que `ah_new` : logs préexistants, socket
historique, vhost possiblement en doublon, même saut d'allauth. Sans
préparation, il subira la **même série de pannes**.

## Ordre recommandé

1. **Publier l'installeur corrigé** (apporte CONF-1, BUG-3, BUG-8 et le blocage
   nginx des médias). Sans cette étape, tout le reste est à refaire à la main.
2. **Corriger au minimum BUG-1, BUG-2 et BUG-5** — ce sont eux qui ont
   transformé des échecs récupérables en interruptions de service.
3. **Contrôles préalables**, avant toute commande :

       ls -la /var/log/gunicorn/ah_pro/            # propriétaire des logs (BUG-1)
       ls -l /etc/systemd/system/gunicorn-ah_pro.* # présence d'un .socket (BUG-2)
       ls -l /etc/nginx/sites-enabled/             # vhost en doublon (BUG-4)
       sudo nginx -T | grep -n server_name         # server_name en conflit
       ls -l /var/lib/jeiko/ah_pro/wheels/         # wheel de secours (BUG-5)

4. **Prendre un dump** avant de commencer.
5. `sudo ./migrate_site.sh ah_pro` puis
   `sudo jeiko-server-update ah_pro --with-client`.
6. **Vérifier la connexion** (`POST` sur la page de connexion), pas seulement
   que la page d'accueil répond — c'est la leçon de CTRL-1.

## Leçon générale

Sur `ah_new`, tous les voyants de la convergence étaient au vert pendant que les
visiteurs recevaient des 502 et que plus personne ne pouvait se connecter. Un
contrôle qui teste le backend depuis la machine, en `GET`, sur la page
d'accueil, ne dit rien de ce que vit un utilisateur. C'est le correctif de fond
à apporter à l'outillage.
