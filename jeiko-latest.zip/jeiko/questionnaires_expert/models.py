from django.db import models
from django.utils.text import slugify
from jeiko.administration_pages.models import Page
from django.conf import settings
import uuid
import string
import random
from django.core.validators import RegexValidator

class ExpertTest(models.Model):
    title = models.CharField(max_length=200)
    slug = models.SlugField(unique=True)
    description = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.title


class ExpertProfileType(models.Model):
    test = models.ForeignKey(ExpertTest, on_delete=models.CASCADE, related_name="profiles")
    name = models.CharField(
        max_length=100
    )
    description = models.TextField(
        blank=True
    )
    result_page = models.ForeignKey(
        Page,
        null=True,
        blank=True,
        on_delete=models.SET_NULL
    )
    slug = models.SlugField(
        max_length=100,
        unique=True,
        blank=True
    )
    is_complex = models.BooleanField(
        default=False,
        help_text="Profil majeur/complexe ou simple"
    )
    is_score_profile = models.BooleanField(
        default=False,
        help_text="Ce profil peut être assigné automatiquement en fonction d'un score global."
    )
    min_score = models.FloatField(
        null=True, blank=True,
        help_text="Score minimum (inclus) pour attribuer ce profil. Laisser vide si non applicable."
    )
    max_score = models.FloatField(
        null=True, blank=True,
        help_text="Score maximum (exclus) pour attribuer ce profil. Laisser vide si non applicable."
    )
    score_axis = models.CharField(
        max_length=100, blank=True,
        help_text="Nom du score à utiliser (laisse vide pour score global). Permet d'étendre aux tests multi-axes."
    )
    # Relation many-to-many récursive pour parents (et donc enfants en reverse)
    parent_profiles = models.ManyToManyField(
        'self',
        symmetrical=False,
        related_name='child_profiles',
        blank=True,
        help_text="Profils parents de ce profil (relation many-to-many récursive)"
    )

    color = models.CharField(
        max_length=7,
        blank=True,
        default="#cccccc",
        validators=[
            RegexValidator(
                regex=r"^#(?:[0-9a-fA-F]{3}){1,2}$",
                message="Entrez une couleur hexadécimale valide, ex : #3A4BC7"
            )
        ],
        help_text="Couleur associée au profil (ex : #FF0000)."
    )

    def save(self, *args, **kwargs):
        if not self.slug and self.name:
            base = slugify(self.name)
            suffix = str(uuid.uuid4())[:8]  # 8 caractères pour limiter la longueur
            self.slug = f"{base}-{suffix}"
        super().save(*args, **kwargs)

    def __str__(self):
        return self.name


class ExpertQuestion(models.Model):
    test = models.ForeignKey(ExpertTest, on_delete=models.CASCADE, related_name='questions')
    text = models.TextField()
    order = models.PositiveIntegerField(default=0)
    question_type = models.CharField(
        max_length=50,
        choices=[('single', 'Choix unique'), ('multiple', 'Choix multiple')],
        default='single'
    )
    extra_config = models.JSONField(blank=True, null=True)

    class Meta:
        ordering = ['order']

    def __str__(self):
        return self.text


class ExpertAnswer(models.Model):
    question = models.ForeignKey(ExpertQuestion, on_delete=models.CASCADE, related_name='answers')
    text = models.CharField(max_length=300)
    order = models.PositiveIntegerField(default=0)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ['order']

    def __str__(self):
        return self.text


class ExpertAnswerProfileWeight(models.Model):
    answer = models.ForeignKey(
        ExpertAnswer,
        on_delete=models.CASCADE,
        related_name='profile_weights',

    )
    profile_type = models.ForeignKey(
        ExpertProfileType,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    weight = models.FloatField(default=1.0)

    class Meta:
        unique_together = ('answer', 'profile_type')

    def __str__(self):
        return f"{self.answer.text} → {self.profile_type.name} (poids {self.weight})"


class ExpertProfileCombination(models.Model):
    test = models.ForeignKey(ExpertTest, on_delete=models.CASCADE, related_name="combinations")

    parent_profile = models.ForeignKey(
        ExpertProfileType,
        on_delete=models.CASCADE,
        related_name='parent_combinations',
        limit_choices_to={'is_complex': True}
    )
    preferred_profile = models.ForeignKey(
        ExpertProfileType,
        on_delete=models.CASCADE,
        related_name='preferred_combinations',
        limit_choices_to={'is_complex': True},
        blank=True, null=True
    )
    alternative_profile = models.ForeignKey(
        ExpertProfileType,
        on_delete=models.CASCADE,
        related_name='alternative_combinations',
        limit_choices_to={'is_complex': True},
        blank=True, null=True
    )
    slug = models.SlugField(max_length=150, blank=True, unique=True)
    title = models.CharField(max_length=150, blank=True)

    def save(self, *args, **kwargs):
        if not self.slug and self.title:
            base = slugify(self.title)
            suffix = str(uuid.uuid4())[:8]  # 8 caractères pour limiter la longueur
            self.slug = f"{base}-{suffix}"
        super().save(*args, **kwargs)

    def __str__(self):
        return self.title or f"Combinaison {self.id} pour {self.test.title}"



class ExpertProfileCriterion(models.Model):
    combination = models.ForeignKey(
        'ExpertProfileCombination',
        on_delete=models.CASCADE,
        related_name='criteria'
    )

    profile_a = models.ForeignKey(
        'ExpertProfileType',
        on_delete=models.CASCADE,
        related_name='criteria_as_a'
    )
    profile_b = models.ForeignKey(
        'ExpertProfileType',
        on_delete=models.CASCADE,
        related_name='criteria_as_b'
    )

    # Comparateur : >, <, >=, <=, ==, ~= (proche)
    COMPARISON_CHOICES = [
        ('>', 'Supérieur à'),
        ('<', 'Inférieur à'),
        ('>=', 'Supérieur ou égal à'),
        ('<=', 'Inférieur ou égal à'),
        ('==', 'Égal à'),
        ('~=', 'Proche de'),  # différence absolue <= tolerance
    ]
    comparison = models.CharField(
        max_length=4,
        choices=COMPARISON_CHOICES,
        default='>',
    )

    # Écart minimal toléré pour que la condition soit vraie (optionnel)
    tolerance = models.IntegerField(
        null=True,
        blank=True,
        help_text="Valeur utilisée uniquement pour '~=' (proximité)"
    )

    # Priorité dans l’évaluation (comme aujourd’hui)
    priority = models.IntegerField(default=0)

    # Type de sortie visé (parent / preferred / alternative)
    OUTPUT_CHOICES = [
        ('parent', 'Parent (dominant)'),
        ('preferred', 'Préféré'),
        ('alternative', 'Alternatif'),
    ]
    output_type = models.CharField(
        max_length=20,
        choices=OUTPUT_CHOICES,
        default='parent',
        help_text="Définit le type de profil ciblé si cette condition est satisfaite"
    )

    def __str__(self):
        return f"{self.profile_a} {self.comparison} {self.profile_b}"


class Prospect(models.Model):

    GENDER_TYPE_CHOICES = [
        ('MEN', 'Homme'),
        ('WOMEN', 'Femme'),
        ('OTHER', 'Autre'),
        ('NOT_PRECISED', 'Non précisé'),
        ('GENDER', 'Genre'),
    ]
    gender = models.CharField(
        default='GENDER',
        verbose_name='Genre',
        choices=GENDER_TYPE_CHOICES,
    )

    firstname = models.CharField(
        max_length=200,
        verbose_name='Prénom',

    )

    lastname = models.CharField(
        max_length=200,
        verbose_name='Nom'
    )

    date_created = models.DateTimeField(
        auto_now_add=True,
        blank=True,
    )

    email = models.EmailField(
        max_length=200,
        verbose_name="Email",
    )

    phone = models.CharField(
        max_length=20,
        verbose_name='Téléphone',
    )



    slug = models.SlugField(max_length=100, unique=True, blank=True)

    def save(self, *args, **kwargs):
        if not self.slug:
            base = slugify(f"{self.firstname}-{self.lastname}")
            self.slug = self._generate_unique_slug(base)
        super().save(*args, **kwargs)

    def _generate_unique_slug(self, base, size=6):
        chars = string.ascii_lowercase + string.digits
        while True:
            suffix = ''.join(random.choices(chars, k=size))
            new_slug = f"{base}-{suffix}"
            if not Prospect.objects.filter(slug=new_slug).exists():
                return new_slug



class ExpertTestData(models.Model):
    data = models.JSONField(
        null=True,
        blank=True,
        verbose_name="Données brutes du test",
        help_text="Contient les réponses, scores, profils, etc."
    )

    prospect = models.ForeignKey(
        Prospect,
        blank=True,
        null=True,
        on_delete=models.CASCADE,
        related_name="test_datas",
        help_text="Le prospect ayant passé le test (si non connecté)."
    )

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        blank=True,
        null=True,
        on_delete=models.SET_NULL,
        related_name="expert_test_datas",
        help_text="Utilisateur connecté (si applicable)."
    )

    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name="Date de création"
    )

    test = models.ForeignKey(
        'ExpertTest',
        on_delete=models.CASCADE,
        related_name="datas",
        verbose_name="Test associé"
    )

    result_profile = models.ForeignKey(
        'ExpertProfileType',
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="result_test_datas",
        help_text="Profil principal déterminé par le test"
    )

    preferred_profile = models.ForeignKey(
        'ExpertProfileType',
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="preferred_test_datas",
        help_text="Profil préféré (si déterminé par une combinaison)"
    )

    alternative_profile = models.ForeignKey(
        'ExpertProfileType',
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="alternative_test_datas",
        help_text="Profil alternatif (si applicable)"
    )

    def __str__(self):
        return f"Résultat {self.test.title} - {self.prospect or 'Anonyme'} ({self.created_at.date()})"




