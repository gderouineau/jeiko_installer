from django.urls import path
from jeiko.questionnaires_expert import views

app_name = "jeiko_administration_questionnaires_expert"

urlpatterns = [
    path("tests/", views.ExpertTestListView.as_view(), name="test_list"),
    path("tests/create/", views.ExpertTestCreateView.as_view(), name="test_add"),
    path("tests/<int:test_id>/", views.ExpertTestDetailView.as_view(), name="test_detail"),
    path("tests/<int:test_id>/edit/", views.ExpertTestUpdateView.as_view(), name="test_edit"),
    path("tests/<int:test_id>/delete/", views.ExpertTestDeleteView.as_view(), name="test_delete"),

    path("tests/<int:test_id>/questions/create/", views.ExpertQuestionCreateView.as_view(), name="question_add"),
    path("questions/<int:question_id>/edit/", views.ExpertQuestionUpdateView.as_view(), name="question_edit"),
    path("questions/<int:question_id>/delete/", views.ExpertQuestionDeleteView.as_view(), name="question_delete"),

    path("questions/<int:question_id>/answers/create/", views.ExpertAnswerCreateView.as_view(), name="answer_add"),
    path("answers/<int:answer_id>/edit/", views.ExpertAnswerUpdateView.as_view(), name="answer_edit"),
    path("answers/<int:answer_id>/delete/", views.ExpertAnswerDeleteView.as_view(), name="answer_delete"),

    path("tests/<int:test_id>/profiles/create/", views.ExpertProfileTypeCreateView.as_view(), name="profile_add"),
    path("profiles/<int:pk>/edit/", views.ExpertProfileTypeUpdateView.as_view(), name="profile_edit"),
    path("profiles/<int:profile_id>/delete/", views.ExpertProfileTypeDeleteView.as_view(), name="profile_delete"),

    path("tests/<int:test_id>/combinations/create/", views.ExpertProfileCombinationCreateView.as_view(), name="combination_add"),
    path("combinations/<int:pk>/edit/", views.ExpertProfileCombinationUpdateView.as_view(), name="combination_edit"),
    path("combinations/<int:pk>/delete/", views.ExpertProfileCombinationDeleteView.as_view(), name="combination_delete"),

    path("combinations/<int:combination_id>/criteria/add/", views.ExpertProfileCriterionCreateView.as_view(), name="criterion_add"),
    path("criteria/<int:criterion_id>/edit/", views.ExpertProfileCriterionUpdateView.as_view(), name="criterion_edit"),
    path("criteria/<int:criterion_id>/delete/", views.ExpertProfileCriterionDeleteView.as_view(), name="criterion_delete"),

    path('testdata/<int:pk>/', views.ExpertTestDataDetailView.as_view(), name="test_data_detail"),

]
