from django.urls import path
import jeiko.administration_pages.views

app_name = 'jeiko_administration_pages'

urlpatterns = [

    # — Pages CRUD & éditeur —
    path(
        '',
        jeiko.administration_pages.views.Main.as_view(),
        name='main'
    ),
    path(
        'add/',
        jeiko.administration_pages.views.PageAdd.as_view(),
        name='page_add'
    ),
    path(
        '<int:page_id>/',
        jeiko.administration_pages.views.SeePage.as_view(),
        name='page_view'
    ),
    path(
        '<int:page_id>/update/',
        jeiko.administration_pages.views.PageUpdate.as_view(),
        name='page_update'
    ),
    path(
        '<int:page_id>/duplicate/',
        jeiko.administration_pages.views.DuplicatePageView.as_view(),
        name='page_duplicate'
    ),
    path(
        '<int:page_id>/editor/',
        jeiko.administration_pages.views.PageEditor.as_view(),
        name='page_editor'
    ),
    path(
        '<int:page_id>/delete/',
        jeiko.administration_pages.views.PageDelete.as_view(),
        name='page_delete'
    ),

    # — Sections —
    path(
        '<int:page_id>/sections/add/',
        jeiko.administration_pages.views.SectionCreate.as_view(),
        name='section_add'
    ),
    path(
        '<int:page_id>/sections/<int:section_id>/update/',
        jeiko.administration_pages.views.SectionUpdate.as_view(),
        name='section_update'
    ),
    path(
        '<int:page_id>/sections/<int:section_id>/delete/',
        jeiko.administration_pages.views.SectionDelete.as_view(),
        name='section_delete'
    ),
    path(
        '<int:page_id>/sections/<int:section_id>/move_up/',
        jeiko.administration_pages.views.SectionMoveUp.as_view(),
        name='section_move_up'
    ),
    path(
        '<int:page_id>/sections/<int:section_id>/move_down/',
        jeiko.administration_pages.views.SectionMoveDown.as_view(),
        name='section_move_down'
    ),

    # — Lignes —
    path(
        '<int:page_id>/sections/<int:section_id>/lines/add/',
        jeiko.administration_pages.views.LineCreate.as_view(),
        name='line_add'
    ),
    path(
        '<int:page_id>/sections/<int:section_id>/lines/<int:line_id>/update/',
        jeiko.administration_pages.views.LineUpdate.as_view(),
        name='line_update'
    ),
    path(
        '<int:page_id>/sections/<int:section_id>/lines/<int:line_id>/delete/',
        jeiko.administration_pages.views.LineDelete.as_view(),
        name='line_delete'
    ),
    path(
        '<int:page_id>/sections/<int:section_id>/lines/<int:line_id>/move_up/',
        jeiko.administration_pages.views.LineMoveUp.as_view(),
        name='line_move_up'
    ),
    path(
        '<int:page_id>/sections/<int:section_id>/lines/<int:line_id>/move_down/',
        jeiko.administration_pages.views.LineMoveDown.as_view(),
        name='line_move_down'
    ),
    # — Contenus (Blocs) —
    path(
        '<int:page_id>/sections/<int:section_id>/lines/<int:line_id>/blocs/<int:bloc_id>/content/add/',
        jeiko.administration_pages.views.ContentTypeChoice.as_view(),
        name='content_add'
    ),
    path(
        '<int:page_id>/sections/<int:section_id>/lines/<int:line_id>/blocs/<int:bloc_id>/content/edit/',
        jeiko.administration_pages.views.EditContent.as_view(),
        name='content_edit'
    ),
    path(
        '<int:page_id>/sections/<int:section_id>/lines/<int:line_id>/blocs/<int:bloc_id>/content/reset/',
        jeiko.administration_pages.views.ResetContent.as_view(),
        name='content_reset'
    ),
    path(
        'editing-menu/',
        jeiko.administration_pages.views.editing_menu,
        name='editing_menu'
    ),
    # — Catégories —
    path(
        'categories/',
        jeiko.administration_pages.views.Categories.as_view(),
        name='categories'
    ),
    path(
        'categories/add/',
        jeiko.administration_pages.views.CategoryAdd.as_view(),
        name='main_category_add'
    ),
    path(
        'categories/<int:main_category_id>/update/',
        jeiko.administration_pages.views.CategoryUpdate.as_view(),
        name='main_category_update'
    ),
    path(
        'categories/<int:main_category_id>/sub/add/',
        jeiko.administration_pages.views.CategoryAdd.as_view(),
        name='sub_category_add'
    ),
    path(
        'categories/<int:main_category_id>/sub/<int:sub_category_id>/update/',
        jeiko.administration_pages.views.CategoryUpdate.as_view(),
        name='sub_category_update'
    ),

]
