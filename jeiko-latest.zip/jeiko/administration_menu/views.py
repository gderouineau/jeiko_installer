from django.contrib.auth.decorators import permission_required
from django.contrib.auth.mixins import PermissionRequiredMixin
from django.core.cache import cache
from django.http import Http404
from django.shortcuts import render, redirect, get_object_or_404

from django.views import View
from django.views.generic.base import TemplateView

from django.utils.decorators import method_decorator
from django.core.cache import cache
from django.views.decorators.cache import never_cache

from jeiko.administration_menu.forms import MenuItemForm
from jeiko.administration_menu.models import MenuItem


decorators = [never_cache]


class Main(View):

    template_name = 'administration_menu/main.html'

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):

        menu_items_up = MenuItem.objects.filter(
            is_sub_menu=False,
            place="U",
        )
        menu_items_down = MenuItem.objects.filter(
            is_sub_menu=False,
            place="D",
        )

        context = {
            'menu_items_up': menu_items_up,
            'menu_items_down': menu_items_down,
        }

        return render(request, self.template_name, context)

class All(View):

    template_name = 'administration_menu/view.html'

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):

        place = kwargs['place']

        menu_items = MenuItem.objects.filter(
            place=place,
            is_sub_menu=False,

        )

        context = {
            'place': place,
            'menu_items': menu_items,
        }

        return render(request, self.template_name, context)

class Add(View):

    template_name = 'administration_menu/add_or_update.html'
    menu_item_form = MenuItemForm

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):

        place = kwargs['place']
        menu_item_form = self.menu_item_form(prefix='menu_item_')


        context = {
            'place': place,
            'update': False,
            'submit_text': "Créer",
            'menu_item_form': menu_item_form,

        }
        return render(request, self.template_name, context)

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):

        place = kwargs['place']
        menu_item_form = self.menu_item_form(
            request.POST,
            prefix='menu_item_'
        )

        if menu_item_form.is_valid():
            menu_item = menu_item_form.save(commit=False)

            previous_menu_item = MenuItem.objects.filter(
            ).order_by(
                'position',
            ).last()
            if previous_menu_item:
                menu_item.position = previous_menu_item.position + 1

            menu_item.place = place

            menu_item.save()

            cache.clear()
            return redirect('jeiko_administration_menu:view', place)
        else:
            pass
        context = {
            'place': place,
            'update': False,
            'submit_text': "Créer",
            'menu_item_form': menu_item_form,

        }
        return render(request, self.template_name, context)

class Update(View):

    template_name = 'administration_menu/add_or_update.html'
    menu_item_form = MenuItemForm

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):

        place = kwargs['place']

        menu_item_id = kwargs['id']
        menu_item = get_object_or_404(MenuItem, id=menu_item_id)
        menu_item_form = self.menu_item_form(
            instance=menu_item,
            prefix='menu_item_'
        )

        context = {
            'place': place,
            'update': True,
            'submit_text': "Modifier",
            'menu_item_form': menu_item_form,
            'menu_item': menu_item,

        }
        return render(request, self.template_name, context)

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):

        place = kwargs['place']

        menu_item_id = kwargs['id']
        menu_item = get_object_or_404(MenuItem, id=menu_item_id)
        menu_item_form = self.menu_item_form(
            request.POST,
            instance=menu_item,
            prefix='menu_item_',
        )

        if menu_item_form.is_valid():

            menu_item_form.save()

            cache.clear()
            return redirect('jeiko_administration_menu:view', place)

        context = {
            'place': place,
            'update': True,
            'submit_text': "Modifier",
            'menu_item_form': menu_item_form,
            'menu_item': menu_item,

        }
        return render(request, self.template_name, context)

class AddSubMenu(View):
    template_name = 'administration_menu/add_or_update_submenu.html'
    menu_item_form = MenuItemForm

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        parent_id = kwargs['parent_id']
        menu_item_form = self.menu_item_form(prefix='menu_item_')

        context = {
            'update': False,
            'submit_text': "Créer",
            'menu_item_form': menu_item_form,
            'parent_id': parent_id,
        }
        return render(request, self.template_name, context)

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):
        parent_id = kwargs['parent_id']
        parent = get_object_or_404(MenuItem, id=parent_id)

        menu_item_form = self.menu_item_form(request.POST, prefix='menu_item_')

        if menu_item_form.is_valid():
            menu_item = menu_item_form.save(commit=False)
            menu_item.is_sub_menu = True
            menu_item.main_menu = parent
            menu_item.place = parent.place
            previous = MenuItem.objects.filter(
                is_sub_menu=True,
                main_menu=parent
            ).order_by('position').last()

            if previous:
                menu_item.position = previous.position + 1

            menu_item.save()
            cache.clear()
            return redirect('jeiko_administration_menu:view', parent.place)

        context = {
            'update': False,
            'submit_text': "Créer",
            'menu_item_form': menu_item_form,
            'parent_id': parent_id,
        }
        return render(request, self.template_name, context)


class UpdateSubMenu(View):
    template_name = 'administration_menu/add_or_update_submenu.html'
    menu_item_form = MenuItemForm

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        submenu_id = kwargs['id']
        submenu = get_object_or_404(MenuItem, id=submenu_id)

        menu_item_form = self.menu_item_form(
            instance=submenu,
            prefix='menu_item_'
        )

        context = {
            'update': True,
            'submit_text': "Modifier",
            'menu_item_form': menu_item_form,
            'submenu': submenu,
        }
        return render(request, self.template_name, context)

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):
        submenu_id = kwargs['id']
        submenu = get_object_or_404(MenuItem, id=submenu_id)

        menu_item_form = self.menu_item_form(
            request.POST,
            instance=submenu,
            prefix='menu_item_'
        )

        if menu_item_form.is_valid():
            menu_item_form.save()
            cache.clear()
            return redirect('jeiko_administration_menu:view', submenu.place)

        context = {
            'update': True,
            'submit_text': "Modifier",
            'menu_item_form': menu_item_form,
            'submenu': submenu,
        }
        return render(request, self.template_name, context)


class DeleteSubMenu(View):
    template_name = 'administration_menu/confirm_delete_submenu.html'

    @method_decorator(never_cache)
    def get(self, request, *args, **kwargs):
        submenu_id = kwargs['id']
        submenu = get_object_or_404(MenuItem, id=submenu_id)
        return render(request, self.template_name, {'submenu': submenu})

    @method_decorator(never_cache)
    def post(self, request, *args, **kwargs):
        submenu_id = kwargs['id']
        submenu = get_object_or_404(MenuItem, id=submenu_id)
        place = submenu.place
        submenu.delete()
        cache.clear()
        return redirect('jeiko_administration_menu:view', place)
