from django import forms
from django.core.validators import EmailValidator
from django.db.models import Q


from jeiko.administration_pages.models import Page
from jeiko.administration_menu.models import MenuItem

class MenuItemForm(forms.ModelForm):

    class Meta:
        model = MenuItem
        fields = [
            'title',
            'active',
            'page',
        ]

