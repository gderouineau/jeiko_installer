document.addEventListener("DOMContentLoaded", function () {
  const menu = document.querySelector(".main-menu");
  const toggle = document.querySelector(".menu-toggle");

  if (toggle) {
    toggle.addEventListener("click", () => {
      menu.classList.toggle("active");
    });
  }
});
