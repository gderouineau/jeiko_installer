// en haut de quill_text_edit.js
console.log('[quill_text_edit] chargé');

// si tu tiens à garder un exécutable direct, enveloppe dans DOMContentLoaded
document.addEventListener('DOMContentLoaded', () => {
  console.log('[quill_text_edit] DOM prêt, on initialise Quill');

  const toolbarOptions = [
    [{ 'header': [1, 2, 3, 4, 5, 6, false]}],
    ['bold', 'italic', 'underline', 'strike'],
    ['link'],
    ['blockquote', 'code-block'],
    [{'list': 'ordered'}, {'list': 'bullet'},  { 'list': 'check' }],
    [{ 'script': 'sub'}, { 'script': 'super' }],
    [{'color': []}, {'background': []}],
    [{'align': []}],
    [{ 'size': ['small', false, 'large', 'huge'] }],
    ];
  console.log('[quill_text_edit] toolbarOptions =', toolbarOptions);

  // tu peux même mettre `debugger;` ici pour déclencher le breakpoint
  const quill = new Quill('#text-editor', {
    modules: { toolbar: toolbarOptions },
    theme: 'snow'
  });

  console.log('[quill_text_edit] Quill instance créée →', quill);
});