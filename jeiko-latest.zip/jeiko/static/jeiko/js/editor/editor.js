import {
    getCookie,
    fetchHtml,
    showModal,
    showToast,
    showConfirmModal,
    closeModal
} from './utils.js';

const csrftoken = getCookie('csrftoken');

export function initOverlayHandlers() {
  const toggleOverlay = (overlay, show) => {
    if (!overlay) return;
    overlay.classList.toggle('visible', show);
  };

  document.querySelectorAll('.section').forEach(section => {
    const overlaySection = section.querySelector('.overlay-section');
    const columns = section.querySelectorAll('.line .column');

    section.addEventListener('mouseenter', () => toggleOverlay(overlaySection, true));
    section.addEventListener('mouseleave', () => toggleOverlay(overlaySection, false));

    columns.forEach(col => {
      const overlayCol = col.querySelector('.overlay-column');
      col.addEventListener('mouseenter', () => {
        toggleOverlay(overlayCol, true);
        toggleOverlay(overlaySection, false);
      });
      col.addEventListener('mouseleave', () => {
        toggleOverlay(overlayCol, false);
        if (section.matches(':hover')) {
          toggleOverlay(overlaySection, true);
        }
      });
    });
  });
}

function refreshOverlays() {
    initOverlayHandlers();
}

/**
 * Synchronise tous les inputs cachés Quill avec leur éditeur Quill associé dans le form.
 */
function syncAllQuillInputs(form) {
    // Pour chaque input caché "-text"
    form.querySelectorAll('input[type="hidden"][name$="-text"]').forEach(input => {
        // Cherche le .ql-editor du même parent ou dans le form (cas modal)
        let editor = null;
        // Cas #text-editor direct parent
        if (input.previousElementSibling && input.previousElementSibling.classList.contains('ql-container')) {
            editor = input.previousElementSibling.querySelector('.ql-editor');
        }
        // Sinon cherche dans le form (fallback)
        if (!editor) editor = form.querySelector('.ql-editor');
        if (editor) input.value = editor.innerHTML;
    });
}

/**
 * Attache un handler AJAX à un form.
 * Synchronise les champs Quill avant POST.
 */
function attachAjaxFormHandler(formId, updateDOMCallback, successMsg = "Opération réussie") {
    const form = document.getElementById(formId);

    if (!form || form._handlerAttached) {
        return;
    }
    form._handlerAttached = true;
    form.addEventListener('submit', async e => {
        e.preventDefault();

        syncAllQuillInputs(form);

        const formData = new FormData(form);
        const url      = form.action || form.dataset.url;

        const res = await fetch(url, {
            method: 'POST',
            headers: {
                'X-CSRFToken': csrftoken,
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: formData,
        });

        let data, isJson = false;
        try {
            data = await res.clone().json();
            isJson = true;
        } catch {
            data = await res.text();
        }

        if (res.ok && isJson && (data.status === 'success' || data.status === 'ok')) {
            closeModal();
            updateDOMCallback(data);
            showToast(successMsg);
            refreshOverlays();
        }
        else if (!isJson) {
            const container = document.querySelector('.modal-body') || document.querySelector('.modal-content');
            if (container) container.innerHTML = data;
            setTimeout(() => attachAjaxFormHandler(formId, updateDOMCallback, successMsg), 0);
        }
        else {
            showToast(data.message || 'Erreur serveur');
        }
    });
}

export function initQuillInModal(body, blocId) {
    // Initialisation pour chaque éditeur texte (si jamais plusieurs modaux)
    body.querySelectorAll('#text-editor').forEach(editorEl => {
        if (!window.Quill) return;

        const toolbarOptions = [
          [{ header: [1,2,3,4,5,6,false] }],
          ['bold','italic','underline','strike'],
          ['link','blockquote','code-block'],
          [{ list: 'ordered' }, { list: 'bullet' }, { list: 'check' }],
          [{ script: 'sub' }, { script: 'super' }],
          [{ color: [] }, { background: [] }],
          [{ align: [] }],
          [{ size: ['small', false, 'large', 'huge'] }]
        ];
        const quill = new Quill(editorEl, {
          theme: 'snow',
          modules: { toolbar: toolbarOptions }
        });

        // Initialise depuis l'input caché dans le même parent
        const input = editorEl.parentNode.querySelector('input[type="hidden"][name$="-text"]')
                   || body.querySelector('input[type="hidden"][name$="-text"]');
        if (input) {
          quill.root.innerHTML = input.value;
        }
    });

    // Handler AJAX sur le form (un seul par modal)
    const form = body.querySelector('#content-edit-form');
    if (form) {
      attachAjaxFormHandler('content-edit-form', editData => {
        if (editData.html) {
          const frag = editData.html;
          const old  = document.getElementById(`bloc-${blocId}`);
          if (old) old.outerHTML = frag;
          closeModal();
          refreshOverlays();
        }
      });
    }
}

// ===================== CRUD Sections ======================

export async function createSection(pageId) {
    const url  = `/jeiko/administration/pages/${pageId}/sections/add/`;
    const html = await fetchHtml(url);
    showModal(html, 'Créer une section');

    setTimeout(() => {
        attachAjaxFormHandler('section-form', data => {
            const frag    = data.html || data.section_html || data.content_html || '';
            const content = document.getElementById('content');
            if (!frag) return;
            if (content) {
                const noSec = content.querySelector('h4');
                if (noSec && noSec.textContent.includes("Aucune section")) noSec.remove();
                const addBtn = content.querySelector('.section-add');
                if (addBtn) addBtn.insertAdjacentHTML('beforebegin', frag);
                else       content.insertAdjacentHTML('beforeend', frag);
            } else {
                document.body.insertAdjacentHTML('beforeend', frag);
            }
            refreshOverlays();
        });
    }, 0);
}

export async function editSection(pageId, sectionId) {
    const url  = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/update/`;
    const html = await fetchHtml(url);
    showModal(html, 'Modifier la section');

    setTimeout(() => {
        attachAjaxFormHandler('section-form', data => {
            const frag = data.html || data.section_html || data.content_html || '';
            const old  = document.getElementById(`section-${sectionId}`);
            if (frag && old) old.outerHTML = frag;
            refreshOverlays();
        });
    }, 0);
}

export function removeSection(pageId, sectionId) {
    showConfirmModal("Es-tu sûr ?", async () => {
        const url = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/delete/`;
        const res = await fetch(url, {
            method: 'POST',
            headers: {
                'X-CSRFToken': csrftoken,
                'X-Requested-With': 'XMLHttpRequest'
            },
        });
        if (!res.ok) { showToast("Erreur lors de la suppression"); return; }
        const data = await res.json();
        if (data.status === 'success') {
            const el = document.getElementById(`section-${sectionId}`);
            if (el) el.remove();
            showToast("Section supprimée");
            const content = document.getElementById('content');
            if (content && !content.querySelector('.section')) {
                const msg = document.createElement('h4');
                msg.textContent = "Aucune section créée pour l'instant";
                content.querySelector('.section-add')?.insertAdjacentElement('beforebegin', msg);
            }
            refreshOverlays();
        } else {
            showToast(data.message || "Erreur lors de la suppression");
        }
    });
}

export async function moveSectionDown(pageId, sectionId) {
  const url = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/move_down/`;
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'X-CSRFToken': csrftoken,
      'X-Requested-With': 'XMLHttpRequest'
    },
  });
  if (!res.ok) { showToast('Erreur serveur'); return; }
  const data = await res.json();
  if (data.status === 'success') {
    const container = document.getElementById('content');
    const secs = Array.from(container.querySelectorAll('.section'));
    const idx = secs.findIndex(el => el.id === `section-${sectionId}`);
    if (idx < secs.length - 1) {
      container.insertBefore(secs[idx+1], secs[idx]);
      showToast('Section déplacée vers le bas');
      refreshOverlays();
    }
  } else {
    showToast(data.message || 'Erreur');
  }
}

// ===================== CRUD Lines ======================

export async function createLine(pageId, sectionId) {
    const url  = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/lines/add/`;
    const html = await fetchHtml(url);
    showModal(html, 'Créer une ligne');

    setTimeout(() => {
        attachAjaxFormHandler('line-form', data => {
            const frag      = data.line_html || data.html || '';
            const sectionEl = document.getElementById(`section-${sectionId}`);
            if (!frag || !sectionEl) return;

            const noLine = sectionEl.querySelector('h4');
            if (noLine && noLine.textContent.includes("Aucune ligne")) noLine.remove();

            const lines = Array.from(sectionEl.querySelectorAll('.line'));
            if (lines.length) {
                lines[lines.length - 1].insertAdjacentHTML('afterend', frag);
            } else {
                sectionEl.querySelector('.overlay-section')?.insertAdjacentHTML('beforebegin', frag);
            }
            refreshOverlays();
        });
    }, 0);
}

export async function editLine(pageId, sectionId, lineId) {
    const url  = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/lines/${lineId}/update/`;
    const html = await fetchHtml(url);
    showModal(html, 'Modifier la ligne');

    setTimeout(() => {
        attachAjaxFormHandler('line-form', data => {
            const frag = data.line_html || data.html || '';
            const old  = document.getElementById(`line-${lineId}`);
            if (frag && old) old.outerHTML = frag;
            refreshOverlays();
        });
    }, 0);
}

export function removeLine(pageId, sectionId, lineId) {
    showConfirmModal("Es-tu sûr de vouloir supprimer cette ligne ?", async () => {
        const url = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/lines/${lineId}/delete/`;
        const res = await fetch(url, {
            method: 'POST',
            headers: {
                'X-CSRFToken': csrftoken,
                'X-Requested-With': 'XMLHttpRequest'
            },
        });
        if (!res.ok) { showToast("Erreur lors de la suppression"); return; }
        const data = await res.json();
        if (data.status === 'success') {
            const el = document.getElementById(`line-${lineId}`);
            if (el) el.remove();
            showToast("Ligne supprimée");
            const sectionEl = document.getElementById(`section-${sectionId}`);
            if (sectionEl && !sectionEl.querySelector('.line')) {
                const msg = document.createElement('h4');
                msg.textContent = "Aucune ligne créée pour l'instant";
                sectionEl.querySelector('.overlay-section')?.insertAdjacentElement('beforebegin', msg);
            }
            refreshOverlays();
        } else {
            showToast(data.message || "Erreur lors de la suppression");
        }
    });
}

export async function moveSectionUp(pageId, sectionId) {
  const url = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/move_up/`;
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'X-CSRFToken': csrftoken,
      'X-Requested-With': 'XMLHttpRequest'
    },
  });
  if (!res.ok) { showToast('Erreur serveur'); return; }
  const data = await res.json();
  if (data.status === 'success') {
    const container = document.getElementById('content');
    const secs = Array.from(container.querySelectorAll('.section'));
    const idx = secs.findIndex(el => el.id === `section-${sectionId}`);
    if (idx > 0) {
      container.insertBefore(secs[idx], secs[idx-1]);
      showToast('Section déplacée vers le haut');
      refreshOverlays();
    }
  } else {
    showToast(data.message || 'Erreur');
  }
}

export async function moveLineUp(pageId, sectionId, lineId) {
  const url = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/lines/${lineId}/move_up/`;
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'X-CSRFToken': csrftoken,
      'X-Requested-With': 'XMLHttpRequest'
    },
  });
  if (!res.ok) {
    showToast('Erreur serveur');
    return;
  }
  const data = await res.json();
  if (data.status === 'success') {
    const sectionEl = document.getElementById(`section-${sectionId}`);
    if (!sectionEl) return;
    const lines = Array.from(sectionEl.querySelectorAll('.line'));
    const idx = lines.findIndex(el => el.id === `line-${lineId}`);
    if (idx > 0) {
      sectionEl.insertBefore(lines[idx], lines[idx - 1]);
      showToast('Ligne déplacée vers le haut');
      refreshOverlays();
    }
  } else {
    showToast(data.message || 'Erreur');
  }
}

export async function moveLineDown(pageId, sectionId, lineId) {
  const url = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/lines/${lineId}/move_down/`;
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'X-CSRFToken': csrftoken,
      'X-Requested-With': 'XMLHttpRequest'
    },
  });
  if (!res.ok) {
    showToast('Erreur serveur');
    return;
  }
  const data = await res.json();
  if (data.status === 'success') {
    const sectionEl = document.getElementById(`section-${sectionId}`);
    if (!sectionEl) return;
    const lines = Array.from(sectionEl.querySelectorAll('.line'));
    const idx = lines.findIndex(el => el.id === `line-${lineId}`);
    if (idx < lines.length - 1) {
      sectionEl.insertBefore(lines[idx + 1], lines[idx]);
      showToast('Ligne déplacée vers le bas');
      refreshOverlays();
    }
  } else {
    showToast(data.message || 'Erreur');
  }
}

// ===================== CRUD Content (Blocs) ======================

export async function chooseContentType(pageId, sectionId, lineId, blocId) {
  const url = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/lines/${lineId}/blocs/${blocId}/content/add/`;
  const res = await fetch(url, {
    method: 'GET',
    headers: {
      'X-CSRFToken': csrftoken,
      'X-Requested-With': 'XMLHttpRequest'
    }
  });
  if (!res.ok) {
    showToast('Erreur serveur');
    return;
  }
  const data = await res.json();

  if (data.status === 'choose_type') {
    showModal(data.html, 'Choisir le type de contenu');
    setTimeout(() => {
      attachAjaxFormHandler('choose-content-form', chooseData => {
        if (chooseData.status === 'success') {
          editContent(pageId, sectionId, lineId, blocId);
        } else {
          showToast(chooseData.message || 'Erreur inattendue');
        }
      });
    }, 0);

  } else if (data.status === 'success') {
    editContent(pageId, sectionId, lineId, blocId);

  } else {
    showToast(data.message || 'Erreur inattendue');
  }
}

export function showEditingParameters(id) {
  document.querySelectorAll('.editing-parameters').forEach(section => {
    const isTarget = section.id === id;
    section.style.display = isTarget ? '' : 'none';
  });
}

async function fetchEditingMenu() {
  try {
    const response = await fetch(
      '/jeiko/administration/pages/editing-menu/',
      { headers: { 'X-Requested-With': 'XMLHttpRequest' } }
    );
    if (response.ok) {
      return await response.text();
    }
  } catch (e) {
    console.warn('Impossible de charger le menu d’édition :', e);
  }
  return '';
}

export async function editContent(pageId, sectionId, lineId, blocId) {
    const url = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/lines/${lineId}/blocs/${blocId}/content/edit/`;

    const res = await fetch(url, {
        method: 'GET',
        headers: {
            'X-CSRFToken': csrftoken,
            'X-Requested-With': 'XMLHttpRequest'
        }
    });
    if (!res.ok) {
        showToast('Erreur serveur');
        return;
    }
    const data = await res.json();

    if (data.status === 'success' && data.html) {
        const menuHtml = await fetchEditingMenu();
        showModal(data.html, menuHtml || 'Édition du contenu');
        const body = document.querySelector('.modal-body');
        initQuillInModal(body, blocId);

        showEditingParameters('content-parameters');

        setTimeout(() => {
            attachAjaxFormHandler('content-edit-form', editData => {
                if (editData.html) {
                    const frag = editData.html;
                    const old  = document.getElementById(`bloc-${blocId}`);
                    if (old) old.outerHTML = frag;
                    closeModal();
                    refreshOverlays();
                }
            });
        }, 0);
    } else {
        showToast(data.message || 'Erreur inattendue');
    }
}

export function resetContent(pageId, sectionId, lineId, blocId) {
    showConfirmModal("Remettre le contenu à zéro ?", async () => {
        const url = `/jeiko/administration/pages/${pageId}/sections/${sectionId}/lines/${lineId}/blocs/${blocId}/content/reset/`;
        const res = await fetch(url, {
            method: 'POST',
            headers: {
                'X-CSRFToken': csrftoken,
                'X-Requested-With': 'XMLHttpRequest'
            },
        });
        if (!res.ok) { showToast("Erreur"); return; }
        const data = await res.json();
        if (data.status === 'reset') {
            showToast("Contenu réinitialisé");
            chooseContentType(pageId, sectionId, lineId, blocId);
            refreshOverlays();
        } else {
            showToast(data.message || "Erreur");
        }
    });
}


// ===================== CRUD Formulaire  ======================

function showAddFieldForm(formulaireId) {
  // Affiche un petit formulaire inline dans le div#add-edit-field-modal
  const modal = document.getElementById('add-edit-field-modal');
  modal.innerHTML = `
    <div style="border:1px solid #ccc; padding:1em; margin-top:1em;">
      <h5>Ajouter un champ</h5>
      <form id="add-field-form">
        <label>Label <input type="text" name="label" required></label><br>
        <label>Nom technique <input type="text" name="name" required></label><br>
        <label>Type
          <select name="type">
            <option value="text">Texte</option>
            <option value="email">Email</option>
            <option value="phone">Téléphone</option>
            <option value="textarea">Zone de texte</option>
            <option value="select">Liste déroulante</option>
            <option value="checkbox">Case à cocher</option>
            <option value="date">Date</option>
            <option value="number">Numérique</option>
          </select>
        </label><br>
        <label>Obligatoire <input type="checkbox" name="required"></label><br>
        <label>Options (JSON ou valeurs séparées par virgule pour select/checkbox)<br>
          <input type="text" name="options">
        </label><br>
        <button type="submit">Ajouter</button>
        <button type="button" onclick="closeFieldForm()">Annuler</button>
      </form>
    </div>
  `;
  modal.style.display = "";
  requestAnimationFrame(() => {
      const form = document.getElementById('add-field-form');
      console.log('form:', form);
      if (!form) {
        alert("ERREUR: Le formulaire #add-field-form n'existe pas dans le DOM !");
        return;
      }
      form.onsubmit = async function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        const data = {};
        formData.forEach((v,k) => data[k]=v);
        data.required = !!formData.get('required');
        // Simple parse des options
        if(data.options && (data.type === "select" || data.type === "checkbox")) {
          if(data.options.trim().startsWith('[')) {
            try { data.options = JSON.parse(data.options); } catch {}
          } else {
            data.options = data.options.split(',').map(s=>s.trim()).filter(Boolean);
          }
        }
        const res = await fetch(`/api/pages/formulaires/${formulaireId}/fields/`, {
          method: 'POST',
          headers: {'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest', 'X-CSRFToken': getCookie('csrftoken'), },
          body: JSON.stringify(data)
        });
        if(res.ok) {
          reloadFieldsList(formulaireId);
          closeFieldForm();
          reloadFieldsList(formulaireId);
        }
      }
  });
}


function closeFieldForm() {
  const modal = document.getElementById('add-edit-field-modal');
  modal.innerHTML = "";
  modal.style.display = "none";
}


async function deleteField(fieldId) {
  if(!confirm("Supprimer ce champ ?")) return;
  // On suppose que tu as accès à formulaireId en variable JS ou via data-
  const formulaireId = document.querySelector('[data-formulaire-id]').dataset.formulaireId;
  const res = await fetch(`/jeiko/api/pages/formulaires/${formulaireId}/fields/${fieldId}/`, {
    method: 'DELETE',
    headers: {'X-Requested-With': 'XMLHttpRequest'}
  });
  if(res.ok) reloadFieldsList(formulaireId);
}


async function moveFieldUp(fieldId) {
  await moveField(fieldId, -1);
}


async function moveFieldDown(fieldId) {
  await moveField(fieldId, 1);
}


async function moveField(fieldId, direction) {
  const fieldsList = Array.from(document.querySelectorAll('#fields-list li'));
  const idx = fieldsList.findIndex(li => li.dataset.fieldId == fieldId);
  if(idx === -1) return;
  const newIdx = idx + direction;
  if(newIdx < 0 || newIdx >= fieldsList.length) return;

  // Change local order
  [fieldsList[idx], fieldsList[newIdx]] = [fieldsList[newIdx], fieldsList[idx]];

  // Patch order sur l’API (envoie la nouvelle liste d’ordre)
  const formulaireId = document.querySelector('[data-formulaire-id]').dataset.formulaireId;
  const newOrder = fieldsList.map((li,i) => ({id: li.dataset.fieldId, order: i}));
  await fetch(`/jeiko/api/pages/formulaires/${formulaireId}/fields/`, {
    method: 'PATCH',
    headers: {'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest'},
    body: JSON.stringify({fields: newOrder})
  });
  reloadFieldsList(formulaireId);
}


async function reloadFieldsList(formulaireId) {
  // Re-fetch le HTML via un endpoint dédié ou regénère le HTML via AJAX et remplace #fields-list
  const res = await fetch(`/jeiko/api/pages/formulaires/${formulaireId}/`, {
    headers: {'X-Requested-With': 'XMLHttpRequest'}
  });
  if(!res.ok) return;
  const data = await res.json();
  // Regénère la liste des champs
  const ul = document.getElementById('fields-list');
  ul.innerHTML = "";
  for(const field of data.fields) {
    ul.insertAdjacentHTML('beforeend', `
      <li data-field-id="${field.id}">
        <span>
          <strong>${field.label}</strong> <em>(${field.type})</em>${field.required ? ' <span style="color:red;">*</span>' : ''}
        </span>
        <button type="button" onclick="editField(${field.id})">éditer</button>
        <button type="button" onclick="deleteField(${field.id})">supprimer</button>
        <button type="button" onclick="moveFieldUp(${field.id})">&#x25B2;</button>
        <button type="button" onclick="moveFieldDown(${field.id})">&#x25BC;</button>
      </li>
    `);
  }
}


// ===================== Exports globaux ======================

window.createSection = createSection;
window.editSection   = editSection;
window.removeSection = removeSection;
window.moveSectionUp = moveSectionUp;
window.moveSectionDown = moveSectionDown;

window.createLine = createLine;
window.editLine   = editLine;
window.removeLine = removeLine;
window.moveLineUp   = moveLineUp;
window.moveLineDown = moveLineDown;

window.chooseContentType = chooseContentType;
window.editContent = editContent;
window.resetContent = resetContent;
window.showEditingParameters = showEditingParameters;

window.showAddFieldForm = showAddFieldForm;
window.closeFieldForm = closeFieldForm;
window.deleteField = deleteField;
window.moveFieldUp = moveFieldUp;
window.moveFieldDown = moveFieldDown;
window.reloadFieldsList =reloadFieldsList;


document.addEventListener('DOMContentLoaded', () => {
  initOverlayHandlers();
});
