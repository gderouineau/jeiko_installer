from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator

import os

from PIL import Image


from django.db import models

class Font(models.Model):
    size = models.CharField(
        default="20px",
        max_length=20,
        verbose_name="Taille de la police",
        help_text="Ex: 18px, 1.2em, etc."
    )
    family = models.CharField(
        default="Georgia",
        max_length=100,
        verbose_name="Famille de police",
        help_text="Ex: Roboto, Playfair Display, Arial, etc."
    )
    fallback = models.CharField(
        default="serif",
        max_length=100,
        verbose_name="Police de secours",
        help_text="Ex: serif, sans-serif, monospace, Arial… (sera utilisée si la police principale n’est pas chargée)"
    )
    stretch = models.CharField(
        default="100%",
        max_length=100,
        verbose_name="Étirement",
        help_text="Ex: 100%, condensed, expanded (optionnel)"
    )
    color = models.CharField(
        default="rgba(0,0,0,1)",
        max_length=30,
        verbose_name="Couleur de la police",
        help_text="Ex: #333, rgba(0,0,0,1)"
    )
    POLICE_STYLE_CHOICES = [
        ("normal", "normal"),
        ("italic", "italic"),
        ("oblique", "oblique"),
    ]
    style = models.CharField(
        default="normal",
        max_length=10,
        choices=POLICE_STYLE_CHOICES,
        verbose_name="Style"
    )
    variant = models.CharField(
        default="normal",
        max_length=20,
        verbose_name="Variante",
        help_text="Ex: small-caps, normal"
    )
    weight = models.CharField(
        default="normal",
        max_length=50,
        verbose_name="Épaisseur de la police",
        help_text="Ex: normal, bold, 700"
    )
    line_height = models.CharField(
        default="normal",
        max_length=50,
        verbose_name="Hauteur de ligne",
        help_text="Ex: 1.2, normal, 32px"
    )
    google_fonts_url = models.URLField(
        blank=True,
        null=True,
        verbose_name="URL Google Fonts",
        help_text="Optionnel : colle ici l’URL Google Fonts si besoin (sinon sera générée automatiquement)."
    )

    def __str__(self):
        return f"{self.family} ({self.size})"

    class Meta:
        verbose_name = "Police"
        verbose_name_plural = "Polices"

class Fonts(models.Model):

    links = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="links"
    )

    links_hover = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="links_hover"
    )
    menu = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="menu"
    )

    menu_hover = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="menu_hover"
    )

    sub_menu = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="sub_menu"
    )

    sub_menu_hover = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="sub_menu_hover"
    )

    text = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="text"
    )

    h1 = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="h1"
    )

    h2 = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="h2"
    )

    h3 = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="h3"
    )

    h4 = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="h4"
    )

    h5 = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="h5"
    )

    h6 = models.OneToOneField(
        Font,
        on_delete=models.CASCADE,
        related_name="h6"
    )


class Logo(models.Model):
    full_size = models.ImageField(
        upload_to='media/images/logo',
        null=True,
        blank=True,
        verbose_name='Logo',
    )
    computer_size = models.ImageField(
        upload_to='images/logo',
        null=True,
        blank=True,
        verbose_name='Logo',
    )

    tablet_size = models.ImageField(
        upload_to='images/logo',
        null=True,
        blank=True,
        verbose_name='Logo',
    )

    mobile_size = models.ImageField(
        upload_to='images/logo',
        null=True,
        blank=True,
        verbose_name='Logo',
    )

    def resize_image(self):
        image = Image.open(self.full_size.path)

        image.thumbnail((150, 150))
        image.save((os.path.splitext(self.full_size.path)[0] + "-computer.webp"), 'webp')

        image.thumbnail((100, 100))
        image.save((os.path.splitext(self.full_size.path)[0] + "-tablet.webp"), 'webp')

        image.thumbnail((75, 75))
        image.save((os.path.splitext(self.full_size.path)[0] + "-mobile.webp"), 'webp')

    def save(self, *args, **kwargs):
        super(Logo, self).save(*args, **kwargs)
        if self.full_size:
            self.resize_image()
            self.computer_size = (os.path.splitext(self.full_size.url)[0] + "-computer.webp")
            self.tablet_size = (os.path.splitext(self.full_size.url)[0] + "-tablet.webp")
            self.mobile_size = (os.path.splitext(self.full_size.url)[0] + "-mobile.webp")
        super().save(*args, **kwargs)


class MailSettings(models.Model):
    # Utilisation d’un singleton, une seule config par site
    host = models.CharField(max_length=200, verbose_name="Serveur SMTP")
    port = models.PositiveIntegerField(
        default=587, validators=[MinValueValidator(1), MaxValueValidator(65535)],
        verbose_name="Port SMTP"
    )
    use_tls = models.BooleanField(default=True, verbose_name="Utiliser TLS")
    use_ssl = models.BooleanField(default=False, verbose_name="Utiliser SSL")
    host_user = models.CharField(max_length=200, blank=True, verbose_name="Nom d’utilisateur SMTP")
    host_password = models.CharField(max_length=200, blank=True, verbose_name="Mot de passe SMTP")
    default_from_email = models.CharField(max_length=200, blank=True, verbose_name="Adresse expéditeur par défaut")
    reply_to_email = models.CharField(max_length=200, blank=True, verbose_name="Adresse reply-to (optionnelle)")
    active = models.BooleanField(default=True, verbose_name="Actif")
    test_receiver = models.CharField(max_length=200, blank=True, verbose_name="Email de test (pour bouton 'Tester')")

    class Meta:
        verbose_name = "Configuration Email"
        verbose_name_plural = "Configuration Email"

    def __str__(self):
        return f"Mail SMTP ({self.host}:{self.port}) pour {self.site_name}"


class WebSite(models.Model):

    name = models.CharField(
        max_length=100,
        blank=True,
        null=True,
        default="Jeiko",
    )
    fonts_phone = models.OneToOneField(
        Fonts,
        on_delete=models.CASCADE,
        related_name='site_phone',
        null=True
    )

    fonts_tablet = models.OneToOneField(
        Fonts,
        on_delete=models.CASCADE,
        related_name='site_tablet',
        null=True
    )

    fonts_computer = models.OneToOneField(
        Fonts,
        on_delete=models.CASCADE,
        related_name='site_computer',
        null=True
    )

    logo = models.OneToOneField(
        Logo,
        on_delete=models.CASCADE,
        related_name='site',
        null=True,
    )

    mail_settings = models.OneToOneField(
        "MailSettings",
        on_delete=models.CASCADE,
        blank=True,
        null=True,
        related_name="website",
        verbose_name="Configuration Email"
    )

