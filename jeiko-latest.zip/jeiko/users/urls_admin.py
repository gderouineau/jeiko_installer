from django.urls import path
from .views_admin import (
    AdminUserListView, AdminUserDetailView, AdminUserUpdateView

)

app_name = 'jeiko_administration_users'
urlpatterns = [
    path('users/', AdminUserListView.as_view(), name='user_list'),
    path('user/<int:pk>/', AdminUserDetailView.as_view(), name='user_detail'),
    path('user/<int:pk>/edit/', AdminUserUpdateView.as_view(), name='user_edit'),
    # futures routes : user-detail, dashboard…
]
