from django import forms
from django.contrib.auth import get_user_model
from allauth.account.forms import SignupForm, LoginForm
from jeiko.users.models import Profile
User = get_user_model()

class ProfileForm(forms.ModelForm):
    """
    Formulaire pour que l’utilisateur modifie son profil.
    """
    class Meta:
        model = Profile
        fields = [
            'avatar',
            'bio',
            'phone_number',
            'date_of_birth',
            'location',
            'website',
        ]
        widgets = {
            'date_of_birth': forms.DateInput(attrs={'type': 'date'}),
        }


class CustomSignupForm(SignupForm):
    """
    Formulaire d’inscription Allauth enrichi pour demander le prénom et nom.
    """
    first_name = forms.CharField(
        max_length=30,
        label="Prénom",
        widget=forms.TextInput(attrs={'placeholder': 'Prénom'}),
    )
    last_name = forms.CharField(
        max_length=30,
        label="Nom",
        widget=forms.TextInput(attrs={'placeholder': 'Nom'}),
    )

    def save(self, request):
        # Crée l'utilisateur via Allauth
        user = super().save(request)
        # Puis on complète firstname / lastname et on crée le profile automatiquement via signal
        user.first_name = self.cleaned_data['first_name']
        user.last_name = self.cleaned_data['last_name']
        user.save()
        return user


class CustomLoginForm(LoginForm):
    login = forms.CharField(
        label="Identifiant",
        widget=forms.TextInput(attrs={
            'placeholder': "Email ou nom d'utilisateur",
            'class': 'form-control',
        }),
        help_text="Saisissez votre e-mail ou votre nom d’utilisateur"
    )
    password = forms.CharField(
        label="Mot de passe",
        widget=forms.PasswordInput(attrs={
            'placeholder': '••••••••',
            'class': 'form-control',
        })
    )