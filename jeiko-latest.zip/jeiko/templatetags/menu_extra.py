from django.template import Library, Node
from django.db.models import Prefetch

from jeiko.administration_menu.models import MenuItem

register = Library()

class AllMenus(Node):
    def render(self, context):
        # Sous-menus actifs, is_sub_menu=True, place="U"
        submenus_qs = MenuItem.objects.filter(
            active=True,
            is_sub_menu=True,
            place="U",
        ).order_by('position')

        # Menus principaux actifs, is_sub_menu=False, place="U"
        menus = MenuItem.objects.filter(
            active=True,
            is_sub_menu=False,
            place="U",
        ).prefetch_related(
            Prefetch('submenus', queryset=submenus_qs, to_attr='active_submenus')
        ).order_by('position')

        context['all_menus'] = menus
        return ''

@register.tag(name="get_all_menus")
def get_all_menus(parser, token):
    return AllMenus()
